<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\pengumuman\create.php

$page_title = 'Buat Pengumuman';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $judul = trim($_POST['judul'] ?? '');
    $isi = trim($_POST['isi'] ?? '');
    $tanggal = $_POST['tanggal'] ?? date('Y-m-d');
    $penulis_id = $_SESSION['user_id'] ?? null;

    // File upload
    $lampiran_name = null;
    if (isset($_FILES['lampiran']) && $_FILES['lampiran']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['lampiran']['tmp_name'];
        $file_name = $_FILES['lampiran']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed_exts = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];
        $mime_type = mime_content_type($file_tmp);
        $allowed_mimes = [
            'application/pdf', 'application/msword', 
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'image/jpeg', 'image/png'
        ];
        
        if (in_array($file_ext, $allowed_exts) && in_array($mime_type, $allowed_mimes)) {
            $upload_dir = dirname(dirname(__DIR__)) . '/assets/uploads/pengumuman/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $lampiran_name = 'announcement_' . time() . '.' . $file_ext;
            if (move_uploaded_file($file_tmp, $upload_dir . $lampiran_name)) {
                // Success
            } else {
                $error = 'Gagal menyimpan file lampiran.';
            }
        } else {
            $error = 'Format file lampiran salah. Hanya menerima PDF, Word, JPG, atau PNG.';
        }
    }

    if ($error === '') {
        if (empty($judul) || empty($isi) || empty($tanggal)) {
            $error = 'Field Judul, Isi Pengumuman, dan Tanggal wajib diisi!';
        } else {
            try {
                // Insert announcement
                $stmt = $pdo->prepare("INSERT INTO pengumuman (judul, isi, tanggal, penulis_id, lampiran) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$judul, $isi, $tanggal, $penulis_id, $lampiran_name]);
                
                write_audit_log("Membuat pengumuman sekolah baru: $judul.");

                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Pengumuman berhasil dipublikasikan!', 'success').then(() => {
                            window.location.href = 'index.php';
                        });
                    });
                </script>";
            } catch (Exception $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}
?>

<div class="glass-card" style="max-width: 700px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-plus me-2"></i> Buat Pengumuman Sekolah Baru</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="create.php" enctype="multipart/form-data">
        <?php csrf_input(); ?>

        <div class="mb-3">
            <label for="judul" class="form-label form-label-custom">Judul Pengumuman <span class="text-danger">*</span></label>
            <input type="text" name="judul" id="judul" class="form-control form-control-custom" placeholder="Tulis judul pengumuman yang jelas" required>
        </div>

        <div class="mb-3">
            <label for="isi" class="form-label form-label-custom">Isi Pengumuman <span class="text-danger">*</span></label>
            <textarea name="isi" id="isi" class="form-control form-control-custom" rows="6" placeholder="Tulis rincian pengumuman disini..." required></textarea>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-6">
                <label for="tanggal" class="form-label form-label-custom">Tanggal Publikasi <span class="text-danger">*</span></label>
                <input type="date" name="tanggal" id="tanggal" class="form-control form-control-custom" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            
            <div class="col-6">
                <label for="lampiran" class="form-label form-label-custom">Lampiran File (Opsional)</label>
                <input type="file" name="lampiran" id="lampiran" class="form-control form-control-custom" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png">
                <span class="text-secondary" style="font-size: 10px;">Format: PDF, Word, Gambar (Maksimal 3MB).</span>
            </div>
        </div>

        <div class="d-flex justify-content-end gap-2">
            <a href="index.php" class="btn btn-outline-custom">Batal</a>
            <button type="submit" class="btn btn-gold">Publikasikan <i class="fa-solid fa-paper-plane ms-1"></i></button>
        </div>
    </form>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
