<?php
// c:\xampp\htdocs\e-petraschool1\modules\tahun_ajaran\index.php

$page_title = 'Data Tahun Ajaran';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';
$success = '';

// Handle creation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $tahun_ajaran = trim($_POST['tahun_ajaran'] ?? '');
    $status = $_POST['status'] ?? 'Tidak Aktif';

    if (empty($tahun_ajaran)) {
        $error = 'Tahun ajaran wajib diisi!';
    } else {
        try {
            // Check if already exists
            $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM tahun_ajaran WHERE tahun_ajaran = ?");
            $check_stmt->execute([$tahun_ajaran]);
            if ($check_stmt->fetchColumn() > 0) {
                $error = "Tahun ajaran '$tahun_ajaran' sudah ada!";
            } else {
                $pdo->beginTransaction();

                if ($status === 'Aktif') {
                    // Set all others to inactive
                    $pdo->exec("UPDATE tahun_ajaran SET status = 'Tidak Aktif'");
                }

                // Insert
                $stmt = $pdo->prepare("INSERT INTO tahun_ajaran (tahun_ajaran, status) VALUES (?, ?)");
                $stmt->execute([$tahun_ajaran, $status]);
                
                $pdo->commit();

                write_audit_log("Menambahkan tahun ajaran baru: $tahun_ajaran (Status: $status).");
                
                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Tahun ajaran berhasil ditambahkan!', 'success').then(() => {
                            window.location.href = 'index.php';
                        });
                    });
                </script>";
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = 'Gagal menyimpan data: ' . $e->getMessage();
        }
    }
}

// Fetch all years
try {
    $stmt = $pdo->query("SELECT * FROM tahun_ajaran ORDER BY tahun_ajaran DESC");
    $years = $stmt->fetchAll();
} catch (Exception $e) {
    echo '<div class="alert alert-danger">Gagal memuat data: ' . $e->getMessage() . '</div>';
}
?>

<div class="row g-4">
    <!-- Left form -->
    <div class="col-lg-4 no-print">
        <div class="glass-card">
            <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-plus me-2"></i> Input Tahun Ajaran</h5>
            
            <?php if ($error !== ''): ?>
                <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
                    <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="index.php">
                <?php csrf_input(); ?>

                <div class="mb-3">
                    <label for="tahun_ajaran" class="form-label form-label-custom">Tahun Ajaran</label>
                    <input type="text" name="tahun_ajaran" id="tahun_ajaran" class="form-control form-control-custom" placeholder="Contoh: 2025/2026" required>
                </div>

                <div class="mb-4">
                    <label for="status" class="form-label form-label-custom">Status</label>
                    <select name="status" id="status" class="form-select form-control-custom bg-dark-select text-white">
                        <option value="Tidak Aktif">Tidak Aktif</option>
                        <option value="Aktif">Aktif</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-gold w-100">Simpan Tahun Ajaran <i class="fa-solid fa-check ms-1"></i></button>
            </form>
        </div>
    </div>

    <!-- Right list table -->
    <div class="col-lg-8">
        <div class="glass-card">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
                <div>
                    <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-calendar me-2"></i> Daftar Tahun Ajaran</h5>
                    <p class="text-secondary small mb-0">Kelola tahun ajaran akademik sekolah. Hanya satu tahun ajaran yang boleh aktif.</p>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table table-custom">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tahun Ajaran</th>
                            <th>Status</th>
                            <th class="no-print">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($years) > 0): ?>
                            <?php $no = 1; foreach ($years as $yr): ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td class="fw-bold text-white"><?php echo htmlspecialchars($yr['tahun_ajaran']); ?></td>
                                    <td>
                                        <span class="badge <?php echo $yr['status'] === 'Aktif' ? 'badge-success' : 'badge-danger'; ?>">
                                            <?php echo htmlspecialchars($yr['status']); ?>
                                        </span>
                                    </td>
                                    <td class="no-print">
                                        <div class="d-flex gap-2">
                                            <a href="edit.php?id=<?php echo $yr['id']; ?>" class="btn btn-xs btn-outline-warning" title="Edit"><i class="fa-solid fa-pen"></i> Edit</a>
                                            <button onclick="confirmDelete('delete.php?id=<?php echo $yr['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i> Hapus</button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center text-secondary py-4">Data tahun ajaran tidak ditemukan.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function confirmDelete(url) {
    Swal.fire({
        title: 'Apakah Anda yakin?',
        text: "Data yang dihapus tidak dapat dikembalikan!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = url;
        }
    });
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
