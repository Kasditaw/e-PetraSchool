<?php
// c:\xampp\htdocs\e-petraschool1\modules\ekskul\index.php

$page_title = 'Ekstrakurikuler';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$filter_ta     = isset($_GET['tahun_ajaran_id']) ? intval($_GET['tahun_ajaran_id']) : 0;
$filter_status = isset($_GET['status'])           ? trim($_GET['status'])            : 'Aktif';

try {
    $ta_list = $pdo->query("SELECT id, tahun_ajaran, status FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();
    if (!$filter_ta) { foreach ($ta_list as $t) { if ($t['status'] === 'Aktif') { $filter_ta = $t['id']; break; } } }

    $q = "SELECT e.*, g.nama_guru AS nama_pembina,
                 (SELECT COUNT(*) FROM ekskul_anggota ea WHERE ea.ekskul_id = e.id AND ea.tahun_ajaran_id = e.tahun_ajaran_id AND ea.status='Aktif') AS jumlah_anggota
          FROM ekskul e
          LEFT JOIN guru g ON e.pembina_id = g.id
          WHERE e.tahun_ajaran_id = ?";
    $params = [$filter_ta];
    if ($filter_status) { $q .= " AND e.status = ?"; $params[] = $filter_status; }
    $q .= " ORDER BY e.nama ASC";
    $stmt = $pdo->prepare($q);
    $stmt->execute($params);
    $ekskul_list = $stmt->fetchAll();

} catch (Exception $e) {
    $ekskul_list = [];
    $error_db = $e->getMessage();
}

$day_colors = ['Senin'=>'#3B82F6','Selasa'=>'#A855F7','Rabu'=>'#10B981','Kamis'=>'#F59E0B','Jumat'=>'#EF4444','Sabtu'=>'#14B8A6'];
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-star me-2"></i>Ekstrakurikuler</h5>
            <p class="text-secondary small mb-0">Kelola kegiatan ekstrakurikuler dan daftar anggota siswa.</p>
        </div>
        <?php if (has_role(['Super Admin','Admin'])): ?>
        <a href="create.php?tahun_ajaran_id=<?php echo $filter_ta; ?>" class="btn btn-gold">
            <i class="fa-solid fa-plus me-1"></i> Tambah Ekskul
        </a>
        <?php endif; ?>
    </div>

    <?php if (isset($error_db)): ?>
        <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i>Tabel belum tersedia. Jalankan: <a href="<?php echo $base_url; ?>database/migrate_ekskul_spp.php" class="alert-link">migrate_ekskul_spp.php</a></div>
    <?php endif; ?>

    <!-- Filters -->
    <form method="GET" class="row g-3 mb-4 align-items-end">
        <div class="col-6 col-md-3">
            <label class="form-label form-label-custom">Tahun Ajaran</label>
            <select name="tahun_ajaran_id" class="form-select form-control-custom bg-dark-select text-white">
                <?php foreach ($ta_list as $ta): ?>
                    <option value="<?php echo $ta['id']; ?>" <?php echo $filter_ta==$ta['id']?'selected':''; ?>>
                        <?php echo htmlspecialchars($ta['tahun_ajaran']); ?><?php echo $ta['status']==='Aktif'?' (Aktif)':''; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Status</label>
            <select name="status" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua</option>
                <option value="Aktif" <?php echo $filter_status==='Aktif'?'selected':''; ?>>Aktif</option>
                <option value="Nonaktif" <?php echo $filter_status==='Nonaktif'?'selected':''; ?>>Nonaktif</option>
            </select>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom"><i class="fa-solid fa-filter me-1"></i> Filter</button>
        </div>
    </form>

    <?php if (empty($ekskul_list)): ?>
        <div class="text-center py-5">
            <i class="fa-solid fa-star-half-stroke" style="font-size:48px;color:rgba(255,255,255,.15);"></i>
            <p class="text-secondary mt-3">Belum ada data ekstrakurikuler.<br>
            <?php if (has_role(['Super Admin','Admin'])): ?><a href="create.php?tahun_ajaran_id=<?php echo $filter_ta; ?>" class="text-gold">+ Tambah sekarang</a><?php endif; ?></p>
        </div>
    <?php else: ?>
        <div class="row g-4">
            <?php foreach ($ekskul_list as $eks): 
                $day_color = $day_colors[$eks['hari']] ?? '#94A3B8';
                $fill_pct  = $eks['kuota'] > 0 ? min(100, round($eks['jumlah_anggota']/$eks['kuota']*100)) : 0;
            ?>
            <div class="col-12 col-md-6 col-lg-4">
                <div style="background:rgba(18,28,54,.5); border:1px solid <?php echo $day_color; ?>33; border-radius:14px; overflow:hidden; height:100%; display:flex; flex-direction:column;">
                    <!-- Header bar -->
                    <div style="background:<?php echo $day_color; ?>22; border-bottom:1px solid <?php echo $day_color; ?>33; padding:14px 16px;">
                        <div class="d-flex justify-content-between align-items-start">
                            <h6 class="fw-bold text-white mb-0" style="font-size:15px;"><?php echo htmlspecialchars($eks['nama']); ?></h6>
                            <span class="badge" style="background:<?php echo $eks['status']==='Aktif' ? 'rgba(16,185,129,.2)' : 'rgba(239,68,68,.2)'; ?>; color:<?php echo $eks['status']==='Aktif' ? '#10B981' : '#EF4444'; ?>; font-size:10px;">
                                <?php echo $eks['status']; ?>
                            </span>
                        </div>
                    </div>
                    <!-- Body -->
                    <div style="padding:14px 16px; flex:1;">
                        <?php if ($eks['deskripsi']): ?>
                            <p class="text-secondary" style="font-size:12px; line-height:1.5; margin-bottom:12px;"><?php echo htmlspecialchars(substr($eks['deskripsi'],0,100)); ?><?php echo strlen($eks['deskripsi'])>100?'...':''; ?></p>
                        <?php endif; ?>

                        <div class="d-flex flex-wrap gap-2 mb-3">
                            <?php if ($eks['hari']): ?>
                            <span style="background:<?php echo $day_color; ?>22; color:<?php echo $day_color; ?>; border:1px solid <?php echo $day_color; ?>44; border-radius:6px; padding:3px 10px; font-size:11px; font-weight:600;">
                                <i class="fa-solid fa-calendar-day me-1"></i><?php echo $eks['hari']; ?>
                                <?php if ($eks['jam_mulai']): ?> <?php echo substr($eks['jam_mulai'],0,5); ?>–<?php echo substr($eks['jam_selesai'],0,5); ?><?php endif; ?>
                            </span>
                            <?php endif; ?>
                            <?php if ($eks['nama_pembina']): ?>
                            <span style="background:rgba(212,175,55,.12); color:#D4AF37; border:1px solid rgba(212,175,55,.25); border-radius:6px; padding:3px 10px; font-size:11px;">
                                <i class="fa-solid fa-user-tie me-1"></i><?php echo htmlspecialchars($eks['nama_pembina']); ?>
                            </span>
                            <?php endif; ?>
                        </div>

                        <!-- Progress anggota -->
                        <div class="mb-1 d-flex justify-content-between" style="font-size:11px;">
                            <span class="text-secondary">Anggota</span>
                            <span class="fw-bold" style="color:<?php echo $day_color; ?>"><?php echo $eks['jumlah_anggota']; ?> / <?php echo $eks['kuota']; ?></span>
                        </div>
                        <div style="height:5px; background:rgba(255,255,255,.08); border-radius:99px; overflow:hidden;">
                            <div style="width:<?php echo $fill_pct; ?>%; height:100%; background:<?php echo $day_color; ?>; border-radius:99px;"></div>
                        </div>
                    </div>
                    <!-- Footer actions -->
                    <?php if (has_role(['Super Admin','Admin'])): ?>
                    <div style="padding:12px 16px; border-top:1px solid rgba(255,255,255,.05); display:flex; gap:8px;">
                        <a href="anggota.php?id=<?php echo $eks['id']; ?>" class="btn btn-sm" style="flex:1; background:<?php echo $day_color; ?>22; color:<?php echo $day_color; ?>; border:1px solid <?php echo $day_color; ?>44; font-size:12px; text-align:center;">
                            <i class="fa-solid fa-users me-1"></i> Kelola Anggota
                        </a>
                        <a href="edit.php?id=<?php echo $eks['id']; ?>" class="btn btn-xs btn-outline-warning" title="Edit"><i class="fa-solid fa-pen"></i></a>
                        <button onclick="confirmDelete('delete.php?id=<?php echo $eks['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i></button>
                    </div>
                    <?php else: ?>
                    <div style="padding:12px 16px; border-top:1px solid rgba(255,255,255,.05);">
                        <a href="anggota.php?id=<?php echo $eks['id']; ?>" class="btn btn-sm w-100" style="background:<?php echo $day_color; ?>22; color:<?php echo $day_color; ?>; border:1px solid <?php echo $day_color; ?>44; font-size:12px;">
                            <i class="fa-solid fa-users me-1"></i> Lihat Anggota
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Summary stats -->
        <div class="row g-3 mt-3">
            <div class="col-6 col-md-3">
                <div style="background:rgba(212,175,55,.1); border:1px solid rgba(212,175,55,.2); border-radius:10px; padding:14px; text-align:center;">
                    <div class="fw-bold text-gold" style="font-size:24px;"><?php echo count($ekskul_list); ?></div>
                    <div class="text-secondary small">Total Ekskul</div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div style="background:rgba(16,185,129,.1); border:1px solid rgba(16,185,129,.2); border-radius:10px; padding:14px; text-align:center;">
                    <div class="fw-bold" style="font-size:24px; color:#10B981;"><?php echo array_sum(array_column($ekskul_list,'jumlah_anggota')); ?></div>
                    <div class="text-secondary small">Total Anggota</div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
