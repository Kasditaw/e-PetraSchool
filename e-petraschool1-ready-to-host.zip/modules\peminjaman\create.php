<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\peminjaman\create.php

$page_title = 'Buat Peminjaman';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin', 'Guru']);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $kode_peminjaman = trim($_POST['kode_peminjaman'] ?? '');
    $nama_peminjam = trim($_POST['nama_peminjam'] ?? '');
    $inventaris_id = intval($_POST['inventaris_id'] ?? 0);
    $tanggal_pinjam = $_POST['tanggal_pinjam'] ?? date('Y-m-d');
    $status = $_POST['status'] ?? 'Dipinjam';
    
    // Optional return date
    $tanggal_kembali = !empty($_POST['tanggal_kembali']) ? $_POST['tanggal_kembali'] : null;

    if (empty($kode_peminjaman) || empty($nama_peminjam) || $inventaris_id === 0 || empty($tanggal_pinjam)) {
        $error = 'Field Kode Transaksi, Nama Peminjam, Aset Barang, dan Tanggal Pinjam wajib diisi!';
    } else {
        try {
            // Check duplicate code
            $chk = $pdo->prepare("SELECT COUNT(*) FROM peminjaman WHERE kode_peminjaman = ?");
            $chk->execute([$kode_peminjaman]);
            if ($chk->fetchColumn() > 0) {
                $error = "Kode transaksi '$kode_peminjaman' sudah terdaftar!";
            } else {
                // Insert borrowing
                $stmt = $pdo->prepare("INSERT INTO peminjaman (kode_peminjaman, nama_peminjam, inventaris_id, tanggal_pinjam, tanggal_kembali, status) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$kode_peminjaman, $nama_peminjam, $inventaris_id, $tanggal_pinjam, $tanggal_kembali, $status]);
                
                // Fetch asset name for logs
                $a_stmt = $pdo->prepare("SELECT nama_barang FROM inventaris WHERE id = ?");
                $a_stmt->execute([$inventaris_id]);
                $asset_name = $a_stmt->fetchColumn();

                write_audit_log("Membuat transaksi peminjaman barang '$asset_name' untuk peminjam: $nama_peminjam.");

                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Transaksi peminjaman berhasil disimpan!', 'success').then(() => {
                            window.location.href = 'index.php';
                        });
                    });
                </script>";
            }
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Fetch all available assets
try {
    $assets = $pdo->query("SELECT id, kode_barang, nama_barang, kondisi FROM inventaris WHERE kondisi = 'Baik' ORDER BY nama_barang ASC")->fetchAll();
} catch (Exception $e) {
    $assets = [];
}
?>

<div class="glass-card" style="max-width: 650px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-plus me-2"></i> Buat Transaksi Peminjaman Aset</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="create.php">
        <?php csrf_input(); ?>

        <div class="mb-3">
            <label for="kode_peminjaman" class="form-label form-label-custom">Kode Transaksi Peminjaman <span class="text-danger">*</span></label>
            <input type="text" name="kode_peminjaman" id="kode_peminjaman" class="form-control form-control-custom" placeholder="Contoh: PMJ-<?php echo date('Ymd-His'); ?>" value="PMJ-<?php echo date('Ymd-His'); ?>" required>
        </div>

        <div class="mb-3">
            <label for="nama_peminjam" class="form-label form-label-custom">Nama Peminjam <span class="text-danger">*</span></label>
            <input type="text" name="nama_peminjam" id="nama_peminjam" class="form-control form-control-custom" placeholder="Nama lengkap peminjam (Siswa/Guru/Staf)" required>
        </div>

        <div class="mb-3">
            <label for="inventaris_id" class="form-label form-label-custom">Barang Aset <span class="text-danger">*</span></label>
            <select name="inventaris_id" id="inventaris_id" class="form-select form-control-custom bg-dark-select text-white" required>
                <option value="" disabled selected>Pilih Barang...</option>
                <?php foreach ($assets as $ast): ?>
                    <option value="<?php echo $ast['id']; ?>"><?php echo htmlspecialchars($ast['nama_barang']) . ' (' . htmlspecialchars($ast['kode_barang']) . ')'; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="row g-3 mb-3">
            <div class="col-6">
                <label for="tanggal_pinjam" class="form-label form-label-custom">Tanggal Pinjam <span class="text-danger">*</span></label>
                <input type="date" name="tanggal_pinjam" id="tanggal_pinjam" class="form-control form-control-custom" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            
            <div class="col-6">
                <label for="tanggal_kembali" class="form-label form-label-custom">Tanggal Pengembalian (Opsional)</label>
                <input type="date" name="tanggal_kembali" id="tanggal_kembali" class="form-control form-control-custom">
            </div>
        </div>

        <div class="mb-4">
            <label for="status" class="form-label form-label-custom">Status Peminjaman</label>
            <select name="status" id="status" class="form-select form-control-custom bg-dark-select text-white">
                <option value="Dipinjam" selected>Dipinjam</option>
                <option value="Dikembalikan">Dikembalikan</option>
            </select>
        </div>

        <div class="d-flex justify-content-end gap-2">
            <a href="index.php" class="btn btn-outline-custom">Batal</a>
            <button type="submit" class="btn btn-gold">Simpan <i class="fa-solid fa-check ms-1"></i></button>
        </div>
    </form>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
