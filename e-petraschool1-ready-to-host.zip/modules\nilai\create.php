<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\nilai\create.php

$page_title = 'Input Nilai Siswa';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin', 'Guru']);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $siswa_id = intval($_POST['siswa_id'] ?? 0);
    $guru_id = intval($_POST['guru_id'] ?? 0);
    $semester = $_POST['semester'] ?? '1';
    $tahun_ajaran = trim($_POST['tahun_ajaran'] ?? '');
    $mata_pelajaran = trim($_POST['mata_pelajaran'] ?? '');
    $nilai_tugas = floatval($_POST['nilai_tugas'] ?? 0);
    $nilai_uts = floatval($_POST['nilai_uts'] ?? 0);
    $nilai_uas = floatval($_POST['nilai_uas'] ?? 0);

    // Calculate final grade on backend
    $nilai_akhir = ($nilai_tugas * 0.3) + ($nilai_uts * 0.3) + ($nilai_uas * 0.4);
    
    // Determine predicate
    $predikat = 'E';
    if ($nilai_akhir >= 86) $predikat = 'A';
    elseif ($nilai_akhir >= 75) $predikat = 'B';
    elseif ($nilai_akhir >= 60) $predikat = 'C';
    elseif ($nilai_akhir >= 45) $predikat = 'D';

    if ($siswa_id === 0 || $guru_id === 0 || empty($tahun_ajaran) || empty($mata_pelajaran)) {
        $error = 'Siswa, Guru pengajar, Tahun Ajaran, dan Mapel wajib diisi!';
    } else {
        try {
            // Save grade
            $stmt = $pdo->prepare("INSERT INTO nilai (siswa_id, guru_id, semester, tahun_ajaran, mata_pelajaran, nilai_tugas, nilai_uts, nilai_uas, nilai_akhir, predikat) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$siswa_id, $guru_id, $semester, $tahun_ajaran, $mata_pelajaran, $nilai_tugas, $nilai_uts, $nilai_uas, $nilai_akhir, $predikat]);

            // Fetch student name for logging
            $s_stmt = $pdo->prepare("SELECT nama_lengkap FROM siswa WHERE id = ?");
            $s_stmt->execute([$siswa_id]);
            $student_name = $s_stmt->fetchColumn();

            write_audit_log("Menginput nilai mata pelajaran $mata_pelajaran untuk siswa: $student_name.");

            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire('Berhasil', 'Nilai siswa berhasil disimpan!', 'success').then(() => {
                        window.location.href = 'index.php';
                    });
                });
            </script>";
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Fetch active students
try {
    $students = $pdo->query("SELECT id, nis, nama_lengkap FROM siswa WHERE status_siswa = 'Aktif' ORDER BY nama_lengkap ASC")->fetchAll();
    $teachers = $pdo->query("SELECT id, nip, nama_guru FROM guru ORDER BY nama_guru ASC")->fetchAll();
} catch (Exception $e) {
    $students = [];
    $teachers = [];
}
?>

<div class="glass-card" style="max-width: 700px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-plus me-2"></i> Input Nilai Siswa Baru</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="create.php">
        <?php csrf_input(); ?>

        <div class="row g-3">
            <div class="col-12 col-md-6">
                <label for="siswa_id" class="form-label form-label-custom">Nama Siswa <span class="text-danger">*</span></label>
                <select name="siswa_id" id="siswa_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="" disabled selected>Pilih Siswa...</option>
                    <?php foreach ($students as $st): ?>
                        <option value="<?php echo $st['id']; ?>"><?php echo htmlspecialchars($st['nama_lengkap']) . ' (NIS: ' . htmlspecialchars($st['nis']) . ')'; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-12 col-md-6">
                <label for="guru_id" class="form-label form-label-custom">Guru Pengajar <span class="text-danger">*</span></label>
                <select name="guru_id" id="guru_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="" disabled selected>Pilih Guru...</option>
                    <?php foreach ($teachers as $tc): ?>
                        <option value="<?php echo $tc['id']; ?>"><?php echo htmlspecialchars($tc['nama_guru']) . ' (' . htmlspecialchars($tc['nip']) . ')'; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-12 col-md-6">
                <label for="mata_pelajaran" class="form-label form-label-custom">Mata Pelajaran <span class="text-danger">*</span></label>
                <input type="text" name="mata_pelajaran" id="mata_pelajaran" class="form-control form-control-custom" placeholder="Contoh: Matematika" required>
            </div>

            <div class="col-6 col-md-3">
                <label for="semester" class="form-label form-label-custom">Semester</label>
                <select name="semester" id="semester" class="form-select form-control-custom bg-dark-select text-white">
                    <option value="1">1 (Ganjil)</option>
                    <option value="2">2 (Genap)</option>
                </select>
            </div>

            <div class="col-6 col-md-3">
                <label for="tahun_ajaran" class="form-label form-label-custom">Tahun Ajaran <span class="text-danger">*</span></label>
                <input type="text" name="tahun_ajaran" id="tahun_ajaran" class="form-control form-control-custom" placeholder="Contoh: 2025/2026" value="2025/2026" required>
            </div>

            <div class="col-12 mt-4">
                <h6 class="text-gold border-bottom border-secondary border-opacity-25 pb-2 mb-3"><i class="fa-solid fa-list-check me-2"></i> Komponen Nilai Angka</h6>
            </div>

            <div class="col-12 col-md-4">
                <label for="nilai_tugas" class="form-label form-label-custom">Nilai Tugas (30%)</label>
                <input type="number" step="0.01" min="0" max="100" name="nilai_tugas" id="nilai_tugas" class="form-control form-control-custom" value="0.00">
            </div>

            <div class="col-12 col-md-4">
                <label for="nilai_uts" class="form-label form-label-custom">Nilai UTS (30%)</label>
                <input type="number" step="0.01" min="0" max="100" name="nilai_uts" id="nilai_uts" class="form-control form-control-custom" value="0.00">
            </div>

            <div class="col-12 col-md-4">
                <label for="nilai_uas" class="form-label form-label-custom">Nilai UAS (40%)</label>
                <input type="number" step="0.01" min="0" max="100" name="nilai_uas" id="nilai_uas" class="form-control form-control-custom" value="0.00">
            </div>

            <div class="col-12 col-md-6 mt-3">
                <label for="nilai_akhir" class="form-label form-label-custom text-gold">Nilai Akhir (Kalkulasi Otomatis)</label>
                <input type="text" id="nilai_akhir" class="form-control form-control-custom fw-bold text-gold" style="background: rgba(212, 175, 55, 0.05) !important;" readonly value="0.00">
            </div>

            <div class="col-12 col-md-6 mt-3">
                <label for="predikat" class="form-label form-label-custom">Predikat (Kalkulasi Otomatis)</label>
                <input type="text" id="predikat" class="form-control form-control-custom fw-bold text-white" readonly value="E">
            </div>

            <div class="col-12 d-flex justify-content-end gap-2 mt-4">
                <a href="index.php" class="btn btn-outline-custom">Batal</a>
                <button type="submit" class="btn btn-gold">Simpan Nilai <i class="fa-solid fa-check ms-1"></i></button>
            </div>
        </div>
    </form>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
