<?php
// =============================================================================
// e-PetraSchool1 — Konfigurasi Environment
// =============================================================================
// File ini TIDAK BOLEH di-commit ke Git atau dibagikan secara publik.
// Salin file ini dan isi sesuai pengaturan hosting Anda.
//
// Di XAMPP lokal: cukup biarkan default di bawah.
// Di hosting:    ubah sesuai kredensial cPanel/database hosting.
// =============================================================================

return [
    // ── App Environment ──────────────────────────────────────────────────────
    // 'development' = tampilkan error di browser (lokal)
    // 'production'  = sembunyikan error, catat ke log (hosting)
    'APP_ENV'       => 'development',

    // ── Base URL ─────────────────────────────────────────────────────────────
    // Kosongkan ('') untuk auto-detect. Isi jika perlu override.
    // Contoh: '/e-petraschool1/' atau '/' jika di root domain.
    'APP_URL'       => '',

    // ── HTTPS ────────────────────────────────────────────────────────────────
    // Set true jika hosting sudah memiliki SSL (redirect HTTP → HTTPS)
    'FORCE_HTTPS'   => false,

    // ── Database ─────────────────────────────────────────────────────────────
    'DB_HOST'       => 'localhost',
    'DB_NAME'       => 'db_petraschool',
    'DB_USER'       => 'root',
    'DB_PASS'       => '',
    'DB_CHARSET'    => 'utf8mb4',
];
