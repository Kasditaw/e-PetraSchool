<?php
// c:\xampp\htdocs\e-petraschool1\modules\ekskul\anggota.php

$page_title = 'Anggota Ekstrakurikuler';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$ekskul_id = intval($_GET['id'] ?? 0);
if (!$ekskul_id) { header('Location: index.php'); exit; }

try {
    $eks_stmt = $pdo->prepare("SELECT e.*, g.nama_guru AS nama_pembina, ta.tahun_ajaran FROM ekskul e LEFT JOIN guru g ON e.pembina_id=g.id JOIN tahun_ajaran ta ON e.tahun_ajaran_id=ta.id WHERE e.id=?");
    $eks_stmt->execute([$ekskul_id]);
    $ekskul = $eks_stmt->fetch();
    if (!$ekskul) { header('Location: index.php'); exit; }

    // Semua siswa aktif (belum join ekskul ini)
    $all_siswa = $pdo->query("SELECT s.id, s.nis, s.nama_lengkap, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON s.kelas_id=k.id WHERE s.status_siswa='Aktif' ORDER BY k.nama_kelas, s.nama_lengkap ASC")->fetchAll();

    // Anggota yang sudah join
    $angg_stmt = $pdo->prepare("SELECT ea.*, s.nama_lengkap, s.nis, k.nama_kelas FROM ekskul_anggota ea JOIN siswa s ON ea.siswa_id=s.id LEFT JOIN kelas k ON s.kelas_id=k.id WHERE ea.ekskul_id=? AND ea.tahun_ajaran_id=? ORDER BY s.nama_lengkap ASC");
    $angg_stmt->execute([$ekskul_id, $ekskul['tahun_ajaran_id']]);
    $anggota = $angg_stmt->fetchAll();
    $anggota_ids = array_column($anggota, 'siswa_id');

    $siswa_belum = array_filter($all_siswa, fn($s) => !in_array($s['id'], $anggota_ids));

} catch (Exception $e) { die("Error: " . $e->getMessage()); }

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && has_role(['Super Admin','Admin'])) {
    check_csrf_request();
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $siswa_ids = $_POST['siswa_ids'] ?? [];
        $added = 0;
        foreach ($siswa_ids as $sid) {
            try {
                $pdo->prepare("INSERT IGNORE INTO ekskul_anggota (ekskul_id,siswa_id,tahun_ajaran_id) VALUES (?,?,?)")->execute([$ekskul_id, intval($sid), $ekskul['tahun_ajaran_id']]);
                $added++;
            } catch (Exception $e) {}
        }
        if ($added > 0) write_audit_log("Menambahkan $added anggota ke ekskul: {$ekskul['nama']}.");
        header("Location: anggota.php?id=$ekskul_id&success=added");
        exit;
    }

    if ($action === 'remove') {
        $angg_id = intval($_POST['angg_id'] ?? 0);
        $pdo->prepare("DELETE FROM ekskul_anggota WHERE id=?")->execute([$angg_id]);
        write_audit_log("Menghapus anggota dari ekskul: {$ekskul['nama']}.");
        header("Location: anggota.php?id=$ekskul_id&success=removed");
        exit;
    }
}
?>
<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-users me-2"></i>Anggota Ekskul — <?php echo htmlspecialchars($ekskul['nama']); ?></h5>
            <p class="text-secondary small mb-0">
                <?php if ($ekskul['nama_pembina']): ?>Pembina: <strong class="text-white"><?php echo htmlspecialchars($ekskul['nama_pembina']); ?></strong> &nbsp;|&nbsp; <?php endif; ?>
                TA: <?php echo htmlspecialchars($ekskul['tahun_ajaran']); ?> &nbsp;|&nbsp;
                Kuota: <strong class="text-gold"><?php echo count($anggota); ?>/<?php echo $ekskul['kuota']; ?></strong>
            </p>
        </div>
        <a href="index.php?tahun_ajaran_id=<?php echo $ekskul['tahun_ajaran_id']; ?>" class="btn btn-outline-custom"><i class="fa-solid fa-arrow-left me-1"></i> Kembali</a>
    </div>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success"><i class="fa-solid fa-check-circle me-2"></i><?php echo $_GET['success']==='added'?'Anggota berhasil ditambahkan!':'Anggota berhasil dihapus!'; ?></div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Panel Tambah Anggota -->
        <?php if (has_role(['Super Admin','Admin']) && !empty($siswa_belum)): ?>
        <div class="col-md-5">
            <div style="background:rgba(212,175,55,.06);border:1px solid rgba(212,175,55,.2);border-radius:12px;padding:20px;">
                <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-user-plus me-2"></i>Tambah Anggota</h6>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                    <input type="hidden" name="action" value="add">
                    <div class="mb-3">
                        <input type="text" id="cari-siswa" placeholder="Cari siswa..." class="form-control form-control-custom" style="font-size:12px;" oninput="filterSiswa(this.value)">
                    </div>
                    <div id="siswa-list" style="max-height:300px;overflow-y:auto;">
                        <?php foreach ($siswa_belum as $s): ?>
                        <label style="display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:8px;cursor:pointer;margin-bottom:4px;border:1px solid rgba(255,255,255,.05);" class="siswa-item hover-item">
                            <input type="checkbox" name="siswa_ids[]" value="<?php echo $s['id']; ?>" style="accent-color:#D4AF37;">
                            <span>
                                <strong style="font-size:12px;color:#fff;"><?php echo htmlspecialchars($s['nama_lengkap']); ?></strong>
                                <small class="text-secondary d-block"><?php echo htmlspecialchars($s['nama_kelas']??'Tanpa Kelas'); ?> · <?php echo htmlspecialchars($s['nis']); ?></small>
                            </span>
                        </label>
                        <?php endforeach; ?>
                    </div>
                    <button type="submit" class="btn btn-gold w-100 mt-3" style="font-size:13px;"><i class="fa-solid fa-plus me-1"></i> Tambahkan yang Dipilih</button>
                </form>
            </div>
        </div>
        <?php endif; ?>

        <!-- Daftar Anggota -->
        <div class="col">
            <h6 class="fw-bold text-white mb-3">Daftar Anggota (<?php echo count($anggota); ?>)</h6>
            <?php if (empty($anggota)): ?>
                <p class="text-secondary">Belum ada anggota.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-custom" style="font-size:12px;">
                        <thead><tr><th>#</th><th>Nama Siswa</th><th>Kelas</th><th>NIS</th><th>Status</th><?php if (has_role(['Super Admin','Admin'])): ?><th>Aksi</th><?php endif; ?></tr></thead>
                        <tbody>
                            <?php $no=1; foreach ($anggota as $a): ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><strong class="text-white"><?php echo htmlspecialchars($a['nama_lengkap']); ?></strong></td>
                                <td><?php echo htmlspecialchars($a['nama_kelas']??'-'); ?></td>
                                <td class="font-monospace text-secondary"><?php echo htmlspecialchars($a['nis']); ?></td>
                                <td><span class="badge" style="background:rgba(16,185,129,.2);color:#10B981;font-size:10px;"><?php echo $a['status']; ?></span></td>
                                <?php if (has_role(['Super Admin','Admin'])): ?>
                                <td>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
                                        <input type="hidden" name="action" value="remove">
                                        <input type="hidden" name="angg_id" value="<?php echo $a['id']; ?>">
                                        <button type="submit" class="btn btn-xs btn-outline-danger" onclick="return confirm('Hapus anggota ini?')"><i class="fa-solid fa-times"></i></button>
                                    </form>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<script>
function filterSiswa(q) {
    document.querySelectorAll('.siswa-item').forEach(el => {
        el.style.display = el.textContent.toLowerCase().includes(q.toLowerCase()) ? '' : 'none';
    });
}
</script>
<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
