<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\guru\index.php

$page_title = 'Data Guru';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

try {
    // Build query
    $query = "SELECT * FROM guru WHERE 1=1";
    $params = [];

    if ($search !== '') {
        $query .= " AND (nama_guru LIKE :search OR nip LIKE :search OR mapel LIKE :search OR jabatan LIKE :search)";
        $params['search'] = "%$search%";
    }

    $query .= " ORDER BY nama_guru ASC";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $teachers = $stmt->fetchAll();

} catch (Exception $e) {
    echo '<div class="alert alert-danger">Gagal memuat data guru: ' . $e->getMessage() . '</div>';
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-chalkboard-user me-2"></i> Pengelolaan Data Guru</h5>
            <p class="text-secondary small mb-0">Kelola informasi tenaga pendidik, jabatan, dan mata pelajaran di SD Kristen Petra 1.</p>
        </div>
        
        <div class="d-flex gap-2 flex-wrap">
            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                <a href="create.php" class="btn btn-gold"><i class="fa-solid fa-plus me-1"></i> Tambah Guru</a>
                <a href="import.php" class="btn btn-outline-custom" style="color:#10B981;"><i class="fa-solid fa-file-csv me-1"></i> Import CSV</a>
            <?php endif; ?>
            <a href="../laporan/export.php?type=guru" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-excel me-1"></i> Ekspor Excel</a>
            <a href="../laporan/print.php?type=guru" target="_blank" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-pdf me-1"></i> Cetak PDF</a>
        </div>
    </div>

    <!-- Search Form -->
    <form method="GET" action="index.php" class="row g-2 mb-4 no-print">
        <div class="col-12 col-md-4">
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari NIP, nama guru, mapel..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">Cari</button>
        </div>
        <?php if ($search !== ''): ?>
            <div class="col-auto">
                <a href="index.php" class="btn btn-outline-danger">Reset</a>
            </div>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>Foto</th>
                    <th>NIP</th>
                    <th>Nama Guru</th>
                    <th>Gender</th>
                    <th>Pendidikan</th>
                    <th>Jabatan</th>
                    <th>Mata Pelajaran</th>
                    <th>No. HP</th>
                    <th class="no-print">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($teachers) > 0): ?>
                    <?php foreach ($teachers as $teacher): ?>
                        <tr>
                            <td>
                                <?php 
                                    $foto_url = !empty($teacher['foto']) ? $base_url . 'assets/uploads/guru/' . $teacher['foto'] : 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=80&h=80&q=80';
                                ?>
                                <img src="<?php echo $foto_url; ?>" alt="Foto" class="rounded border" style="width: 40px; height: 50px; object-fit: cover;">
                            </td>
                            <td><strong class="text-white font-monospace"><?php echo htmlspecialchars($teacher['nip']); ?></strong></td>
                            <td class="fw-semibold text-white"><?php echo htmlspecialchars($teacher['nama_guru']); ?></td>
                            <td><?php echo $teacher['gender'] === 'L' ? 'Laki-laki' : 'Perempuan'; ?></td>
                            <td><?php echo htmlspecialchars($teacher['pendidikan']); ?></td>
                            <td><span class="badge badge-secondary"><?php echo htmlspecialchars($teacher['jabatan']); ?></span></td>
                            <td><span class="text-gold"><?php echo htmlspecialchars($teacher['mapel']); ?></span></td>
                            <td><?php echo htmlspecialchars($teacher['no_hp']); ?></td>
                            <td class="no-print">
                                <div class="d-flex gap-2">
                                    <a href="print.php?id=<?php echo $teacher['id']; ?>" class="btn btn-xs btn-outline-custom text-gold" title="Cetak Biodata"><i class="fa-solid fa-print"></i> Cetak</a>
                                    
                                    <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                        <a href="edit.php?id=<?php echo $teacher['id']; ?>#histori-section" class="btn btn-xs btn-outline-info" title="Riwayat Kepegawaian"><i class="fa-solid fa-timeline"></i> Histori</a>
                                        <a href="edit.php?id=<?php echo $teacher['id']; ?>" class="btn btn-xs btn-outline-warning" title="Edit"><i class="fa-solid fa-pen"></i> Edit</a>
                                        <button onclick="confirmDelete('delete.php?id=<?php echo $teacher['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i> Hapus</button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center text-secondary py-4">Data guru tidak ditemukan.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
