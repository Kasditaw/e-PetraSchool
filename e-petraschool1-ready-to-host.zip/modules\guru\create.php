<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\guru\create.php

$page_title = 'Tambah Guru';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $nip = trim($_POST['nip'] ?? '');
    $nama_guru = trim($_POST['nama_guru'] ?? '');
    $gender = $_POST['gender'] ?? '';
    $pendidikan = trim($_POST['pendidikan'] ?? '');
    $jabatan = trim($_POST['jabatan'] ?? '');
    
    // Mapel selection handling
    $mapel_select = trim($_POST['mapel_select'] ?? '');
    $mapel_custom = trim($_POST['mapel_custom'] ?? '');
    $mapel = ($mapel_select === 'Lainnya') ? $mapel_custom : $mapel_select;
    if (empty($mapel)) {
        $mapel = '-';
    }

    $no_hp = trim($_POST['no_hp'] ?? '');
    $alamat = trim($_POST['alamat'] ?? '');
    $email = trim($_POST['email'] ?? '');
    
    // File upload
    $foto_name = null;
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['foto']['tmp_name'];
        $file_name = $_FILES['foto']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed_exts = ['jpg', 'jpeg', 'png'];
        $mime_type = mime_content_type($file_tmp);
        $allowed_mimes = ['image/jpeg', 'image/png', 'image/pjpeg'];
        
        if (in_array($file_ext, $allowed_exts) && in_array($mime_type, $allowed_mimes)) {
            $upload_dir = dirname(dirname(__DIR__)) . '/assets/uploads/guru/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $foto_name = 'teacher_' . $nip . '_' . time() . '.' . $file_ext;
            if (move_uploaded_file($file_tmp, $upload_dir . $foto_name)) {
                // Success
            } else {
                $error = 'Gagal menyimpan foto.';
            }
        } else {
            $error = 'Format file foto salah. Hanya menerima JPG, JPEG, atau PNG.';
        }
    }

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $status_aktif = $_POST['status_aktif'] ?? 'Aktif';

    if ($error === '') {
        if (empty($nip) || empty($nama_guru) || empty($gender) || empty($pendidikan) || empty($no_hp) || empty($email) || empty($username) || empty($password)) {
            $error = 'Field NIP, Nama, Gender, Pendidikan, No HP, Email, Username, dan Password wajib diisi!';
        } else {
            try {
                // Check duplicate NIP
                $chk1 = $pdo->prepare("SELECT COUNT(*) FROM guru WHERE nip = ?");
                $chk1->execute([$nip]);
                if ($chk1->fetchColumn() > 0) {
                    $error = "NIP '$nip' sudah digunakan!";
                } else {
                    // Check duplicate email
                    $chk2 = $pdo->prepare("SELECT COUNT(*) FROM guru WHERE email = ?");
                    $chk2->execute([$email]);
                    if ($chk2->fetchColumn() > 0) {
                        $error = "Email '$email' sudah digunakan!";
                    } else {
                        // Check duplicate username
                        $chk3 = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
                        $chk3->execute([$username]);
                        if ($chk3->fetchColumn() > 0) {
                            $error = "Username '$username' sudah digunakan!";
                        } else {
                            $pdo->beginTransaction();

                            // Insert guru
                            $stmt = $pdo->prepare("INSERT INTO guru (nip, nama_guru, gender, pendidikan, jabatan, mapel, no_hp, alamat, email, foto) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                            $stmt->execute([$nip, $nama_guru, $gender, $pendidikan, $jabatan, $mapel, $no_hp, $alamat, $email, $foto_name]);
                            $guru_id = $pdo->lastInsertId();

                            // Insert user login
                            $hashed_pass = password_hash($password, PASSWORD_BCRYPT);
                            $stmt_user = $pdo->prepare("INSERT INTO users (username, password, nama, role_id, guru_id, status_aktif) VALUES (?, ?, ?, 3, ?, ?)");
                            $stmt_user->execute([$username, $hashed_pass, $nama_guru, $guru_id, $status_aktif]);

                            $pdo->commit();

                            write_audit_log("Menambahkan data guru baru: $nama_guru (NIP: $nip) dan membuat akun login: $username.");
                            
                            echo "<script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    Swal.fire('Berhasil', 'Data guru dan akun login berhasil disimpan!', 'success').then(() => {
                                        window.location.href = 'index.php';
                                    });
                                });
                            </script>";
                        }
                    }
                }
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $error = 'Error database: ' . $e->getMessage();
            }
        }
    }
}
$mapel_list = [];
try {
    $mapel_list = $pdo->query("SELECT nama_mapel FROM mata_pelajaran WHERE status = 'Aktif' ORDER BY nama_mapel ASC")->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) {
    // fallback
}
?>

<div class="glass-card" style="max-width: 750px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-user-plus me-2"></i> Tambah Data Guru Baru</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="create.php" enctype="multipart/form-data">
        <?php csrf_input(); ?>

        <div class="row g-3">
            <div class="col-12 col-md-6">
                <label for="nip" class="form-label form-label-custom">NIP (Nomor Induk Pegawai) <span class="text-danger">*</span></label>
                <input type="text" name="nip" id="nip" class="form-control form-control-custom" placeholder="Contoh: GUR006" required>
            </div>
            
            <div class="col-12 col-md-6">
                <label for="nama_guru" class="form-label form-label-custom">Nama Lengkap Guru <span class="text-danger">*</span></label>
                <input type="text" name="nama_guru" id="nama_guru" class="form-control form-control-custom" placeholder="Nama lengkap beserta gelar" required>
            </div>

            <div class="col-12 col-md-4">
                <label for="gender" class="form-label form-label-custom">Jenis Kelamin <span class="text-danger">*</span></label>
                <select name="gender" id="gender" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="" disabled selected>Pilih...</option>
                    <option value="L">Laki-laki</option>
                    <option value="P">Perempuan</option>
                </select>
            </div>

            <div class="col-12 col-md-4">
                <label for="pendidikan" class="form-label form-label-custom">Pendidikan Terakhir <span class="text-danger">*</span></label>
                <input type="text" name="pendidikan" id="pendidikan" class="form-control form-control-custom" placeholder="Contoh: S1 PGSD" required>
            </div>

            <div class="col-12 col-md-4">
                <label for="jabatan" class="form-label form-label-custom">Jabatan Kepegawaian</label>
                <input type="text" name="jabatan" id="jabatan" class="form-control form-control-custom" placeholder="Contoh: Guru Kelas, Wali Kelas">
            </div>

            <div class="col-12 col-md-6">
                <label for="mapel_select" class="form-label form-label-custom">Mata Pelajaran yang Diajar <span class="text-danger">*</span></label>
                <select name="mapel_select" id="mapel_select" class="form-select form-control-custom bg-dark-select text-white" onchange="toggleCustomMapelInput(this.value)" required>
                    <option value="" disabled selected>Pilih Mata Pelajaran...</option>
                    <option value="Guru Kelas">Guru Kelas</option>
                    <?php foreach ($mapel_list as $m_name): ?>
                        <option value="<?php echo htmlspecialchars($m_name); ?>"><?php echo htmlspecialchars($m_name); ?></option>
                    <?php endforeach; ?>
                    <option value="Lainnya">Lainnya (Input Manual)...</option>
                </select>
            </div>

            <div class="col-12 col-md-6 d-none" id="custom-mapel-container">
                <label for="mapel_custom" class="form-label form-label-custom">Mata Pelajaran Kustom <span class="text-danger">*</span></label>
                <input type="text" name="mapel_custom" id="mapel_custom" class="form-control form-control-custom" placeholder="Ketik nama mata pelajaran kustom">
            </div>

            <div class="col-12 col-md-6">
                <label for="no_hp" class="form-label form-label-custom">Nomor HP / WhatsApp <span class="text-danger">*</span></label>
                <input type="text" name="no_hp" id="no_hp" class="form-control form-control-custom" placeholder="Contoh: 0812345678" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="email" class="form-label form-label-custom">Email Petra <span class="text-danger">*</span></label>
                <input type="email" name="email" id="email" class="form-control form-control-custom" placeholder="Contoh: guru@petra.sch.id" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="foto" class="form-label form-label-custom">Foto Guru</label>
                <input type="file" name="foto" id="foto" class="form-control form-control-custom" accept="image/*">
            </div>

            <div class="col-12">
                <label for="alamat" class="form-label form-label-custom">Alamat Lengkap</label>
                <textarea name="alamat" id="alamat" class="form-control form-control-custom" rows="2" placeholder="Alamat domisili lengkap saat ini"></textarea>
            </div>

            <div class="col-12 mt-4">
                <h6 class="text-gold border-bottom border-secondary border-opacity-25 pb-2 mb-3"><i class="fa-solid fa-key me-2"></i> Akun Akses e-Jurnal</h6>
            </div>

            <div class="col-12 col-md-4">
                <label for="username" class="form-label form-label-custom">Username <span class="text-danger">*</span></label>
                <input type="text" name="username" id="username" class="form-control form-control-custom" placeholder="Masukkan username" required autocomplete="off">
            </div>

            <div class="col-12 col-md-4">
                <label for="password" class="form-label form-label-custom">Password <span class="text-danger">*</span></label>
                <input type="password" name="password" id="password" class="form-control form-control-custom" placeholder="Masukkan password" required autocomplete="new-password">
            </div>

            <div class="col-12 col-md-4">
                <label for="status_aktif" class="form-label form-label-custom">Status Aktif <span class="text-danger">*</span></label>
                <select name="status_aktif" id="status_aktif" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="Aktif" selected>Aktif</option>
                    <option value="Tidak Aktif">Tidak Aktif</option>
                </select>
            </div>

            <div class="col-12 d-flex justify-content-end gap-2 mt-4">
                <a href="index.php" class="btn btn-outline-custom">Batal</a>
                <button type="submit" class="btn btn-gold">Simpan <i class="fa-solid fa-check ms-1"></i></button>
            </div>
        </div>
    </form>
</div>

<script>
function toggleCustomMapelInput(val) {
    var container = document.getElementById('custom-mapel-container');
    var input = document.getElementById('mapel_custom');
    if (val === 'Lainnya') {
        container.classList.remove('d-none');
        input.setAttribute('required', 'required');
        input.focus();
    } else {
        container.classList.add('d-none');
        input.removeAttribute('required');
        input.value = '';
    }
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
