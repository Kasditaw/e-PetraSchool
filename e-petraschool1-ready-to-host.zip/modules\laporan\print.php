<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\laporan\print.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';

// Enforce login
check_login();

$type = isset($_GET['type']) ? $_GET['type'] : '';

if (empty($type)) {
    die("Error: Tipe laporan tidak ditentukan.");
}

$orientation = ($type === 'histori_siswa') ? 'portrait' : 'landscape';

$report_titles = [
    'siswa' => 'Data Siswa Aktif',
    'guru' => 'Data Guru',
    'karyawan' => 'Data Staf & Karyawan',
    'inventaris' => 'Buku Induk Inventaris Aset',
    'barang_rusak' => 'Daftar Barang Rusak Berat',
    'ruangan' => 'Daftar Ruangan & Penanggung Jawab',
    'alumni' => 'Buku Induk Alumni',
    'nilai' => 'Rekapitulasi Nilai Akademik Siswa',
    'peminjaman' => 'Riwayat Transaksi Peminjaman Aset',
    'pengumuman' => 'Arsip Pengumuman Resmi',
    'audit_log' => 'Audit Trail System Logs',
    'jurnal_harian' => 'Rekap e-Jurnal Mengajar Harian',
    'jurnal_bulanan' => 'Rekap e-Jurnal Mengajar Bulanan',
    'jurnal_semester' => 'Rekap e-Jurnal Mengajar Semester',
    'siswa_tingkat' => 'Daftar Siswa Per Tingkat Kelas',
    'rekap_tahun_ajaran' => 'Rekapitulasi Siswa Per Tahun Ajaran',
    'mutasi' => 'Laporan Mutasi Masuk & Keluar Siswa',
    'alumni_angkatan' => 'Daftar Alumni Per Angkatan',
    'histori_siswa' => 'Histori Kelas & Riwayat Akademik Siswa'
];
$display_title = $report_titles[$type] ?? 'Laporan Sekolah';

// Log report printing
write_audit_log("Mencetak dokumen laporan PDF/Print: " . ucfirst($type) . ".");

// Compute base_url
$project_dir = str_replace('\\', '/', dirname(dirname(__DIR__)));
$web_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
$base_url = str_replace($web_root, '', $project_dir);
if (empty($base_url)) {
    $base_url = '/';
} else {
    if (substr($base_url, 0, 1) !== '/') {
        $base_url = '/' . $base_url;
    }
    if (substr($base_url, -1) !== '/') {
        $base_url .= '/';
    }
}
$base_url = str_replace('//', '/', $base_url);

// Embed logo as base64 so it always loads in print/PDF regardless of URL path
$logo_file = dirname(dirname(__DIR__)) . '/assets/images/logo.png';

if (file_exists($logo_file)) {
    $logo_data = base64_encode(file_get_contents($logo_file));
    $logo_src  = 'data:image/png;base64,' . $logo_data;
} else {
    $logo_src  = $base_url . 'assets/images/logo.png';
}

// Left logo: Tut Wuri Handayani
$tut_wuri_file = dirname(dirname(__DIR__)) . '/assets/images/tut_wuri.png';
if (file_exists($tut_wuri_file)) {
    $tut_wuri_data = base64_encode(file_get_contents($tut_wuri_file));
    $tut_wuri_src  = 'data:image/png;base64,' . $tut_wuri_data;
} else {
    $tut_wuri_src  = 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Logo-Tut-Wuri-Handayani-PNG-Warna.png/120px-Logo-Tut-Wuri-Handayani-PNG-Warna.png';
}

$filter_info = [];
if ($type === 'nilai') {
    if (isset($_GET['tahun_ajaran']) && $_GET['tahun_ajaran'] !== '') {
        $filter_info[] = "Tahun Ajaran: " . htmlspecialchars($_GET['tahun_ajaran']);
    }
    if (isset($_GET['semester']) && $_GET['semester'] !== '') {
        $filter_info[] = "Semester: " . ($_GET['semester'] === '1' ? '1 (Ganjil)' : '2 (Genap)');
    }
    if (isset($_GET['kelas_id']) && $_GET['kelas_id'] !== '') {
        try {
            $stmt = $pdo->prepare("SELECT nama_kelas FROM kelas WHERE id = :id");
            $stmt->execute(['id' => intval($_GET['kelas_id'])]);
            $selected_kelas_name = $stmt->fetchColumn();
            if ($selected_kelas_name) {
                $filter_info[] = "Kelas: " . htmlspecialchars($selected_kelas_name);
            }
        } catch (Exception $e) {
            // Ignore error
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan <?php echo ucfirst($type); ?> - SD Kristen Petra 1</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&display=swap" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <!-- Custom CSS -->
    <style>
        * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
        body {
            background-color: #f8fafc !important;
            color: #0f172a !important;
            margin: 0;
            padding: 0;
            font-family: 'Outfit', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }
        .print-container {
            width: <?php echo $orientation === 'landscape' ? '297mm' : '210mm'; ?>;
            min-height: <?php echo $orientation === 'landscape' ? '210mm' : '297mm'; ?>;
            background-color: #ffffff !important;
            padding: 15mm;
            box-shadow: 0 4px 20px rgba(15, 23, 42, 0.05);
            margin: 30px auto;
            box-sizing: border-box;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            position: relative;
        }
        .report-kop-surat {
            border-bottom: 3px double #0f172a;
            padding-bottom: 12px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .kop-logo-left, .kop-logo-right {
            width: 70px;
            height: 70px;
            flex: 0 0 70px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .kop-logo-left img, .kop-logo-right img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }
        .kop-title {
            flex: 1 1 auto;
            min-width: 0;
            text-align: center;
            padding: 0 15px;
        }
        .kop-title h4 {
            margin: 2px 0;
            font-weight: 800;
            color: #0f172a;
            font-size: 16px;
            text-transform: uppercase;
        }
        .kop-title p {
            margin: 4px 0 0 0;
            font-size: 11px;
            color: #475569;
        }
        .report-title {
            font-size: 14px;
            font-weight: bold;
            color: #091124;
            margin: 20px 0 15px 0;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            text-align: left;
            width: 100%;
        }
        .report-table-print {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            table-layout: auto;
        }
        .report-table-print th {
            background-color: #ebf2f7 !important;
            color: #000000 !important;
            border: 1px solid #94a3b8 !important;
            font-weight: bold;
            padding: 8px 10px;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            white-space: nowrap;
        }
        .report-table-print td {
            border: 1px solid #cbd5e1 !important;
            color: #334155 !important;
            padding: 8px 10px;
            font-size: 11.5px;
            line-height: 1.4;
            word-wrap: break-word;
            word-break: break-word;
        }
        .btn-print-panel {
            position: fixed;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
            z-index: 1000;
        }
        .btn-action-print {
            background: #D4AF37;
            color: #000;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-family: 'Outfit', sans-serif;
            box-shadow: 0 4px 12px rgba(212, 175, 55, 0.3);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
        }
        .btn-action-print:hover {
            background: #f3cd48;
            transform: translateY(-1px);
        }
        .btn-action-back {
            background: #ffffff;
            color: #334155;
            border: 1px solid #e2e8f0;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-family: 'Outfit', sans-serif;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        }
        .btn-action-back:hover {
            background: #f8fafc;
            border-color: #cbd5e1;
            transform: translateY(-1px);
        }
        /* Custom styled info box for individual reports */
        .info-card-print {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }
        @media print {
            @page {
                size: <?php echo $orientation === 'landscape' ? '330mm 215mm' : '215mm 330mm'; ?>;
                margin: 0;
            }
            body {
                background-color: #ffffff !important;
                padding: 0 !important;
                margin: 0 !important;
            }
            .print-container {
                width: 100% !important;
                min-height: auto !important;
                border: none !important;
                box-shadow: none !important;
                padding: 8mm 15mm !important;
                margin: 0 !important;
                background-color: #ffffff !important;
                box-sizing: border-box !important;
            }
            tr {
                page-break-inside: avoid !important;
            }
            .report-table-print th, .report-table-print td {
                padding: 5px 8px !important;
                font-size: 10.5px !important;
                line-height: 1.25 !important;
            }
            .btn-print-panel {
                display: none !important;
            }
            <?php if ($type === 'histori_siswa'): ?>
            .report-kop-surat {
                margin-bottom: 12px !important;
                padding-bottom: 8px !important;
            }
            .info-card-print {
                padding: 10px !important;
                margin-bottom: 12px !important;
            }
            h6 {
                margin-top: 12px !important;
                margin-bottom: 6px !important;
                font-size: 11px !important;
            }
            .report-table-print th, .report-table-print td {
                padding: 3px 5px !important;
                font-size: 8.5px !important;
                line-height: 1.2 !important;
            }
            <?php endif; ?>
        }
    </style>
</head>
<body>

    <div class="btn-print-panel no-print">
        <a href="index.php" class="btn-action-back"><i class="fa-solid fa-chevron-left"></i> Kembali</a>
        <button onclick="window.print()" class="btn-action-print"><i class="fa-solid fa-print"></i> Cetak PDF</button>
    </div>

    <?php
    $upper_title = mb_strtoupper($display_title);
    $prepend_laporan = true;
    $keywords = ['LAPORAN', 'REKAP', 'BUKU INDUK', 'DAFTAR', 'ARSIP', 'HISTORI', 'RIWAYAT'];
    foreach ($keywords as $kw) {
        if (strpos($upper_title, $kw) !== false) {
            $prepend_laporan = false;
            break;
        }
    }
    $full_title = $prepend_laporan ? 'LAPORAN ' . $upper_title : $upper_title;
    ?>

    <?php if ($type !== 'nilai'): ?>
    <div class="print-container">
        <!-- Kop Surat -->
    <div class="report-kop-surat">
        <div class="kop-logo-left">
            <img src="<?php echo $tut_wuri_src; ?>" alt="Logo Kemdikbud">
        </div>
        <div class="kop-title">
            <div style="font-size: 13px; font-weight: bold; margin: 0; text-transform: uppercase; color: #091124;">Kementerian Pendidikan Dasar dan Menengah</div>
            <div style="font-size: 13px; font-weight: bold; margin: 1px 0; text-transform: uppercase; color: #091124;">Dinas Pendidikan Kota Surabaya</div>
            <h4>SD KRISTEN PETRA 1 SURABAYA</h4>
            <p>Jalan WR. Supratman 46, Surabaya 60264 | Email: sd1@pppkpetra.sch.id</p>
        </div>
        <div class="kop-logo-right">
            <img src="<?php echo $logo_src; ?>" alt="Logo SD Kristen Petra 1">
        </div>
    </div>

    <div class="report-title">
        <?php echo htmlspecialchars($full_title); ?>
    </div>
    <?php if ($type === 'nilai' && !empty($filter_info)): ?>
    <div style="font-size: 12px; color: #475569; margin-top: -10px; margin-bottom: 20px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; text-align: left; width: 100%;">
        <i class="fa-solid fa-filter me-1" style="color: #D4AF37;"></i> <?php echo implode(' &nbsp;|&nbsp; ', $filter_info); ?>
    </div>
    <?php endif; ?>

    <table class="report-table-print">
    <?php endif; ?>
        <?php
        try {
            $romanize = function($nama) {
                $nama_roman = preg_replace_callback('/(\d+)/', function($matches) {
                    $map = [1 => 'I', 2 => 'II', 3 => 'III', 4 => 'IV', 5 => 'V', 6 => 'VI'];
                    return $map[$matches[1]] ?? $matches[1];
                }, $nama);
                return preg_replace('/([I|V|X]+)([A-HJ-UW-Z])/', '$1 $2', $nama_roman);
            };

            switch ($type) {
                case 'siswa':
                    $q = "SELECT s.*, k.nama_kelas, k.id as kelas_id_val FROM siswa s LEFT JOIN kelas k ON s.kelas_id = k.id WHERE 1=1";
                    $p = [];
                    if (isset($_GET['kelas_id']) && $_GET['kelas_id'] !== '') {
                        $q .= " AND s.kelas_id = :kelas_id";
                        $p['kelas_id'] = intval($_GET['kelas_id']);
                    }
                    if (isset($_GET['status_siswa']) && $_GET['status_siswa'] !== '') {
                        $q .= " AND s.status_siswa = :status_siswa";
                        $p['status_siswa'] = $_GET['status_siswa'];
                    }
                    $q .= " ORDER BY k.nama_kelas ASC, s.nama_lengkap ASC";
                    $stmt = $pdo->prepare($q);
                    $stmt->execute($p);
                    $rows = $stmt->fetchAll();
                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>NIS</th>
                            <th>NISN</th>
                            <th>Nama Lengkap</th>
                            <th>L/P</th>
                            <th>Agama</th>
                            <th>No HP Ortu</th>
                            <th>Kelas</th>
                            <th>Tahun Masuk</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    $current_kelas = null;
                    foreach ($rows as $row) {
                        // Cetak baris sub-header kelas saat kelas berganti
                        if ($row['nama_kelas'] !== $current_kelas) {
                            $current_kelas = $row['nama_kelas'];
                            $clean_kelas_label = $current_kelas ? preg_replace('/^Kelas\s+/i', '', trim($current_kelas)) : '';
                            $kelas_label = $clean_kelas_label ? 'Kelas ' . $romanize($clean_kelas_label) : 'Tanpa Kelas';
                            echo "<tr style='background-color:#dbeafe !important;'>
                                <td colspan='10' style='font-weight:bold; font-size:12px; color:#1e3a5f; padding:6px 10px; border:1px solid #94a3b8;'>
                                    &#128218; " . htmlspecialchars($kelas_label) . "
                                </td>
                            </tr>";
                        }
                        
                        $clean_row_kelas = $row['nama_kelas'] ? preg_replace('/^Kelas\s+/i', '', trim($row['nama_kelas'])) : '';
                        $formatted_row_kelas = $clean_row_kelas ? 'Kelas ' . $romanize($clean_row_kelas) : '-';

                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td style='font-family: monospace; white-space: nowrap;'>".htmlspecialchars($row['nis'])."</td>
                            <td style='font-family: monospace; white-space: nowrap;'>".htmlspecialchars($row['nisn'])."</td>
                            <td><strong>".htmlspecialchars($row['nama_lengkap'])."</strong></td>
                            <td align='center' style='white-space: nowrap;'>".$row['gender']."</td>
                            <td>".htmlspecialchars($row['agama'])."</td>
                            <td style='white-space: nowrap;'>".htmlspecialchars($row['no_hp_ortu'])."</td>
                            <td align='center' style='white-space: nowrap;'><strong>".htmlspecialchars($formatted_row_kelas)."</strong></td>
                            <td align='center' style='white-space: nowrap;'>".$row['tahun_masuk']."</td>
                            <td align='center' style='white-space: nowrap;'>".$row['status_siswa']."</td>
                        </tr>";
                    }
                    echo "</tbody>";
                    break;


                case 'guru':
                    $stmt = $pdo->query("SELECT g.*, k.nama_kelas FROM guru g LEFT JOIN kelas k ON k.wali_kelas_id = g.id ORDER BY CASE WHEN k.nama_kelas IS NULL THEN 1 ELSE 0 END, k.nama_kelas ASC, g.nama_guru ASC");
                    $rows = $stmt->fetchAll();
                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>NIP</th>
                            <th>Nama Guru</th>
                            <th>L/P</th>
                            <th>Kelas</th>
                            <th>Pendidikan</th>
                            <th>Jabatan</th>
                            <th>Mapel</th>
                            <th>No. HP</th>
                            <th>Alamat</th>
                            <th>Email</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    foreach ($rows as $row) {
                        $clean_kelas = $row['nama_kelas'] ? preg_replace('/^Kelas\s+/i', '', trim($row['nama_kelas'])) : '';
                        $kelas_name = $clean_kelas ? 'Kelas ' . $romanize($clean_kelas) : '-';
                        $mapel_name = !empty($row['mapel']) ? htmlspecialchars($row['mapel']) : '-';
                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td align='center' style='white-space: nowrap;'>".htmlspecialchars($row['nip'])."</td>
                            <td><strong>".htmlspecialchars($row['nama_guru'])."</strong></td>
                            <td align='center' style='white-space: nowrap;'>".$row['gender']."</td>
                            <td align='center' style='white-space: nowrap;'><strong>".htmlspecialchars($kelas_name)."</strong></td>
                            <td>".htmlspecialchars($row['pendidikan'])."</td>
                            <td>".htmlspecialchars($row['jabatan'])."</td>
                            <td align='center' style='white-space: nowrap;'>".$mapel_name."</td>
                            <td style='white-space: nowrap;'>".htmlspecialchars($row['no_hp'])."</td>
                            <td>".htmlspecialchars($row['alamat'])."</td>
                            <td style='white-space: nowrap;'>".htmlspecialchars($row['email'])."</td>
                        </tr>";
                    }
                    echo "</tbody>";
                    break;

                case 'karyawan':
                    $stmt = $pdo->query("SELECT * FROM karyawan ORDER BY nama ASC");
                    $rows = $stmt->fetchAll();
                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>NIK</th>
                            <th>Nama Karyawan</th>
                            <th>Jabatan</th>
                            <th>Unit Kerja</th>
                            <th>No HP</th>
                            <th>Alamat</th>
                            <th>Tgl Masuk</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    foreach ($rows as $row) {
                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td style='font-family: monospace; white-space: nowrap;'>".htmlspecialchars($row['nik'])."</td>
                            <td><strong>".htmlspecialchars($row['nama'])."</strong></td>
                            <td>".htmlspecialchars($row['jabatan'])."</td>
                            <td>".htmlspecialchars($row['unit_kerja'])."</td>
                            <td style='white-space: nowrap;'>".htmlspecialchars($row['no_hp'])."</td>
                            <td>".htmlspecialchars($row['alamat'])."</td>
                            <td align='center' style='white-space: nowrap;'>".date('d/m/Y', strtotime($row['tanggal_masuk']))."</td>
                            <td align='center' style='white-space: nowrap;'>".$row['status']."</td>
                        </tr>";
                    }
                    echo "</tbody>";
                    break;

                case 'inventaris':
                    $stmt = $pdo->query("SELECT i.*, k.nama_kategori, r.nama_ruangan FROM inventaris i JOIN kategori_barang k ON i.kategori_id = k.id LEFT JOIN ruangan r ON i.ruangan_id = r.id ORDER BY i.kode_barang ASC");
                    $rows = $stmt->fetchAll();
                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Aset</th>
                            <th>Nama Barang</th>
                            <th>Kategori</th>
                            <th>Merk</th>
                            <th>Thn Perolehan</th>
                            <th>Jml</th>
                            <th>Kondisi</th>
                            <th>Lokasi</th>
                            <th>Sumber Dana</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    foreach ($rows as $row) {
                        $peripheral_html = "";
                        if (!empty($row['sn_cpu']) || !empty($row['sn_monitor']) || !empty($row['sn_keyboard']) || !empty($row['sn_mouse']) || !empty($row['kode_cpu']) || !empty($row['kode_monitor']) || !empty($row['kode_keyboard']) || !empty($row['kode_mouse'])) {
                            $peripheral_html .= "<div style='font-size: 10px; margin-top: 4px; color: #777; line-height: 1.3;'>";
                            if (!empty($row['sn_cpu']) || !empty($row['kode_cpu'])) {
                                $peripheral_html .= "• CPU: " . htmlspecialchars($row['sn_cpu'] ?: '-') . " (" . htmlspecialchars($row['kode_cpu'] ?: '-') . ")<br>";
                            }
                            if ($row['nama_barang'] === 'PC Desktop' || $row['nama_kategori'] === 'PC Desktop Unit' || $row['nama_kategori'] === 'PC AIO') {
                                if (!empty($row['sn_monitor']) || !empty($row['kode_monitor'])) {
                                    $peripheral_html .= "• Monitor: " . htmlspecialchars($row['sn_monitor'] ?: '-') . " (" . htmlspecialchars($row['kode_monitor'] ?: '-') . ")<br>";
                                }
                                if (!empty($row['sn_keyboard']) || !empty($row['kode_keyboard'])) {
                                    $peripheral_html .= "• KB: " . htmlspecialchars($row['sn_keyboard'] ?: '-') . " (" . htmlspecialchars($row['kode_keyboard'] ?: '-') . ")<br>";
                                }
                                if (!empty($row['sn_mouse']) || !empty($row['kode_mouse'])) {
                                    $peripheral_html .= "• MS: " . htmlspecialchars($row['sn_mouse'] ?: '-') . " (" . htmlspecialchars($row['kode_mouse'] ?: '-') . ")<br>";
                                }
                            }
                            if (substr($peripheral_html, -4) === "<br>") {
                                $peripheral_html = substr($peripheral_html, 0, -4);
                            }
                            $peripheral_html .= "</div>";
                        }

                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td style='white-space: nowrap; font-family: monospace;'>".htmlspecialchars($row['kode_barang'])."</td>
                            <td>
                                <strong>".htmlspecialchars($row['nama_barang'])."</strong>
                                ".$peripheral_html."
                            </td>
                            <td>".htmlspecialchars($row['nama_kategori'])."</td>
                            <td>".htmlspecialchars($row['merk'])."</td>
                            <td align='center' style='white-space: nowrap;'>".htmlspecialchars($row['tahun_perolehan'] ?? '-')."</td>
                            <td align='center' style='white-space: nowrap;'>".intval($row['jumlah'])."</td>
                            <td align='center' style='white-space: nowrap;'>".$row['kondisi']."</td>
                            <td>".htmlspecialchars($row['nama_ruangan'] ?? '-')."</td>
                            <td align='center' style='white-space: nowrap;'>".htmlspecialchars($row['sumber_dana'])."</td>
                        </tr>";
                    }
                    echo "</tbody>";
                    break;

                case 'barang_rusak':
                    $stmt = $pdo->query("SELECT i.*, k.nama_kategori, r.nama_ruangan FROM inventaris i JOIN kategori_barang k ON i.kategori_id = k.id LEFT JOIN ruangan r ON i.ruangan_id = r.id WHERE i.kondisi = 'Rusak Berat' ORDER BY i.kode_barang ASC");
                    $rows = $stmt->fetchAll();
                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Aset</th>
                            <th>Nama Barang</th>
                            <th>Kategori</th>
                            <th>Merk</th>
                            <th>Thn Perolehan</th>
                            <th>Jml</th>
                            <th>Kondisi</th>
                            <th>Lokasi</th>
                            <th>Sumber Dana</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    foreach ($rows as $row) {
                        $peripheral_html = "";
                        if (!empty($row['sn_cpu']) || !empty($row['sn_monitor']) || !empty($row['sn_keyboard']) || !empty($row['sn_mouse']) || !empty($row['kode_cpu']) || !empty($row['kode_monitor']) || !empty($row['kode_keyboard']) || !empty($row['kode_mouse'])) {
                            $peripheral_html .= "<div style='font-size: 10px; margin-top: 4px; color: #777; line-height: 1.3;'>";
                            if (!empty($row['sn_cpu']) || !empty($row['kode_cpu'])) {
                                $peripheral_html .= "• CPU: " . htmlspecialchars($row['sn_cpu'] ?: '-') . " (" . htmlspecialchars($row['kode_cpu'] ?: '-') . ")<br>";
                            }
                            if ($row['nama_barang'] === 'PC Desktop' || $row['nama_kategori'] === 'PC Desktop Unit' || $row['nama_kategori'] === 'PC AIO') {
                                if (!empty($row['sn_monitor']) || !empty($row['kode_monitor'])) {
                                    $peripheral_html .= "• Monitor: " . htmlspecialchars($row['sn_monitor'] ?: '-') . " (" . htmlspecialchars($row['kode_monitor'] ?: '-') . ")<br>";
                                }
                                if (!empty($row['sn_keyboard']) || !empty($row['kode_keyboard'])) {
                                    $peripheral_html .= "• KB: " . htmlspecialchars($row['sn_keyboard'] ?: '-') . " (" . htmlspecialchars($row['kode_keyboard'] ?: '-') . ")<br>";
                                }
                                if (!empty($row['sn_mouse']) || !empty($row['kode_mouse'])) {
                                    $peripheral_html .= "• MS: " . htmlspecialchars($row['sn_mouse'] ?: '-') . " (" . htmlspecialchars($row['kode_mouse'] ?: '-') . ")<br>";
                                }
                            }
                            if (substr($peripheral_html, -4) === "<br>") {
                                $peripheral_html = substr($peripheral_html, 0, -4);
                            }
                            $peripheral_html .= "</div>";
                        }

                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td style='white-space: nowrap; font-family: monospace;'>".htmlspecialchars($row['kode_barang'])."</td>
                            <td>
                                <strong>".htmlspecialchars($row['nama_barang'])."</strong>
                                ".$peripheral_html."
                            </td>
                            <td>".htmlspecialchars($row['nama_kategori'])."</td>
                            <td>".htmlspecialchars($row['merk'])."</td>
                            <td align='center' style='white-space: nowrap;'>".htmlspecialchars($row['tahun_perolehan'] ?? '-')."</td>
                            <td align='center' style='white-space: nowrap;'>".intval($row['jumlah'])."</td>
                            <td align='center' style='color:red; font-weight:bold; white-space: nowrap;'>".$row['kondisi']."</td>
                            <td>".htmlspecialchars($row['nama_ruangan'] ?? '-')."</td>
                            <td align='center' style='white-space: nowrap;'>".htmlspecialchars($row['sumber_dana'])."</td>
                        </tr>";
                    }
                    echo "</tbody>";
                    break;

                case 'ruangan':
                    $stmt = $pdo->query("SELECT r.*, g.nama_guru FROM ruangan r LEFT JOIN guru g ON r.penanggung_jawab_id = g.id ORDER BY r.kode_ruangan ASC");
                    $rows = $stmt->fetchAll();
                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Ruangan</th>
                            <th>Nama Ruangan</th>
                            <th>Lantai</th>
                            <th>Kapasitas</th>
                            <th>Kondisi</th>
                            <th>Penanggung Jawab</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    foreach ($rows as $row) {
                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td style='font-family: monospace; white-space: nowrap;'>".htmlspecialchars($row['kode_ruangan'])."</td>
                            <td><strong>".htmlspecialchars($row['nama_ruangan'])."</strong></td>
                            <td align='center' style='white-space: nowrap;'>Lantai ".$row['lantai']."</td>
                            <td align='center' style='white-space: nowrap;'>".intval($row['kapasitas'])." Orang</td>
                            <td align='center' style='white-space: nowrap;'>".$row['kondisi']."</td>
                            <td>".htmlspecialchars($row['nama_guru'] ?? '-')."</td>
                        </tr>";
                    }
                    echo "</tbody>";
                    break;

                case 'alumni':
                    $stmt = $pdo->query("SELECT * FROM alumni ORDER BY tahun_lulus DESC, nama_alumni ASC");
                    $rows = $stmt->fetchAll();
                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>NIS</th>
                            <th>Nama Alumni</th>
                            <th>Tahun Lulus</th>
                            <th>No HP</th>
                            <th>Pekerjaan</th>
                            <th>Pendidikan Lanjutan</th>
                            <th>Alamat</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    foreach ($rows as $row) {
                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td style='font-family: monospace; white-space: nowrap;'>".htmlspecialchars($row['nis'])."</td>
                            <td><strong>".htmlspecialchars($row['nama_alumni'])."</strong></td>
                            <td align='center' style='white-space: nowrap;'>".$row['tahun_lulus']."</td>
                            <td style='white-space: nowrap;'>".htmlspecialchars($row['no_hp'])."</td>
                            <td>".htmlspecialchars($row['pekerjaan'])."</td>
                            <td>".htmlspecialchars($row['pendidikan_lanjutan'])."</td>
                            <td>".htmlspecialchars($row['alamat'])."</td>
                        </tr>";
                    }
                    echo "</tbody>";
                    break;

                case 'nilai':
                    // Helper to get teacher from mapel
                    $get_teacher = function($subject_name, $wali_kelas) use ($pdo) {
                        static $cache = [];
                        $clean_subject = strtolower(trim($subject_name));
                        if (isset($cache[$clean_subject])) {
                            return $cache[$clean_subject];
                        }
                        
                        try {
                            $stmt = $pdo->prepare("SELECT nama_guru FROM guru WHERE LOWER(mapel) LIKE :subject LIMIT 1");
                            $stmt->execute(['subject' => '%' . $clean_subject . '%']);
                            $name = $stmt->fetchColumn();
                            if ($name) {
                                $cache[$clean_subject] = $name;
                                return $name;
                            }
                        } catch (Exception $e) {}
                        
                        $cache[$clean_subject] = $wali_kelas ?: '-';
                        return $cache[$clean_subject];
                    };

                    // Query raport_siswa instead of nilai
                    $q = "SELECT r.*, s.nama_lengkap, s.nis, k.nama_kelas, g.nama_guru as nama_wali
                          FROM raport_siswa r
                          JOIN siswa s ON r.siswa_id = s.id
                          JOIN kelas k ON r.kelas_id = k.id
                          LEFT JOIN guru g ON k.wali_kelas_id = g.id
                          WHERE 1=1";
                    $p = [];
                    if (isset($_GET['tahun_ajaran']) && $_GET['tahun_ajaran'] !== '') {
                        $q .= " AND r.tahun_ajaran = :tahun_ajaran";
                        $p['tahun_ajaran'] = $_GET['tahun_ajaran'];
                    }
                    if (isset($_GET['semester']) && $_GET['semester'] !== '') {
                        $q .= " AND r.semester = :semester";
                        $p['semester'] = $_GET['semester'];
                    }
                    if (isset($_GET['kelas_id']) && $_GET['kelas_id'] !== '') {
                        $q .= " AND r.kelas_id = :kelas_id";
                        $p['kelas_id'] = intval($_GET['kelas_id']);
                    }
                    $q .= " ORDER BY k.nama_kelas ASC, s.nama_lengkap ASC";
                    $stmt = $pdo->prepare($q);
                    $stmt->execute($p);
                    $raports = $stmt->fetchAll();

                    // Transform report card JSON data to flat rows structure
                    $rows = [];
                    foreach ($raports as $raport) {
                        $academic_grades = json_decode($raport['academic_grades'], true) ?: [];
                        foreach ($academic_grades as $subject_key => $grade_item) {
                            $score = (isset($grade_item['score']) && $grade_item['score'] !== '') ? floatval($grade_item['score']) : null;
                            if ($score === null) continue; // skip if score is not filled
                            
                            $predikat = 'E';
                            if ($score >= 86) $predikat = 'A';
                            elseif ($score >= 75) $predikat = 'B';
                            elseif ($score >= 60) $predikat = 'C';
                            elseif ($score >= 45) $predikat = 'D';
                            
                            $nama_guru = $get_teacher($subject_key, $raport['nama_wali']);
                            
                            $rows[] = [
                                'nis' => $raport['nis'],
                                'nama_lengkap' => $raport['nama_lengkap'],
                                'nama_kelas' => $raport['nama_kelas'],
                                'mata_pelajaran' => $subject_key,
                                'nama_guru' => $nama_guru,
                                'semester' => $raport['semester'],
                                'tahun_ajaran' => $raport['tahun_ajaran'],
                                'nilai_tugas' => '',
                                'nilai_uts' => '',
                                'nilai_uas' => '',
                                'nilai_akhir' => $score,
                                'predikat' => $predikat
                            ];
                        }
                    }

                    // Group rows by class name
                    $grouped_grades = [];
                    foreach ($rows as $row) {
                        $kelas_name = $row['nama_kelas'] ?: 'Tanpa Kelas';
                        $grouped_grades[$kelas_name][] = $row;
                    }

                    if (empty($grouped_grades)) {
                        $grouped_grades['Tanpa Kelas'] = [];
                    }

                    $class_keys = array_keys($grouped_grades);
                    $total_classes = count($class_keys);
                    $class_index = 0;

                    // Resolve current local date inside case
                    $indo_months = [
                        'January' => 'Januari',
                        'February' => 'Februari',
                        'March' => 'Maret',
                        'April' => 'April',
                        'May' => 'Mei',
                        'June' => 'Juni',
                        'July' => 'Juli',
                        'August' => 'Agustus',
                        'September' => 'September',
                        'October' => 'Oktober',
                        'November' => 'November',
                        'December' => 'Desember'
                    ];
                    $local_date_id = strtr(date('d F Y'), $indo_months);

                    foreach ($grouped_grades as $kelas_name => $class_rows) {
                        $class_index++;
                        
                        // 1. Open print-container for this class
                        echo '<div class="print-container" style="margin-bottom: 30px; ' . ($class_index < $total_classes ? 'page-break-after: always;' : '') . '">';
                        
                        // 2. Kop Surat
                        echo '
                        <div class="report-kop-surat">
                            <div class="kop-logo-left">
                                <img src="' . $tut_wuri_src . '" alt="Logo Kemdikbud">
                            </div>
                            <div class="kop-title">
                                <div style="font-size: 13px; font-weight: bold; margin: 0; text-transform: uppercase; color: #091124;">Kementerian Pendidikan Dasar dan Menengah</div>
                                <div style="font-size: 13px; font-weight: bold; margin: 1px 0; text-transform: uppercase; color: #091124;">Dinas Pendidikan Kota Surabaya</div>
                                <h4>SD KRISTEN PETRA 1 SURABAYA</h4>
                                <p>Jalan WR. Supratman 46, Surabaya 60264 | Email: sd1@pppkpetra.sch.id</p>
                            </div>
                            <div class="kop-logo-right">
                                <img src="' . $logo_src . '" alt="Logo SD Kristen Petra 1">
                            </div>
                        </div>';
                        
                        // 3. Title & Subtitle
                        echo '
                        <div class="report-title">
                            ' . htmlspecialchars($full_title) . '
                        </div>';
                        
                        $class_filter_info = [];
                        if (isset($_GET['tahun_ajaran']) && $_GET['tahun_ajaran'] !== '') {
                            $class_filter_info[] = "Tahun Ajaran: " . htmlspecialchars($_GET['tahun_ajaran']);
                        }
                        if (isset($_GET['semester']) && $_GET['semester'] !== '') {
                            $class_filter_info[] = "Semester: " . ($_GET['semester'] === '1' ? '1 (Ganjil)' : '2 (Genap)');
                        }
                        $class_filter_info[] = "Kelas: " . ($kelas_name !== 'Tanpa Kelas' ? $romanize($kelas_name) : 'Tanpa Kelas');
                        
                        echo '
                        <div style="font-size: 12px; color: #475569; margin-top: -10px; margin-bottom: 20px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; text-align: left; width: 100%;">
                            <i class="fa-solid fa-filter me-1" style="color: #D4AF37;"></i> ' . implode(' &nbsp;|&nbsp; ', $class_filter_info) . '
                        </div>';
                        
                        // 4. Open Table & Head
                        echo '<table class="report-table-print">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>NIS</th>
                                    <th>Nama Siswa</th>
                                    <th>Kelas</th>
                                    <th>Mapel</th>
                                    <th>Guru Pengajar</th>
                                    <th>Semester</th>
                                    <th>Tugas</th>
                                    <th>UTS</th>
                                    <th>UAS</th>
                                    <th>Nilai Akhir</th>
                                    <th>Predikat</th>
                                </tr>
                            </thead>
                            <tbody>';
                            
                        if (empty($class_rows)) {
                            echo "<tr><td colspan='12' align='center' class='text-muted py-3'>Tidak ada data nilai untuk kelas ini.</td></tr>";
                        } else {
                            $no = 1;
                            foreach ($class_rows as $row) {
                                echo "<tr>
                                    <td align='center'>".$no++."</td>
                                    <td style='font-family: monospace;'>".htmlspecialchars($row['nis'])."</td>
                                    <td><strong>".htmlspecialchars($row['nama_lengkap'])."</strong></td>
                                    <td align='center'><strong>".($row['nama_kelas'] ? 'Kelas ' . $romanize($row['nama_kelas']) : '-')."</strong></td>
                                    <td>".htmlspecialchars($row['mata_pelajaran'])."</td>
                                    <td>".htmlspecialchars($row['nama_guru'])."</td>
                                    <td align='center'>".$row['semester']." (".$row['tahun_ajaran'].")</td>
                                    <td align='right'>".(is_numeric($row['nilai_tugas']) ? number_format($row['nilai_tugas'], 2) : '')."</td>
                                    <td align='right'>".(is_numeric($row['nilai_uts']) ? number_format($row['nilai_uts'], 2) : '')."</td>
                                    <td align='right'>".(is_numeric($row['nilai_uas']) ? number_format($row['nilai_uas'], 2) : '')."</td>
                                    <td align='right'><strong>".(is_numeric($row['nilai_akhir']) ? number_format($row['nilai_akhir'], 2) : '')."</strong></td>
                                    <td align='center'><strong>".$row['predikat']."</strong></td>
                                </tr>";
                            }
                        }
                        
                        // 5. Close Table
                        echo '</tbody>
                        </table>';
                        
                        // 6. Signature Block
                        echo '
                        <div style="margin-top: 25px; display: flex; justify-content: flex-end; font-size: 13px; page-break-inside: avoid;">
                            <div style="width: 250px; text-align: center;">
                                <p style="margin-bottom: 35px; line-height: 1.5; color: #0f172a;">Surabaya, ' . $local_date_id . '<br>Mengetahui,<br>Kepala Sekolah,</p>
                                <strong style="color: #0f172a;">Lilia, S.Pd., M.Psi.</strong><br>
                                <span style="color: #64748b; font-size: 11px;">NIP. -</span>
                            </div>
                        </div>';
                        
                        // 7. Close print-container
                        echo '</div>';
                    }
                    break;

                case 'peminjaman':
                    $stmt = $pdo->query("SELECT p.*, i.nama_barang, i.kode_barang FROM peminjaman p JOIN inventaris i ON p.inventaris_id = i.id ORDER BY p.tanggal_pinjam DESC");
                    $rows = $stmt->fetchAll();
                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Peminjaman</th>
                            <th>Nama Peminjam</th>
                            <th>Barang Aset</th>
                            <th>Tanggal Pinjam</th>
                            <th>Tanggal Kembali</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    foreach ($rows as $row) {
                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td font-family='monospace'>".htmlspecialchars($row['kode_peminjaman'])."</td>
                            <td>".htmlspecialchars($row['nama_peminjam'])."</td>
                            <td>".htmlspecialchars($row['nama_barang'])." (".htmlspecialchars($row['kode_barang']).")</td>
                            <td align='center'>".date('d/m/Y', strtotime($row['tanggal_pinjam']))."</td>
                            <td align='center'>".(!empty($row['tanggal_kembali']) ? date('d/m/Y', strtotime($row['tanggal_kembali'])) : '-')."</td>
                            <td align='center'>".$row['status']."</td>
                        </tr>";
                    }
                    echo "</tbody>";
                    break;

                case 'audit_log':
                    $stmt = $pdo->query("SELECT * FROM audit_log ORDER BY tanggal DESC");
                    $rows = $stmt->fetchAll();
                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>Waktu Kejadian</th>
                            <th>Username</th>
                            <th>Aktivitas</th>
                            <th>IP Address</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    foreach ($rows as $row) {
                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td align='center'>".date('d/m/Y H:i:s', strtotime($row['tanggal']))."</td>
                            <td>".htmlspecialchars($row['username'])."</td>
                            <td>".htmlspecialchars($row['aktivitas'])."</td>
                            <td align='center'>".htmlspecialchars($row['ip_address'])."</td>
                        </tr>";
                    }
                    echo "</tbody>";
                    break;

                case 'pengumuman':
                    $stmt = $pdo->query("SELECT p.*, u.nama FROM pengumuman p LEFT JOIN users u ON p.penulis_id = u.id ORDER BY p.tanggal DESC");
                    $rows = $stmt->fetchAll();
                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Judul</th>
                            <th>Isi Pengumuman</th>
                            <th>Penulis</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    foreach ($rows as $row) {
                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td align='center'>".date('d/m/Y', strtotime($row['tanggal']))."</td>
                            <td><strong>".htmlspecialchars($row['judul'])."</strong></td>
                            <td>".htmlspecialchars(strip_tags($row['isi']))."</td>
                            <td>".htmlspecialchars($row['nama'] ?? 'Admin')."</td>
                        </tr>";
                    }
                    echo "</tbody>";
                    break;

                case 'jurnal_harian':
                    $q = "SELECT jd.*, j.tanggal, j.hari, j.jabatan, g.nama_guru, g.nip, m.nama_mapel, k.nama_kelas, j.status
                          FROM jurnal_mengajar_detail jd
                          JOIN jurnal_mengajar j ON jd.jurnal_id = j.id
                          JOIN guru g ON j.guru_id = g.id
                          LEFT JOIN mata_pelajaran m ON jd.mapel_id = m.id
                          LEFT JOIN kelas k ON jd.kelas_id = k.id
                          WHERE 1=1";
                    $p = [];
                    
                    if (isset($_GET['guru_id']) && $_GET['guru_id'] !== '') {
                        $q .= " AND j.guru_id = :guru_id";
                        $p['guru_id'] = intval($_GET['guru_id']);
                    }
                    if (isset($_GET['kelas_id']) && $_GET['kelas_id'] !== '') {
                        $q .= " AND jd.kelas_id = :kelas_id";
                        $p['kelas_id'] = intval($_GET['kelas_id']);
                    }
                    if (isset($_GET['mapel_id']) && $_GET['mapel_id'] !== '') {
                        $q .= " AND jd.mapel_id = :mapel_id";
                        $p['mapel_id'] = intval($_GET['mapel_id']);
                    }
                    if (isset($_GET['tgl_mulai']) && $_GET['tgl_mulai'] !== '') {
                        $q .= " AND j.tanggal >= :tgl_mulai";
                        $p['tgl_mulai'] = $_GET['tgl_mulai'];
                    }
                    if (isset($_GET['tgl_selesai']) && $_GET['tgl_selesai'] !== '') {
                        $q .= " AND j.tanggal <= :tgl_selesai";
                        $p['tgl_selesai'] = $_GET['tgl_selesai'];
                    }
                    if (isset($_GET['ta_id']) && $_GET['ta_id'] !== '') {
                        $q .= " AND j.tahun_ajaran_id = :ta_id";
                        $p['ta_id'] = intval($_GET['ta_id']);
                    }
                    if (isset($_GET['semester_id']) && $_GET['semester_id'] !== '') {
                        $q .= " AND j.semester_id = :semester_id";
                        $p['semester_id'] = intval($_GET['semester_id']);
                    }

                    $q .= " ORDER BY j.tanggal ASC, jd.jam_ke ASC";
                    $stmt = $pdo->prepare($q);
                    $stmt->execute($p);
                    $rows = $stmt->fetchAll();

                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Hari</th>
                            <th>Nama Guru</th>
                            <th>NIP</th>
                            <th>Jam Ke</th>
                            <th>Mata Pelajaran</th>
                            <th>Kelas</th>
                            <th>Materi Pokok</th>
                            <th>Kegiatan KBM</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    foreach ($rows as $row) {
                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td align='center'>".date('d/m/Y', strtotime($row['tanggal']))."</td>
                            <td align='center'>".htmlspecialchars($row['hari'])."</td>
                            <td>".htmlspecialchars($row['nama_guru'])."</td>
                            <td font-family='monospace'>".htmlspecialchars($row['nip'])."</td>
                            <td align='center'>".$row['jam_ke']."</td>
                            <td>".htmlspecialchars($row['nama_mapel'] ?? '-')."</td>
                            <td>".htmlspecialchars($row['nama_kelas'] ?? '-')."</td>
                            <td>".htmlspecialchars($row['materi'])."</td>
                            <td>".htmlspecialchars($row['kegiatan'])."</td>
                        </tr>";
                    }
                    echo "</tbody>";
                    break;

                case 'jurnal_bulanan':
                    $bulan = isset($_GET['bulan']) && $_GET['bulan'] !== '' ? intval($_GET['bulan']) : intval(date('m'));
                    
                    $q = "SELECT g.id, g.nama_guru, g.nip,
                          (SELECT COUNT(*) FROM jurnal_mengajar_detail jd JOIN jurnal_mengajar j ON jd.jurnal_id = j.id WHERE j.guru_id = g.id AND MONTH(j.tanggal) = ?) as total_jam,
                          (SELECT COUNT(DISTINCT j.tanggal) FROM jurnal_mengajar j WHERE j.guru_id = g.id AND MONTH(j.tanggal) = ?) as total_hari
                          FROM guru g
                          ORDER BY g.nama_guru ASC";
                    
                    $stmt = $pdo->prepare($q);
                    $stmt->execute([$bulan, $bulan]);
                    $rows = $stmt->fetchAll();

                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Guru</th>
                            <th>NIP</th>
                            <th>Total Jam Mengajar</th>
                            <th>Total Hari Mengajar</th>
                            <th>Persentase Kehadiran</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    foreach ($rows as $row) {
                        $percentage = ($row['total_hari'] / 20) * 100;
                        if ($percentage > 100) $percentage = 100;
                        
                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td><strong>".htmlspecialchars($row['nama_guru'])."</strong></td>
                            <td style='font-family: monospace; white-space: nowrap;'>".htmlspecialchars($row['nip'])."</td>
                            <td align='center' style='white-space: nowrap;'>".$row['total_jam']." Jam</td>
                            <td align='center' style='white-space: nowrap;'>".$row['total_hari']." Hari</td>
                            <td align='center' style='white-space: nowrap;'>".number_format($percentage, 1)."%</td>
                        </tr>";
                    }
                    echo "</tbody>";
                    break;

                case 'jurnal_semester':
                    $ta_id = isset($_GET['ta_id']) && $_GET['ta_id'] !== '' ? intval($_GET['ta_id']) : null;
                    $semester_id = isset($_GET['semester_id']) && $_GET['semester_id'] !== '' ? intval($_GET['semester_id']) : null;

                    if (!$ta_id) {
                        $ta_id = $pdo->query("SELECT id FROM tahun_ajaran WHERE status = 'Aktif'")->fetchColumn();
                    }
                    if (!$semester_id) {
                        $semester_id = $pdo->query("SELECT id FROM semester WHERE status = 'Aktif'")->fetchColumn();
                    }

                    $q = "SELECT g.nama_guru, g.nip,
                          (SELECT COUNT(*) FROM jurnal_mengajar_detail jd JOIN jurnal_mengajar j ON jd.jurnal_id = j.id WHERE j.guru_id = g.id AND j.tahun_ajaran_id = ? AND j.semester_id = ?) as total_jam,
                          (SELECT COUNT(DISTINCT j.tanggal) FROM jurnal_mengajar j WHERE j.guru_id = g.id AND j.tahun_ajaran_id = ? AND j.semester_id = ?) as total_hari,
                          (SELECT COUNT(*) FROM jurnal_mengajar j WHERE j.guru_id = g.id AND j.tahun_ajaran_id = ? AND j.semester_id = ? AND j.status = 'Disetujui') as disetujui,
                          (SELECT COUNT(*) FROM jurnal_mengajar j WHERE j.guru_id = g.id AND j.tahun_ajaran_id = ? AND j.semester_id = ? AND j.status = 'Revisi') as revisi
                          FROM guru g
                          ORDER BY g.nama_guru ASC";
                    
                    $stmt = $pdo->prepare($q);
                    $stmt->execute([
                        $ta_id, $semester_id,
                        $ta_id, $semester_id,
                        $ta_id, $semester_id,
                        $ta_id, $semester_id
                    ]);
                    $rows = $stmt->fetchAll();

                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Guru</th>
                            <th>NIP</th>
                            <th>Total Jam Mengajar</th>
                            <th>Total Hari Mengajar</th>
                            <th>Jurnal Disetujui</th>
                            <th>Jurnal Perlu Revisi</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    foreach ($rows as $row) {
                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td><strong>".htmlspecialchars($row['nama_guru'])."</strong></td>
                            <td style='font-family: monospace; white-space: nowrap;'>".htmlspecialchars($row['nip'])."</td>
                            <td align='center' style='white-space: nowrap;'>".$row['total_jam']." Jam</td>
                            <td align='center' style='white-space: nowrap;'>".$row['total_hari']." Hari</td>
                            <td align='center' style='color:green; white-space: nowrap;'>".$row['disetujui']."</td>
                            <td align='center' style='color:red; white-space: nowrap;'>".$row['revisi']."</td>
                        </tr>";
                    }
                    echo "</tbody>";
                    break;

                case 'siswa_tingkat':
                    $tingkat = isset($_GET['tingkat']) ? $_GET['tingkat'] : '';
                    if (!in_array($tingkat, ['1', '2', '3', '4', '5', '6'])) {
                        die("Tingkat tidak valid.");
                    }
                    $stmt = $pdo->prepare("
                        SELECT s.*, k.nama_kelas 
                        FROM siswa s 
                        LEFT JOIN kelas k ON s.kelas_id = k.id 
                        WHERE k.tingkat = ? AND s.status_siswa = 'Aktif' 
                        ORDER BY k.nama_kelas ASC, s.nama_lengkap ASC
                    ");
                    $stmt->execute([$tingkat]);
                    $rows = $stmt->fetchAll();

                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>NIS</th>
                            <th>NISN</th>
                            <th>Nama Lengkap</th>
                            <th>L/P</th>
                            <th>Agama</th>
                            <th>Tempat, Tanggal Lahir</th>
                            <th>Nama Orang Tua</th>
                            <th>Alamat Domisili</th>
                            <th>Kelas</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    $current_kelas = null;
                    foreach ($rows as $row) {
                        if ($row['nama_kelas'] !== $current_kelas) {
                            $current_kelas = $row['nama_kelas'];
                            $kelas_label = $current_kelas ? $romanize($current_kelas) : 'Tanpa Kelas';
                            echo "<tr style='background-color:#dbeafe !important;'>
                                <td colspan='10' style='font-weight:bold; font-size:12px; color:#1e3a5f; padding:6px 10px; border:1px solid #94a3b8;'>
                                    &#128218; " . htmlspecialchars($kelas_label) . "
                                </td>
                            </tr>";
                        }
                        $ortu = $row['nama_ayah'] ?: ($row['nama_ibu'] ?: '-');
                        $ttl = $row['tempat_lahir'] . ', ' . ($row['tanggal_lahir'] ? date('d-m-Y', strtotime($row['tanggal_lahir'])) : '-');
                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td style='font-family: monospace;'>".htmlspecialchars($row['nis'])."</td>
                            <td style='font-family: monospace;'>".htmlspecialchars($row['nisn'])."</td>
                            <td><strong>".htmlspecialchars($row['nama_lengkap'])."</strong></td>
                            <td align='center'>".$row['gender']."</td>
                            <td>".htmlspecialchars($row['agama'])."</td>
                            <td>".htmlspecialchars($ttl)."</td>
                            <td>".htmlspecialchars($ortu)."</td>
                            <td>".htmlspecialchars($row['alamat'] ?: '-')."</td>
                            <td align='center'><strong>".($row['nama_kelas'] ? 'Kelas ' . $romanize($row['nama_kelas']) : '-')."</strong></td>
                        </tr>";
                    }
                    echo "</tbody>";
                    break;

                case 'rekap_tahun_ajaran':
                    $ta_id = isset($_GET['ta_id']) ? intval($_GET['ta_id']) : 0;
                    $ta_stmt = $pdo->prepare("SELECT tahun_ajaran FROM tahun_ajaran WHERE id = ?");
                    $ta_stmt->execute([$ta_id]);
                    $ta_name = $ta_stmt->fetchColumn() ?: '-';

                    $stmt = $pdo->prepare("
                        SELECT k.nama_kelas, k.tingkat, k.kapasitas, g.nama_guru,
                               (SELECT COUNT(*) FROM riwayat_kelas r JOIN siswa s ON r.siswa_id = s.id WHERE r.kelas_id = k.id AND r.tahun_ajaran_id = ? AND s.status_siswa = 'Aktif') as jumlah_siswa,
                               (SELECT COUNT(*) FROM riwayat_kelas r JOIN siswa s ON r.siswa_id = s.id WHERE r.kelas_id = k.id AND r.tahun_ajaran_id = ? AND s.status_siswa = 'Aktif' AND s.gender = 'L') as jumlah_l,
                               (SELECT COUNT(*) FROM riwayat_kelas r JOIN siswa s ON r.siswa_id = s.id WHERE r.kelas_id = k.id AND r.tahun_ajaran_id = ? AND s.status_siswa = 'Aktif' AND s.gender = 'P') as jumlah_p
                        FROM kelas k
                        LEFT JOIN guru g ON k.wali_kelas_id = g.id
                        WHERE k.status = 'Aktif'
                        ORDER BY k.nama_kelas ASC
                    ");
                    $stmt->execute([$ta_id, $ta_id, $ta_id]);
                    $rows = $stmt->fetchAll();

                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Kelas</th>
                            <th>Tingkat</th>
                            <th>Wali Kelas</th>
                            <th>Kapasitas</th>
                            <th>Siswa L</th>
                            <th>Siswa P</th>
                            <th>Total Siswa</th>
                            <th>Keterisian (%)</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    $tot_cap = 0;
                    $tot_l = 0;
                    $tot_p = 0;
                    $tot_siswa = 0;
                    foreach ($rows as $row) {
                        $fill_percent = $row['kapasitas'] > 0 ? round(($row['jumlah_siswa'] / $row['kapasitas']) * 100, 1) : 0;
                        $tot_cap += intval($row['kapasitas']);
                        $tot_l += intval($row['jumlah_l']);
                        $tot_p += intval($row['jumlah_p']);
                        $tot_siswa += intval($row['jumlah_siswa']);

                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td align='center'><strong>".($row['nama_kelas'] ? 'Kelas ' . $romanize($row['nama_kelas']) : '-')."</strong></td>
                            <td align='center'>Tingkat ".$row['tingkat']."</td>
                            <td>".htmlspecialchars($row['nama_guru'] ?: '-')."</td>
                            <td align='center'>".$row['kapasitas']."</td>
                            <td align='center'>".$row['jumlah_l']."</td>
                            <td align='center'>".$row['jumlah_p']."</td>
                            <td align='center'><strong>".$row['jumlah_siswa']."</strong></td>
                            <td align='center'>".$fill_percent."%</td>
                        </tr>";
                    }
                    $tot_fill_percent = $tot_cap > 0 ? round(($tot_siswa / $tot_cap) * 100, 1) : 0;
                    echo "<tr style='font-weight:bold; background-color:#f8fafc;'>
                        <td colspan='4' align='right'>TOTAL / RATA-RATA:</td>
                        <td align='center'>".$tot_cap."</td>
                        <td align='center'>".$tot_l."</td>
                        <td align='center'>".$tot_p."</td>
                        <td align='center'>".$tot_siswa."</td>
                        <td align='center'>".$tot_fill_percent."%</td>
                    </tr>";
                    echo "</tbody>";
                    break;

                case 'mutasi':
                    $ta_id = isset($_GET['ta_id']) && $_GET['ta_id'] !== '' ? intval($_GET['ta_id']) : null;
                    $q = "
                        SELECT s.nis, s.nisn, s.nama_lengkap, s.gender, r.status as status_riwayat, r.tanggal_masuk, k.nama_kelas, ta.tahun_ajaran
                        FROM riwayat_kelas r
                        JOIN siswa s ON r.siswa_id = s.id
                        JOIN kelas k ON r.kelas_id = k.id
                        JOIN tahun_ajaran ta ON r.tahun_ajaran_id = ta.id
                        WHERE r.status IN ('Pindahan', 'Keluar')
                    ";
                    $p = [];
                    if ($ta_id) {
                        $q .= " AND r.tahun_ajaran_id = ?";
                        $p[] = $ta_id;
                    }
                    $q .= " ORDER BY ta.tahun_ajaran DESC, r.tanggal_masuk DESC, s.nama_lengkap ASC";
                    $stmt = $pdo->prepare($q);
                    $stmt->execute($p);
                    $rows = $stmt->fetchAll();

                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>NIS</th>
                            <th>NISN</th>
                            <th>Nama Siswa</th>
                            <th>L/P</th>
                            <th>Jenis Mutasi</th>
                            <th>Tanggal Efektif</th>
                            <th>Kelas</th>
                            <th>Tahun Ajaran</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    foreach ($rows as $row) {
                        $status_label = $row['status_riwayat'] === 'Pindahan' ? 'Mutasi Masuk (Pindahan)' : 'Mutasi Keluar';
                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td style='font-family: monospace;'>".htmlspecialchars($row['nis'])."</td>
                            <td style='font-family: monospace;'>".htmlspecialchars($row['nisn'])."</td>
                            <td><strong>".htmlspecialchars($row['nama_lengkap'])."</strong></td>
                            <td align='center'>".$row['gender']."</td>
                            <td align='center'><span style='color: ".($row['status_riwayat'] === 'Pindahan' ? 'green' : 'red')."; font-weight: bold;'>".$status_label."</span></td>
                            <td align='center'>".date('d/m/Y', strtotime($row['tanggal_masuk']))."</td>
                            <td align='center'><strong>".($row['nama_kelas'] ? 'Kelas ' . $romanize($row['nama_kelas']) : '-')."</strong></td>
                            <td align='center'>".htmlspecialchars($row['tahun_ajaran'])."</td>
                        </tr>";
                    }
                    if (empty($rows)) {
                        echo "<tr><td colspan='9' align='center' class='text-muted py-3'>Tidak ada data mutasi siswa pada periode ini.</td></tr>";
                    }
                    echo "</tbody>";
                    break;

                case 'alumni_angkatan':
                    $ta_id = isset($_GET['ta_id']) ? intval($_GET['ta_id']) : 0;
                    $ta_stmt = $pdo->prepare("SELECT tahun_ajaran FROM tahun_ajaran WHERE id = ?");
                    $ta_stmt->execute([$ta_id]);
                    $ta_name = $ta_stmt->fetchColumn() ?: '-';

                    $stmt = $pdo->prepare("
                        SELECT s.*, k.nama_kelas
                        FROM riwayat_kelas r
                        JOIN siswa s ON r.siswa_id = s.id
                        LEFT JOIN kelas k ON r.kelas_id = k.id
                        WHERE r.tahun_ajaran_id = ? AND r.status = 'Lulus'
                        ORDER BY s.nama_lengkap ASC
                    ");
                    $stmt->execute([$ta_id]);
                    $rows = $stmt->fetchAll();

                    echo "<thead>
                        <tr>
                            <th>No</th>
                            <th>NIS</th>
                            <th>NISN</th>
                            <th>Nama Lengkap</th>
                            <th>L/P</th>
                            <th>Agama</th>
                            <th>Kelas Terakhir</th>
                            <th>Tahun Lulus (Angkatan)</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    foreach ($rows as $row) {
                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td style='font-family: monospace;'>".htmlspecialchars($row['nis'])."</td>
                            <td style='font-family: monospace;'>".htmlspecialchars($row['nisn'])."</td>
                            <td><strong>".htmlspecialchars($row['nama_lengkap'])."</strong></td>
                            <td align='center'>".$row['gender']."</td>
                            <td>".htmlspecialchars($row['agama'])."</td>
                            <td align='center'><strong>".($row['nama_kelas'] ? 'Kelas ' . $romanize($row['nama_kelas']) : '-')."</strong></td>
                            <td align='center'>".htmlspecialchars($ta_name)."</td>
                        </tr>";
                    }
                    if (empty($rows)) {
                        echo "<tr><td colspan='8' align='center' class='text-muted py-3'>Tidak ada data alumni untuk angkatan ini.</td></tr>";
                    }
                    echo "</tbody>";
                    break;

                case 'histori_siswa':
                    $siswa_id = isset($_GET['siswa_id']) ? intval($_GET['siswa_id']) : 0;
                    $siswa_stmt = $pdo->prepare("SELECT * FROM siswa WHERE id = ?");
                    $siswa_stmt->execute([$siswa_id]);
                    $student = $siswa_stmt->fetch();
                    if (!$student) {
                        die("Siswa tidak ditemukan.");
                    }

                    $stmt = $pdo->prepare("
                        SELECT r.status as status_placement, r.tanggal_masuk, k.nama_kelas, k.tingkat, ta.tahun_ajaran, g.nama_guru
                        FROM riwayat_kelas r
                        JOIN kelas k ON r.kelas_id = k.id
                        JOIN tahun_ajaran ta ON r.tahun_ajaran_id = ta.id
                        LEFT JOIN guru g ON k.wali_kelas_id = g.id
                        WHERE r.siswa_id = ?
                        ORDER BY ta.tahun_ajaran ASC
                    ");
                    $stmt->execute([$siswa_id]);
                    $rows = $stmt->fetchAll();

                    // Close the outer table that print.php automatically opened
                    echo "</table>";

                    // Output Profile Details
                    $ttl = $student['tempat_lahir'] . ', ' . ($student['tanggal_lahir'] ? date('d F Y', strtotime($student['tanggal_lahir'])) : '-');
                    echo "<div class='info-card-print mb-4'>
                        <div class='row' style='display:flex; flex-wrap:wrap;'>
                            <div style='flex:0 0 50%; max-width:50%; font-size:13px;'>
                                <table style='width:100%; border-collapse:collapse;'>
                                    <tr><td style='padding:4px 0; font-weight:bold; width:150px;'>Nama Lengkap</td><td>: ".htmlspecialchars($student['nama_lengkap'])."</td></tr>
                                    <tr><td style='padding:4px 0; font-weight:bold;'>NIS / NISN</td><td>: ".htmlspecialchars($student['nis'])." / ".htmlspecialchars($student['nisn'])."</td></tr>
                                    <tr><td style='padding:4px 0; font-weight:bold;'>Jenis Kelamin / Agama</td><td>: ".($student['gender'] === 'L' ? 'Laki-laki' : 'Perempuan')." / ".htmlspecialchars($student['agama'])."</td></tr>
                                    <tr><td style='padding:4px 0; font-weight:bold;'>Tempat, Tgl Lahir</td><td>: ".htmlspecialchars($ttl)."</td></tr>
                                </table>
                            </div>
                            <div style='flex:0 0 50%; max-width:50%; font-size:13px;'>
                                <table style='width:100%; border-collapse:collapse;'>
                                    <tr><td style='padding:4px 0; font-weight:bold; width:150px;'>Nama Orang Tua</td><td>: ".htmlspecialchars($student['nama_ayah'] ?: ($student['nama_ibu'] ?: '-'))."</td></tr>
                                    <tr><td style='padding:4px 0; font-weight:bold;'>Alamat Domisili</td><td>: ".htmlspecialchars($student['alamat'] ?: '-')."</td></tr>
                                    <tr><td style='padding:4px 0; font-weight:bold;'>Status Saat Ini</td><td>: <span style='font-weight:bold; color:".($student['status_siswa'] === 'Aktif' ? 'green' : 'blue').";'>".htmlspecialchars($student['status_siswa'])."</span></td></tr>
                                </table>
                            </div>
                        </div>
                    </div>";

                    echo "<h6 class='fw-bold mb-2' style='color:#091124; margin-top:20px;'>Riwayat Penempatan Kelas & Tahun Ajaran:</h6>";

                    // Re-open table for history logs
                    echo "<table class='report-table-print'>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tahun Ajaran</th>
                            <th>Tingkat</th>
                            <th>Kelas</th>
                            <th>Wali Kelas</th>
                            <th>Tanggal Masuk</th>
                            <th>Status Penempatan</th>
                        </tr>
                    </thead>
                    <tbody>";
                    $no = 1;
                    foreach ($rows as $row) {
                        echo "<tr>
                            <td align='center'>".$no++."</td>
                            <td align='center'><strong>".htmlspecialchars($row['tahun_ajaran'])."</strong></td>
                            <td align='center'>Tingkat ".$row['tingkat']."</td>
                            <td align='center'><strong>".($row['nama_kelas'] ? 'Kelas ' . $romanize($row['nama_kelas']) : '-')."</strong></td>
                            <td>".htmlspecialchars($row['nama_guru'] ?: '-')."</td>
                            <td align='center'>".date('d/m/Y', strtotime($row['tanggal_masuk']))."</td>
                            <td align='center'><strong>".htmlspecialchars($row['status_placement'])."</strong></td>
                        </tr>";
                    }
                    if (empty($rows)) {
                        echo "<tr><td colspan='7' align='center' class='text-muted py-3'>Belum ada riwayat penempatan kelas untuk siswa ini.</td></tr>";
                    }
                    echo "</tbody>";
                    echo "</table>";

                    // Fetch student grade history from raport_siswa
                    $hist_grades_stmt = $pdo->prepare("
                        SELECT r.*, k.nama_kelas
                        FROM raport_siswa r
                        JOIN kelas k ON r.kelas_id = k.id
                        WHERE r.siswa_id = ?
                        ORDER BY r.tahun_ajaran ASC, r.semester ASC
                    ");
                    $hist_grades_stmt->execute([$siswa_id]);
                    $hist_grades_rows = $hist_grades_stmt->fetchAll();

                    // Group by tahun_ajaran => [ semester => data ]
                    $hist_grades_by_ta = [];
                    foreach ($hist_grades_rows as $row) {
                        $ta = $row['tahun_ajaran'];
                        $sem = $row['semester'];
                        $hist_grades_by_ta[$ta][$sem] = [
                            'nama_kelas'  => $row['nama_kelas'],
                            'grades'      => json_decode($row['academic_grades'], true) ?: [],
                            'ekskul'      => json_decode($row['ekstrakurikuler'], true) ?: [],
                            'kokurikuler' => $row['kokurikuler_deskripsi'],
                            'sakit'       => $row['sakit'],
                            'izin'        => $row['izin'],
                            'alpa'        => $row['alpa']
                        ];
                    }

                    // Output Grade History transcript section
                    echo "<h6 class='fw-bold mb-2' style='color:#091124; margin-top:30px; font-size: 14px;'>Riwayat Perkembangan Akademik & Rapor Siswa:</h6>";
                    
                    if (empty($hist_grades_by_ta)) {
                        echo "<p style='font-size:12px; color:#555;'>Belum ada riwayat nilai akademik/rapor untuk siswa ini.</p>";
                    } else {
                        $default_subjects = [
                            'Agama' => 'Pendidikan Agama',
                            'Pancasila' => 'Pancasila',
                            'Bahasa Indonesia' => 'Bahasa Indonesia',
                            'Matematika' => 'Matematika',
                            'IPAS' => 'IPAS',
                            'PJOK' => 'PJOK',
                            'Seni Budaya' => 'Seni Budaya',
                            'Bhs. Inggris' => 'Bhs. Inggris',
                            'Bhs. Jawa' => 'Bhs. Jawa',
                            'Bhs. Mandarin' => 'Bhs. Mandarin'
                        ];

                        foreach ($hist_grades_by_ta as $ta => $semesters) {
                            // Find all subjects in this TA
                            $all_subjects_ta = [];
                            foreach ($semesters as $sdata) {
                                foreach (array_keys($sdata['grades']) as $sk) {
                                    $all_subjects_ta[$sk] = true;
                                }
                            }
                            $all_subjects_ta = array_keys($all_subjects_ta);
                            if (empty($all_subjects_ta)) {
                                $all_subjects_ta = array_keys($default_subjects);
                            }

                            echo "<div style='margin-bottom: 25px; page-break-inside: avoid;'>";
                            echo "<div style='font-size: 12px; font-weight: bold; background: #f1f5f9; padding: 6px 10px; border: 1px solid #cbd5e1; border-bottom: none;'>";
                            echo "Tahun Ajaran: " . htmlspecialchars($ta);
                            echo "</div>";

                            echo "<table class='report-table-print' style='margin-top: 0; margin-bottom: 10px; width: 100%; border-collapse: collapse;'>";
                            echo "<thead>";
                            echo "<tr>";
                            echo "<th style='width: 18%; text-align: left; font-size: 10px; padding: 6px; border: 1px solid #000; background: #e2e8f0;'>Mata Pelajaran</th>";
                            foreach ($semesters as $sem_num => $sdata) {
                                echo "<th colspan='2' style='text-align: center; font-size: 10px; padding: 6px; border: 1px solid #000; background: #e2e8f0;'>Semester $sem_num (Kelas: " . htmlspecialchars($sdata['nama_kelas']) . ")</th>";
                            }
                            echo "</tr>";
                            echo "<tr>";
                            echo "<th style='border: 1px solid #000; padding: 4px;'></th>";
                            foreach ($semesters as $sem_num => $sdata) {
                                echo "<th style='width: 6%; text-align: center; font-size: 9px; padding: 4px; border: 1px solid #000;'>Nilai</th>";
                                echo "<th style='width: 35%; text-align: left; font-size: 9px; padding: 4px; border: 1px solid #000;'>Capaian Kompetensi (Tertinggi)</th>";
                            }
                            echo "</tr>";
                            echo "</thead>";
                            echo "<tbody>";

                            foreach ($all_subjects_ta as $subj) {
                                $subj_display = $default_subjects[$subj] ?? $subj;
                                echo "<tr>";
                                echo "<td style='border: 1px solid #000; padding: 6px; font-size: 10px; font-weight: bold;'> " . htmlspecialchars($subj_display) . "</td>";
                                foreach ($semesters as $sem_num => $sdata) {
                                    $g = $sdata['grades'][$subj] ?? [];
                                    $score = isset($g['score']) && $g['score'] !== '' ? floatval($g['score']) : null;
                                    echo "<td style='border: 1px solid #000; padding: 6px; text-align: center; font-size: 11px; font-weight: bold;'>" . ($score !== null ? number_format($score, 0) : '—') . "</td>";
                                    echo "<td style='border: 1px solid #000; padding: 6px; font-size: 9.5px; line-height:1.3; text-align: justify;'>" . htmlspecialchars($g['desc_max'] ?? '—') . "</td>";
                                }
                                echo "</tr>";
                            }

                            // Average row
                            echo "<tr style='background: #f8fafc;'>";
                            echo "<td style='border: 1px solid #000; padding: 6px; font-size: 10px; font-weight: bold;'>📊 Rata-rata Akademik</td>";
                            foreach ($semesters as $sem_num => $sdata) {
                                $scores = array_filter(array_column($sdata['grades'], 'score'));
                                $avg = count($scores) > 0 ? round(array_sum($scores) / count($scores), 1) : null;
                                echo "<td colspan='2' style='border: 1px solid #000; padding: 6px; text-align: center; font-size: 11px; font-weight: bold; color: #6257DE;'>" . ($avg !== null ? number_format($avg, 1) : '—') . "</td>";
                            }
                            echo "</tr>";
                            echo "</tbody>";
                            echo "</table>";

                            // Attendance and Ekskul row
                            echo "<div style='display: flex; gap: 10px; margin-bottom: 15px;'>";
                            foreach ($semesters as $sem_num => $sdata) {
                                echo "<div style='flex: 1; border: 1px solid #cbd5e1; padding: 8px; font-size: 10px; background: #fafafa;'>";
                                echo "<div style='font-weight: bold; margin-bottom: 4px; border-bottom: 1px dashed #cbd5e1; padding-bottom: 2px;'>SEMESTER $sem_num — KEHADIRAN & EKSKUL</div>";
                                echo "<span style='margin-right: 10px;'>🤒 Sakit: <strong>" . intval($sdata['sakit']) . " hr</strong></span>";
                                echo "<span style='margin-right: 10px;'>📋 Izin: <strong>" . intval($sdata['izin']) . " hr</strong></span>";
                                echo "<span>❌ Alpa: <strong>" . intval($sdata['alpa']) . " hr</strong></span>";
                                if (!empty($sdata['ekskul'])) {
                                    echo "<div style='margin-top: 4px;'>";
                                    foreach ($sdata['ekskul'] as $ek) {
                                        echo "<span style='display:inline-block; border:1px solid #ccc; background:#fff; border-radius:4px; padding:1px 5px; font-size:8.5px; margin:2px 2px 0 0;'>⭐ " . htmlspecialchars($ek['nama'] ?? $ek['name'] ?? '') . " (" . htmlspecialchars($ek['predikat'] ?? $ek['predicate'] ?? $ek['grade'] ?? 'B') . ")</span>";
                                    }
                                    echo "</div>";
                                }
                                echo "</div>";
                            }
                            echo "</div>";
                            echo "</div>"; // end TA block
                        }
                    }
                    echo "<table style='display:none;'><tbody>";
                    break;

                default:
                    die("Tipe laporan tidak didukung.");
            }
        $indo_months = [
            'January' => 'Januari',
            'February' => 'Februari',
            'March' => 'Maret',
            'April' => 'April',
            'May' => 'Mei',
            'June' => 'Juni',
            'July' => 'Juli',
            'August' => 'Agustus',
            'September' => 'September',
            'October' => 'Oktober',
            'November' => 'November',
            'December' => 'Desember'
        ];
        $date_id = strtr(date('d F Y'), $indo_months);
        } catch (Exception $e) {
            die("Error Query Database: " . $e->getMessage());
        }
        ?>
    <?php if ($type !== 'nilai'): ?>
    </table>

    <div style="margin-top: 15px; display: flex; justify-content: flex-end; font-size: 13px; page-break-inside: avoid;">
        <div style="width: 250px; text-align: center;">
            <p style="margin-bottom: 20px; line-height: 1.5; color: #0f172a;">Surabaya, <?php echo $date_id; ?><br>Mengetahui,<br>Kepala Sekolah,</p>
            <strong style="color: #0f172a;">Lilia, S.Pd., M.Psi.</strong><br>
            <span style="color: #64748b; font-size: 11px;">NIP. -</span>
        </div>
    </div>

    </div>
    <?php endif; ?>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(() => {
                window.print();
            }, 500);
        });
    </script>
</body>
</html>
