<?php
// c:\xampp\htdocs\e-petraschool1\modules\guru\import.php

$page_title = 'Import Data Guru via CSV';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin','Admin']);

$error = ''; $success = ''; $preview = []; $errors_detail = [];

// Template download
if (isset($_GET['template'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="template_import_guru.csv"');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM untuk Excel
    fputcsv($out, ['nip','nama_guru','jenis_kelamin','tempat_lahir','tanggal_lahir','agama','no_hp','email','alamat','pendidikan_terakhir','jabatan','mata_pelajaran','status_kepegawaian']);
    fputcsv($out, ['198501012010011001','Budi Santoso','Laki-laki','Surabaya','1985-01-01','Kristen','08123456789','budi@sd.sch.id','Jl. Contoh No.1','S1 Pendidikan','Guru Kelas','Matematika','PNS']);
    fclose($out); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();
    $action = $_POST['action'] ?? 'preview';

    if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        $error = 'File CSV wajib diunggah!';
    } else {
        $file = $_FILES['csv_file']['tmp_name'];
        $ext  = strtolower(pathinfo($_FILES['csv_file']['name'], PATHINFO_EXTENSION));
        if ($ext !== 'csv') { $error = 'Hanya file .csv yang diterima!'; }
        else {
            $handle = fopen($file, 'r');
            $header = fgetcsv($handle);
            // Normalize BOM
            if ($header) $header[0] = ltrim($header[0], "\xEF\xBB\xBF");
            $required = ['nip','nama_guru','jenis_kelamin'];
            $missing  = array_diff($required, $header);
            if (!empty($missing)) {
                $error = 'Kolom wajib tidak ada: ' . implode(', ', $missing);
            } else {
                $rows = []; $row_num = 1;
                while (($row = fgetcsv($handle)) !== false) {
                    $row_num++;
                    if (count($row) < count($required)) { $errors_detail[] = "Baris $row_num: kolom tidak lengkap, dilewati."; continue; }
                    $data = array_combine($header, array_pad($row, count($header), ''));
                    if (empty(trim($data['nama_guru']))) { $errors_detail[] = "Baris $row_num: nama_guru kosong, dilewati."; continue; }
                    $rows[] = $data;
                }
                fclose($handle);

                if ($action === 'preview') {
                    $preview = $rows;
                } elseif ($action === 'import') {
                    $saved = 0; $skip = 0;
                    $ins = $pdo->prepare("INSERT INTO guru (nip,nama_guru,jenis_kelamin,tempat_lahir,tanggal_lahir,agama,no_hp,email,alamat,pendidikan_terakhir,jabatan,mata_pelajaran,status_kepegawaian)
                                          VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                                          ON DUPLICATE KEY UPDATE nama_guru=VALUES(nama_guru), no_hp=VALUES(no_hp), email=VALUES(email)");
                    foreach ($rows as $d) {
                        try {
                            $tgl = !empty($d['tanggal_lahir']) ? date('Y-m-d', strtotime($d['tanggal_lahir'])) : null;
                            $ins->execute([
                                trim($d['nip']??''), trim($d['nama_guru']), trim($d['jenis_kelamin']??'Laki-laki'),
                                trim($d['tempat_lahir']??''), $tgl, trim($d['agama']??''),
                                trim($d['no_hp']??''), trim($d['email']??''), trim($d['alamat']??''),
                                trim($d['pendidikan_terakhir']??''), trim($d['jabatan']??''), trim($d['mata_pelajaran']??''),
                                trim($d['status_kepegawaian']??'')
                            ]);
                            $saved++;
                        } catch (Exception $e) { $errors_detail[] = "Error untuk {$d['nama_guru']}: ".$e->getMessage(); $skip++; }
                    }
                    write_audit_log("Import data guru via CSV: $saved berhasil, $skip gagal.");
                    $success = "Import selesai! $saved guru berhasil" . ($skip?" ($skip gagal/duplikat)":'') . ".";
                }
            }
        }
    }
}
?>
<div class="glass-card" style="max-width:900px;margin:0 auto;">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-file-csv me-2"></i>Import Data Guru via CSV</h5>
            <p class="text-secondary small mb-0">Upload file CSV untuk menambah data guru secara massal.</p>
        </div>
        <div class="d-flex gap-2">
            <a href="?template=1" class="btn btn-outline-custom"><i class="fa-solid fa-download me-1"></i> Unduh Template CSV</a>
            <a href="index.php" class="btn btn-outline-custom"><i class="fa-solid fa-arrow-left me-1"></i> Kembali</a>
        </div>
    </div>

    <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><i class="fa-solid fa-check-circle me-2"></i><?php echo htmlspecialchars($success); ?></div><?php endif; ?>
    <?php if (!empty($errors_detail)): ?>
    <div class="alert alert-warning">
        <strong>Peringatan:</strong><ul class="mb-0 mt-1" style="font-size:12px;">
        <?php foreach ($errors_detail as $ed): ?><li><?php echo htmlspecialchars($ed); ?></li><?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <!-- Instructions -->
    <div style="background:rgba(59,130,246,.08);border:1px solid rgba(59,130,246,.2);border-radius:10px;padding:16px;margin-bottom:24px;">
        <h6 class="fw-bold" style="color:#3B82F6;font-size:13px;"><i class="fa-solid fa-circle-info me-2"></i>Petunjuk Import</h6>
        <ol style="font-size:12px;color:#94A3B8;margin:8px 0 0;padding-left:20px;">
            <li>Unduh template CSV di atas dan isi sesuai format</li>
            <li>Kolom <strong class="text-white">nama_guru</strong> dan <strong class="text-white">jenis_kelamin</strong> wajib diisi</li>
            <li>Format tanggal_lahir: <strong class="text-white">YYYY-MM-DD</strong> (mis: 1985-01-01)</li>
            <li>Data duplikat (NIP sama) akan diperbarui, bukan ditolak</li>
        </ol>
    </div>

    <!-- Upload Form -->
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
        <div class="row g-3 mb-4 align-items-end">
            <div class="col-md-6">
                <label class="form-label form-label-custom">File CSV <span class="text-danger">*</span></label>
                <input type="file" name="csv_file" class="form-control form-control-custom" accept=".csv" required>
            </div>
            <div class="col-auto">
                <button type="submit" name="action" value="preview" class="btn btn-outline-custom"><i class="fa-solid fa-eye me-1"></i> Preview</button>
            </div>
        </div>

        <?php if (!empty($preview)): ?>
        <div class="table-responsive mb-3">
            <p class="fw-bold text-gold mb-2"><i class="fa-solid fa-eye me-1"></i> Preview <?php echo count($preview); ?> baris data:</p>
            <table class="table table-custom" style="font-size:11px;">
                <thead><tr><th>#</th><th>NIP</th><th>Nama</th><th>Jenis Kelamin</th><th>Jabatan</th><th>Status</th></tr></thead>
                <tbody>
                    <?php $n=1; foreach ($preview as $p): ?>
                    <tr><td><?php echo $n++; ?></td><td class="font-monospace"><?php echo htmlspecialchars($p['nip']??''); ?></td><td><?php echo htmlspecialchars($p['nama_guru']); ?></td><td><?php echo htmlspecialchars($p['jenis_kelamin']??''); ?></td><td><?php echo htmlspecialchars($p['jabatan']??''); ?></td><td><?php echo htmlspecialchars($p['status_kepegawaian']??''); ?></td></tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <button type="submit" name="action" value="import" class="btn btn-gold"><i class="fa-solid fa-file-import me-1"></i> Konfirmasi & Import <?php echo count($preview); ?> Data</button>
        <?php endif; ?>
    </form>
</div>
<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
