<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\includes\footer.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$current_page = basename($_SERVER['SCRIPT_NAME']);
?>

        <?php if ($current_page !== 'login.php' && $current_page !== 'forgot-password.php'): ?>
                </main>
                
                <!-- Footer copyright bar -->
                <footer class="mt-auto py-3 text-center no-print" style="font-size: 11px; border-top: 1px solid var(--border); color: var(--text-2); letter-spacing: 0.2px;">
                    <span>&copy; <?php echo date('Y'); ?> SD Kristen Petra 1 Surabaya &mdash; Sistem Manajemen Sekolah Terintegrasi.</span>
                </footer>
            </div> <!-- End of main-workspace -->
        <?php endif; ?>

    </div> <!-- End of app-frame -->

    <!-- Bootstrap 5 Bundle with Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Main App Custom Script -->
    <script src="<?php echo $base_url; ?>assets/js/main.js"></script>

<?php if ($current_page !== 'login.php' && $current_page !== 'forgot-password.php' && is_logged_in()): ?>
<script>
// AJAX Notifikasi Polling — setiap 60 detik
(function() {
    function pollNotif() {
        fetch('<?php echo $base_url; ?>includes/notif_poll.php', { credentials: 'same-origin' })
            .then(r => r.json())
            .then(data => {
                const badge = document.getElementById('notif-badge');
                if (badge) {
                    if (data.count > 0) {
                        badge.textContent = data.count;
                        badge.style.display = '';
                    } else {
                        badge.style.display = 'none';
                    }
                }
            })
            .catch(() => {});
    }
    pollNotif();
    setInterval(pollNotif, 60000);
})();

// Session Inactivity Timeout Handler
(function() {
    const timeoutSeconds = 600; // 10 menit (600 detik)
    const warningSeconds = 60;  // Tampilkan peringatan 60 detik sebelum timeout
    let idleTime = 0;
    let warningShown = false;
    let countdownTimer = null;

    function resetIdleTimer() {
        idleTime = 0;
        if (warningShown) {
            Swal.close();
            warningShown = false;
            // Kirim heartbeat ke server untuk memperpanjang sesi server-side
            fetch('<?php echo $base_url; ?>includes/heartbeat.php')
                .catch(() => {});
        }
    }

    // Reset idleTime saat ada aktivitas pengguna
    const events = ['mousemove', 'keypress', 'click', 'scroll', 'touchstart'];
    events.forEach(eventName => {
        document.addEventListener(eventName, () => {
            if (!warningShown) {
                idleTime = 0;
            }
        }, true);
    });

    // Jalankan timer pengecekan inaktivitas setiap detik
    setInterval(() => {
        idleTime++;

        // Tampilkan SweetAlert2 jika waktu tidak aktif mencapai batas peringatan
        if (idleTime >= (timeoutSeconds - warningSeconds) && !warningShown) {
            warningShown = true;
            let timeLeft = warningSeconds;

            Swal.fire({
                title: 'Sesi Akan Berakhir!',
                html: 'Sesi Anda akan berakhir dalam <strong id="timeout-countdown">' + timeLeft + '</strong> detik karena tidak ada aktivitas.<br>Apakah Anda ingin tetap masuk?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, Tetap Masuk',
                cancelButtonText: 'Keluar Sekarang',
                confirmButtonColor: '#2563eb',
                cancelButtonColor: '#dc2626',
                allowOutsideClick: false,
                allowEscapeKey: false,
                didOpen: () => {
                    countdownTimer = setInterval(() => {
                        timeLeft--;
                        const el = document.getElementById('timeout-countdown');
                        if (el) el.textContent = timeLeft;

                        if (timeLeft <= 0) {
                            clearInterval(countdownTimer);
                            window.location.href = '<?php echo $base_url; ?>logout.php?reason=timeout';
                        }
                    }, 1000);
                },
                willClose: () => {
                    clearInterval(countdownTimer);
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    resetIdleTimer();
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    window.location.href = '<?php echo $base_url; ?>logout.php?reason=timeout';
                }
            });
        }

        // Fallback jika terjadi keterlambatan eksekusi JS browser
        if (idleTime >= timeoutSeconds) {
            window.location.href = '<?php echo $base_url; ?>logout.php?reason=timeout';
        }
    }, 1000);
})();
</script>
<?php endif; ?>
</body>
</html>

