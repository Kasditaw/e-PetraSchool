<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris_karyawan\edit.php

$page_title = 'Edit Penugasan Aset';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id <= 0 && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../karyawan/index.php");
    exit;
}

$error = '';

// Fetch assignment details
try {
    $stmt = $pdo->prepare("
        SELECT ik.*, k.nama as karyawan_nama, k.nik as karyawan_nik, i.nama_barang, i.kode_barang 
        FROM inventaris_karyawan ik
        JOIN karyawan k ON ik.karyawan_id = k.id
        JOIN inventaris i ON ik.inventaris_id = i.id
        WHERE ik.id = ?
    ");
    $stmt->execute([$id]);
    $assignment = $stmt->fetch();
    
    if (!$assignment && $_SERVER['REQUEST_METHOD'] !== 'POST') {
        die("<div class='alert alert-danger m-4'>Data penugasan tidak ditemukan.</div>");
    }
} catch (Exception $e) {
    die("<div class='alert alert-danger m-4'>Database Error: " . $e->getMessage() . "</div>");
}

// Handle POST Request for update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();
    
    $id = intval($_POST['id'] ?? 0);
    $karyawan_id = intval($_POST['karyawan_id'] ?? 0);
    $tanggal_mulai = $_POST['tanggal_mulai'] ?? '';
    $status = $_POST['status'] ?? 'Aktif';
    $tanggal_selesai = !empty($_POST['tanggal_selesai']) ? $_POST['tanggal_selesai'] : null;
    $keterangan = trim($_POST['keterangan'] ?? '');

    if ($status === 'Selesai' && empty($tanggal_selesai)) {
        $tanggal_selesai = date('Y-m-d');
    }
    if ($status === 'Aktif') {
        $tanggal_selesai = null;
    }
    
    if ($id <= 0 || empty($tanggal_mulai)) {
        $error = 'Tanggal mulai wajib diisi!';
    } else {
        try {
            $stmt = $pdo->prepare("
                UPDATE inventaris_karyawan 
                SET tanggal_mulai = ?, tanggal_selesai = ?, status = ?, keterangan = ?
                WHERE id = ? AND karyawan_id = ?
            ");
            $stmt->execute([$tanggal_mulai, $tanggal_selesai, $status, $keterangan, $id, $karyawan_id]);
            
            // Log update
            $log_msg = "Mengubah data penugasan aset ID: $id untuk karyawan ID: $karyawan_id. Status baru: $status.";
            write_audit_log($log_msg);
            
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire('Berhasil', 'Data penugasan aset berhasil diperbarui!', 'success').then(() => {
                        window.location.href = 'index.php?karyawan_id=$karyawan_id';
                    });
                });
            </script>";
            exit;
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>

<div class="glass-card" style="max-width: 650px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-pen-to-square me-2"></i> Edit Penugasan Aset Karyawan</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="edit.php">
        <?php csrf_input(); ?>
        <input type="hidden" name="id" value="<?php echo $assignment['id']; ?>">
        <input type="hidden" name="karyawan_id" value="<?php echo $assignment['karyawan_id']; ?>">

        <div class="row g-3">
            <div class="col-12">
                <label class="form-label form-label-custom">Nama Karyawan</label>
                <input type="text" class="form-control form-control-custom" style="background-color: rgba(255,255,255,0.03);" readonly value="<?php echo htmlspecialchars($assignment['karyawan_nama']) . ' (NIP: ' . htmlspecialchars($assignment['karyawan_nik']) . ')'; ?>">
            </div>

            <div class="col-12">
                <label class="form-label form-label-custom">Barang Aset / Inventaris</label>
                <input type="text" class="form-control form-control-custom" style="background-color: rgba(255,255,255,0.03);" readonly value="<?php echo htmlspecialchars($assignment['nama_barang']) . ' (' . htmlspecialchars($assignment['kode_barang']) . ')'; ?>">
            </div>

            <div class="col-12 col-md-6">
                <label for="tanggal_mulai" class="form-label form-label-custom">Tanggal Mulai Ditugaskan <span class="text-danger">*</span></label>
                <input type="date" name="tanggal_mulai" id="tanggal_mulai" class="form-control form-control-custom" value="<?php echo htmlspecialchars($assignment['tanggal_mulai']); ?>" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="status" class="form-label form-label-custom">Status</label>
                <select name="status" id="status" class="form-select form-control-custom bg-dark-select text-white" onchange="toggleEndDateField()">
                    <option value="Aktif" <?php echo $assignment['status'] === 'Aktif' ? 'selected' : ''; ?>>Aktif</option>
                    <option value="Selesai" <?php echo $assignment['status'] === 'Selesai' ? 'selected' : ''; ?>>Selesai (Diakhiri)</option>
                </select>
            </div>

            <div class="col-12" id="tanggal_selesai_container" <?php echo $assignment['status'] === 'Selesai' ? '' : 'style="display: none;"'; ?>>
                <label for="tanggal_selesai" class="form-label form-label-custom">Tanggal Selesai Ditugaskan</label>
                <input type="date" name="tanggal_selesai" id="tanggal_selesai" class="form-control form-control-custom" value="<?php echo htmlspecialchars($assignment['tanggal_selesai'] ?? date('Y-m-d')); ?>">
            </div>

            <div class="col-12">
                <label for="keterangan" class="form-label form-label-custom">Keterangan / Catatan Penugasan</label>
                <textarea name="keterangan" id="keterangan" class="form-control form-control-custom" rows="3" placeholder="Alasan, kondisi barang, dll."><?php echo htmlspecialchars($assignment['keterangan']); ?></textarea>
            </div>

            <div class="col-12 d-flex justify-content-end gap-2 mt-4">
                <a href="index.php?karyawan_id=<?php echo $assignment['karyawan_id']; ?>" class="btn btn-outline-custom">Batal</a>
                <button type="submit" class="btn btn-gold">Simpan Perubahan <i class="fa-solid fa-check ms-1"></i></button>
            </div>
        </div>
    </form>
</div>

<script>
function toggleEndDateField() {
    const statusSelect = document.getElementById('status');
    const endDateContainer = document.getElementById('tanggal_selesai_container');
    const endDateInput = document.getElementById('tanggal_selesai');
    
    if (statusSelect.value === 'Selesai') {
        endDateContainer.style.display = 'block';
        endDateInput.setAttribute('required', 'required');
    } else {
        endDateContainer.style.display = 'none';
        endDateInput.removeAttribute('required');
    }
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
