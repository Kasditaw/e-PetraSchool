<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris\pengembalian.php

$page_title = 'Pengembalian Barang';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_inventaris_access();

$error = '';
$success = '';

// Handle Return Process
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'return_item') {
    require_role(['Super Admin', 'Admin']);
    check_csrf_request();
    
    $peminjaman_id = intval($_POST['peminjaman_id'] ?? 0);
    $tanggal_kembali = $_POST['tanggal_kembali'] ?? date('Y-m-d');
    
    if ($peminjaman_id > 0) {
        try {
            // Fetch borrowing and asset info
            $stmt = $pdo->prepare("
                SELECT p.*, i.nama_barang, i.kode_barang 
                FROM peminjaman p 
                JOIN inventaris i ON p.inventaris_id = i.id 
                WHERE p.id = ? AND p.status = 'Dipinjam'
            ");
            $stmt->execute([$peminjaman_id]);
            $borrow = $stmt->fetch();
            
            if ($borrow) {
                $pdo->beginTransaction();
                
                // Update status in peminjaman table
                $update = $pdo->prepare("UPDATE peminjaman SET status = 'Dikembalikan', tanggal_kembali = ? WHERE id = ?");
                $update->execute([$tanggal_kembali, $peminjaman_id]);
                
                // Add entry to histori_inventaris
                $hist = $pdo->prepare("INSERT INTO histori_inventaris (inventaris_id, aktivitas, pengguna, keterangan) VALUES (?, 'Pengembalian', ?, ?)");
                $hist->execute([
                    $borrow['inventaris_id'],
                    $_SESSION['nama'] ?? 'Admin',
                    "Barang " . $borrow['nama_barang'] . " (" . $borrow['kode_barang'] . ") dikembalikan oleh " . $borrow['nama_peminjam']
                ]);
                
                write_audit_log("Mencatat pengembalian barang: " . $borrow['nama_barang'] . " oleh " . $borrow['nama_peminjam']);
                
                $pdo->commit();
                
                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Barang berhasil dikembalikan!', 'success').then(() => {
                            window.location.href = 'pengembalian.php';
                        });
                    });
                </script>";
                exit;
            } else {
                $error = 'Transaksi peminjaman tidak ditemukan atau sudah dikembalikan.';
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = 'Gagal memproses pengembalian: ' . $e->getMessage();
        }
    } else {
        $error = 'ID Peminjaman tidak valid.';
    }
}

// Fetch active loans
try {
    $stmt = $pdo->query("
        SELECT p.*, i.nama_barang, i.kode_barang, i.foto_barang 
        FROM peminjaman p 
        JOIN inventaris i ON p.inventaris_id = i.id 
        WHERE p.status = 'Dipinjam' 
        ORDER BY p.tanggal_pinjam DESC
    ");
    $active_loans = $stmt->fetchAll();
} catch (Exception $e) {
    $active_loans = [];
    $error = 'Database error: ' . $e->getMessage();
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-arrow-rotate-left me-2"></i> Pengembalian Aset Sekolah</h5>
            <p class="text-secondary small mb-0">Kelola dan catat pengembalian aset sekolah yang sedang dipinjam oleh guru atau staf.</p>
        </div>
        <div>
            <a href="../peminjaman/index.php" class="btn btn-outline-custom"><i class="fa-solid fa-list me-1"></i> Log Semua Peminjaman</a>
        </div>
    </div>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Transaksi</th>
                    <th>Peminjam</th>
                    <th>Barang Aset</th>
                    <th>Tanggal Pinjam</th>
                    <th>Durasi Pinjam</th>
                    <th class="text-center">
                        <?php if (has_role(['Super Admin', 'Admin'])): ?>
                        Aksi Cepat
                        <?php endif; ?>
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($active_loans) > 0): ?>
                    <?php 
                    $no = 1; 
                    foreach ($active_loans as $loan): 
                        // Calculate days borrowed
                        $tgl_pinjam = new DateTime($loan['tanggal_pinjam']);
                        $today = new DateTime();
                        $diff = $today->diff($tgl_pinjam);
                        $days = $diff->days;
                        $duration_text = $days == 0 ? 'Hari ini' : $days . ' hari';
                    ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><span class="badge badge-secondary"><?php echo htmlspecialchars($loan['kode_peminjaman']); ?></span></td>
                            <td class="fw-semibold text-white"><?php echo htmlspecialchars($loan['nama_peminjam']); ?></td>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <?php if (!empty($loan['foto_barang'])): ?>
                                        <img src="<?php echo $base_url; ?>assets/uploads/inventaris/<?php echo $loan['foto_barang']; ?>" alt="Foto" class="rounded border" style="width: 35px; height: 30px; object-fit: cover;">
                                    <?php endif; ?>
                                    <div>
                                        <strong class="text-white"><?php echo htmlspecialchars($loan['nama_barang']); ?></strong>
                                        <span class="text-secondary small d-block font-monospace"><?php echo htmlspecialchars($loan['kode_barang']); ?></span>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo date('d M Y', strtotime($loan['tanggal_pinjam'])); ?></td>
                            <td>
                                <span class="badge <?php echo $days > 7 ? 'bg-danger text-white' : 'badge-warning'; ?>">
                                    <?php echo $duration_text; ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                <form method="POST" action="pengembalian.php" class="d-inline return-form">
                                    <?php csrf_input(); ?>
                                    <input type="hidden" name="action" value="return_item">
                                    <input type="hidden" name="peminjaman_id" value="<?php echo $loan['id']; ?>">
                                    <input type="hidden" name="tanggal_kembali" value="<?php echo date('Y-m-d'); ?>">
                                    <button type="button" class="btn btn-xs btn-success btn-return" data-peminjam="<?php echo htmlspecialchars($loan['nama_peminjam']); ?>" data-barang="<?php echo htmlspecialchars($loan['nama_barang']); ?>">
                                        <i class="fa-solid fa-check me-1"></i> Kembalikan
                                    </button>
                                </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center text-secondary py-4">Tidak ada barang yang sedang dipinjam saat ini.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const returnButtons = document.querySelectorAll('.btn-return');
    returnButtons.forEach(button => {
        button.addEventListener('click', function() {
            const form = this.closest('form');
            const peminjam = this.getAttribute('data-peminjam');
            const barang = this.getAttribute('data-barang');
            
            Swal.fire({
                title: 'Konfirmasi Pengembalian',
                text: `Apakah Anda yakin ingin mencatat pengembalian ${barang} oleh ${peminjam}?`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ya, Kembalikan!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    });
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
