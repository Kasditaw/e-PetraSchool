<?php
// c:\xampp\htdocs\e-petraschool1\modules\absensi_siswa\input.php

$page_title = 'Input Absensi Siswa';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error   = '';
$success = '';

$filter_kelas    = isset($_GET['kelas_id'])       ? intval($_GET['kelas_id'])       : 0;
$filter_ta       = isset($_GET['tahun_ajaran_id']) ? intval($_GET['tahun_ajaran_id']): 0;
$filter_semester = isset($_GET['semester_id'])     ? intval($_GET['semester_id'])    : 0;
$filter_tanggal  = isset($_GET['tanggal'])          ? $_GET['tanggal']                : date('Y-m-d');

try {
    $kelas_list = $pdo->query("SELECT id, nama_kelas FROM kelas WHERE status = 'Aktif' ORDER BY nama_kelas ASC")->fetchAll();
    $ta_list    = $pdo->query("SELECT id, tahun_ajaran, status FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();
    $sem_list   = $pdo->query("SELECT id, semester, status FROM semester ORDER BY semester ASC")->fetchAll();

    if (!$filter_ta)       { foreach ($ta_list  as $t) { if ($t['status'] === 'Aktif') { $filter_ta       = $t['id']; break; } } }
    if (!$filter_semester) { foreach ($sem_list as $s) { if ($s['status'] === 'Aktif') { $filter_semester = $s['id']; break; } } }

    // Siswa di kelas
    $siswa_list = [];
    if ($filter_kelas) {
        $ss = $pdo->prepare("SELECT id, nis, nama_lengkap, gender FROM siswa WHERE kelas_id = ? AND status_siswa = 'Aktif' ORDER BY nama_lengkap ASC");
        $ss->execute([$filter_kelas]);
        $siswa_list = $ss->fetchAll();

        // Cek absensi yang sudah ada untuk tanggal & kelas ini
        if (!empty($siswa_list)) {
            $ids = array_column($siswa_list, 'id');
            $ph  = implode(',', array_fill(0, count($ids), '?'));
            $ex  = $pdo->prepare("SELECT siswa_id, status, keterangan FROM absensi_siswa WHERE siswa_id IN ($ph) AND tanggal = ?");
            $ex->execute(array_merge($ids, [$filter_tanggal]));
            $existing = [];
            foreach ($ex->fetchAll() as $e) {
                $existing[$e['siswa_id']] = ['status' => $e['status'], 'keterangan' => $e['keterangan']];
            }
        }
    }

} catch (Exception $e) {
    $error = $e->getMessage();
}

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($error)) {
    check_csrf_request();

    $kelas_id = intval($_POST['kelas_id'] ?? 0);
    $tanggal  = $_POST['tanggal'] ?? '';
    $ta_id    = intval($_POST['tahun_ajaran_id'] ?? 0);
    $sem_id   = intval($_POST['semester_id'] ?? 0);
    $absensi  = $_POST['absensi'] ?? [];

    if (!$kelas_id || !$tanggal || !$ta_id || !$sem_id || empty($absensi)) {
        $error = 'Data tidak lengkap!';
    } else {
        try {
            $ins = $pdo->prepare("
                INSERT INTO absensi_siswa (siswa_id, kelas_id, tanggal, status, keterangan, dicatat_oleh, tahun_ajaran_id, semester_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE status=VALUES(status), keterangan=VALUES(keterangan), dicatat_oleh=VALUES(dicatat_oleh)
            ");

            $saved = 0;
            foreach ($absensi as $siswa_id => $data) {
                $st   = $data['status'] ?? 'Hadir';
                $ket  = trim($data['keterangan'] ?? '');
                $ins->execute([intval($siswa_id), $kelas_id, $tanggal, $st, $ket, $_SESSION['user_id'], $ta_id, $sem_id]);
                $saved++;
            }

            write_audit_log("Input absensi siswa: $saved siswa pada tanggal $tanggal.");
            $success = "Absensi untuk $saved siswa berhasil disimpan!";

            // Reload existing data
            $ids = array_keys($absensi);
            $ph  = implode(',', array_fill(0, count($ids), '?'));
            $ex  = $pdo->prepare("SELECT siswa_id, status, keterangan FROM absensi_siswa WHERE siswa_id IN ($ph) AND tanggal = ?");
            $ex->execute(array_merge($ids, [$tanggal]));
            $existing = [];
            foreach ($ex->fetchAll() as $e) {
                $existing[$e['siswa_id']] = ['status' => $e['status'], 'keterangan' => $e['keterangan']];
            }

        } catch (Exception $e) {
            $error = 'Gagal menyimpan: ' . $e->getMessage();
        }
    }
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-user-check me-2"></i>Input Absensi Siswa</h5>
            <p class="text-secondary small mb-0">Input kehadiran siswa per kelas dan tanggal.</p>
        </div>
        <a href="index.php" class="btn btn-outline-custom"><i class="fa-solid fa-arrow-left me-1"></i> Kembali</a>
    </div>

    <?php if ($error): ?><div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><i class="fa-solid fa-circle-check me-2"></i><?php echo htmlspecialchars($success); ?></div><?php endif; ?>

    <!-- Filter Form -->
    <form method="GET" action="input.php" class="row g-3 mb-4 align-items-end">
        <div class="col-6 col-md-3">
            <label class="form-label form-label-custom">Kelas <span class="text-danger">*</span></label>
            <select name="kelas_id" class="form-select form-control-custom bg-dark-select text-white" required>
                <option value="">-- Pilih Kelas --</option>
                <?php foreach ($kelas_list as $kl): ?>
                    <option value="<?php echo $kl['id']; ?>" <?php echo $filter_kelas == $kl['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($kl['nama_kelas']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-6 col-md-3">
            <label class="form-label form-label-custom">Tanggal <span class="text-danger">*</span></label>
            <input type="date" name="tanggal" class="form-control form-control-custom" value="<?php echo htmlspecialchars($filter_tanggal); ?>" required>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Tahun Ajaran</label>
            <select name="tahun_ajaran_id" class="form-select form-control-custom bg-dark-select text-white">
                <?php foreach ($ta_list as $ta): ?>
                    <option value="<?php echo $ta['id']; ?>" <?php echo $filter_ta == $ta['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($ta['tahun_ajaran']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Semester</label>
            <select name="semester_id" class="form-select form-control-custom bg-dark-select text-white">
                <?php foreach ($sem_list as $sm): ?>
                    <option value="<?php echo $sm['id']; ?>" <?php echo $filter_semester == $sm['id'] ? 'selected' : ''; ?>>
                        Sem <?php echo htmlspecialchars($sm['semester']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom"><i class="fa-solid fa-search me-1"></i> Tampilkan</button>
        </div>
    </form>

    <?php if (!empty($siswa_list) && $filter_kelas): ?>
        <!-- Quick Action Buttons -->
        <div class="d-flex gap-2 mb-3 flex-wrap">
            <button type="button" onclick="setAllStatus('Hadir')" class="btn btn-sm" style="background:rgba(16,185,129,.2); color:#10B981; border:1px solid #10B981;">
                <i class="fa-solid fa-check me-1"></i> Semua Hadir
            </button>
            <button type="button" onclick="setAllStatus('Alfa')" class="btn btn-sm" style="background:rgba(239,68,68,.2); color:#EF4444; border:1px solid #EF4444;">
                <i class="fa-solid fa-xmark me-1"></i> Semua Alfa
            </button>
            <span class="text-secondary small align-self-center ms-2">
                <i class="fa-solid fa-info-circle me-1"></i>
                Tanggal: <strong class="text-white"><?php echo date('l, d F Y', strtotime($filter_tanggal)); ?></strong>
                <?php if (isset($existing) && count($existing) > 0): ?>
                    &nbsp;|&nbsp; <span class="text-warning"><i class="fa-solid fa-pencil me-1"></i>Data sudah ada — akan ditimpa</span>
                <?php endif; ?>
            </span>
        </div>

        <form method="POST" action="input.php?kelas_id=<?php echo $filter_kelas; ?>&tanggal=<?php echo urlencode($filter_tanggal); ?>&tahun_ajaran_id=<?php echo $filter_ta; ?>&semester_id=<?php echo $filter_semester; ?>">
            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
            <input type="hidden" name="kelas_id" value="<?php echo $filter_kelas; ?>">
            <input type="hidden" name="tanggal" value="<?php echo htmlspecialchars($filter_tanggal); ?>">
            <input type="hidden" name="tahun_ajaran_id" value="<?php echo $filter_ta; ?>">
            <input type="hidden" name="semester_id" value="<?php echo $filter_semester; ?>">

            <div class="table-responsive">
                <table class="table table-custom">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama Siswa</th>
                            <th>NIS</th>
                            <th style="text-align:center;">
                                <span style="color:#10B981;">Hadir</span>
                            </th>
                            <th style="text-align:center;">
                                <span style="color:#F59E0B;">Sakit</span>
                            </th>
                            <th style="text-align:center;">
                                <span style="color:#3B82F6;">Izin</span>
                            </th>
                            <th style="text-align:center;">
                                <span style="color:#EF4444;">Alfa</span>
                            </th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; foreach ($siswa_list as $siswa):
                            $cur_status = $existing[$siswa['id']]['status'] ?? 'Hadir';
                            $cur_ket    = $existing[$siswa['id']]['keterangan'] ?? '';
                        ?>
                        <tr id="row-<?php echo $siswa['id']; ?>">
                            <td><?php echo $no++; ?></td>
                            <td>
                                <strong class="text-white"><?php echo htmlspecialchars($siswa['nama_lengkap']); ?></strong>
                                <span class="badge ms-1" style="font-size:9px; background:<?php echo $siswa['gender']==='L' ? 'rgba(59,130,246,.2)' : 'rgba(236,72,153,.2)'; ?>; color:<?php echo $siswa['gender']==='L' ? '#3B82F6' : '#EC4899'; ?>;"><?php echo $siswa['gender'] === 'L' ? 'L' : 'P'; ?></span>
                            </td>
                            <td><span class="text-secondary font-monospace" style="font-size:12px;"><?php echo htmlspecialchars($siswa['nis']); ?></span></td>
                            <?php foreach (['Hadir','Sakit','Izin','Alfa'] as $st):
                                $colors = ['Hadir'=>'#10B981','Sakit'=>'#F59E0B','Izin'=>'#3B82F6','Alfa'=>'#EF4444'];
                            ?>
                            <td style="text-align:center;">
                                <label style="cursor:pointer;">
                                    <input type="radio"
                                           name="absensi[<?php echo $siswa['id']; ?>][status]"
                                           value="<?php echo $st; ?>"
                                           class="status-radio d-none"
                                           data-siswa="<?php echo $siswa['id']; ?>"
                                           <?php echo $cur_status === $st ? 'checked' : ''; ?>
                                           onchange="updateRowColor(<?php echo $siswa['id']; ?>, '<?php echo $st; ?>', '<?php echo $colors[$st]; ?>')">
                                    <span class="status-btn" id="btn-<?php echo $siswa['id']; ?>-<?php echo $st; ?>"
                                          style="display:inline-flex; align-items:center; justify-content:center; width:36px; height:36px; border-radius:8px; border:2px solid <?php echo $cur_status === $st ? $colors[$st] : 'rgba(255,255,255,.1)'; ?>; background:<?php echo $cur_status === $st ? $colors[$st].'33' : 'transparent'; ?>; color:<?php echo $cur_status === $st ? $colors[$st] : '#64748B'; ?>; font-weight:700; font-size:12px; transition:all .15s;">
                                        <?php echo substr($st,0,1); ?>
                                    </span>
                                </label>
                            </td>
                            <?php endforeach; ?>
                            <td>
                                <input type="text" name="absensi[<?php echo $siswa['id']; ?>][keterangan]"
                                       class="form-control form-control-custom" style="font-size:12px; padding:6px 10px;"
                                       placeholder="Opsional..." maxlength="100"
                                       value="<?php echo htmlspecialchars($cur_ket); ?>">
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="d-flex gap-3 mt-3">
                <button type="submit" class="btn btn-gold"><i class="fa-solid fa-floppy-disk me-1"></i> Simpan Absensi</button>
                <a href="index.php?kelas_id=<?php echo $filter_kelas; ?>" class="btn btn-outline-custom">Lihat Rekap</a>
            </div>
        </form>
    <?php elseif ($filter_kelas): ?>
        <div class="text-center py-5">
            <i class="fa-solid fa-user-slash" style="font-size:48px; color:rgba(255,255,255,.15);"></i>
            <p class="text-secondary mt-3">Tidak ada siswa aktif di kelas ini.</p>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="fa-solid fa-hand-pointer" style="font-size:48px; color:rgba(255,255,255,.15);"></i>
            <p class="text-secondary mt-3">Pilih kelas dan tanggal untuk mulai input absensi.</p>
        </div>
    <?php endif; ?>
</div>

<script>
const statusColors = {
    'Hadir': '#10B981',
    'Sakit': '#F59E0B',
    'Izin':  '#3B82F6',
    'Alfa':  '#EF4444'
};

function updateRowColor(siswaId, status, color) {
    ['Hadir','Sakit','Izin','Alfa'].forEach(st => {
        const btn = document.getElementById(`btn-${siswaId}-${st}`);
        if (!btn) return;
        const c = statusColors[st];
        if (st === status) {
            btn.style.borderColor  = c;
            btn.style.background   = c + '33';
            btn.style.color        = c;
        } else {
            btn.style.borderColor  = 'rgba(255,255,255,.1)';
            btn.style.background   = 'transparent';
            btn.style.color        = '#64748B';
        }
    });
}

function setAllStatus(status) {
    document.querySelectorAll('.status-radio').forEach(radio => {
        if (radio.value === status) {
            radio.checked = true;
            const siswaId = radio.getAttribute('data-siswa');
            updateRowColor(siswaId, status, statusColors[status]);
        }
    });
}

// Init colors on load
document.querySelectorAll('.status-radio:checked').forEach(radio => {
    const siswaId = radio.getAttribute('data-siswa');
    updateRowColor(siswaId, radio.value, statusColors[radio.value]);
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
