<?php
// c:\xampp\htdocs\e-petraschool1\modules\pengaturan\index.php

$page_title = 'Pengaturan Sistem';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';
$success = '';

// Load current settings
try {
    $stmt = $pdo->query("SELECT * FROM pengaturan_sistem");
    $settings_raw = $stmt->fetchAll();
    
    $settings = [];
    foreach ($settings_raw as $s) {
        $settings[$s['nama_kunci']] = $s['nilai_kunci'];
    }
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $nama_sekolah = trim($_POST['nama_sekolah'] ?? 'SD Kristen Petra 1');
    
    // File upload logo_sekolah
    $logo_name = $settings['logo_sekolah'] ?? '';
    if (isset($_FILES['logo_sekolah']) && $_FILES['logo_sekolah']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['logo_sekolah']['tmp_name'];
        $file_name = $_FILES['logo_sekolah']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed_exts = ['jpg', 'jpeg', 'png'];
        $mime_type = mime_content_type($file_tmp);
        $allowed_mimes = ['image/jpeg', 'image/png', 'image/pjpeg'];
        
        if (in_array($file_ext, $allowed_exts) && in_array($mime_type, $allowed_mimes)) {
            $upload_dir = dirname(dirname(__DIR__)) . '/assets/uploads/pengaturan/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            // Delete old logo if exists
            if (!empty($logo_name) && file_exists($upload_dir . $logo_name)) {
                unlink($upload_dir . $logo_name);
            }
            
            $logo_name = 'logo_' . time() . '.' . $file_ext;
            if (move_uploaded_file($file_tmp, $upload_dir . $logo_name)) {
                // Success
            } else {
                $error = 'Gagal menyimpan file logo baru.';
            }
        } else {
            $error = 'Format file logo salah. Hanya menerima JPG, JPEG, atau PNG.';
        }
    }

    if ($error === '') {
        try {
            // Update nama_sekolah
            $upd1 = $pdo->prepare("INSERT INTO pengaturan_sistem (nama_kunci, nilai_kunci) VALUES ('nama_sekolah', ?) ON DUPLICATE KEY UPDATE nilai_kunci = ?");
            $upd1->execute([$nama_sekolah, $nama_sekolah]);

            // Update logo_sekolah
            $upd2 = $pdo->prepare("INSERT INTO pengaturan_sistem (nama_kunci, nilai_kunci) VALUES ('logo_sekolah', ?) ON DUPLICATE KEY UPDATE nilai_kunci = ?");
            $upd2->execute([$logo_name, $logo_name]);

            write_audit_log("Mengubah pengaturan sistem (Nama Sekolah: $nama_sekolah).");
            
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire('Berhasil', 'Pengaturan berhasil diperbarui!', 'success').then(() => {
                        window.location.href = 'index.php';
                    });
                });
            </script>";
        } catch (Exception $e) {
            $error = 'Database Error: ' . $e->getMessage();
        }
    }
}
?>

<div class="glass-card" style="max-width: 650px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-gears me-2"></i> Pengaturan Sistem & Identitas Sekolah</h5>
    <p class="text-secondary small mb-4">Ubah identitas sekolah dan logo yang akan ditampilkan di aplikasi e-Jurnal Mengajar.</p>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="index.php" enctype="multipart/form-data">
        <?php csrf_input(); ?>

        <div class="mb-4">
            <label for="nama_sekolah" class="form-label form-label-custom">Nama Sekolah <span class="text-danger">*</span></label>
            <input type="text" name="nama_sekolah" id="nama_sekolah" class="form-control form-control-custom" value="<?php echo htmlspecialchars($settings['nama_sekolah'] ?? 'SD Kristen Petra 1'); ?>" required>
        </div>

        <div class="mb-4">
            <label for="logo_sekolah" class="form-label form-label-custom">Logo Sekolah</label>
            <div class="d-flex align-items-center gap-4">
                <div class="p-2 bg-dark bg-opacity-50 border border-secondary border-opacity-10 rounded text-center d-flex align-items-center justify-content-center" style="width: 100px; height: 100px;">
                    <?php 
                        $logo_path = !empty($settings['logo_sekolah']) ? $base_url . 'assets/uploads/pengaturan/' . $settings['logo_sekolah'] : 'https://img.icons8.com/color/96/school.png';
                    ?>
                    <img id="logo-preview" src="<?php echo $logo_path; ?>" alt="Logo Sekolah" style="max-width: 100%; max-height: 100%; object-fit: contain;">
                </div>
                <div class="flex-grow-1">
                    <input type="file" name="logo_sekolah" id="logo_sekolah" class="form-control form-control-custom" accept="image/*" onchange="previewImage(event)">
                    <span class="text-secondary small d-block mt-2">Menerima format JPG, JPEG, PNG. Ukuran maksimal 2MB.</span>
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-end gap-2 mt-4 pt-2 border-top border-secondary border-opacity-10">
            <button type="submit" class="btn btn-gold px-4">Perbarui Pengaturan <i class="fa-solid fa-check ms-1"></i></button>
        </div>
    </form>
</div>

<script>
function previewImage(event) {
    const reader = new FileReader();
    reader.onload = function(){
        const output = document.getElementById('logo-preview');
        output.src = reader.result;
    }
    reader.readAsDataURL(event.target.files[0]);
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
