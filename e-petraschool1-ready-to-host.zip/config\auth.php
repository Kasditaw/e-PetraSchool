<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\config\auth.php

if (session_status() === PHP_SESSION_NONE) {
    // Set secure session cookie parameters
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    ini_set('session.cookie_samesite', 'Lax');

    // Enable Secure flag automatically when served over HTTPS
    $is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
                || (($_SERVER['SERVER_PORT'] ?? 80) == 443);
    ini_set('session.cookie_secure', $is_https ? 1 : 0);

    session_start();
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/audit.php';

/**
 * Compute the application's base URL dynamically.
 * Uses APP_URL from env.php if set, otherwise auto-detects from DOCUMENT_ROOT.
 * @return string Base URL with trailing slash (e.g., '/e-petraschool1/' or '/')
 */
function _get_base_url() {
    static $cached = null;
    if ($cached !== null) return $cached;

    // Check env.php for explicit APP_URL
    $env_path = __DIR__ . '/env.php';
    if (file_exists($env_path)) {
        $env = require $env_path;
        if (!empty($env['APP_URL'])) {
            $url = $env['APP_URL'];
            if (substr($url, -1) !== '/') $url .= '/';
            if (substr($url, 0, 1) !== '/') $url = '/' . $url;
            $cached = str_replace('//', '/', $url);
            return $cached;
        }
    }

    // Auto-detect from DOCUMENT_ROOT
    $project_dir = str_replace('\\', '/', dirname(__DIR__));
    $web_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
    $base_url = str_replace($web_root, '', $project_dir);
    if (empty($base_url)) {
        $base_url = '/';
    } else {
        if (substr($base_url, 0, 1) !== '/') $base_url = '/' . $base_url;
        if (substr($base_url, -1) !== '/') $base_url .= '/';
    }
    $cached = str_replace('//', '/', $base_url);
    return $cached;
}

/**
 * Check if user is logged in
 */
function is_logged_in() {
    global $pdo;

    // Check session first
    if (isset($_SESSION['user_id'])) {
        return true;
    }

    // Check remember me cookie
    if (isset($_COOKIE['petra_remember'])) {
        $token = $_COOKIE['petra_remember'];
        try {
            $stmt = $pdo->prepare("SELECT u.*, r.nama_role FROM users u JOIN roles r ON u.role_id = r.id WHERE u.remember_token = ? LIMIT 1");
            $stmt->execute([$token]);
            $user = $stmt->fetch();

            if ($user) {
                if (isset($user['status_aktif']) && $user['status_aktif'] === 'Tidak Aktif') {
                    // Token invalid since user is inactive
                    setcookie('petra_remember', '', time() - 3600, '/', '', false, true);
                    return false;
                }

                // Set session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['nama'] = $user['nama'];
                $_SESSION['role'] = $user['nama_role'];
                $_SESSION['role_id'] = $user['role_id'];
                $_SESSION['guru_id'] = $user['guru_id'] ?? null;
                
                // Regenerate session for security
                session_regenerate_id(true);
                
                write_audit_log("User login otomatis via Remember Me Cookie.", $user['id'], $user['username']);
                return true;
            }
        } catch (Exception $e) {
            error_log("Remember me cookie error: " . $e->getMessage());
        }
    }

    return false;
}

/**
 * Require user to be logged in
 */
function check_login() {
    if (!is_logged_in()) {
        // Compute base URL dynamically
        $login_path = _get_base_url() . 'login.php';
        
        header("Location: " . $login_path);
        exit;
    }

    // Special restriction for user '199302001'
    if (isset($_SESSION['username']) && $_SESSION['username'] === '199302001') {
        $allowed_scripts = [
            'dashboard.php', // modules/inventaris/dashboard.php
            'index.php',     // modules/inventaris/index.php
            'create.php',    // modules/inventaris/create.php
            'logout.php'
        ];
        
        $current_script = basename($_SERVER['SCRIPT_NAME']);
        $current_uri = str_replace('\\', '/', $_SERVER['REQUEST_URI']);
        
        $is_allowed = false;
        if (in_array($current_script, $allowed_scripts)) {
            if (strpos($current_uri, '/modules/inventaris/') !== false || $current_script === 'logout.php') {
                $is_allowed = true;
            }
        }
        
        if (!$is_allowed) {
            $redirect_url = _get_base_url() . 'modules/inventaris/dashboard.php';
            
            header("Location: " . $redirect_url);
            exit;
        }
    }
}

/**
 * Check if user has specific role or roles
 * @param array|string $allowed_roles
 * @return bool
 */
function has_role($allowed_roles) {
    if (!isset($_SESSION['role'])) {
        return false;
    }

    // Special override: user '201807007' has all privileges
    if (isset($_SESSION['username']) && $_SESSION['username'] === '201807007') {
        return true;
    }

    if (is_array($allowed_roles)) {
        return in_array($_SESSION['role'], $allowed_roles);
    }

    return $_SESSION['role'] === $allowed_roles;
}

/**
 * Enforce role permission, abort with error if unauthorized
 * @param array|string $allowed_roles
 */
function require_role($allowed_roles) {
    check_login();
    if (!has_role($allowed_roles)) {
        write_audit_log("Percobaan akses halaman tanpa hak izin role (" . (is_array($allowed_roles) ? implode(', ', $allowed_roles) : $allowed_roles) . ").");
        http_response_code(403);
        
        // Redirect to dashboard or error page
        $dashboard_path = _get_base_url() . 'modules/dashboard/index.php';
        
        echo "<!DOCTYPE html>
        <html>
        <head>
            <title>Akses Ditolak - SD Kristen Petra 1</title>
            <link href='https://fonts.googleapis.com/css2?family=Outfit:wght@400;600&display=swap' rel='stylesheet'>
            <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css'>
            <style>
                body { background-color: #050A18; color: #fff; font-family: 'Outfit', sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
                .card { text-align: center; background: rgba(18, 28, 54, 0.6); padding: 40px; border-radius: 12px; border: 1px solid rgba(255, 255, 255, 0.08); max-width: 500px; box-shadow: 0 8px 32px rgba(0,0,0,0.5); }
                h1 { color: #EF4444; margin-top: 0; }
                p { color: #94A3B8; margin-bottom: 24px; }
                .btn { background: linear-gradient(135deg, #D4AF37 0%, #F3CD48 100%); color: #000; text-decoration: none; padding: 10px 20px; border-radius: 6px; font-weight: 600; display: inline-flex; align-items: center; gap: 8px; }
            </style>
        </head>
        <body>
            <div class='card'>
                <i class='fa-solid fa-triangle-exclamation' style='font-size: 48px; color: #EF4444; margin-bottom: 16px;'></i>
                <h1>Akses Ditolak</h1>
                <p>Maaf, Anda tidak memiliki izin untuk mengakses halaman ini. Halaman ini memerlukan hak akses role: <strong>" . (is_array($allowed_roles) ? implode(', ', $allowed_roles) : $allowed_roles) . "</strong>.</p>
                <a href='$dashboard_path' class='btn'><i class='fa-solid fa-house'></i> Kembali ke Dashboard</a>
            </div>
        </body>
        </html>";
        exit;
    }
}

/**
 * Check if the current logged-in user can access the Inventaris module.
 * Access is granted to:
 *  - Super Admin and Admin (always)
 *  - Any user whose guru_id / associated NIP is in inventaris_akses_nip table
 *    (checked via session username match against karyawan records)
 *
 * @return bool
 */
function can_access_inventaris() {
    global $pdo;

    // Super Admin and Admin always have access
    if (has_role(['Super Admin', 'Admin'])) {
        return true;
    }

    // Cache result in session to avoid repeated DB queries
    if (isset($_SESSION['inventaris_akses'])) {
        return (bool) $_SESSION['inventaris_akses'];
    }

    // Check if the current user's username matches a registered NIP in inventaris_akses_nip
    // (Admin can link a karyawan NIP to a user account via the akses_nip page)
    try {
        $user_id = $_SESSION['user_id'] ?? 0;
        // Check by stored nip in session (set at login) or by user_id linkage
        // We check via a simple lookup: if any NIP in inventaris_akses_nip
        // matches the logged-in username (as some admins set username = NIP)
        $username = $_SESSION['username'] ?? '';

        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM inventaris_akses_nip ian
            JOIN karyawan k ON ian.karyawan_id = k.id
            WHERE ian.nip = ? OR k.nik = ?
        ");
        $stmt->execute([$username, $username]);
        $found = $stmt->fetchColumn() > 0;

        $_SESSION['inventaris_akses'] = $found;
        return $found;
    } catch (Exception $e) {
        return false;
    }
}

/**
 * Require inventaris access, redirect with error if unauthorized
 */
function require_inventaris_access() {
    check_login();
    if (!can_access_inventaris()) {
        write_audit_log("Percobaan akses modul Inventaris tanpa NIP terdaftar.");
        http_response_code(403);
        $dashboard_path = file_exists('../dashboard/index.php') ? '../dashboard/index.php' : '../../modules/dashboard/index.php';
        echo "<!DOCTYPE html>
        <html><head>
            <title>Akses Ditolak - Inventaris</title>
            <link href='https://fonts.googleapis.com/css2?family=Outfit:wght@400;600&display=swap' rel='stylesheet'>
            <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css'>
            <style>
                body{background:#050A18;color:#fff;font-family:'Outfit',sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;}
                .card{text-align:center;background:rgba(18,28,54,.6);padding:40px;border-radius:12px;border:1px solid rgba(255,255,255,.08);max-width:500px;box-shadow:0 8px 32px rgba(0,0,0,.5);}
                h1{color:#EF4444;margin-top:0;}p{color:#94A3B8;margin-bottom:24px;}
                .btn{background:linear-gradient(135deg,#D4AF37 0%,#F3CD48 100%);color:#000;text-decoration:none;padding:10px 20px;border-radius:6px;font-weight:600;display:inline-flex;align-items:center;gap:8px;}
            </style>
        </head><body>
            <div class='card'>
                <i class='fa-solid fa-lock' style='font-size:48px;color:#EF4444;margin-bottom:16px;'></i>
                <h1>Akses Ditolak</h1>
                <p>NIP Anda tidak terdaftar sebagai petugas inventaris.<br>Hubungi Admin untuk mendapatkan akses.</p>
                <a href='$dashboard_path' class='btn'><i class='fa-solid fa-house'></i> Kembali ke Dashboard</a>
            </div>
        </body></html>";
        exit;
    }
}

// ── Session Inactivity Timeout (10 minutes) ──────────────────────────────────
if (isset($_SESSION['user_id'])) {
    $current_script = basename($_SERVER['SCRIPT_NAME']);
    $is_polling = ($current_script === 'notif_poll.php');
    $is_logout = ($current_script === 'logout.php');
    
    $timeout_duration = 600; // 10 menit (600 detik)
    
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timeout_duration)) {
        if (!$is_polling && !$is_logout) {
            $base_url = _get_base_url();
            header("Location: " . $base_url . "logout.php?reason=timeout");
            exit;
        }
    } else {
        if (!$is_polling && !$is_logout) {
            $_SESSION['last_activity'] = time();
        }
    }
}
?>
