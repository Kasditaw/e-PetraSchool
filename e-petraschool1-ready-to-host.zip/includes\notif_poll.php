<?php
// c:\xampp\htdocs\e-petraschool1\includes\notif_poll.php
// AJAX endpoint — polling notifikasi terbaru

require_once __DIR__ . '/../config/auth.php';

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['count' => 0]);
    exit;
}

header('Content-Type: application/json');

try {
    require_once __DIR__ . '/../config/db.php';

    $last_seen = isset($_SESSION['notif_last_seen']) ? $_SESSION['notif_last_seen'] : date('Y-m-d H:i:s', strtotime('-24 hours'));

    $count = 0;
    $items = [];

    // Pengumuman baru (hari ini)
    $pengumuman = $pdo->prepare("SELECT COUNT(*) FROM pengumuman WHERE tanggal >= CURDATE() AND created_at > ?");
    $pengumuman->execute([$last_seen]);
    $peng_count = intval($pengumuman->fetchColumn());
    if ($peng_count > 0) {
        $count += $peng_count;
        $items[] = ['type' => 'pengumuman', 'text' => "$peng_count pengumuman baru", 'url' => 'modules/pengumuman/index.php'];
    }

    // Jurnal menunggu verifikasi (hanya untuk Kepsek/Admin)
    if (in_array($_SESSION['role'] ?? '', ['Kepala Sekolah', 'Super Admin', 'Admin'])) {
        $jurnal = $pdo->query("SELECT COUNT(*) FROM jurnal_mengajar WHERE status='Menunggu Verifikasi'")->fetchColumn();
        if ($jurnal > 0) {
            $count += $jurnal;
            $items[] = ['type' => 'jurnal', 'text' => "$jurnal jurnal menunggu verifikasi", 'url' => 'modules/jurnal/verifikasi_ks.php'];
        }
    }

    echo json_encode(['count' => $count, 'items' => $items, 'ts' => date('H:i:s')]);

} catch (Exception $e) {
    echo json_encode(['count' => 0, 'items' => [], 'error' => $e->getMessage()]);
}
