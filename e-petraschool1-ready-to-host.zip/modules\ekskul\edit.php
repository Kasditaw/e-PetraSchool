<?php
// c:\xampp\htdocs\e-petraschool1\modules\ekskul\edit.php
$page_title = 'Edit Ekstrakurikuler';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin','Admin']);
$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }
try {
    $guru_list = $pdo->query("SELECT id,nama_guru FROM guru ORDER BY nama_guru ASC")->fetchAll();
    $ta_list   = $pdo->query("SELECT id,tahun_ajaran,status FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();
    $stmt = $pdo->prepare("SELECT * FROM ekskul WHERE id=?"); $stmt->execute([$id]);
    $eks = $stmt->fetch();
    if (!$eks) { header('Location: index.php'); exit; }
} catch (Exception $e) { die($e->getMessage()); }
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();
    $nama=$_POST['nama']??''; $deskripsi=$_POST['deskripsi']??'';
    $pembina_id=intval($_POST['pembina_id']??0)?:null;
    $hari=$_POST['hari']??''?:null; $jam_mulai=$_POST['jam_mulai']??''?:null; $jam_selesai=$_POST['jam_selesai']??''?:null;
    $kuota=intval($_POST['kuota']??30); $status=$_POST['status']??'Aktif'; $ta_id=intval($_POST['tahun_ajaran_id']??0);
    if (!$nama) { $error='Nama ekskul wajib diisi!'; }
    else {
        $pdo->prepare("UPDATE ekskul SET nama=?,deskripsi=?,pembina_id=?,hari=?,jam_mulai=?,jam_selesai=?,kuota=?,status=?,tahun_ajaran_id=? WHERE id=?")
            ->execute([$nama,$deskripsi,$pembina_id,$hari,$jam_mulai,$jam_selesai,$kuota,$status,$ta_id,$id]);
        write_audit_log("Memperbarui ekskul ID#$id: $nama.");
        echo "<script>document.addEventListener('DOMContentLoaded',function(){Swal.fire('Berhasil!','Ekskul diperbarui.','success').then(()=>{window.location.href='index.php?tahun_ajaran_id=$ta_id';});});</script>";
        $eks=array_merge($eks,compact('nama','deskripsi','pembina_id','hari','jam_mulai','jam_selesai','kuota','status','ta_id'));
    }
}
?>
<div class="glass-card" style="max-width:720px;margin:0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-star-half-stroke me-2"></i>Edit Ekstrakurikuler</h5>
    <?php if (!empty($error)): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
        <div class="row g-3">
            <div class="col-md-8"><label class="form-label form-label-custom">Nama Ekskul *</label><input type="text" name="nama" class="form-control form-control-custom" required value="<?php echo htmlspecialchars($eks['nama']); ?>"></div>
            <div class="col-md-4">
                <label class="form-label form-label-custom">Tahun Ajaran *</label>
                <select name="tahun_ajaran_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <?php foreach ($ta_list as $ta): ?><option value="<?php echo $ta['id']; ?>" <?php echo $eks['tahun_ajaran_id']==$ta['id']?'selected':''; ?>><?php echo htmlspecialchars($ta['tahun_ajaran']); ?></option><?php endforeach; ?>
                </select>
            </div>
            <div class="col-12"><label class="form-label form-label-custom">Deskripsi</label><textarea name="deskripsi" class="form-control form-control-custom" rows="3"><?php echo htmlspecialchars($eks['deskripsi']??''); ?></textarea></div>
            <div class="col-md-6">
                <label class="form-label form-label-custom">Pembina</label>
                <select name="pembina_id" class="form-select form-control-custom bg-dark-select text-white">
                    <option value="">-- Tanpa Pembina --</option>
                    <?php foreach ($guru_list as $g): ?><option value="<?php echo $g['id']; ?>" <?php echo $eks['pembina_id']==$g['id']?'selected':''; ?>><?php echo htmlspecialchars($g['nama_guru']); ?></option><?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3"><label class="form-label form-label-custom">Kuota</label><input type="number" name="kuota" class="form-control form-control-custom" value="<?php echo $eks['kuota']; ?>" min="1"></div>
            <div class="col-md-3">
                <label class="form-label form-label-custom">Status</label>
                <select name="status" class="form-select form-control-custom bg-dark-select text-white">
                    <option value="Aktif" <?php echo $eks['status']==='Aktif'?'selected':''; ?>>Aktif</option>
                    <option value="Nonaktif" <?php echo $eks['status']==='Nonaktif'?'selected':''; ?>>Nonaktif</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label form-label-custom">Hari</label>
                <select name="hari" class="form-select form-control-custom bg-dark-select text-white">
                    <option value="">--</option>
                    <?php foreach (['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'] as $h): ?><option value="<?php echo $h; ?>" <?php echo $eks['hari']===$h?'selected':''; ?>><?php echo $h; ?></option><?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4"><label class="form-label form-label-custom">Jam Mulai</label><input type="time" name="jam_mulai" class="form-control form-control-custom" value="<?php echo htmlspecialchars(substr($eks['jam_mulai']??'',0,5)); ?>"></div>
            <div class="col-md-4"><label class="form-label form-label-custom">Jam Selesai</label><input type="time" name="jam_selesai" class="form-control form-control-custom" value="<?php echo htmlspecialchars(substr($eks['jam_selesai']??'',0,5)); ?>"></div>
        </div>
        <div class="d-flex gap-3 mt-4">
            <button type="submit" class="btn btn-gold"><i class="fa-solid fa-floppy-disk me-1"></i> Simpan</button>
            <a href="index.php?tahun_ajaran_id=<?php echo $eks['tahun_ajaran_id']; ?>" class="btn btn-outline-custom">Batal</a>
        </div>
    </form>
</div>
<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
