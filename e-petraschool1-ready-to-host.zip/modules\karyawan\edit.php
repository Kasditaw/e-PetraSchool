<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\karyawan\edit.php

$page_title = 'Edit Karyawan';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';

try {
    // Load current employee record along with user login details
    $stmt = $pdo->prepare("SELECT k.*, u.username, u.role_id, u.status_aktif FROM karyawan k LEFT JOIN users u ON k.id = u.karyawan_id WHERE k.id = ?");
    $stmt->execute([$id]);
    $employee = $stmt->fetch();
    
    if (!$employee) {
        die('<div class="alert alert-danger">Data karyawan tidak ditemukan!</div>');
    }

    $roles_stmt = $pdo->query("SELECT id, nama_role FROM roles WHERE nama_role != 'Super Admin' ORDER BY id");
    $roles = $roles_stmt->fetchAll();
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $nik = trim($_POST['nik'] ?? '');
    $nama = trim($_POST['nama'] ?? '');
    $jabatan = trim($_POST['jabatan'] ?? '');
    $unit_kerja = trim($_POST['unit_kerja'] ?? '');
    $no_hp = trim($_POST['no_hp'] ?? '');
    $alamat = trim($_POST['alamat'] ?? '');
    $tanggal_masuk = $_POST['tanggal_masuk'] ?? '';
    $status = $_POST['status'] ?? 'Tetap';

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role_id = intval($_POST['role_id'] ?? 0);
    $status_aktif = $_POST['status_aktif'] ?? 'Aktif';

    if (empty($nik) || empty($nama) || empty($jabatan) || empty($unit_kerja) || empty($no_hp) || empty($tanggal_masuk) || empty($username) || $role_id <= 0) {
        $error = 'Field NIP, Nama, Jabatan, Unit Kerja, No HP, Tanggal Masuk, Username, dan Hak Akses wajib diisi!';
    } else {
        try {
            // Check duplicate NIP on other records
            $chk = $pdo->prepare("SELECT COUNT(*) FROM karyawan WHERE nik = ? AND id != ?");
            $chk->execute([$nik, $id]);
            if ($chk->fetchColumn() > 0) {
                $error = "NIP '$nik' sudah terdaftar pada karyawan lain!";
            } else {
                // Check duplicate username on other users
                $chk_user = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND (karyawan_id != ? OR karyawan_id IS NULL)");
                $chk_user->execute([$username, $id]);
                if ($chk_user->fetchColumn() > 0) {
                    $error = "Username '$username' sudah digunakan oleh pengguna lain!";
                } else {
                    $pdo->beginTransaction();

                    // Update karyawan
                    $stmt = $pdo->prepare("UPDATE karyawan SET nik = ?, nama = ?, jabatan = ?, unit_kerja = ?, no_hp = ?, alamat = ?, tanggal_masuk = ?, status = ? WHERE id = ?");
                    $stmt->execute([$nik, $nama, $jabatan, $unit_kerja, $no_hp, $alamat, $tanggal_masuk, $status, $id]);

                    // Check if user account already exists
                    $check_user = $pdo->prepare("SELECT id FROM users WHERE karyawan_id = ?");
                    $check_user->execute([$id]);
                    $user_id = $check_user->fetchColumn();

                    if ($user_id) {
                        // Update user login info
                        if (!empty($password)) {
                            $hashed_pass = password_hash($password, PASSWORD_BCRYPT);
                            $stmt_user = $pdo->prepare("UPDATE users SET username = ?, password = ?, nama = ?, role_id = ?, status_aktif = ? WHERE id = ?");
                            $stmt_user->execute([$username, $hashed_pass, $nama, $role_id, $status_aktif, $user_id]);
                        } else {
                            $stmt_user = $pdo->prepare("UPDATE users SET username = ?, nama = ?, role_id = ?, status_aktif = ? WHERE id = ?");
                            $stmt_user->execute([$username, $nama, $role_id, $status_aktif, $user_id]);
                        }
                    } else {
                        // Create new user login info
                        $hashed_pass = password_hash(!empty($password) ? $password : 'admin123', PASSWORD_BCRYPT);
                        $stmt_user = $pdo->prepare("INSERT INTO users (username, password, nama, role_id, karyawan_id, status_aktif) VALUES (?, ?, ?, ?, ?, ?)");
                        $stmt_user->execute([$username, $hashed_pass, $nama, $role_id, $id, $status_aktif]);
                    }

                    $pdo->commit();

                    write_audit_log("Mengubah data karyawan: $nama (NIP: $nik) dan memperbarui akun login: $username.");

                    echo "<script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire('Berhasil', 'Data karyawan dan akun login berhasil diubah!', 'success').then(() => {
                                window.location.href = 'index.php';
                            });
                        });
                    </script>";
                }
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>

<div class="glass-card" style="max-width: 750px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-user-pen me-2"></i> Edit Data Karyawan</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="edit.php?id=<?php echo $id; ?>">
        <?php csrf_input(); ?>

        <div class="row g-3">
            <div class="col-12 col-md-6">
                <label for="nik" class="form-label form-label-custom">NIP (Nomor Induk Pegawai) <span class="text-danger">*</span></label>
                <input type="text" name="nik" id="nik" class="form-control form-control-custom" value="<?php echo htmlspecialchars($employee['nik']); ?>" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="nama" class="form-label form-label-custom">Nama Lengkap Karyawan <span class="text-danger">*</span></label>
                <input type="text" name="nama" id="nama" class="form-control form-control-custom" value="<?php echo htmlspecialchars($employee['nama']); ?>" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="jabatan" class="form-label form-label-custom">Jabatan Pekerjaan <span class="text-danger">*</span></label>
                <input type="text" name="jabatan" id="jabatan" class="form-control form-control-custom" value="<?php echo htmlspecialchars($employee['jabatan']); ?>" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="unit_kerja" class="form-label form-label-custom">Unit Kerja / Divisi <span class="text-danger">*</span></label>
                <input type="text" name="unit_kerja" id="unit_kerja" class="form-control form-control-custom" value="<?php echo htmlspecialchars($employee['unit_kerja']); ?>" placeholder="Contoh: Tata Usaha, Perpustakaan, Keamanan" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="no_hp" class="form-label form-label-custom">Nomor HP / WA <span class="text-danger">*</span></label>
                <input type="text" name="no_hp" id="no_hp" class="form-control form-control-custom" value="<?php echo htmlspecialchars($employee['no_hp']); ?>" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="tanggal_masuk" class="form-label form-label-custom">Tanggal Masuk Bekerja <span class="text-danger">*</span></label>
                <input type="date" name="tanggal_masuk" id="tanggal_masuk" class="form-control form-control-custom" value="<?php echo $employee['tanggal_masuk']; ?>" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="status" class="form-label form-label-custom">Status Kepegawaian <span class="text-danger">*</span></label>
                <select name="status" id="status" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="Tetap" <?php echo $employee['status'] === 'Tetap' ? 'selected' : ''; ?>>Tetap</option>
                    <option value="Kontrak" <?php echo $employee['status'] === 'Kontrak' ? 'selected' : ''; ?>>Kontrak</option>
                    <option value="Harian" <?php echo $employee['status'] === 'Harian' ? 'selected' : ''; ?>>Harian</option>
                </select>
            </div>

            <div class="col-12">
                <label for="alamat" class="form-label form-label-custom">Alamat Lengkap</label>
                <textarea name="alamat" id="alamat" class="form-control form-control-custom" rows="2"><?php echo htmlspecialchars($employee['alamat']); ?></textarea>
            </div>

            <div class="col-12 mt-4">
                <h6 class="text-gold border-bottom border-secondary border-opacity-25 pb-2 mb-3"><i class="fa-solid fa-key me-2"></i> Akun Akses Sistem</h6>
            </div>

            <div class="col-12 col-md-3">
                <label for="username" class="form-label form-label-custom">Username <span class="text-danger">*</span></label>
                <input type="text" name="username" id="username" class="form-control form-control-custom" value="<?php echo htmlspecialchars($employee['username'] ?? ''); ?>" required autocomplete="off">
            </div>

            <div class="col-12 col-md-3">
                <label for="password" class="form-label form-label-custom">Password Baru (Kosongkan jika tidak diubah)</label>
                <input type="password" name="password" id="password" class="form-control form-control-custom" placeholder="Password baru" autocomplete="new-password">
            </div>

            <div class="col-12 col-md-3">
                <label for="role_id" class="form-label form-label-custom">Hak Akses <span class="text-danger">*</span></label>
                <select name="role_id" id="role_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="" disabled>Pilih Role...</option>
                    <?php foreach ($roles as $role): ?>
                        <option value="<?php echo $role['id']; ?>" <?php echo ($employee['role_id'] ?? '') == $role['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($role['nama_role']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-12 col-md-3">
                <label for="status_aktif" class="form-label form-label-custom">Status Hack Akses <span class="text-danger">*</span></label>
                <select name="status_aktif" id="status_aktif" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="Aktif" <?php echo ($employee['status_aktif'] ?? 'Aktif') === 'Aktif' ? 'selected' : ''; ?>>Aktif</option>
                    <option value="Tidak Aktif" <?php echo ($employee['status_aktif'] ?? '') === 'Tidak Aktif' ? 'selected' : ''; ?>>Tidak Aktif</option>
                </select>
            </div>

            <div class="col-12 d-flex justify-content-end gap-2 mt-4">
                <a href="index.php" class="btn btn-outline-custom">Batal</a>
                <button type="submit" class="btn btn-gold">Simpan Perubahan <i class="fa-solid fa-check ms-1"></i></button>
            </div>
        </div>
    </form>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
