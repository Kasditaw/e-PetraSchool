<?php
// c:\xampp\htdocs\e-petraschool1\modules\mata_pelajaran\delete.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    try {
        // Fetch mapel info for audit log
        $stmt = $pdo->prepare("SELECT nama_mapel, kode_mapel FROM mata_pelajaran WHERE id = ?");
        $stmt->execute([$id]);
        $sub = $stmt->fetch();

        if ($sub) {
            // Delete subject
            $delete_stmt = $pdo->prepare("DELETE FROM mata_pelajaran WHERE id = ?");
            $delete_stmt->execute([$id]);
            
            write_audit_log("Menghapus mata pelajaran: " . $sub['nama_mapel'] . " (Kode: " . $sub['kode_mapel'] . ").");
        }
    } catch (Exception $e) {
        error_log("Failed to delete subject: " . $e->getMessage());
    }
}

header("Location: index.php");
exit;
?>
