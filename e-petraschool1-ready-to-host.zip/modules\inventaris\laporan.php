<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris\laporan.php

$page_title = 'Laporan Inventaris';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
if (!has_role('Kepala Sekolah')) {
    require_inventaris_access();
}

$kategori_id = isset($_GET['kategori_id']) && $_GET['kategori_id'] !== '' ? intval($_GET['kategori_id']) : '';
$ruangan_id = isset($_GET['ruangan_id']) && $_GET['ruangan_id'] !== '' ? intval($_GET['ruangan_id']) : '';
$kondisi = isset($_GET['kondisi']) ? trim($_GET['kondisi']) : '';
$status_pinjam = isset($_GET['status_pinjam']) ? trim($_GET['status_pinjam']) : '';
$status_rusak = isset($_GET['status_rusak']) ? trim($_GET['status_rusak']) : '';
$tahun = isset($_GET['tahun']) && $_GET['tahun'] !== '' ? intval($_GET['tahun']) : '';

try {
    // Basic Query joining Kategori & Ruangan
    $query = "
        SELECT i.*, k.nama_kategori, r.nama_ruangan 
        FROM inventaris i 
        JOIN kategori_barang k ON i.kategori_id = k.id 
        LEFT JOIN ruangan r ON i.ruangan_id = r.id 
        WHERE i.status_aktif = 'Aktif'
    ";
    
    $params = [];
    
    if ($kategori_id !== '') {
        $query .= " AND i.kategori_id = :kategori_id";
        $params['kategori_id'] = $kategori_id;
    }
    
    if ($ruangan_id !== '') {
        $query .= " AND i.ruangan_id = :ruangan_id";
        $params['ruangan_id'] = $ruangan_id;
    }
    
    if ($kondisi !== '') {
        $query .= " AND i.kondisi = :kondisi";
        $params['kondisi'] = $kondisi;
    }
    
    if ($status_rusak === '1') {
        $query .= " AND i.kondisi IN ('Rusak Ringan', 'Rusak Berat')";
    }
    
    if ($tahun !== '') {
        $query .= " AND i.tahun_perolehan = :tahun";
        $params['tahun'] = $tahun;
    }
    
    if ($status_pinjam !== '') {
        if ($status_pinjam === 'Dipinjam') {
            $query .= " AND i.id IN (SELECT DISTINCT inventaris_id FROM peminjaman WHERE status = 'Dipinjam')";
        } elseif ($status_pinjam === 'Tersedia') {
            $query .= " AND i.id NOT IN (SELECT DISTINCT inventaris_id FROM peminjaman WHERE status = 'Dipinjam')";
        }
    }

    $query .= " ORDER BY i.kode_barang ASC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $assets = $stmt->fetchAll();

    // Fetch filters options
    $categories = $pdo->query("SELECT id, nama_kategori FROM kategori_barang ORDER BY nama_kategori ASC")->fetchAll();
    $rooms = $pdo->query("SELECT id, nama_ruangan FROM ruangan ORDER BY nama_ruangan ASC")->fetchAll();
    $years = $pdo->query("SELECT DISTINCT tahun_perolehan FROM inventaris WHERE status_aktif = 'Aktif' AND tahun_perolehan IS NOT NULL AND tahun_perolehan > 0 ORDER BY tahun_perolehan DESC")->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) {
    $assets = [];
    $categories = [];
    $rooms = [];
    $years = [];
    $error = 'Database error: ' . $e->getMessage();
}

// Build query string for export/print
$query_string = http_build_query($_GET);
?>

<div class="glass-card mb-4 no-print">
    <h5 class="text-gold fw-bold mb-3"><i class="fa-solid fa-filter me-2"></i> Filter Laporan Inventaris</h5>
    <form method="GET" action="laporan.php" class="row g-3">
        <div class="col-12 col-md-3">
            <label for="kategori_id" class="form-label form-label-custom small text-secondary">Kategori</label>
            <select name="kategori_id" id="kategori_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua Kategori</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo $cat['id']; ?>" <?php echo $kategori_id === $cat['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($cat['nama_kategori']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-12 col-md-3">
            <label for="ruangan_id" class="form-label form-label-custom small text-secondary">Lokasi / Ruangan</label>
            <select name="ruangan_id" id="ruangan_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua Ruangan</option>
                <?php foreach ($rooms as $rm): ?>
                    <option value="<?php echo $rm['id']; ?>" <?php echo $ruangan_id === $rm['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($rm['nama_ruangan']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-12 col-md-2">
            <label for="kondisi" class="form-label form-label-custom small text-secondary">Kondisi</label>
            <select name="kondisi" id="kondisi" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua Kondisi</option>
                <option value="Baik" <?php echo $kondisi === 'Baik' ? 'selected' : ''; ?>>Baik</option>
                <option value="Cukup" <?php echo $kondisi === 'Cukup' ? 'selected' : ''; ?>>Cukup</option>
                <option value="Rusak Ringan" <?php echo $kondisi === 'Rusak Ringan' ? 'selected' : ''; ?>>Rusak Ringan</option>
                <option value="Rusak Berat" <?php echo $kondisi === 'Rusak Berat' ? 'selected' : ''; ?>>Rusak Berat</option>
            </select>
        </div>

        <div class="col-12 col-md-2">
            <label for="tahun" class="form-label form-label-custom small text-secondary">Tahun Perolehan</label>
            <select name="tahun" id="tahun" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua Tahun</option>
                <?php foreach ($years as $y): ?>
                    <option value="<?php echo $y; ?>" <?php echo $tahun === $y ? 'selected' : ''; ?>><?php echo $y; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-12 col-md-2">
            <label for="status_pinjam" class="form-label form-label-custom small text-secondary">Status Pinjam</label>
            <select name="status_pinjam" id="status_pinjam" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua</option>
                <option value="Dipinjam" <?php echo $status_pinjam === 'Dipinjam' ? 'selected' : ''; ?>>Sedang Dipinjam</option>
                <option value="Tersedia" <?php echo $status_pinjam === 'Tersedia' ? 'selected' : ''; ?>>Tersedia di Lokasi</option>
            </select>
        </div>

        <div class="col-12 col-md-3">
            <div class="form-check form-switch pt-2">
                <input class="form-check-input" type="checkbox" name="status_rusak" id="status_rusak" value="1" <?php echo $status_rusak === '1' ? 'checked' : ''; ?>>
                <label class="form-check-label text-white small" for="status_rusak">Hanya Tampilkan Aset Rusak</label>
            </div>
        </div>

        <div class="col-12 d-flex justify-content-end gap-2">
            <button type="submit" class="btn btn-outline-custom"><i class="fa-solid fa-magnifying-glass me-1"></i> Terapkan Filter</button>
            <a href="laporan.php" class="btn btn-outline-danger"><i class="fa-solid fa-xmark me-1"></i> Reset</a>
        </div>
    </form>
</div>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-file-invoice-dollar me-2"></i> Laporan Aset Sekolah</h5>
            <p class="text-secondary small mb-0">Rincian tabel pencarian aset berdasarkan filter terpilih.</p>
        </div>
        <div class="d-flex gap-2 no-print">
            <a href="export_laporan.php?<?php echo $query_string; ?>" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-excel me-1"></i> Ekspor CSV / Excel</a>
            <a href="print_laporan.php?<?php echo $query_string; ?>" target="_blank" class="btn btn-gold"><i class="fa-solid fa-print me-1"></i> Cetak Laporan</a>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Barang</th>
                    <th>Nama Barang</th>
                    <th>Kategori</th>
                    <th>Lokasi</th>
                    <th>Merk / Model</th>
                    <th>Kondisi</th>
                    <th>Tahun</th>
                    <th>Harga Perolehan</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($assets) > 0): ?>
                    <?php 
                    $no = 1; 
                    $total_investasi = 0;
                    foreach ($assets as $ast): 
                        $total_investasi += $ast['harga'];
                    ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><span class="badge badge-secondary font-monospace"><?php echo htmlspecialchars($ast['kode_barang']); ?></span></td>
                            <td class="fw-semibold text-white"><?php echo htmlspecialchars($ast['nama_barang']); ?></td>
                            <td><?php echo htmlspecialchars($ast['nama_kategori']); ?></td>
                            <td><?php echo htmlspecialchars($ast['nama_ruangan'] ?: 'Gudang / Belum Alokasi'); ?></td>
                            <td><?php echo htmlspecialchars(($ast['merk'] ? $ast['merk'] : '-') . ($ast['tipe_model'] ? ' / ' . $ast['tipe_model'] : '')); ?></td>
                            <td>
                                <?php 
                                $cond = $ast['kondisi'];
                                $badgeClass = 'bg-success';
                                if ($cond === 'Cukup') $badgeClass = 'bg-info';
                                elseif ($cond === 'Rusak Ringan') $badgeClass = 'bg-warning text-dark';
                                elseif ($cond === 'Rusak Berat') $badgeClass = 'bg-danger';
                                ?>
                                <span class="badge <?php echo $badgeClass; ?>"><?php echo htmlspecialchars($cond); ?></span>
                            </td>
                            <td><?php echo htmlspecialchars($ast['tahun_perolehan'] ?: '-'); ?></td>
                            <td class="text-gold fw-bold text-end">Rp <?php echo number_format($ast['harga'], 0, ',', '.'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr class="fw-bold border-top border-secondary">
                        <td colspan="8" class="text-end text-white pe-3">Total Investasi Aset Terfilter:</td>
                        <td class="text-gold text-end">Rp <?php echo number_format($total_investasi, 0, ',', '.'); ?></td>
                    </tr>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center text-secondary py-4">Tidak ada data aset yang cocok dengan filter.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
