<?php
// c:\xampp\htdocs\e-petraschool1\modules\jurnal\delete.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_role(['Super Admin', 'Admin', 'Kepala Sekolah']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    try {
        // Fetch journal details for logging
        $stmt = $pdo->prepare("SELECT j.tanggal, g.nama_guru 
                              FROM jurnal_mengajar j
                              JOIN guru g ON j.guru_id = g.id 
                              WHERE j.id = ?");
        $stmt->execute([$id]);
        $jurnal = $stmt->fetch();

        if ($jurnal) {
            // Delete journal (cascades to details and verifications due to DB foreign keys)
            $delete_stmt = $pdo->prepare("DELETE FROM jurnal_mengajar WHERE id = ?");
            $delete_stmt->execute([$id]);
            
            write_audit_log("Menghapus jurnal mengajar Guru: " . $jurnal['nama_guru'] . " tanggal " . $jurnal['tanggal'] . ".");
        }
    } catch (Exception $e) {
        error_log("Failed to delete journal: " . $e->getMessage());
    }
}

header("Location: index.php");
exit;
?>
