<?php
// c:\xampp\htdocs\e-petraschool1\modules\spp\bayar.php

$page_title = 'Input Pembayaran SPP';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin','Admin']);

$tagihan_id = intval($_GET['id'] ?? 0);
if (!$tagihan_id) { header('Location: index.php'); exit; }

$bulan_names = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
$error = '';

try {
    $t_stmt = $pdo->prepare("SELECT t.*, s.nama_lengkap, s.nis, k.nama_kelas FROM spp_tagihan t JOIN siswa s ON t.siswa_id=s.id LEFT JOIN kelas k ON t.kelas_id=k.id WHERE t.id=?");
    $t_stmt->execute([$tagihan_id]); $tagihan = $t_stmt->fetch();
    if (!$tagihan) { header('Location: index.php'); exit; }

    // Riwayat pembayaran
    $pay_stmt = $pdo->prepare("SELECT p.*, u.nama AS petugas FROM spp_pembayaran p LEFT JOIN users u ON p.petugas_id=u.id WHERE p.tagihan_id=? ORDER BY p.tanggal_bayar DESC");
    $pay_stmt->execute([$tagihan_id]); $pembayaran = $pay_stmt->fetchAll();
    $total_bayar = array_sum(array_column($pembayaran,'jumlah_bayar'));
    $sisa = $tagihan['nominal'] - $total_bayar;
} catch (Exception $e) { die($e->getMessage()); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();
    $jumlah_bayar = floatval(str_replace(['.'],[''], $_POST['jumlah_bayar']??'0'));
    $metode       = trim($_POST['metode'] ?? 'Tunai');
    $tanggal_bayar= $_POST['tanggal_bayar'] ?? date('Y-m-d');
    $catatan      = trim($_POST['catatan'] ?? '');

    if ($jumlah_bayar <= 0) { $error = 'Jumlah bayar harus lebih dari 0!'; }
    elseif ($jumlah_bayar > $sisa + 0.01) { $error = 'Jumlah bayar melebihi sisa tagihan!'; }
    else {
        try {
            $pdo->prepare("INSERT INTO spp_pembayaran (tagihan_id,tanggal_bayar,jumlah_bayar,metode,petugas_id,catatan) VALUES (?,?,?,?,?,?)")
                ->execute([$tagihan_id,$tanggal_bayar,$jumlah_bayar,$metode,$_SESSION['user_id'],$catatan]);
            $new_total = $total_bayar + $jumlah_bayar;
            $new_status = $new_total >= $tagihan['nominal'] ? 'Lunas' : 'Cicil';
            $pdo->prepare("UPDATE spp_tagihan SET status=? WHERE id=?")->execute([$new_status,$tagihan_id]);
            write_audit_log("Input pembayaran SPP Rp ".number_format($jumlah_bayar,0,',','.')." untuk {$tagihan['nama_lengkap']}.");
            $success = "Pembayaran Rp ".number_format($jumlah_bayar,0,',','.')." berhasil dicatat! Status: $new_status";
            // Reload
            $pay_stmt->execute([$tagihan_id]); $pembayaran = $pay_stmt->fetchAll();
            $total_bayar = array_sum(array_column($pembayaran,'jumlah_bayar'));
            $sisa = $tagihan['nominal'] - $total_bayar;
            $t_stmt->execute([$tagihan_id]); $tagihan = $t_stmt->fetch();
        } catch (Exception $e) { $error = 'Gagal: '.$e->getMessage(); }
    }
}
?>
<div class="glass-card" style="max-width:800px;margin:0 auto;">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-money-bill-wave me-2"></i>Input Pembayaran SPP</h5>
            <p class="text-secondary small mb-0">
                <strong class="text-white"><?php echo htmlspecialchars($tagihan['nama_lengkap']); ?></strong>
                · <?php echo htmlspecialchars($tagihan['nama_kelas']??''); ?>
                · SPP <?php echo $bulan_names[$tagihan['bulan']]; ?> <?php echo $tagihan['tahun']; ?>
            </p>
        </div>
        <a href="index.php" class="btn btn-outline-custom"><i class="fa-solid fa-arrow-left me-1"></i> Kembali</a>
    </div>

    <!-- Info tagihan -->
    <div class="row g-3 mb-4">
        <div class="col-4">
            <div style="background:rgba(255,255,255,.04);border-radius:10px;padding:14px;text-align:center;">
                <div class="text-secondary small">Total Tagihan</div>
                <div class="fw-bold text-white">Rp <?php echo number_format($tagihan['nominal'],0,',','.'); ?></div>
            </div>
        </div>
        <div class="col-4">
            <div style="background:rgba(16,185,129,.1);border-radius:10px;padding:14px;text-align:center;">
                <div class="text-secondary small">Terbayar</div>
                <div class="fw-bold" style="color:#10B981;">Rp <?php echo number_format($total_bayar,0,',','.'); ?></div>
            </div>
        </div>
        <div class="col-4">
            <div style="background:rgba(239,68,68,.1);border-radius:10px;padding:14px;text-align:center;">
                <div class="text-secondary small">Sisa</div>
                <div class="fw-bold" style="color:#EF4444;">Rp <?php echo number_format(max(0,$sisa),0,',','.'); ?></div>
            </div>
        </div>
    </div>

    <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <?php if (!empty($success)): ?><div class="alert alert-success"><i class="fa-solid fa-check-circle me-2"></i><?php echo htmlspecialchars($success); ?></div><?php endif; ?>

    <?php if ($sisa > 0): ?>
    <!-- Form bayar -->
    <div style="background:rgba(212,175,55,.06);border:1px solid rgba(212,175,55,.2);border-radius:12px;padding:20px;margin-bottom:20px;">
        <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-plus-circle me-2"></i>Catat Pembayaran Baru</h6>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label form-label-custom">Jumlah Bayar (Rp) *</label>
                    <input type="number" name="jumlah_bayar" class="form-control form-control-custom" required min="1" max="<?php echo ceil($sisa); ?>" placeholder="<?php echo ceil($sisa); ?>">
                    <small class="text-secondary">Sisa: Rp <?php echo number_format($sisa,0,',','.'); ?></small>
                </div>
                <div class="col-md-3">
                    <label class="form-label form-label-custom">Metode</label>
                    <select name="metode" class="form-select form-control-custom bg-dark-select text-white">
                        <option value="Tunai">Tunai</option>
                        <option value="Transfer">Transfer</option>
                        <option value="QRIS">QRIS</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label form-label-custom">Tanggal Bayar</label>
                    <input type="date" name="tanggal_bayar" class="form-control form-control-custom" value="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="col-md-5">
                    <label class="form-label form-label-custom">Catatan</label>
                    <input type="text" name="catatan" class="form-control form-control-custom" placeholder="Opsional...">
                </div>
            </div>
            <button type="submit" class="btn btn-gold mt-3"><i class="fa-solid fa-check me-1"></i> Simpan Pembayaran</button>
        </form>
    </div>
    <?php else: ?>
        <div class="alert alert-success"><i class="fa-solid fa-circle-check me-2"></i><strong>Tagihan Lunas!</strong> Tidak ada sisa pembayaran.</div>
    <?php endif; ?>

    <!-- Riwayat -->
    <?php if (!empty($pembayaran)): ?>
    <h6 class="fw-bold text-white mb-3">Riwayat Pembayaran</h6>
    <div class="table-responsive">
        <table class="table table-custom" style="font-size:12px;">
            <thead><tr><th>#</th><th>Tanggal</th><th>Jumlah</th><th>Metode</th><th>Petugas</th><th>Catatan</th></tr></thead>
            <tbody>
                <?php $no=1; foreach ($pembayaran as $p): ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo date('d M Y', strtotime($p['tanggal_bayar'])); ?></td>
                    <td class="fw-bold" style="color:#10B981;">Rp <?php echo number_format($p['jumlah_bayar'],0,',','.'); ?></td>
                    <td><?php echo $p['metode']; ?></td>
                    <td class="text-secondary"><?php echo htmlspecialchars($p['petugas']??'—'); ?></td>
                    <td class="text-secondary"><?php echo htmlspecialchars($p['catatan']??'—'); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>
<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
