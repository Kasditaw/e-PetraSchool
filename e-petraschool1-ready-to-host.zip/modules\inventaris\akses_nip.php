<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris\akses_nip.php
// Halaman kelola NIP yang berhak akses Inventaris (Super Admin & Admin only)

$page_title = 'Akses NIP Inventaris';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error   = '';
$success = '';

// ── HANDLE HAPUS ──────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'hapus_akses') {
    check_csrf_request();
    $hapus_id = intval($_POST['hapus_id'] ?? 0);
    if ($hapus_id > 0) {
        try {
            $del = $pdo->prepare("DELETE FROM inventaris_akses_nip WHERE id = ?");
            $del->execute([$hapus_id]);
            write_audit_log("Menghapus akses NIP inventaris (id: $hapus_id).");
            $success = 'Akses NIP berhasil dihapus.';
        } catch (Exception $e) {
            $error = 'Gagal menghapus: ' . $e->getMessage();
        }
    }
}

// ── HANDLE TAMBAH ─────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'tambah_akses') {
    check_csrf_request();
    $karyawan_id = intval($_POST['karyawan_id'] ?? 0);
    $keterangan  = trim($_POST['keterangan'] ?? '');

    if ($karyawan_id <= 0) {
        $error = 'Pilih karyawan terlebih dahulu.';
    } else {
        try {
            // Ambil NIP dari karyawan yang dipilih
            $k = $pdo->prepare("SELECT nik, nama FROM karyawan WHERE id = ?");
            $k->execute([$karyawan_id]);
            $kar = $k->fetch();

            if (!$kar) {
                $error = 'Karyawan tidak ditemukan.';
            } else {
                // Cek duplikat
                $chk = $pdo->prepare("SELECT COUNT(*) FROM inventaris_akses_nip WHERE karyawan_id = ?");
                $chk->execute([$karyawan_id]);
                if ($chk->fetchColumn() > 0) {
                    $error = "NIP karyawan <strong>{$kar['nama']}</strong> sudah terdaftar!";
                } else {
                    $ins = $pdo->prepare("INSERT INTO inventaris_akses_nip (nip, karyawan_id, keterangan) VALUES (?, ?, ?)");
                    $ins->execute([$kar['nik'], $karyawan_id, $keterangan]);
                    write_audit_log("Menambahkan akses inventaris untuk NIP: {$kar['nik']} ({$kar['nama']}).");
                    $success = "Akses inventaris untuk <strong>{$kar['nama']}</strong> (NIP: {$kar['nik']}) berhasil ditambahkan.";
                }
            }
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// ── LOAD DATA ─────────────────────────────────────────────
try {
    // Daftar karyawan yang belum punya akses (untuk dropdown tambah)
    $available = $pdo->query("
        SELECT k.id, k.nik, k.nama, k.jabatan, k.unit_kerja
        FROM karyawan k
        WHERE k.id NOT IN (SELECT karyawan_id FROM inventaris_akses_nip)
        ORDER BY k.nama ASC
    ")->fetchAll();

    // Daftar NIP yang sudah terdaftar
    $registered = $pdo->query("
        SELECT ian.id, ian.nip, ian.keterangan, ian.created_at,
               k.nama, k.jabatan, k.unit_kerja, k.status
        FROM inventaris_akses_nip ian
        JOIN karyawan k ON ian.karyawan_id = k.id
        ORDER BY k.nama ASC
    ")->fetchAll();
} catch (Exception $e) {
    $error = 'Gagal memuat data: ' . $e->getMessage();
    $available  = [];
    $registered = [];
}
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo $error; ?>
    </div>
<?php endif; ?>

<?php if ($success !== ''): ?>
    <div class="alert border-0 small mb-4 py-2" style="background:rgba(16,185,129,0.15);color:#34d399;" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i> <?php echo $success; ?>
    </div>
<?php endif; ?>

<!-- Header + Tambah Form -->
<div class="glass-card mb-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1">
                <i class="fa-solid fa-key me-2"></i> Kelola Akses NIP — Inventaris Aset
            </h5>
            <p class="text-secondary small mb-0">
                Daftarkan NIP karyawan yang berhak mengakses menu <strong>Inventarisasi &amp; Manajemen Aset Sekolah</strong>.<br>
                Selain Super Admin &amp; Admin, hanya NIP yang terdaftar di sini yang dapat membuka menu inventaris.
            </p>
        </div>
        <a href="index.php" class="btn btn-outline-custom text-gold">
            <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Inventaris
        </a>
    </div>

    <!-- Form Tambah -->
    <form method="POST" action="akses_nip.php" class="row g-3 align-items-end">
        <?php csrf_input(); ?>
        <input type="hidden" name="action" value="tambah_akses">

        <div class="col-12 col-md-5">
            <label for="karyawan_id" class="form-label form-label-custom">
                Pilih Karyawan <span class="text-danger">*</span>
            </label>
            <select name="karyawan_id" id="karyawan_id" class="form-select form-control-custom bg-dark-select text-white" required>
                <option value="" disabled selected>— Pilih Karyawan —</option>
                <?php foreach ($available as $av): ?>
                    <option value="<?php echo $av['id']; ?>">
                        <?php echo htmlspecialchars($av['nama']); ?>
                        (NIP: <?php echo htmlspecialchars($av['nik']); ?>)
                        — <?php echo htmlspecialchars($av['jabatan']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <?php if (empty($available)): ?>
                <small class="text-secondary mt-1 d-block">Semua karyawan sudah terdaftar.</small>
            <?php endif; ?>
        </div>

        <div class="col-12 col-md-5">
            <label for="keterangan" class="form-label form-label-custom">Keterangan (Opsional)</label>
            <input type="text" name="keterangan" id="keterangan" class="form-control form-control-custom"
                   placeholder="Contoh: Petugas Inventaris Utama">
        </div>

        <div class="col-12 col-md-2">
            <button type="submit" class="btn btn-gold w-100" <?php echo empty($available) ? 'disabled' : ''; ?>>
                <i class="fa-solid fa-plus me-1"></i> Tambah Akses
            </button>
        </div>
    </form>
</div>

<!-- Tabel Daftar NIP Terdaftar -->
<div class="glass-card">
    <h6 class="text-gold fw-bold mb-3">
        <i class="fa-solid fa-list-check me-2"></i>
        Daftar NIP Terdaftar
        <span class="badge badge-secondary ms-2"><?php echo count($registered); ?> NIP</span>
    </h6>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIP</th>
                    <th>Nama Karyawan</th>
                    <th>Jabatan</th>
                    <th>Unit Kerja</th>
                    <th>Status</th>
                    <th>Keterangan</th>
                    <th>Tgl Ditambah</th>
                    <th class="no-print">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($registered) > 0): ?>
                    <?php $no = 1; foreach ($registered as $reg): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td>
                                <strong class="text-gold font-monospace"><?php echo htmlspecialchars($reg['nip']); ?></strong>
                            </td>
                            <td class="fw-semibold text-white"><?php echo htmlspecialchars($reg['nama']); ?></td>
                            <td><?php echo htmlspecialchars($reg['jabatan']); ?></td>
                            <td><?php echo htmlspecialchars($reg['unit_kerja']); ?></td>
                            <td>
                                <?php
                                    $bc = 'badge-secondary';
                                    if ($reg['status'] === 'Tetap')    $bc = 'badge-success';
                                    elseif ($reg['status'] === 'Kontrak') $bc = 'badge-warning';
                                ?>
                                <span class="badge <?php echo $bc; ?>"><?php echo $reg['status']; ?></span>
                            </td>
                            <td class="text-secondary small"><?php echo htmlspecialchars($reg['keterangan'] ?: '—'); ?></td>
                            <td class="text-secondary small"><?php echo date('d M Y', strtotime($reg['created_at'])); ?></td>
                            <td class="no-print">
                                <form method="POST" action="akses_nip.php" style="display:inline;"
                                      onsubmit="return confirm('Hapus akses NIP <?php echo htmlspecialchars($reg['nama'], ENT_QUOTES); ?>?')">
                                    <?php csrf_input(); ?>
                                    <input type="hidden" name="action" value="hapus_akses">
                                    <input type="hidden" name="hapus_id" value="<?php echo $reg['id']; ?>">
                                    <button type="submit" class="btn btn-xs btn-outline-danger">
                                        <i class="fa-solid fa-trash"></i> Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center text-secondary py-5">
                            <i class="fa-solid fa-key fa-2x mb-2 d-block opacity-25"></i>
                            Belum ada NIP yang terdaftar.<br>
                            <small>Tambahkan NIP karyawan di atas agar dapat mengakses menu inventaris.</small>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
