<?php
// c:\xampp\htdocs\e-petraschool1\modules\jurnal\dashboard_verifikasi.php
// Modul Dashboard Verifikasi Jurnal - Khusus Kepala Sekolah

$page_title = 'Dashboard Verifikasi Jurnal';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Kepala Sekolah']);

// --- Filter ---
$filter_ta    = isset($_GET['tahun_ajaran_id']) ? intval($_GET['tahun_ajaran_id']) : 0;
$filter_sem   = isset($_GET['semester_id'])     ? intval($_GET['semester_id'])     : 0;
$filter_guru  = isset($_GET['guru_id'])         ? intval($_GET['guru_id'])         : 0;

try {
    // Load tahun ajaran & semester options
    $ta_list  = $pdo->query("SELECT * FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();
    $sem_list = $pdo->query("SELECT * FROM semester ORDER BY id ASC")->fetchAll();

    // Default to active TA/Sem if not set
    if ($filter_ta === 0) {
        foreach ($ta_list as $ta) {
            if ($ta['status'] === 'Aktif') { $filter_ta = $ta['id']; break; }
        }
    }
    if ($filter_sem === 0) {
        foreach ($sem_list as $s) {
            if ($s['status'] === 'Aktif') { $filter_sem = $s['id']; break; }
        }
    }

    // ===== STATISTIK UTAMA =====
    $cond_ta_sem = " AND j.tahun_ajaran_id = :ta_id AND j.semester_id = :sem_id";
    $base_params = [':ta_id' => $filter_ta, ':sem_id' => $filter_sem];

    $s = $pdo->prepare("SELECT
        COUNT(*) AS total,
        SUM(j.status = 'Menunggu Verifikasi') AS menunggu,
        SUM(j.status = 'Disetujui')           AS disetujui,
        SUM(j.status = 'Revisi')              AS revisi
        FROM jurnal_mengajar j WHERE 1=1" . $cond_ta_sem);
    $s->execute($base_params);
    $stats = $s->fetch();

    // ===== PROGRESS PER GURU =====
    $guru_params = $base_params;
    $guru_where  = $cond_ta_sem;
    if ($filter_guru > 0) {
        $guru_where .= " AND j.guru_id = :guru_filter";
        $guru_params[':guru_filter'] = $filter_guru;
    }

    $gq = $pdo->prepare("SELECT
        g.id AS guru_id,
        g.nama_guru,
        g.nip,
        COUNT(j.id)                                   AS total_jurnal,
        SUM(j.status = 'Menunggu Verifikasi')         AS menunggu,
        SUM(j.status = 'Disetujui')                   AS disetujui,
        SUM(j.status = 'Revisi')                      AS revisi,
        MAX(j.tanggal)                                AS terakhir_input
        FROM guru g
        LEFT JOIN jurnal_mengajar j ON j.guru_id = g.id" . $guru_where . "
        GROUP BY g.id, g.nama_guru, g.nip
        ORDER BY menunggu DESC, g.nama_guru ASC");
    $gq->execute($guru_params);
    $guru_progress = $gq->fetchAll();

    // ===== JURNAL MENUNGGU VERIFIKASI (Terbaru 20) =====
    $jq_params = $base_params;
    $jq_where  = $cond_ta_sem;
    if ($filter_guru > 0) {
        $jq_where .= " AND j.guru_id = :guru_filter2";
        $jq_params[':guru_filter2'] = $filter_guru;
    }
    $jq = $pdo->prepare("SELECT j.*, g.nama_guru, g.nip, s.semester, t.tahun_ajaran
        FROM jurnal_mengajar j
        JOIN guru g ON j.guru_id = g.id
        JOIN semester s ON j.semester_id = s.id
        JOIN tahun_ajaran t ON j.tahun_ajaran_id = t.id
        WHERE j.status = 'Menunggu Verifikasi'" . $jq_where . "
        ORDER BY j.tanggal ASC, j.created_at ASC
        LIMIT 30");
    $jq->execute($jq_params);
    $pending_journals = $jq->fetchAll();

    // ===== HISTORI VERIFIKASI TERBARU =====
    $hq = $pdo->prepare("SELECT j.*, g.nama_guru, s.semester, t.tahun_ajaran,
        v.catatan, v.tanggal_verifikasi, u.nama AS verifikator
        FROM jurnal_mengajar j
        JOIN guru g ON j.guru_id = g.id
        JOIN semester s ON j.semester_id = s.id
        JOIN tahun_ajaran t ON j.tahun_ajaran_id = t.id
        LEFT JOIN verifikasi_jurnal v ON v.jurnal_id = j.id
        LEFT JOIN users u ON u.id = v.verifikator_id
        WHERE j.status IN ('Disetujui','Revisi')" . $cond_ta_sem . "
        ORDER BY v.tanggal_verifikasi DESC
        LIMIT 15");
    $hq->execute($base_params);
    $history = $hq->fetchAll();

    // ===== GURU LIST FOR FILTER =====
    $guru_list = $pdo->query("SELECT id, nama_guru, nip FROM guru ORDER BY nama_guru ASC")->fetchAll();

} catch (Exception $e) {
    die('<div class="alert alert-danger">Error database: ' . htmlspecialchars($e->getMessage()) . '</div>');
}

// Helper
$total     = max(1, (int)($stats['total']    ?? 0));
$menunggu  = (int)($stats['menunggu']  ?? 0);
$disetujui = (int)($stats['disetujui'] ?? 0);
$revisi    = (int)($stats['revisi']    ?? 0);
$pct_done  = round(($disetujui / $total) * 100);

// Get selected label
$ta_label  = '—'; foreach ($ta_list  as $x) { if ($x['id'] == $filter_ta)  { $ta_label  = $x['tahun_ajaran']; break; } }
$sem_label = '—'; foreach ($sem_list as $x) { if ($x['id'] == $filter_sem) { $sem_label = $x['semester'];     break; } }
?>

<!-- ===== FILTER BAR ===== -->
<div class="glass-card mb-4 py-3">
    <form method="GET" action="dashboard_verifikasi.php" class="row g-3 align-items-end">
        <div class="col-12 col-md-auto">
            <span class="text-gold fw-bold" style="font-size:14px;">
                <i class="fa-solid fa-shield-halved me-2"></i>Dashboard Verifikasi Jurnal
            </span>
        </div>
        <div class="col-12 col-sm-6 col-md-3">
            <label class="form-label form-label-custom mb-1">Tahun Ajaran</label>
            <select name="tahun_ajaran_id" class="form-select form-control-custom bg-dark-select text-white">
                <?php foreach ($ta_list as $ta): ?>
                    <option value="<?php echo $ta['id']; ?>" <?php echo $filter_ta == $ta['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($ta['tahun_ajaran']); ?>
                        <?php echo $ta['status'] === 'Aktif' ? ' (Aktif)' : ''; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-sm-6 col-md-2">
            <label class="form-label form-label-custom mb-1">Semester</label>
            <select name="semester_id" class="form-select form-control-custom bg-dark-select text-white">
                <?php foreach ($sem_list as $s): ?>
                    <option value="<?php echo $s['id']; ?>" <?php echo $filter_sem == $s['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($s['semester']); ?>
                        <?php echo $s['status'] === 'Aktif' ? ' (Aktif)' : ''; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-sm-6 col-md-3">
            <label class="form-label form-label-custom mb-1">Filter Guru</label>
            <select name="guru_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="0">Semua Guru</option>
                <?php foreach ($guru_list as $g): ?>
                    <option value="<?php echo $g['id']; ?>" <?php echo $filter_guru == $g['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($g['nama_guru']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-auto d-flex gap-2">
            <button type="submit" class="btn btn-gold px-4">
                <i class="fa-solid fa-filter me-1"></i>Terapkan
            </button>
            <a href="dashboard_verifikasi.php" class="btn btn-outline-secondary">Reset</a>
        </div>
    </form>
</div>

<!-- ===== STAT CARDS ===== -->
<div class="row g-3 mb-4">
    <!-- Total -->
    <div class="col-6 col-md-3">
        <div class="glass-card h-100 d-flex flex-column align-items-center justify-content-center text-center py-4"
             style="border-left: 3px solid #60a5fa;">
            <div style="font-size:2rem; font-weight:800; color:#60a5fa; line-height:1;"><?php echo $stats['total'] ?? 0; ?></div>
            <div class="text-secondary small mt-1">Total Jurnal</div>
            <div style="font-size:11px; color:#60a5fa; margin-top:4px; font-weight:600;">
                <?php echo $ta_label; ?> &bull; Sem. <?php echo $sem_label; ?>
            </div>
        </div>
    </div>
    <!-- Menunggu -->
    <div class="col-6 col-md-3">
        <div class="glass-card h-100 d-flex flex-column align-items-center justify-content-center text-center py-4 <?php echo $menunggu > 0 ? 'stat-pulse-warn' : ''; ?>"
             style="border-left: 3px solid #f59e0b;">
            <div style="font-size:2rem; font-weight:800; color:#f59e0b; line-height:1;"><?php echo $menunggu; ?></div>
            <div class="text-secondary small mt-1">Menunggu Verifikasi</div>
            <?php if ($menunggu > 0): ?>
                <div class="mt-2">
                    <a href="#section-pending" class="btn btn-xs btn-outline-warning" style="font-size:10px; padding:2px 10px;">
                        <i class="fa-solid fa-arrow-down me-1"></i>Lihat
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <!-- Disetujui -->
    <div class="col-6 col-md-3">
        <div class="glass-card h-100 d-flex flex-column align-items-center justify-content-center text-center py-4"
             style="border-left: 3px solid #10b981;">
            <div style="font-size:2rem; font-weight:800; color:#10b981; line-height:1;"><?php echo $disetujui; ?></div>
            <div class="text-secondary small mt-1">Disetujui</div>
            <div style="font-size:11px; color:#10b981; margin-top:4px; font-weight:600;"><?php echo $pct_done; ?>% selesai</div>
        </div>
    </div>
    <!-- Revisi -->
    <div class="col-6 col-md-3">
        <div class="glass-card h-100 d-flex flex-column align-items-center justify-content-center text-center py-4"
             style="border-left: 3px solid #ef4444;">
            <div style="font-size:2rem; font-weight:800; color:#ef4444; line-height:1;"><?php echo $revisi; ?></div>
            <div class="text-secondary small mt-1">Perlu Revisi</div>
            <?php if ($revisi > 0): ?>
                <div class="mt-2 text-secondary" style="font-size:10px;">Menunggu perbaikan guru</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ===== OVERALL PROGRESS BAR ===== -->
<div class="glass-card mb-4">
    <div class="d-flex justify-content-between align-items-center mb-2">
        <span class="text-secondary small fw-semibold">Progress Verifikasi Keseluruhan</span>
        <span class="text-gold fw-bold"><?php echo $pct_done; ?>%</span>
    </div>
    <div class="progress" style="height:10px; border-radius:99px; background:rgba(255,255,255,0.05);">
        <div class="progress-bar" role="progressbar"
             style="width:<?php echo $pct_done; ?>%; background: linear-gradient(90deg, #10b981, #34d399); border-radius:99px; transition: width 1.2s ease;"
             aria-valuenow="<?php echo $pct_done; ?>" aria-valuemin="0" aria-valuemax="100"></div>
    </div>
    <div class="d-flex gap-4 mt-2">
        <span class="small" style="color:#10b981;"><i class="fa-solid fa-circle-check me-1"></i><?php echo $disetujui; ?> Disetujui</span>
        <span class="small" style="color:#f59e0b;"><i class="fa-solid fa-clock me-1"></i><?php echo $menunggu; ?> Menunggu</span>
        <span class="small" style="color:#ef4444;"><i class="fa-solid fa-rotate-left me-1"></i><?php echo $revisi; ?> Revisi</span>
    </div>
</div>

<!-- ===== PROGRESS PER GURU ===== -->
<div class="glass-card mb-4">
    <h5 class="text-gold fw-bold mb-4">
        <i class="fa-solid fa-chalkboard-user me-2"></i>Progress Jurnal per Guru
    </h5>
    <?php if (empty($guru_progress)): ?>
        <p class="text-secondary text-center py-4">Belum ada data jurnal untuk periode ini.</p>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-custom" id="table-guru-progress">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama Guru</th>
                    <th class="text-center">Total</th>
                    <th class="text-center" style="color:#f59e0b;">Menunggu</th>
                    <th class="text-center" style="color:#10b981;">Disetujui</th>
                    <th class="text-center" style="color:#ef4444;">Revisi</th>
                    <th>Progress</th>
                    <th>Input Terakhir</th>
                    <th class="no-print">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php $no = 1; foreach ($guru_progress as $gp):
                $g_total = max(1, (int)$gp['total_jurnal']);
                $g_ok    = (int)$gp['disetujui'];
                $g_wait  = (int)$gp['menunggu'];
                $g_rev   = (int)$gp['revisi'];
                $g_pct   = ($g_total > 0) ? round(($g_ok / $g_total) * 100) : 0;

                // Progress bar color
                $bar_color = '#10b981';
                if ($g_pct < 50) $bar_color = '#f59e0b';
                if ($g_pct < 20) $bar_color = '#ef4444';
            ?>
                <tr>
                    <td class="text-secondary small"><?php echo $no++; ?></td>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <div class="avatar-letter d-flex align-items-center justify-content-center rounded-circle bg-primary text-white"
                                 style="width:32px;height:32px;font-size:13px;font-weight:700;flex-shrink:0;">
                                <?php echo strtoupper(substr($gp['nama_guru'], 0, 1)); ?>
                            </div>
                            <div>
                                <strong class="text-white d-block" style="font-size:13px;"><?php echo htmlspecialchars($gp['nama_guru']); ?></strong>
                                <span class="text-secondary font-monospace" style="font-size:10px;">NIP: <?php echo htmlspecialchars($gp['nip']); ?></span>
                            </div>
                        </div>
                    </td>
                    <td class="text-center fw-bold text-white"><?php echo $gp['total_jurnal'] ?? 0; ?></td>
                    <td class="text-center">
                        <?php if ($g_wait > 0): ?>
                            <span class="badge badge-warning"><?php echo $g_wait; ?></span>
                        <?php else: ?>
                            <span class="text-secondary">—</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-center">
                        <span class="badge badge-success"><?php echo $g_ok; ?></span>
                    </td>
                    <td class="text-center">
                        <?php if ($g_rev > 0): ?>
                            <span class="badge badge-danger"><?php echo $g_rev; ?></span>
                        <?php else: ?>
                            <span class="text-secondary">—</span>
                        <?php endif; ?>
                    </td>
                    <td style="min-width:130px;">
                        <div class="d-flex align-items-center gap-2">
                            <div class="progress flex-grow-1" style="height:6px; border-radius:99px; background:rgba(255,255,255,0.05);">
                                <div class="progress-bar" style="width:<?php echo $g_pct; ?>%; background:<?php echo $bar_color; ?>; border-radius:99px;"></div>
                            </div>
                            <span style="font-size:10px; color:<?php echo $bar_color; ?>; font-weight:700; min-width:30px;"><?php echo $g_pct; ?>%</span>
                        </div>
                    </td>
                    <td>
                        <?php if ($gp['terakhir_input']): ?>
                            <span class="text-secondary small"><?php echo date('d M Y', strtotime($gp['terakhir_input'])); ?></span>
                        <?php else: ?>
                            <span class="text-secondary small">Belum ada</span>
                        <?php endif; ?>
                    </td>
                    <td class="no-print">
                        <a href="index.php?guru_id=<?php echo $gp['guru_id']; ?>&status=Menunggu+Verifikasi" 
                           class="btn btn-xs btn-gold" title="Lihat jurnal menunggu dari guru ini">
                            <i class="fa-solid fa-file-circle-check me-1"></i>Verifikasi
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<!-- ===== JURNAL MENUNGGU VERIFIKASI ===== -->
<div class="glass-card mb-4" id="section-pending">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="text-gold fw-bold mb-0">
            <i class="fa-solid fa-hourglass-half me-2"></i>Antrian Verifikasi
            <?php if ($menunggu > 0): ?>
                <span class="badge badge-warning ms-2" style="font-size:12px;"><?php echo $menunggu; ?></span>
            <?php endif; ?>
        </h5>
        <a href="index.php?status=Menunggu+Verifikasi" class="btn btn-xs btn-outline-custom text-gold">
            <i class="fa-solid fa-arrow-up-right-from-square me-1"></i>Lihat Semua
        </a>
    </div>

    <?php if (empty($pending_journals)): ?>
        <div class="text-center py-5">
            <i class="fa-solid fa-circle-check text-success mb-3" style="font-size:3rem; opacity:0.7;"></i>
            <p class="text-secondary mb-0">Semua jurnal sudah diverifikasi! Tidak ada antrian tersisa.</p>
        </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Guru</th>
                    <th>Hari & Tanggal</th>
                    <th>T.A / Semester</th>
                    <th>Jumlah Jam</th>
                    <th>Diinput</th>
                    <th class="no-print">Aksi Cepat</th>
                </tr>
            </thead>
            <tbody>
            <?php $no = 1; foreach ($pending_journals as $pj): ?>
                <?php
                // Count jam KBM
                try {
                    $jam_stmt = $pdo->prepare("SELECT COUNT(*) FROM jurnal_mengajar_detail WHERE jurnal_id = ?");
                    $jam_stmt->execute([$pj['id']]);
                    $jam_count = $jam_stmt->fetchColumn();
                } catch(Exception $e) { $jam_count = '?'; }

                // Days waiting
                $days_wait = (int)floor((time() - strtotime($pj['created_at'])) / 86400);
                $wait_color = '#10b981';
                if ($days_wait >= 3) $wait_color = '#f59e0b';
                if ($days_wait >= 7) $wait_color = '#ef4444';
                ?>
                <tr>
                    <td class="text-secondary small"><?php echo $no++; ?></td>
                    <td>
                        <strong class="text-white d-block" style="font-size:13px;"><?php echo htmlspecialchars($pj['nama_guru']); ?></strong>
                        <span class="text-secondary font-monospace" style="font-size:10px;"><?php echo htmlspecialchars($pj['nip']); ?></span>
                    </td>
                    <td>
                        <strong class="text-white d-block"><?php echo htmlspecialchars($pj['hari']); ?></strong>
                        <span class="text-secondary small"><?php echo date('d M Y', strtotime($pj['tanggal'])); ?></span>
                    </td>
                    <td>
                        <span class="badge badge-secondary" style="font-size:10px;"><?php echo htmlspecialchars($pj['tahun_ajaran']); ?></span>
                        <span class="badge badge-secondary" style="font-size:10px;"><?php echo htmlspecialchars($pj['semester']); ?></span>
                    </td>
                    <td class="text-center">
                        <span class="badge badge-secondary"><?php echo $jam_count; ?> Jam</span>
                    </td>
                    <td>
                        <span style="color:<?php echo $wait_color; ?>; font-size:11px; font-weight:600;">
                            <?php
                            if ($days_wait === 0) echo 'Hari ini';
                            elseif ($days_wait === 1) echo '1 hari lalu';
                            else echo $days_wait . ' hari lalu';
                            ?>
                        </span>
                    </td>
                    <td class="no-print">
                        <div class="d-flex gap-2">
                            <a href="verifikasi.php?id=<?php echo $pj['id']; ?>" class="btn btn-xs btn-gold" title="Buka form verifikasi">
                                <i class="fa-solid fa-signature me-1"></i>Verifikasi
                            </a>
                            <a href="print_detail.php?id=<?php echo $pj['id']; ?>" target="_blank" class="btn btn-xs btn-outline-custom text-gold" title="Lihat detail jurnal">
                                <i class="fa-solid fa-eye"></i>
                            </a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<!-- ===== HISTORI VERIFIKASI TERBARU ===== -->
<div class="glass-card mb-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h5 class="text-gold fw-bold mb-0">
            <i class="fa-solid fa-clock-rotate-left me-2"></i>Histori Verifikasi Terbaru
        </h5>
    </div>

    <?php if (empty($history)): ?>
        <p class="text-secondary text-center py-4">Belum ada riwayat verifikasi untuk periode ini.</p>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Guru</th>
                    <th>Tanggal Jurnal</th>
                    <th class="text-center">Status</th>
                    <th>Verifikator</th>
                    <th>Tgl Verifikasi</th>
                    <th>Catatan Supervisi</th>
                    <th class="no-print">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php $no = 1; foreach ($history as $h): ?>
                <?php
                $s_class = 'badge-success';
                if ($h['status'] === 'Revisi') $s_class = 'badge-danger';
                ?>
                <tr>
                    <td class="text-secondary small"><?php echo $no++; ?></td>
                    <td>
                        <strong class="text-white" style="font-size:13px;"><?php echo htmlspecialchars($h['nama_guru']); ?></strong>
                    </td>
                    <td>
                        <span class="text-secondary small"><?php echo date('d M Y', strtotime($h['tanggal'])); ?></span>
                    </td>
                    <td class="text-center">
                        <span class="badge <?php echo $s_class; ?>"><?php echo htmlspecialchars($h['status']); ?></span>
                    </td>
                    <td>
                        <span class="text-secondary small"><?php echo htmlspecialchars($h['verifikator'] ?? '—'); ?></span>
                    </td>
                    <td>
                        <span class="text-secondary small">
                            <?php echo $h['tanggal_verifikasi'] ? date('d/m/Y H:i', strtotime($h['tanggal_verifikasi'])) : '—'; ?>
                        </span>
                    </td>
                    <td>
                        <span class="text-secondary small d-inline-block text-truncate" style="max-width:200px;"
                              title="<?php echo htmlspecialchars($h['catatan'] ?? ''); ?>">
                            <?php echo !empty($h['catatan']) ? htmlspecialchars($h['catatan']) : '<em>Tanpa catatan</em>'; ?>
                        </span>
                    </td>
                    <td class="no-print">
                        <a href="verifikasi.php?id=<?php echo $h['id']; ?>" class="btn btn-xs btn-outline-info" title="Ubah Verifikasi">
                            <i class="fa-solid fa-pen-to-square"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<style>
/* Pulse animation for "menunggu" card */
@keyframes pulseWarn {
    0%, 100% { box-shadow: 0 0 0 0 rgba(245,158,11,0); }
    50%       { box-shadow: 0 0 0 6px rgba(245,158,11,0.15); }
}
.stat-pulse-warn {
    animation: pulseWarn 2s ease-in-out infinite;
}
</style>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
