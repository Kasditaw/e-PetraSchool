<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\siswa\export_excel.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';

// Enforce login
check_login();

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$filter_kelas = isset($_GET['kelas_id']) ? $_GET['kelas_id'] : '';
$filter_status = isset($_GET['status_siswa']) ? $_GET['status_siswa'] : '';

try {
    // Build query
    $query = "SELECT s.*, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON s.kelas_id = k.id WHERE 1=1";
    $params = [];

    if ($search !== '') {
        $query .= " AND (s.nama_lengkap LIKE :search OR s.nis LIKE :search OR s.nisn LIKE :search)";
        $params['search'] = "%$search%";
    }

    if ($filter_kelas !== '') {
        $query .= " AND s.kelas_id = :kelas_id";
        $params['kelas_id'] = intval($filter_kelas);
    }

    if ($filter_status !== '') {
        $query .= " AND s.status_siswa = :status_siswa";
        $params['status_siswa'] = $filter_status;
    }

    $query .= " ORDER BY s.nama_lengkap ASC";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $students = $stmt->fetchAll();

    // Log the excel export
    write_audit_log("Melakukan ekspor Excel data siswa.");

    // Headers for Excel file download
    header("Content-Type: application/vnd.ms-excel; charset=utf-8");
    header("Content-Disposition: attachment; filename=Laporan_Siswa_Petra1_" . date('Ymd_His') . ".xls");
    header("Pragma: no-cache");
    header("Expires: 0");

    // Output spreadsheet content as HTML Table which Excel parses natively
    echo "
    <table border='1'>
        <tr>
            <th colspan='15' style='font-size: 16px; font-weight: bold; text-align: center; height: 40px; background-color: #D4AF37; color: #000000;'>
                LAPORAN DATA SISWA SD KRISTEN PETRA 1 SURABAYA
            </th>
        </tr>
        <tr>
            <th style='background-color: #0B132B; color: #ffffff; font-weight: bold;'>No</th>
            <th style='background-color: #0B132B; color: #ffffff; font-weight: bold;'>NIS</th>
            <th style='background-color: #0B132B; color: #ffffff; font-weight: bold;'>NISN</th>
            <th style='background-color: #0B132B; color: #ffffff; font-weight: bold;'>Nama Lengkap</th>
            <th style='background-color: #0B132B; color: #ffffff; font-weight: bold;'>Jenis Kelamin</th>
            <th style='background-color: #0B132B; color: #ffffff; font-weight: bold;'>Tempat Lahir</th>
            <th style='background-color: #0B132B; color: #ffffff; font-weight: bold;'>Tanggal Lahir</th>
            <th style='background-color: #0B132B; color: #ffffff; font-weight: bold;'>Agama</th>
            <th style='background-color: #0B132B; color: #ffffff; font-weight: bold;'>Alamat Domisili</th>
            <th style='background-color: #0B132B; color: #ffffff; font-weight: bold;'>No HP Ortu</th>
            <th style='background-color: #0B132B; color: #ffffff; font-weight: bold;'>Nama Ayah</th>
            <th style='background-color: #0B132B; color: #ffffff; font-weight: bold;'>Nama Ibu</th>
            <th style='background-color: #0B132B; color: #ffffff; font-weight: bold;'>Kelas</th>
            <th style='background-color: #0B132B; color: #ffffff; font-weight: bold;'>Tahun Masuk</th>
            <th style='background-color: #0B132B; color: #ffffff; font-weight: bold;'>Status</th>
        </tr>
    ";

    $no = 1;
    foreach ($students as $student) {
        $gender_text = $student['gender'] === 'L' ? 'Laki-laki' : 'Perempuan';
        echo "
        <tr>
            <td style='text-align: center;'>" . $no++ . "</td>
            <td style='font-family: monospace; text-align: left;'>" . htmlspecialchars($student['nis']) . "</td>
            <td style='font-family: monospace; text-align: left;'>" . htmlspecialchars($student['nisn']) . "</td>
            <td>" . htmlspecialchars($student['nama_lengkap']) . "</td>
            <td>" . $gender_text . "</td>
            <td>" . htmlspecialchars($student['tempat_lahir']) . "</td>
            <td style='text-align: center;'>" . htmlspecialchars($student['tanggal_lahir']) . "</td>
            <td>" . htmlspecialchars($student['agama']) . "</td>
            <td>" . htmlspecialchars($student['alamat']) . "</td>
            <td style='text-align: left;'>" . htmlspecialchars($student['no_hp_ortu']) . "</td>
            <td>" . htmlspecialchars($student['nama_ayah']) . "</td>
            <td>" . htmlspecialchars($student['nama_ibu']) . "</td>
            <td>" . htmlspecialchars($student['nama_kelas'] ?? 'Tanpa Kelas') . "</td>
            <td style='text-align: center;'>" . htmlspecialchars($student['tahun_masuk']) . "</td>
            <td style='text-align: center; font-weight: bold;'>" . htmlspecialchars($student['status_siswa']) . "</td>
        </tr>
        ";
    }
    echo "</table>";
    exit;

} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}
?>
