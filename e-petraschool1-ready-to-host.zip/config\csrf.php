<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\config\csrf.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Generate CSRF Token and store in session if not exists
 */
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Output hidden input field for CSRF
 */
function csrf_input() {
    $token = generate_csrf_token();
    echo '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
}

/**
 * Validate CSRF Token
 */
function validate_csrf_token($token) {
    if (!isset($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Middleware to check CSRF for POST requests
 */
function check_csrf_request() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['csrf_token'] ?? '';
        if (!validate_csrf_token($token)) {
            // Log access violation
            require_once __DIR__ . '/audit.php';
            write_audit_log('Attempted unauthorized action (CSRF Token mismatch)', null, 'SYSTEM_CSRF');
            
            http_response_code(403);
            die("Error: Token keamanan (CSRF) tidak valid atau telah kadaluarsa.");
        }
    }
}
?>
