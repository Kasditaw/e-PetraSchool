<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris\dashboard.php

$page_title = 'Dashboard Inventaris';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_inventaris_access();

try {
    // 1. KPI Statistics
    // Total Aset
    $stmt = $pdo->query("SELECT SUM(jumlah) FROM inventaris WHERE status_aktif = 'Aktif'");
    $total_aset = intval($stmt->fetchColumn());

    // Aset Aktif (Baik + Cukup)
    $stmt = $pdo->query("SELECT SUM(jumlah) FROM inventaris WHERE status_aktif = 'Aktif' AND kondisi IN ('Baik', 'Cukup')");
    $aset_aktif = intval($stmt->fetchColumn());

    // Aset Rusak (Rusak Ringan + Rusak Berat)
    $stmt = $pdo->query("SELECT SUM(jumlah) FROM inventaris WHERE status_aktif = 'Aktif' AND kondisi IN ('Rusak Ringan', 'Rusak Berat')");
    $aset_rusak = intval($stmt->fetchColumn());

    // Aset Dipinjam
    $stmt = $pdo->query("SELECT COUNT(*) FROM peminjaman WHERE status = 'Dipinjam'");
    $aset_dipinjam = intval($stmt->fetchColumn());

    // Aset Dalam Perawatan (Total unique items maintained in the last 6 months or ever)
    $stmt = $pdo->query("SELECT COUNT(DISTINCT inventaris_id) FROM perawatan_barang");
    $aset_rawat = intval($stmt->fetchColumn());

    // Nilai Total Aset
    $stmt = $pdo->query("SELECT SUM(harga * jumlah) FROM inventaris WHERE status_aktif = 'Aktif'");
    $nilai_total = floatval($stmt->fetchColumn());

    // 2. Chart Data: Assets by Category
    $cat_stmt = $pdo->query("
        SELECT k.nama_kategori, SUM(i.jumlah) as jumlah 
        FROM inventaris i 
        JOIN kategori_barang k ON i.kategori_id = k.id 
        WHERE i.status_aktif = 'Aktif'
        GROUP BY k.id 
        ORDER BY jumlah DESC
    ");
    $cat_data = $cat_stmt->fetchAll();
    
    $cat_labels = [];
    $cat_values = [];
    foreach ($cat_data as $row) {
        $cat_labels[] = $row['nama_kategori'];
        $cat_values[] = intval($row['jumlah']);
    }

    // Chart Data: Assets by Condition
    $cond_stmt = $pdo->query("
        SELECT kondisi, SUM(jumlah) as jumlah 
        FROM inventaris 
        WHERE status_aktif = 'Aktif'
        GROUP BY kondisi
    ");
    $cond_data = $cond_stmt->fetchAll();
    
    $cond_labels = [];
    $cond_values = [];
    $cond_colors = [];
    
    $color_map = [
        'Baik' => '#10b981', // green
        'Cukup' => '#3b82f6', // blue
        'Rusak Ringan' => '#f59e0b', // orange
        'Rusak Berat' => '#ef4444' // red
    ];
    
    foreach ($cond_data as $row) {
        $cond_labels[] = $row['kondisi'];
        $cond_values[] = intval($row['jumlah']);
        $cond_colors[] = $color_map[$row['kondisi']] ?? '#6b7280';
    }

    // 3. Recent Activities (Mutasi & Perawatan)
    $history_stmt = $pdo->query("
        SELECT h.*, i.nama_barang, i.kode_barang 
        FROM histori_inventaris h 
        JOIN inventaris i ON h.inventaris_id = i.id 
        ORDER BY h.tanggal DESC 
        LIMIT 6
    ");
    $recent_history = $history_stmt->fetchAll();

} catch (Exception $e) {
    echo '<div class="alert alert-danger">Database error: ' . $e->getMessage() . '</div>';
}
?>

<style>
.kpi-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    border: 1px solid var(--border-color);
}
.kpi-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    border-color: rgba(212, 175, 55, 0.3);
}
.kpi-icon {
    font-size: 24px;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 12px;
}
.kpi-icon.gold {
    background: rgba(212, 175, 55, 0.1);
    color: var(--color-gold);
}
.kpi-icon.blue {
    background: rgba(59, 130, 246, 0.1);
    color: #3b82f6;
}
.kpi-icon.success {
    background: rgba(16, 185, 129, 0.1);
    color: #10b981;
}
.kpi-icon.warning {
    background: rgba(245, 158, 11, 0.1);
    color: #f59e0b;
}
.kpi-icon.danger {
    background: rgba(239, 68, 68, 0.1);
    color: #ef4444;
}
.kpi-icon.purple {
    background: rgba(139, 92, 246, 0.1);
    color: #8b5cf6;
}
.activity-item {
    border-left: 3px solid var(--color-gold);
    background: rgba(255,255,255,0.02);
    border-radius: 0 6px 6px 0;
    padding: 10px 14px;
    transition: transform 0.2s ease;
}
.activity-item:hover {
    transform: translateX(4px);
    background: rgba(255,255,255,0.04);
}
</style>

<div class="glass-card mb-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-chart-pie me-2"></i> Dashboard Manajemen Inventaris</h5>
            <p class="text-secondary small mb-0">Statistik real-time, kondisi, nilai perolehan, dan aktivitas log aset SD Kristen Petra 1.</p>
        </div>
        <div>
            <a href="index.php" class="btn btn-gold"><i class="fa-solid fa-boxes-stacked me-1"></i> Data Inventaris Utama</a>
        </div>
    </div>
</div>

<!-- KPI Summary Cards -->
<div class="row g-3 mb-4">
    <!-- Total Aset -->
    <div class="col-6 col-md-4 col-lg-2">
        <div class="glass-card kpi-card p-3 mb-0 h-100">
            <div class="kpi-icon blue mb-2"><i class="fa-solid fa-boxes-stacked"></i></div>
            <div>
                <span class="text-secondary small d-block mb-1">Total Aset</span>
                <h3 class="fw-bold mb-0 text-white"><?php echo number_format($total_aset, 0, ',', '.'); ?> <span class="small text-secondary" style="font-size: 12px;">Unit</span></h3>
            </div>
        </div>
    </div>
    <!-- Aset Aktif -->
    <div class="col-6 col-md-4 col-lg-2">
        <div class="glass-card kpi-card p-3 mb-0 h-100">
            <div class="kpi-icon success mb-2"><i class="fa-solid fa-check-circle"></i></div>
            <div>
                <span class="text-secondary small d-block mb-1">Aset Layak</span>
                <h3 class="fw-bold mb-0 text-success"><?php echo number_format($aset_aktif, 0, ',', '.'); ?> <span class="small text-secondary" style="font-size: 12px;">Unit</span></h3>
            </div>
        </div>
    </div>
    <!-- Aset Rusak -->
    <div class="col-6 col-md-4 col-lg-2">
        <div class="glass-card kpi-card p-3 mb-0 h-100">
            <div class="kpi-icon danger mb-2"><i class="fa-solid fa-circle-xmark"></i></div>
            <div>
                <span class="text-secondary small d-block mb-1">Aset Rusak</span>
                <h3 class="fw-bold mb-0 text-danger"><?php echo number_format($aset_rusak, 0, ',', '.'); ?> <span class="small text-secondary" style="font-size: 12px;">Unit</span></h3>
            </div>
        </div>
    </div>
    <!-- Aset Dipinjam -->
    <div class="col-6 col-md-4 col-lg-2">
        <div class="glass-card kpi-card p-3 mb-0 h-100">
            <div class="kpi-icon warning mb-2"><i class="fa-solid fa-handshake-angle"></i></div>
            <div>
                <span class="text-secondary small d-block mb-1">Dipinjam</span>
                <h3 class="fw-bold mb-0 text-warning"><?php echo number_format($aset_dipinjam, 0, ',', '.'); ?> <span class="small text-secondary" style="font-size: 12px;">Unit</span></h3>
            </div>
        </div>
    </div>
    <!-- Aset Dirawat -->
    <div class="col-6 col-md-4 col-lg-2">
        <div class="glass-card kpi-card p-3 mb-0 h-100">
            <div class="kpi-icon purple mb-2"><i class="fa-solid fa-screwdriver-wrench"></i></div>
            <div>
                <span class="text-secondary small d-block mb-1">Pernah Servis</span>
                <h3 class="fw-bold mb-0 text-white" style="color: #c084fc !important;"><?php echo number_format($aset_rawat, 0, ',', '.'); ?> <span class="small text-secondary" style="font-size: 12px;">Tipe</span></h3>
            </div>
        </div>
    </div>
    <!-- Total Nilai Aset -->
    <div class="col-6 col-md-4 col-lg-2">
        <div class="glass-card kpi-card p-3 mb-0 h-100">
            <div class="kpi-icon gold mb-2"><i class="fa-solid fa-wallet"></i></div>
            <div>
                <span class="text-secondary small d-block mb-1">Total Nilai</span>
                <h4 class="fw-bold mb-0 text-gold" style="font-size: 15px;">Rp <?php echo number_format($nilai_total, 0, ',', '.'); ?></h4>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Category Chart -->
    <div class="col-12 col-md-6">
        <div class="glass-card h-100 mb-0">
            <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-chart-simple me-2"></i> Jumlah Aset per Kategori</h6>
            <div style="position: relative; height: 260px;">
                <canvas id="categoryChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Condition Chart -->
    <div class="col-12 col-md-6">
        <div class="glass-card h-100 mb-0">
            <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-chart-pie me-2"></i> Proporsi Kondisi Aset</h6>
            <div style="position: relative; height: 260px;">
                <canvas id="conditionChart"></canvas>
            </div>
        </div>
    </div>
</div>

<!-- Recent Activities -->
<div class="glass-card">
    <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-clock-rotate-left me-2"></i> Histori Aktivitas Inventaris Terbaru</h6>
    
    <div class="row g-3">
        <?php if (count($recent_history) > 0): ?>
            <?php foreach ($recent_history as $hist): ?>
                <div class="col-md-6">
                    <div class="activity-item d-flex justify-content-between align-items-start gap-2">
                        <div>
                            <span class="badge badge-secondary mb-1" style="font-size: 10px;"><?php echo htmlspecialchars($hist['aktivitas']); ?></span>
                            <h6 class="text-white small fw-bold mb-1"><?php echo htmlspecialchars($hist['nama_barang']); ?> <span class="font-monospace text-secondary small">(<?php echo htmlspecialchars($hist['kode_barang']); ?>)</span></h6>
                            <p class="text-secondary mb-0" style="font-size: 11px;"><?php echo htmlspecialchars($hist['keterangan']); ?></p>
                        </div>
                        <div class="text-end" style="min-width: 90px;">
                            <span class="text-white d-block" style="font-size: 10.5px; font-weight: 600;"><i class="fa-solid fa-user me-1 text-gold" style="font-size: 9px;"></i> <?php echo htmlspecialchars($hist['pengguna']); ?></span>
                            <span class="text-secondary" style="font-size: 9.5px;"><?php echo date('d-m-Y H:i', strtotime($hist['tanggal'])); ?></span>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center text-secondary py-4">Belum ada aktivitas inventaris tercatat. Aktivitas akan tercatat ketika terjadi mutasi, servis, peminjaman, atau penghapusan aset.</div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Category Chart
    const ctxCat = document.getElementById('categoryChart').getContext('2d');
    new Chart(ctxCat, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($cat_labels); ?>,
            datasets: [{
                label: 'Jumlah Unit',
                data: <?php echo json_encode($cat_values); ?>,
                backgroundColor: 'rgba(212, 175, 55, 0.45)',
                borderColor: '#D4AF37',
                borderWidth: 1.5,
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    grid: { color: 'rgba(255,255,255,0.06)' },
                    ticks: { color: '#94a3b8' }
                },
                x: {
                    grid: { display: false },
                    ticks: { color: '#94a3b8' }
                }
            }
        }
    });

    // Condition Chart
    const ctxCond = document.getElementById('conditionChart').getContext('2d');
    new Chart(ctxCond, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode($cond_labels); ?>,
            datasets: [{
                data: <?php echo json_encode($cond_values); ?>,
                backgroundColor: <?php echo json_encode($cond_colors); ?>,
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: { color: '#94a3b8', boxWidth: 12 }
                }
            }
        }
    });
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
