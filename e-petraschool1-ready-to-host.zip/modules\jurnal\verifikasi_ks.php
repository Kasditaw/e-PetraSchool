<?php
// c:\xampp\htdocs\e-petraschool\modules\jurnal\verifikasi_ks.php
// Modul Verifikasi Jurnal Mengajar - Khusus Kepala Sekolah

$page_title = 'Verifikasi Jurnal — Kepala Sekolah';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Kepala Sekolah']);

// ======================================================
// FILTER PARAMS
// ======================================================
$filter_ta   = isset($_GET['tahun_ajaran_id']) ? intval($_GET['tahun_ajaran_id']) : 0;
$filter_sem  = isset($_GET['semester_id'])     ? intval($_GET['semester_id'])     : 0;
$filter_guru = isset($_GET['guru_id'])         ? intval($_GET['guru_id'])         : 0;
$filter_status = isset($_GET['status'])        ? trim($_GET['status'])            : '';
$search        = isset($_GET['search'])        ? trim($_GET['search'])            : '';
$view_mode     = isset($_GET['view'])          ? trim($_GET['view'])              : 'dashboard'; // dashboard | antrian | histori | per_guru

try {
    $ta_list  = $pdo->query("SELECT * FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();
    $sem_list = $pdo->query("SELECT * FROM semester ORDER BY id ASC")->fetchAll();

    // Default to active
    if ($filter_ta === 0) {
        foreach ($ta_list as $ta) {
            if ($ta['status'] === 'Aktif') { $filter_ta = $ta['id']; break; }
        }
    }
    if ($filter_sem === 0) {
        foreach ($sem_list as $s) {
            if ($s['status'] === 'Aktif') { $filter_sem = $s['id']; break; }
        }
    }

    // ---- STATISTIK UTAMA ----
    $base_params = [':ta_id' => $filter_ta, ':sem_id' => $filter_sem];
    $cond_ta_sem = " AND j.tahun_ajaran_id = :ta_id AND j.semester_id = :sem_id";

    $s_stmt = $pdo->prepare("SELECT
        COUNT(*)                              AS total,
        SUM(j.status = 'Menunggu Verifikasi') AS menunggu,
        SUM(j.status = 'Disetujui')           AS disetujui,
        SUM(j.status = 'Revisi')              AS revisi
        FROM jurnal_mengajar j WHERE 1=1" . $cond_ta_sem);
    $s_stmt->execute($base_params);
    $stats = $s_stmt->fetch();

    // ---- PER GURU PROGRESS ----
    $gp_params = $base_params;
    $gp_where  = $cond_ta_sem;
    if ($filter_guru > 0) {
        $gp_where .= " AND j.guru_id = :guru_filter";
        $gp_params[':guru_filter'] = $filter_guru;
    }
    $gp_stmt = $pdo->prepare("SELECT
        g.id AS guru_id, g.nama_guru, g.nip, g.foto,
        COUNT(j.id)                            AS total_jurnal,
        SUM(j.status = 'Menunggu Verifikasi')  AS menunggu,
        SUM(j.status = 'Disetujui')            AS disetujui,
        SUM(j.status = 'Revisi')               AS revisi,
        MAX(j.tanggal)                         AS terakhir_input,
        MAX(j.created_at)                      AS terakhir_submit
        FROM guru g
        LEFT JOIN jurnal_mengajar j ON j.guru_id = g.id" . $gp_where . "
        GROUP BY g.id, g.nama_guru, g.nip, g.foto
        ORDER BY menunggu DESC, g.nama_guru ASC");
    $gp_stmt->execute($gp_params);
    $guru_progress = $gp_stmt->fetchAll();

    // ---- JURNAL MENUNGGU (antrian) ----
    $pend_params = $base_params;
    $pend_where  = $cond_ta_sem;
    if ($filter_guru > 0) {
        $pend_where .= " AND j.guru_id = :guru_filter2";
        $pend_params[':guru_filter2'] = $filter_guru;
    }
    if ($search !== '') {
        $pend_where .= " AND (g.nama_guru LIKE :search OR j.hari LIKE :search)";
        $pend_params[':search'] = "%$search%";
    }
    $pend_stmt = $pdo->prepare("SELECT j.*, g.nama_guru, g.nip, s.semester, t.tahun_ajaran
        FROM jurnal_mengajar j
        JOIN guru g ON j.guru_id = g.id
        JOIN semester s ON j.semester_id = s.id
        JOIN tahun_ajaran t ON j.tahun_ajaran_id = t.id
        WHERE j.status = 'Menunggu Verifikasi'" . $pend_where . "
        ORDER BY j.tanggal ASC, j.created_at ASC");
    $pend_stmt->execute($pend_params);
    $pending_journals = $pend_stmt->fetchAll();

    // ---- HISTORI VERIFIKASI ----
    $hist_params = $base_params;
    $hist_where  = $cond_ta_sem;
    if ($filter_guru > 0) {
        $hist_where .= " AND j.guru_id = :guru_filter3";
        $hist_params[':guru_filter3'] = $filter_guru;
    }
    if ($filter_status !== '') {
        $hist_where .= " AND j.status = :h_status";
        $hist_params[':h_status'] = $filter_status;
    }
    if ($search !== '') {
        $hist_where .= " AND g.nama_guru LIKE :search2";
        $hist_params[':search2'] = "%$search%";
    }
    $hist_stmt = $pdo->prepare("SELECT j.*, g.nama_guru, g.nip, s.semester, t.tahun_ajaran,
        v.catatan, v.tanggal_verifikasi, u.nama AS verifikator
        FROM jurnal_mengajar j
        JOIN guru g ON j.guru_id = g.id
        JOIN semester s ON j.semester_id = s.id
        JOIN tahun_ajaran t ON j.tahun_ajaran_id = t.id
        LEFT JOIN verifikasi_jurnal v ON v.jurnal_id = j.id
        LEFT JOIN users u ON u.id = v.verifikator_id
        WHERE j.status IN ('Disetujui','Revisi')" . $hist_where . "
        ORDER BY v.tanggal_verifikasi DESC
        LIMIT 50");
    $hist_stmt->execute($hist_params);
    $history = $hist_stmt->fetchAll();

    // ---- GURU LIST FOR FILTER ----
    $guru_list = $pdo->query("SELECT id, nama_guru, nip FROM guru ORDER BY nama_guru ASC")->fetchAll();

} catch (Exception $e) {
    die('<div class="alert alert-danger">Error database: ' . htmlspecialchars($e->getMessage()) . '</div>');
}

// ======================================================
// COMPUTED SUMMARY
// ======================================================
$total_j   = (int)($stats['total']    ?? 0);
$menunggu  = (int)($stats['menunggu'] ?? 0);
$disetujui = (int)($stats['disetujui'] ?? 0);
$revisi    = (int)($stats['revisi']   ?? 0);
$pct_done  = $total_j > 0 ? round(($disetujui / $total_j) * 100) : 0;

$ta_label  = '—'; foreach ($ta_list  as $x) { if ($x['id'] == $filter_ta)  { $ta_label  = $x['tahun_ajaran']; break; } }
$sem_label = '—'; foreach ($sem_list as $x) { if ($x['id'] == $filter_sem) { $sem_label = $x['semester'];     break; } }

// Build base query string for links
$base_qs = http_build_query(array_filter([
    'tahun_ajaran_id' => $filter_ta,
    'semester_id'     => $filter_sem,
    'guru_id'         => $filter_guru ?: '',
]));
?>

<!-- ======================================================
     PAGE STYLES
     ====================================================== -->
<style>
/* ---- KS Module Custom Styles ---- */
.ks-hero {
    background: linear-gradient(135deg, rgba(212,175,55,0.12) 0%, rgba(59,130,246,0.08) 50%, rgba(16,185,129,0.06) 100%);
    border: 1px solid rgba(212,175,55,0.25);
    border-radius: 16px;
    padding: 28px 32px;
    margin-bottom: 28px;
    position: relative;
    overflow: hidden;
}
.ks-hero::before {
    content: '';
    position: absolute;
    top: -60px; right: -60px;
    width: 200px; height: 200px;
    background: radial-gradient(circle, rgba(212,175,55,0.12) 0%, transparent 70%);
    pointer-events: none;
}
.ks-stat-card {
    background: var(--card-bg, rgba(255,255,255,0.03));
    border: 1px solid var(--border-color, rgba(255,255,255,0.08));
    border-radius: 14px;
    padding: 20px 22px;
    transition: transform 0.2s, box-shadow 0.2s;
    position: relative;
    overflow: hidden;
}
.ks-stat-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 12px 30px rgba(0,0,0,0.2);
}
.ks-stat-value {
    font-size: 2.4rem;
    font-weight: 800;
    line-height: 1;
    font-family: 'Outfit', sans-serif;
}
.ks-tab-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 9px 18px;
    border-radius: 8px;
    border: 1px solid transparent;
    font-size: 13.5px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    transition: all 0.18s;
    color: var(--text-secondary, #94a3b8);
}
.ks-tab-btn:hover {
    background: rgba(212,175,55,0.08);
    border-color: rgba(212,175,55,0.2);
    color: #D4AF37;
}
.ks-tab-btn.active {
    background: rgba(212,175,55,0.12);
    border-color: rgba(212,175,55,0.35);
    color: #D4AF37;
}
.ks-tab-btn .tab-badge {
    background: #f59e0b;
    color: #000;
    border-radius: 50px;
    padding: 1px 7px;
    font-size: 10px;
    font-weight: 800;
    min-width: 20px;
    text-align: center;
}
.progress-ring {
    width: 90px; height: 90px;
    position: relative;
    flex-shrink: 0;
}
.progress-ring svg { transform: rotate(-90deg); }
.progress-ring .ring-text {
    position: absolute;
    top: 50%; left: 50%;
    transform: translate(-50%, -50%);
    font-weight: 800;
    font-size: 18px;
    color: #D4AF37;
    font-family: 'Outfit', sans-serif;
}
.guru-card {
    background: var(--card-bg, rgba(255,255,255,0.03));
    border: 1px solid var(--border-color, rgba(255,255,255,0.07));
    border-radius: 12px;
    padding: 16px 18px;
    transition: border-color 0.2s, transform 0.2s;
}
.guru-card:hover {
    border-color: rgba(212,175,55,0.3);
    transform: translateY(-2px);
}
.guru-avatar {
    width: 44px; height: 44px;
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 17px; font-weight: 700;
    color: #fff; flex-shrink: 0;
    font-family: 'Outfit', sans-serif;
}
.mini-bar {
    height: 5px;
    border-radius: 99px;
    background: rgba(255,255,255,0.05);
    overflow: hidden;
    margin-top: 8px;
}
.mini-bar-fill {
    height: 100%;
    border-radius: 99px;
    transition: width 0.8s ease;
}
.pending-row-urgent {
    border-left: 3px solid #ef4444 !important;
}
.pending-row-warn {
    border-left: 3px solid #f59e0b !important;
}
@keyframes pulseWarn {
    0%,100% { box-shadow: 0 0 0 0 rgba(245,158,11,0); }
    50%      { box-shadow: 0 0 0 8px rgba(245,158,11,0.12); }
}
.card-pulse-warn { animation: pulseWarn 2.2s ease-in-out infinite; }
.section-panel {
    background: var(--card-bg, rgba(255,255,255,0.03));
    border: 1px solid var(--border-color, rgba(255,255,255,0.07));
    border-radius: 14px;
    padding: 24px;
    margin-bottom: 24px;
}
.section-title {
    font-size: 15px;
    font-weight: 700;
    color: #D4AF37;
    margin-bottom: 18px;
    display: flex;
    align-items: center;
    gap: 9px;
}
</style>

<!-- ======================================================
     KS HERO BANNER
     ====================================================== -->
<div class="ks-hero mb-4">
    <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
        <div>
            <div class="d-flex align-items-center gap-3 mb-2">
                <div style="width:52px;height:52px;background:linear-gradient(135deg,#D4AF37,#f59e0b);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0;">
                    <i class="fa-solid fa-shield-check" style="color:#000;"></i>
                </div>
                <div>
                    <h4 class="fw-bold mb-0" style="color:#D4AF37;font-family:'Outfit',sans-serif;">
                        Verifikasi Jurnal Mengajar
                    </h4>
                    <span class="text-secondary small">Panel Supervisi Kepala Sekolah — <?php echo htmlspecialchars($ta_label); ?> / Sem. <?php echo htmlspecialchars($sem_label); ?></span>
                </div>
            </div>
            <p class="text-secondary small mb-0">
                Pantau, verifikasi, dan supervisi jurnal harian seluruh guru. Gunakan filter untuk menyesuaikan tampilan.
            </p>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <a href="index.php" class="btn btn-outline-secondary btn-sm">
                <i class="fa-solid fa-list me-1"></i>Semua Jurnal
            </a>
            <a href="verifikasi_ks.php?<?php echo $base_qs; ?>&view=antrian" class="btn btn-gold btn-sm <?php echo $menunggu > 0 ? 'card-pulse-warn' : ''; ?>">
                <i class="fa-solid fa-hourglass-half me-1"></i>Antrian 
                <?php if ($menunggu > 0): ?>
                    <span class="badge bg-dark ms-1"><?php echo $menunggu; ?></span>
                <?php endif; ?>
            </a>
            <button id="btn-export-excel" class="btn btn-outline-success btn-sm" style="border-radius: 8px; font-weight: 600;">
                <i class="fa-solid fa-file-excel me-1"></i>Excel
            </button>
            <button id="btn-export-pdf" class="btn btn-outline-danger btn-sm" style="border-radius: 8px; font-weight: 600;">
                <i class="fa-solid fa-file-pdf me-1"></i>PDF
            </button>
        </div>
    </div>
</div>

<!-- ======================================================
     FILTER BAR
     ====================================================== -->
<div class="section-panel py-3 mb-4">
    <form method="GET" action="verifikasi_ks.php" class="row g-2 align-items-end">
        <input type="hidden" name="view" value="<?php echo htmlspecialchars($view_mode); ?>">
        <div class="col-12 col-sm-6 col-md-3">
            <label class="form-label form-label-custom mb-1">Tahun Ajaran</label>
            <select name="tahun_ajaran_id" class="form-select form-control-custom bg-dark-select text-white">
                <?php foreach ($ta_list as $ta): ?>
                    <option value="<?php echo $ta['id']; ?>" <?php echo $filter_ta == $ta['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($ta['tahun_ajaran']); ?><?php echo $ta['status'] === 'Aktif' ? ' ★' : ''; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom mb-1">Semester</label>
            <select name="semester_id" class="form-select form-control-custom bg-dark-select text-white">
                <?php foreach ($sem_list as $s): ?>
                    <option value="<?php echo $s['id']; ?>" <?php echo $filter_sem == $s['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($s['semester']); ?><?php echo $s['status'] === 'Aktif' ? ' ★' : ''; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-6 col-md-3">
            <label class="form-label form-label-custom mb-1">Filter Guru</label>
            <select name="guru_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="0">Semua Guru</option>
                <?php foreach ($guru_list as $g): ?>
                    <option value="<?php echo $g['id']; ?>" <?php echo $filter_guru == $g['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($g['nama_guru']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-md-3">
            <label class="form-label form-label-custom mb-1">Pencarian</label>
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari nama guru..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        <div class="col-auto d-flex gap-2">
            <button type="submit" class="btn btn-gold px-4"><i class="fa-solid fa-filter me-1"></i>Terapkan</button>
            <a href="verifikasi_ks.php" class="btn btn-outline-secondary">Reset</a>
        </div>
    </form>
</div>

<!-- ======================================================
     STAT CARDS ROW
     ====================================================== -->
<div class="row g-3 mb-4">
    <!-- Total -->
    <div class="col-6 col-md-3">
        <div class="ks-stat-card" style="border-left: 3px solid #60a5fa;">
            <div class="d-flex align-items-center justify-content-between mb-2">
                <span class="text-secondary small fw-semibold">Total Jurnal</span>
                <i class="fa-solid fa-journal-whills" style="color:#60a5fa; font-size:18px;"></i>
            </div>
            <div class="ks-stat-value" style="color:#60a5fa;"><?php echo $total_j; ?></div>
            <div class="small text-secondary mt-1"><?php echo $ta_label; ?> · <?php echo $sem_label; ?></div>
        </div>
    </div>

    <!-- Menunggu -->
    <div class="col-6 col-md-3">
        <a href="verifikasi_ks.php?<?php echo $base_qs; ?>&view=antrian" class="text-decoration-none">
            <div class="ks-stat-card <?php echo $menunggu > 0 ? 'card-pulse-warn' : ''; ?>" style="border-left: 3px solid #f59e0b;">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <span class="text-secondary small fw-semibold">Menunggu</span>
                    <i class="fa-solid fa-hourglass-half" style="color:#f59e0b; font-size:18px;"></i>
                </div>
                <div class="ks-stat-value" style="color:#f59e0b;"><?php echo $menunggu; ?></div>
                <div class="small mt-1" style="color:#f59e0b; font-weight:600;">
                    <?php echo $menunggu > 0 ? 'Perlu ditindaklanjuti' : 'Semua sudah diverifikasi'; ?>
                </div>
            </div>
        </a>
    </div>

    <!-- Disetujui -->
    <div class="col-6 col-md-3">
        <div class="ks-stat-card" style="border-left: 3px solid #10b981;">
            <div class="d-flex align-items-center justify-content-between mb-2">
                <span class="text-secondary small fw-semibold">Disetujui</span>
                <i class="fa-solid fa-circle-check" style="color:#10b981; font-size:18px;"></i>
            </div>
            <div class="ks-stat-value" style="color:#10b981;"><?php echo $disetujui; ?></div>
            <div class="small mt-1" style="color:#10b981; font-weight:600;"><?php echo $pct_done; ?>% dari total</div>
        </div>
    </div>

    <!-- Revisi -->
    <div class="col-6 col-md-3">
        <div class="ks-stat-card" style="border-left: 3px solid #ef4444;">
            <div class="d-flex align-items-center justify-content-between mb-2">
                <span class="text-secondary small fw-semibold">Revisi</span>
                <i class="fa-solid fa-rotate-left" style="color:#ef4444; font-size:18px;"></i>
            </div>
            <div class="ks-stat-value" style="color:#ef4444;"><?php echo $revisi; ?></div>
            <div class="small text-secondary mt-1"><?php echo $revisi > 0 ? 'Menunggu perbaikan guru' : 'Tidak ada revisi'; ?></div>
        </div>
    </div>
</div>

<!-- ======================================================
     OVERALL PROGRESS
     ====================================================== -->
<div class="section-panel mb-4">
    <div class="d-flex align-items-center gap-4 flex-wrap">
        <!-- Progress Ring SVG -->
        <div class="progress-ring" title="<?php echo $pct_done; ?>% terverifikasi">
            <svg viewBox="0 0 90 90" xmlns="http://www.w3.org/2000/svg">
                <circle cx="45" cy="45" r="37" stroke="rgba(255,255,255,0.06)" stroke-width="7" fill="none"/>
                <circle cx="45" cy="45" r="37"
                    stroke="#10b981" stroke-width="7" fill="none"
                    stroke-dasharray="<?php echo round(2 * M_PI * 37 * $pct_done / 100, 2); ?> <?php echo round(2 * M_PI * 37, 2); ?>"
                    stroke-linecap="round"
                    style="transition: stroke-dasharray 1.2s ease;"/>
            </svg>
            <div class="ring-text"><?php echo $pct_done; ?>%</div>
        </div>

        <div class="flex-grow-1">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="fw-bold text-white" style="font-size:15px;">Progress Verifikasi — <?php echo $ta_label; ?> / Sem. <?php echo $sem_label; ?></span>
                <span class="badge" style="background:rgba(16,185,129,0.15); color:#10b981; font-size:11px; font-weight:700; border:1px solid rgba(16,185,129,0.25);">
                    <?php echo $disetujui; ?> / <?php echo $total_j; ?> Disetujui
                </span>
            </div>
            <div class="progress mb-3" style="height:10px; border-radius:99px; background:rgba(255,255,255,0.05);">
                <div class="progress-bar" role="progressbar"
                     style="width:<?php echo $pct_done; ?>%; background: linear-gradient(90deg, #10b981, #34d399); border-radius:99px; transition: width 1.2s ease;"
                     aria-valuenow="<?php echo $pct_done; ?>" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <div class="d-flex gap-4 flex-wrap">
                <span class="small" style="color:#10b981;"><i class="fa-solid fa-circle-check me-1"></i><?php echo $disetujui; ?> Disetujui</span>
                <span class="small" style="color:#f59e0b;"><i class="fa-solid fa-clock me-1"></i><?php echo $menunggu; ?> Menunggu</span>
                <span class="small" style="color:#ef4444;"><i class="fa-solid fa-rotate-left me-1"></i><?php echo $revisi; ?> Perlu Revisi</span>
                <span class="small text-secondary"><i class="fa-solid fa-circle-dot me-1"></i><?php echo $total_j; ?> Total Jurnal</span>
            </div>
        </div>
    </div>
</div>

<!-- ======================================================
     TAB NAVIGATION
     ====================================================== -->
<div class="d-flex gap-2 flex-wrap mb-4">
    <a href="verifikasi_ks.php?<?php echo $base_qs; ?>&view=dashboard"
       class="ks-tab-btn <?php echo $view_mode === 'dashboard' ? 'active' : ''; ?>">
        <i class="fa-solid fa-gauge-high"></i> Ringkasan Per Guru
    </a>
    <a href="verifikasi_ks.php?<?php echo $base_qs; ?>&view=antrian"
       class="ks-tab-btn <?php echo $view_mode === 'antrian' ? 'active' : ''; ?>">
        <i class="fa-solid fa-hourglass-half"></i> Antrian Verifikasi
        <?php if ($menunggu > 0): ?>
            <span class="tab-badge"><?php echo $menunggu; ?></span>
        <?php endif; ?>
    </a>
    <a href="verifikasi_ks.php?<?php echo $base_qs; ?>&view=histori"
       class="ks-tab-btn <?php echo $view_mode === 'histori' ? 'active' : ''; ?>">
        <i class="fa-solid fa-clock-rotate-left"></i> Histori Verifikasi
    </a>
</div>

<!-- ======================================================
     PANEL: RINGKASAN PER GURU (Card Grid)
     ====================================================== -->
<?php if ($view_mode === 'dashboard'): ?>
<div class="section-panel">
    <div class="section-title">
        <i class="fa-solid fa-chalkboard-user"></i>
        Progress Jurnal per Guru
        <span class="badge" style="background:rgba(255,255,255,0.06); color:#94a3b8; font-size:11px; font-weight:600; margin-left:4px;"><?php echo count($guru_progress); ?> Guru</span>
    </div>

    <?php if (empty($guru_progress)): ?>
        <div class="text-center py-5 text-secondary">
            <i class="fa-solid fa-inbox mb-3" style="font-size:3rem; opacity:0.3;"></i>
            <p class="mb-0">Belum ada data jurnal untuk periode ini.</p>
        </div>
    <?php else: ?>
    <div class="row g-3">
        <?php foreach ($guru_progress as $gp):
            $g_total = max(1, (int)$gp['total_jurnal']);
            $g_ok    = (int)$gp['disetujui'];
            $g_wait  = (int)$gp['menunggu'];
            $g_rev   = (int)$gp['revisi'];
            $g_pct   = ($g_total > 0) ? round(($g_ok / $g_total) * 100) : 0;

            $bar_color = '#10b981';
            if ($g_pct < 70) $bar_color = '#f59e0b';
            if ($g_pct < 30) $bar_color = '#ef4444';

            // Avatar letter + color from name
            $letter = strtoupper(substr($gp['nama_guru'], 0, 1));
            $avatar_colors = ['#3b82f6','#8b5cf6','#ec4899','#14b8a6','#f97316','#06b6d4','#84cc16','#f59e0b'];
            $avatar_bg = $avatar_colors[ord($letter) % count($avatar_colors)];
        ?>
        <div class="col-12 col-sm-6 col-lg-4">
            <div class="guru-card">
                <div class="d-flex align-items-start gap-3 mb-3">
                    <div class="guru-avatar" style="background:<?php echo $avatar_bg; ?>;"><?php echo $letter; ?></div>
                    <div class="flex-grow-1 overflow-hidden">
                        <strong class="text-white d-block text-truncate" style="font-size:13.5px;"><?php echo htmlspecialchars($gp['nama_guru']); ?></strong>
                        <span class="text-secondary font-monospace" style="font-size:10px;">NIP: <?php echo htmlspecialchars($gp['nip']); ?></span>
                    </div>
                    <?php if ($g_wait > 0): ?>
                        <a href="verifikasi_ks.php?<?php echo $base_qs; ?>&guru_id=<?php echo $gp['guru_id']; ?>&view=antrian"
                           class="btn btn-xs btn-gold flex-shrink-0" style="font-size:10px; padding:3px 10px;" title="Lihat antrian dari guru ini">
                            <i class="fa-solid fa-signature me-1"></i><?php echo $g_wait; ?>
                        </a>
                    <?php endif; ?>
                </div>

                <!-- Progress bar -->
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <span class="text-secondary" style="font-size:11px;">Progress</span>
                    <span style="font-size:11px; font-weight:700; color:<?php echo $bar_color; ?>;"><?php echo $g_pct; ?>%</span>
                </div>
                <div class="mini-bar">
                    <div class="mini-bar-fill" style="width:<?php echo $g_pct; ?>%; background:<?php echo $bar_color; ?>;"></div>
                </div>

                <!-- Stats row -->
                <div class="d-flex gap-2 justify-content-between mt-3">
                    <span class="text-center flex-fill">
                        <span class="d-block fw-bold text-white" style="font-size:15px;"><?php echo $gp['total_jurnal'] ?? 0; ?></span>
                        <span class="text-secondary" style="font-size:9px; text-transform:uppercase; letter-spacing:0.5px;">Total</span>
                    </span>
                    <span class="text-center flex-fill">
                        <span class="d-block fw-bold" style="font-size:15px; color:#f59e0b;"><?php echo $g_wait; ?></span>
                        <span class="text-secondary" style="font-size:9px; text-transform:uppercase; letter-spacing:0.5px;">Menunggu</span>
                    </span>
                    <span class="text-center flex-fill">
                        <span class="d-block fw-bold" style="font-size:15px; color:#10b981;"><?php echo $g_ok; ?></span>
                        <span class="text-secondary" style="font-size:9px; text-transform:uppercase; letter-spacing:0.5px;">Disetujui</span>
                    </span>
                    <span class="text-center flex-fill">
                        <span class="d-block fw-bold" style="font-size:15px; color:#ef4444;"><?php echo $g_rev; ?></span>
                        <span class="text-secondary" style="font-size:9px; text-transform:uppercase; letter-spacing:0.5px;">Revisi</span>
                    </span>
                </div>

                <!-- Last input -->
                <?php if ($gp['terakhir_input']): ?>
                    <div class="mt-3 pt-2 border-top border-secondary border-opacity-10 d-flex justify-content-between align-items-center">
                        <span class="text-secondary" style="font-size:10px;"><i class="fa-regular fa-calendar me-1"></i>Input terakhir</span>
                        <span class="text-secondary" style="font-size:10px; font-weight:600;"><?php echo date('d M Y', strtotime($gp['terakhir_input'])); ?></span>
                    </div>
                <?php else: ?>
                    <div class="mt-3 pt-2 border-top border-secondary border-opacity-10">
                        <span class="text-secondary" style="font-size:10px;">Belum ada jurnal di periode ini</span>
                    </div>
                <?php endif; ?>

                <!-- Action buttons -->
                <div class="d-flex gap-2 mt-3">
                    <a href="index.php?guru_id=<?php echo $gp['guru_id']; ?>&<?php echo $base_qs; ?>" 
                       class="btn btn-xs btn-outline-secondary flex-fill" style="font-size:11px;">
                        <i class="fa-solid fa-list me-1"></i>Semua Jurnal
                    </a>
                    <?php if ($g_wait > 0): ?>
                        <a href="index.php?guru_id=<?php echo $gp['guru_id']; ?>&status=Menunggu+Verifikasi&<?php echo $base_qs; ?>"
                           class="btn btn-xs btn-gold flex-fill" style="font-size:11px;">
                            <i class="fa-solid fa-file-circle-check me-1"></i>Verifikasi
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>


<!-- ======================================================
     PANEL: ANTRIAN VERIFIKASI
     ====================================================== -->
<?php if ($view_mode === 'antrian'): ?>
<div class="section-panel">
    <div class="section-title">
        <i class="fa-solid fa-hourglass-half" style="color:#f59e0b;"></i>
        Antrian Verifikasi
        <?php if (count($pending_journals) > 0): ?>
            <span class="badge" style="background:#f59e0b; color:#000; font-size:11px; font-weight:700;"><?php echo count($pending_journals); ?></span>
        <?php endif; ?>
        <a href="index.php?status=Menunggu+Verifikasi&<?php echo $base_qs; ?>" class="btn btn-xs btn-outline-secondary ms-auto" style="font-size:11px;">
            <i class="fa-solid fa-arrow-up-right-from-square me-1"></i>Tampilan Penuh
        </a>
    </div>

    <?php if (empty($pending_journals)): ?>
        <div class="text-center py-5">
            <i class="fa-solid fa-circle-check text-success mb-3" style="font-size:3.5rem; opacity:0.6;"></i>
            <h6 class="text-white mb-1">Semua Bersih!</h6>
            <p class="text-secondary mb-0">Tidak ada jurnal yang menunggu verifikasi untuk periode ini.</p>
        </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th style="width:40px;">#</th>
                    <th>Guru</th>
                    <th>Hari & Tanggal</th>
                    <th>T.A / Sem.</th>
                    <th class="text-center">Jam KBM</th>
                    <th>Diinput Sejak</th>
                    <th class="no-print" style="min-width:160px;">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php $no = 1; foreach ($pending_journals as $pj):
                try {
                    $jam_c_stmt = $pdo->prepare("SELECT COUNT(*) FROM jurnal_mengajar_detail WHERE jurnal_id = ?");
                    $jam_c_stmt->execute([$pj['id']]);
                    $jam_count = $jam_c_stmt->fetchColumn();
                } catch(Exception $e) { $jam_count = '?'; }

                $days_wait = (int)floor((time() - strtotime($pj['created_at'])) / 86400);
                $wait_color = '#10b981';
                $urgency_class = '';
                if ($days_wait >= 3) { $wait_color = '#f59e0b'; $urgency_class = 'pending-row-warn'; }
                if ($days_wait >= 7) { $wait_color = '#ef4444'; $urgency_class = 'pending-row-urgent'; }
            ?>
                <tr class="<?php echo $urgency_class; ?>">
                    <td class="text-secondary small"><?php echo $no++; ?></td>
                    <td>
                        <strong class="text-white d-block" style="font-size:13px;"><?php echo htmlspecialchars($pj['nama_guru']); ?></strong>
                        <span class="text-secondary font-monospace" style="font-size:10px;"><?php echo htmlspecialchars($pj['nip']); ?></span>
                    </td>
                    <td>
                        <strong class="text-white d-block"><?php echo htmlspecialchars($pj['hari']); ?></strong>
                        <span class="text-secondary small"><?php echo date('d M Y', strtotime($pj['tanggal'])); ?></span>
                    </td>
                    <td>
                        <span class="badge badge-secondary" style="font-size:10px;"><?php echo htmlspecialchars($pj['tahun_ajaran']); ?></span>
                        <span class="badge badge-secondary" style="font-size:10px;"><?php echo htmlspecialchars($pj['semester']); ?></span>
                    </td>
                    <td class="text-center">
                        <span class="badge badge-secondary"><?php echo $jam_count; ?> Jam</span>
                    </td>
                    <td>
                        <span style="color:<?php echo $wait_color; ?>; font-size:12px; font-weight:700;">
                            <?php
                            if ($days_wait === 0) echo '<i class="fa-solid fa-circle" style="font-size:7px; margin-right:4px;"></i>Hari ini';
                            elseif ($days_wait === 1) echo '1 hari lalu';
                            else echo $days_wait . ' hari lalu';
                            ?>
                        </span>
                        <?php if ($days_wait >= 7): ?>
                            <span class="badge badge-danger d-block mt-1" style="font-size:9px;">Urgent!</span>
                        <?php endif; ?>
                    </td>
                    <td class="no-print">
                        <div class="d-flex gap-2">
                            <a href="verifikasi.php?id=<?php echo $pj['id']; ?>" class="btn btn-xs btn-gold" title="Verifikasi jurnal ini">
                                <i class="fa-solid fa-signature me-1"></i>Verifikasi
                            </a>
                            <a href="print_detail.php?id=<?php echo $pj['id']; ?>" target="_blank" class="btn btn-xs btn-outline-custom text-gold" title="Lihat detail jurnal">
                                <i class="fa-solid fa-eye"></i>
                            </a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Quick batch info -->
    <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top border-secondary border-opacity-10">
        <span class="text-secondary small">
            <i class="fa-solid fa-info-circle me-1"></i>
            Menampilkan <strong class="text-white"><?php echo count($pending_journals); ?></strong> jurnal menunggu verifikasi.
            Klik tombol <strong class="text-gold">Verifikasi</strong> untuk membuka form supervisi.
        </span>
        <?php
        $urgent_count = 0;
        foreach ($pending_journals as $pj_chk) {
            if ((int)floor((time() - strtotime($pj_chk['created_at'])) / 86400) >= 7) $urgent_count++;
        }
        if ($urgent_count > 0):
        ?>
            <span class="badge badge-danger" style="font-size:11px;">
                <i class="fa-solid fa-triangle-exclamation me-1"></i><?php echo $urgent_count; ?> sudah > 7 hari
            </span>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>


<!-- ======================================================
     PANEL: HISTORI VERIFIKASI
     ====================================================== -->
<?php if ($view_mode === 'histori'): ?>
<div class="section-panel">
    <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
        <div class="section-title mb-0">
            <i class="fa-solid fa-clock-rotate-left" style="color:#D4AF37;"></i>
            Histori Verifikasi Jurnal
        </div>

        <!-- Status filter pills -->
        <div class="d-flex gap-2 flex-wrap">
            <a href="verifikasi_ks.php?<?php echo $base_qs; ?>&view=histori"
               class="btn btn-xs <?php echo $filter_status === '' ? 'btn-gold' : 'btn-outline-secondary'; ?>">Semua</a>
            <a href="verifikasi_ks.php?<?php echo $base_qs; ?>&view=histori&status=Disetujui"
               class="btn btn-xs <?php echo $filter_status === 'Disetujui' ? 'btn-success' : 'btn-outline-secondary'; ?>">
                <i class="fa-solid fa-check me-1"></i>Disetujui
            </a>
            <a href="verifikasi_ks.php?<?php echo $base_qs; ?>&view=histori&status=Revisi"
               class="btn btn-xs <?php echo $filter_status === 'Revisi' ? 'btn-danger' : 'btn-outline-secondary'; ?>">
                <i class="fa-solid fa-rotate-left me-1"></i>Revisi
            </a>
        </div>
    </div>

    <?php if (empty($history)): ?>
        <div class="text-center py-5 text-secondary">
            <i class="fa-solid fa-clock-rotate-left mb-3" style="font-size:3rem; opacity:0.3;"></i>
            <p class="mb-0">Belum ada riwayat verifikasi untuk periode ini.</p>
        </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Guru</th>
                    <th>Tanggal Jurnal</th>
                    <th class="text-center">Status</th>
                    <th>Verifikator</th>
                    <th>Tgl Verifikasi</th>
                    <th>Catatan Supervisi</th>
                    <th class="no-print">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php $no = 1; foreach ($history as $h):
                $s_class = 'badge-success';
                if ($h['status'] === 'Revisi') $s_class = 'badge-danger';
            ?>
                <tr>
                    <td class="text-secondary small"><?php echo $no++; ?></td>
                    <td>
                        <strong class="text-white" style="font-size:13px;"><?php echo htmlspecialchars($h['nama_guru']); ?></strong>
                        <span class="text-secondary d-block font-monospace" style="font-size:10px;"><?php echo htmlspecialchars($h['nip']); ?></span>
                    </td>
                    <td>
                        <span class="text-secondary small">
                            <?php echo htmlspecialchars($h['hari'] ?? ''); ?>,
                            <?php echo date('d M Y', strtotime($h['tanggal'])); ?>
                        </span>
                    </td>
                    <td class="text-center">
                        <span class="badge <?php echo $s_class; ?>"><?php echo htmlspecialchars($h['status']); ?></span>
                    </td>
                    <td>
                        <span class="text-secondary small"><?php echo htmlspecialchars($h['verifikator'] ?? '—'); ?></span>
                    </td>
                    <td>
                        <span class="text-secondary small">
                            <?php echo $h['tanggal_verifikasi'] ? date('d/m/Y H:i', strtotime($h['tanggal_verifikasi'])) : '—'; ?>
                        </span>
                    </td>
                    <td style="max-width:220px;">
                        <span class="text-secondary small d-block text-truncate"
                              title="<?php echo htmlspecialchars($h['catatan'] ?? ''); ?>">
                            <?php echo !empty($h['catatan']) ? htmlspecialchars($h['catatan']) : '<em class="opacity-50">Tanpa catatan</em>'; ?>
                        </span>
                    </td>
                    <td class="no-print">
                        <div class="d-flex gap-1">
                            <a href="verifikasi.php?id=<?php echo $h['id']; ?>" class="btn btn-xs btn-outline-info" title="Ubah/Lihat Verifikasi">
                                <i class="fa-solid fa-pen-to-square"></i>
                            </a>
                            <a href="print_detail.php?id=<?php echo $h['id']; ?>" target="_blank" class="btn btn-xs btn-outline-custom text-gold" title="Cetak">
                                <i class="fa-solid fa-print"></i>
                            </a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <p class="text-secondary small mt-2">Menampilkan <?php echo count($history); ?> entri histori terbaru.</p>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- html2pdf.js CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

<script>
window.guruProgressData = <?php echo json_encode($guru_progress); ?>;
window.pendingJournalsData = <?php echo json_encode($pending_journals); ?>;
window.historyData = <?php echo json_encode($history); ?>;
window.currentViewMode = <?php echo json_encode($view_mode); ?>;
window.tahunAjaranLabel = <?php echo json_encode($ta_label); ?>;
window.semesterLabel = <?php echo json_encode($sem_label); ?>;

document.addEventListener('DOMContentLoaded', () => {
    function getActiveTableForExport(isExcel) {
        const view = window.currentViewMode;
        let tableHtml = '';
        
        if (view === 'dashboard') {
            // Build table from window.guruProgressData
            let rows = '';
            if (window.guruProgressData && window.guruProgressData.length > 0) {
                window.guruProgressData.forEach((gp, idx) => {
                    const total = parseInt(gp.total_jurnal) || 0;
                    const ok = parseInt(gp.disetujui) || 0;
                    const wait = parseInt(gp.menunggu) || 0;
                    const rev = parseInt(gp.revisi) || 0;
                    const pct = total > 0 ? Math.round((ok / total) * 100) : 0;
                    const tgl = gp.terakhir_input ? gp.terakhir_input : '—';
                    
                    rows += `<tr>
                        <td style="text-align:center;">${idx + 1}</td>
                        <td>${gp.nama_guru}</td>
                        <td style="font-family:monospace;">${gp.nip}</td>
                        <td style="text-align:center;">${gp.total_jurnal}</td>
                        <td style="text-align:center;">${wait}</td>
                        <td style="text-align:center;">${ok}</td>
                        <td style="text-align:center;">${rev}</td>
                        <td style="text-align:center;">${pct}%</td>
                        <td style="text-align:center;">${tgl}</td>
                    </tr>`;
                });
            } else {
                rows = `<tr><td colspan="9" style="text-align:center; color:#888;">Belum ada data jurnal.</td></tr>`;
            }
            
            tableHtml = `
                <table border="1" cellpadding="5" style="border-collapse:collapse; width:100%; font-size:12px;">
                    <thead>
                        <tr style="background-color:#f1f5f9;">
                            <th>No</th>
                            <th>Nama Guru</th>
                            <th>NIP</th>
                            <th>Total Jurnal</th>
                            <th>Menunggu</th>
                            <th>Disetujui</th>
                            <th>Revisi</th>
                            <th>Progress (%)</th>
                            <th>Input Terakhir</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${rows}
                    </tbody>
                </table>
            `;
        } else {
            // Clone from DOM
            const originalTable = document.querySelector('.table-custom');
            if (!originalTable) return '';
            
            const clone = originalTable.cloneNode(true);
            // Remove 'no-print' elements (like the Aksi column)
            clone.querySelectorAll('.no-print').forEach(el => el.remove());
            
            if (isExcel) {
                clone.setAttribute('border', '1px');
                clone.style.borderCollapse = 'collapse';
                clone.style.width = '100%';
            }
            tableHtml = clone.outerHTML;
        }
        
        return tableHtml;
    }

    // Excel Export
    document.getElementById('btn-export-excel').addEventListener('click', () => {
        const tableHtml = getActiveTableForExport(true);
        if (!tableHtml) {
            Swal.fire('Error', 'Data tabel tidak ditemukan.', 'error');
            return;
        }
        
        const titleMap = {
            'dashboard': 'Ringkasan_Progress_Jurnal_Guru',
            'antrian': 'Antrian_Verifikasi_Jurnal',
            'histori': 'Histori_Verifikasi_Jurnal'
        };
        const titleText = titleMap[window.currentViewMode] || 'Laporan_Jurnal';
        
        const excelHtml = `
        <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
        <head>
            <meta charset="utf-8">
            <style>
                body { font-family: sans-serif; }
                th { background-color: #f1f5f9; font-weight: bold; }
                td { text-align: left; }
            </style>
        </head>
        <body>
            <div style="text-align:center; margin-bottom:15px;">
                <h2>SD KRISTEN PETRA 1 SURABAYA</h2>
                <h3>LAPORAN SUPERVISI JURNAL MENGAJAR</h3>
                <p>Periode: Tahun Ajaran ${window.tahunAjaranLabel} / Semester ${window.semesterLabel}</p>
            </div>
            ${tableHtml}
        </body>
        </html>
        `;
        
        const blob = new Blob([excelHtml], { type: 'application/vnd.ms-excel;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `${titleText}_${window.tahunAjaranLabel.replace('/', '_')}.xls`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });

    // PDF Export
    document.getElementById('btn-export-pdf').addEventListener('click', () => {
        const tableHtml = getActiveTableForExport(false);
        if (!tableHtml) {
            Swal.fire('Error', 'Data tabel tidak ditemukan.', 'error');
            return;
        }
        
        const titleMap = {
            'dashboard': 'Ringkasan Progress Jurnal Guru',
            'antrian': 'Antrian Verifikasi Jurnal',
            'histori': 'Histori Verifikasi Jurnal'
        };
        const titleText = titleMap[window.currentViewMode] || 'Laporan Jurnal';
        
        const element = document.createElement('div');
        element.className = 'p-6 bg-white text-slate-800 font-sans';
        element.style.padding = '20px';
        element.style.fontFamily = 'Arial, sans-serif';
        
        element.innerHTML = `
            <div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid #000; padding-bottom: 10px;">
                <h2 style="margin: 0; font-size: 18px; font-weight: bold; text-transform: uppercase; color: #000;">SD KRISTEN PETRA 1 SURABAYA</h2>
                <h3 style="margin: 5px 0 0 0; font-size: 14px; font-weight: bold; text-transform: uppercase; color: #000;">${titleText}</h3>
                <p style="margin: 5px 0 0 0; font-size: 11px; color:#555;">Tahun Ajaran ${window.tahunAjaranLabel} / Semester ${window.semesterLabel}</p>
            </div>
            <div style="margin-top: 15px;">
                ${tableHtml}
            </div>
            <div style="margin-top: 40px; display: flex; justify-content: space-between; font-size: 11px; page-break-inside: avoid; color: #000;">
                <div>Dicetak pada: ${new Date().toLocaleString('id-ID')}</div>
                <div style="text-align: center; width: 200px;">
                    <p>Mengetahui,</p>
                    <p style="margin-bottom: 50px;">Kepala Sekolah,</p>
                    <p style="font-weight: bold; border-top: 1px solid #000; display: inline-block; padding-top: 3px; min-width: 150px; text-align: center;">Lilia, S.Pd., M.Psi.</p>
                </div>
            </div>
        `;
        
        // Clean table styling for print presentation
        const table = element.querySelector('table');
        if (table) {
            table.style.width = '100%';
            table.style.borderCollapse = 'collapse';
            table.style.marginTop = '10px';
            table.style.fontSize = '11px';
            table.querySelectorAll('th, td').forEach(el => {
                el.style.border = '1px solid #000';
                el.style.padding = '6px 5px';
                el.style.color = '#000';
            });
            table.querySelectorAll('th').forEach(el => {
                el.style.backgroundColor = '#f1f5f9';
                el.style.fontWeight = 'bold';
            });
        }
        
        const opt = {
            margin:       10,
            filename:     `${titleText.replace(/\s+/g, '_')}.pdf`,
            image:        { type: 'jpeg', quality: 0.98 },
            html2canvas:  { scale: 2, useCORS: true },
            jsPDF:        { unit: 'mm', format: 'a4', orientation: 'landscape' }
        };
        
        html2pdf().set(opt).from(element).save();
    });
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
