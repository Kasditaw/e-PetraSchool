<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris\mutasi.php

$page_title = 'Mutasi Lokasi Barang';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_inventaris_access();

$error = '';
$success = '';

// Handle Mutation Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'mutate') {
    require_role(['Super Admin', 'Admin']);
    check_csrf_request();

    $inventaris_id = intval($_POST['inventaris_id'] ?? 0);
    $lokasi_tujuan_id = intval($_POST['lokasi_tujuan_id'] ?? 0);
    $tanggal_mutasi = $_POST['tanggal_mutasi'] ?? date('Y-m-d');
    $petugas = trim($_POST['petugas'] ?? '');
    $keterangan = trim($_POST['keterangan'] ?? '');

    if ($inventaris_id === 0 || $lokasi_tujuan_id === 0 || empty($petugas)) {
        $error = 'Semua field bertanda bintang (*) wajib diisi!';
    } else {
        try {
            $pdo->beginTransaction();

            // Get current room of the asset
            $ast_stmt = $pdo->prepare("
                SELECT i.nama_barang, i.kode_barang, i.ruangan_id, r.nama_ruangan as nama_ruangan_asal 
                FROM inventaris i
                LEFT JOIN ruangan r ON i.ruangan_id = r.id
                WHERE i.id = ? AND i.status_aktif = 'Aktif'
            ");
            $ast_stmt->execute([$inventaris_id]);
            $asset = $ast_stmt->fetch();

            if ($asset) {
                $lokasi_asal_id = $asset['ruangan_id'];
                
                // Prevent mutation to the same room
                if ($lokasi_asal_id == $lokasi_tujuan_id) {
                    $error = 'Ruangan tujuan tidak boleh sama dengan ruangan asal!';
                    $pdo->rollBack();
                } else {
                    // Fetch destination room details
                    $dest_stmt = $pdo->prepare("SELECT nama_ruangan FROM ruangan WHERE id = ?");
                    $dest_stmt->execute([$lokasi_tujuan_id]);
                    $dest_room_name = $dest_stmt->fetchColumn() ?: 'Gudang/Belum Dialokasikan';

                    $asal_room_name = $asset['nama_ruangan_asal'] ?: 'Belum Dialokasikan';

                    // Insert mutation record
                    $ins = $pdo->prepare("
                        INSERT INTO mutasi_barang (inventaris_id, lokasi_asal_id, lokasi_tujuan_id, tanggal_mutasi, petugas, keterangan) 
                        VALUES (?, ?, ?, ?, ?, ?)
                    ");
                    $ins->execute([$inventaris_id, $lokasi_asal_id, $lokasi_tujuan_id, $tanggal_mutasi, $petugas, $keterangan]);

                    // Update room_id in inventaris
                    $upd = $pdo->prepare("UPDATE inventaris SET ruangan_id = ? WHERE id = ?");
                    $upd->execute([$lokasi_tujuan_id, $inventaris_id]);

                    // Insert into history log
                    $hist = $pdo->prepare("INSERT INTO histori_inventaris (inventaris_id, aktivitas, pengguna, keterangan) VALUES (?, 'Mutasi', ?, ?)");
                    $hist->execute([
                        $inventaris_id,
                        $_SESSION['nama'] ?? 'Admin',
                        "Mutasi lokasi: Dipindahkan dari $asal_room_name ke $dest_room_name oleh $petugas. Ket: $keterangan"
                    ]);

                    write_audit_log("Melakukan mutasi barang " . $asset['nama_barang'] . " (" . $asset['kode_barang'] . ") dari $asal_room_name ke $dest_room_name");

                    $pdo->commit();
                    echo "<script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire('Berhasil', 'Aset berhasil dimutasikan ke ruangan baru!', 'success').then(() => {
                                window.location.href = 'mutasi.php';
                            });
                        });
                    </script>";
                    exit;
                }
            } else {
                $error = 'Data barang tidak ditemukan atau tidak aktif.';
                $pdo->rollBack();
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = 'Gagal menyimpan mutasi: ' . $e->getMessage();
        }
    }
}

// Fetch mutation list
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
try {
    $query = "
        SELECT m.*, i.nama_barang, i.kode_barang, 
               r1.nama_ruangan as ruangan_asal, r2.nama_ruangan as ruangan_tujuan 
        FROM mutasi_barang m 
        JOIN inventaris i ON m.inventaris_id = i.id 
        LEFT JOIN ruangan r1 ON m.lokasi_asal_id = r1.id 
        LEFT JOIN ruangan r2 ON m.lokasi_tujuan_id = r2.id
    ";
    if ($search !== '') {
        $query .= " WHERE i.nama_barang LIKE :search OR i.kode_barang LIKE :search OR m.petugas LIKE :search OR m.keterangan LIKE :search";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['search' => "%$search%"]);
    } else {
        $stmt = $pdo->query($query . " ORDER BY m.tanggal_mutasi DESC, m.id DESC");
    }
    $mutations = $stmt->fetchAll();

    // Fetch active assets for selection (with current room information)
    $assets = $pdo->query("
        SELECT i.id, i.kode_barang, i.nama_barang, i.ruangan_id, r.nama_ruangan 
        FROM inventaris i 
        LEFT JOIN ruangan r ON i.ruangan_id = r.id 
        WHERE i.status_aktif = 'Aktif' 
        ORDER BY i.nama_barang ASC
    ")->fetchAll();

    // Fetch rooms for destination selection
    $rooms = $pdo->query("SELECT id, kode_ruangan, nama_ruangan FROM ruangan ORDER BY nama_ruangan ASC")->fetchAll();
} catch (Exception $e) {
    $mutations = [];
    $assets = [];
    $rooms = [];
    $error = 'Database error: ' . $e->getMessage();
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-arrows-spin me-2"></i> Mutasi Ruangan Aset</h5>
            <p class="text-secondary small mb-0">Catat dan pantau perpindahan atau transfer penempatan barang inventaris antar ruangan / gedung sekolah.</p>
        </div>
        <div>
            <?php if (has_role(['Super Admin', 'Admin'])): ?>
            <button class="btn btn-gold" data-bs-toggle="modal" data-bs-target="#modalMutasi" onclick="openCreateModal()"><i class="fa-solid fa-plus me-1"></i> Buat Mutasi</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <!-- Search Form -->
    <form method="GET" action="mutasi.php" class="row g-2 mb-4 no-print">
        <div class="col-12 col-md-4">
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari barang, petugas, keterangan..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">Cari</button>
        </div>
        <?php if ($search !== ''): ?>
            <div class="col-auto">
                <a href="mutasi.php" class="btn btn-outline-danger">Reset</a>
            </div>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Barang Aset</th>
                    <th>Tanggal Mutasi</th>
                    <th>Lokasi Asal</th>
                    <th>Lokasi Tujuan</th>
                    <th>Petugas / PJ</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($mutations) > 0): ?>
                    <?php $no = 1; foreach ($mutations as $mut): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td>
                                <strong class="text-white"><?php echo htmlspecialchars($mut['nama_barang']); ?></strong>
                                <span class="text-secondary small d-block font-monospace"><?php echo htmlspecialchars($mut['kode_barang']); ?></span>
                            </td>
                            <td><?php echo date('d M Y', strtotime($mut['tanggal_mutasi'])); ?></td>
                            <td><span class="text-danger fw-semibold"><i class="fa-solid fa-door-open me-1"></i> <?php echo htmlspecialchars($mut['ruangan_asal'] ?: 'Belum Dialokasikan'); ?></span></td>
                            <td><span class="text-success fw-semibold"><i class="fa-solid fa-door-closed me-1"></i> <?php echo htmlspecialchars($mut['ruangan_tujuan'] ?: 'Gudang'); ?></span></td>
                            <td class="text-white"><?php echo htmlspecialchars($mut['petugas']); ?></td>
                            <td class="small"><?php echo htmlspecialchars($mut['keterangan'] ?: '-'); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center text-secondary py-4">Belum ada catatan mutasi ruangan.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Form -->
<div class="modal fade" id="modalMutasi" tabindex="-1" aria-labelledby="modalMutasiLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content modal-content-custom">
            <div class="modal-header">
                <h5 class="modal-title text-gold fw-bold" id="modalMutasiLabel"><i class="fa-solid fa-arrows-spin me-2"></i> Pindahkan Lokasi Aset</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="mutasi.php">
                <?php csrf_input(); ?>
                <input type="hidden" name="action" value="mutate">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="inventaris_id" class="form-label form-label-custom">Pilih Barang Aset <span class="text-danger">*</span></label>
                        <select name="inventaris_id" id="form_inventaris_id" class="form-select form-control-custom bg-dark-select text-white" onchange="onAssetChange()" required>
                            <option value="" disabled selected>Pilih Barang...</option>
                            <?php foreach ($assets as $ast): ?>
                                <option value="<?php echo $ast['id']; ?>" 
                                        data-room-id="<?php echo $ast['ruangan_id']; ?>" 
                                        data-room-name="<?php echo htmlspecialchars($ast['nama_ruangan'] ?: 'Belum Dialokasikan'); ?>">
                                    <?php echo htmlspecialchars($ast['nama_barang']) . ' (' . htmlspecialchars($ast['kode_barang']) . ')'; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label form-label-custom">Lokasi Penempatan Saat Ini</label>
                        <input type="text" id="display_ruangan_asal" class="form-control form-control-custom" style="background-color: rgba(255,255,255,0.03);" readonly value="-">
                    </div>

                    <div class="mb-3">
                        <label for="lokasi_tujuan_id" class="form-label form-label-custom">Lokasi Tujuan Mutasi <span class="text-danger">*</span></label>
                        <select name="lokasi_tujuan_id" id="form_lokasi_tujuan_id" class="form-select form-control-custom bg-dark-select text-white" required>
                            <option value="" disabled selected>Pilih Ruangan Tujuan...</option>
                            <?php foreach ($rooms as $rm): ?>
                                <option value="<?php echo $rm['id']; ?>"><?php echo htmlspecialchars($rm['nama_ruangan']) . ' (' . htmlspecialchars($rm['kode_ruangan']) . ')'; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="tanggal_mutasi" class="form-label form-label-custom">Tanggal Mutasi <span class="text-danger">*</span></label>
                        <input type="date" name="tanggal_mutasi" id="form_tanggal_mutasi" class="form-control form-control-custom" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="petugas" class="form-label form-label-custom">Petugas Pelaksana / PJ Mutasi <span class="text-danger">*</span></label>
                        <input type="text" name="petugas" id="form_petugas" class="form-control form-control-custom" placeholder="Nama Pelaksana Pemindahan" required>
                    </div>

                    <div class="mb-3">
                        <label for="keterangan" class="form-label form-label-custom">Keterangan / Alasan Mutasi</label>
                        <textarea name="keterangan" id="form_keterangan" class="form-control form-control-custom" rows="3" placeholder="Alasan pemindahan lokasi aset..."></textarea>
                    </div>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-gold">Simpan Mutasi <i class="fa-solid fa-check ms-1"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openCreateModal() {
    document.getElementById('form_inventaris_id').value = '';
    document.getElementById('display_ruangan_asal').value = '-';
    document.getElementById('form_lokasi_tujuan_id').value = '';
    document.getElementById('form_tanggal_mutasi').value = '<?php echo date('Y-m-d'); ?>';
    document.getElementById('form_petugas').value = '';
    document.getElementById('form_keterangan').value = '';
}

function onAssetChange() {
    const select = document.getElementById('form_inventaris_id');
    const selectedOption = select.options[select.selectedIndex];
    
    if (selectedOption) {
        const roomName = selectedOption.getAttribute('data-room-name');
        document.getElementById('display_ruangan_asal').value = roomName;
    } else {
        document.getElementById('display_ruangan_asal').value = '-';
    }
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
