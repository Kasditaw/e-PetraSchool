<?php
// c:\xampp\htdocs\e-petraschool1\modules\absensi_siswa\rekap.php

$page_title = 'Rekap Absensi Siswa';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$filter_kelas    = isset($_GET['kelas_id'])       ? intval($_GET['kelas_id'])       : 0;
$filter_bulan    = isset($_GET['bulan'])           ? intval($_GET['bulan'])           : intval(date('m'));
$filter_tahun    = isset($_GET['tahun'])           ? intval($_GET['tahun'])           : intval(date('Y'));
$filter_ta       = isset($_GET['tahun_ajaran_id']) ? intval($_GET['tahun_ajaran_id']): 0;
$filter_semester = isset($_GET['semester_id'])     ? intval($_GET['semester_id'])    : 0;

$bulan_names = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

try {
    $kelas_list = $pdo->query("SELECT id, nama_kelas FROM kelas WHERE status = 'Aktif' ORDER BY nama_kelas ASC")->fetchAll();
    $ta_list    = $pdo->query("SELECT id, tahun_ajaran, status FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();
    $sem_list   = $pdo->query("SELECT id, semester, status FROM semester ORDER BY semester ASC")->fetchAll();

    if (!$filter_ta) { foreach ($ta_list as $t) { if ($t['status'] === 'Aktif') { $filter_ta = $t['id']; break; } } }
    if (!$filter_semester) { foreach ($sem_list as $s) { if ($s['status'] === 'Aktif') { $filter_semester = $s['id']; break; } } }

    $rekap_data = [];
    $kelas_nama = '';

    if ($filter_kelas) {
        foreach ($kelas_list as $kl) { if ($kl['id'] == $filter_kelas) { $kelas_nama = $kl['nama_kelas']; break; } }

        $start_date = "$filter_tahun-" . str_pad($filter_bulan,2,'0',STR_PAD_LEFT) . "-01";
        $end_date   = "$filter_tahun-" . str_pad($filter_bulan,2,'0',STR_PAD_LEFT) . "-" . cal_days_in_month(CAL_GREGORIAN, $filter_bulan, $filter_tahun);

        $stmt = $pdo->prepare("
            SELECT s.id AS siswa_id, s.nis, s.nama_lengkap, s.gender,
                   ab.status, COUNT(*) AS jumlah
            FROM siswa s
            LEFT JOIN absensi_siswa ab ON s.id = ab.siswa_id AND ab.tanggal BETWEEN ? AND ?
            WHERE s.kelas_id = ? AND s.status_siswa = 'Aktif'
            GROUP BY s.id, ab.status
            ORDER BY s.nama_lengkap ASC, ab.status ASC
        ");
        $stmt->execute([$start_date, $end_date, $filter_kelas]);
        $rows = $stmt->fetchAll();

        // Pivot
        foreach ($rows as $r) {
            $sid = $r['siswa_id'];
            if (!isset($rekap_data[$sid])) {
                $rekap_data[$sid] = ['nis' => $r['nis'], 'nama' => $r['nama_lengkap'], 'gender' => $r['gender'],
                                     'Hadir' => 0, 'Sakit' => 0, 'Izin' => 0, 'Alfa' => 0];
            }
            if ($r['status']) {
                $rekap_data[$sid][$r['status']] = intval($r['jumlah']);
            }
        }
    }

} catch (Exception $e) {
    $error_db = $e->getMessage();
    $rekap_data = [];
}
?>

<div class="glass-card">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-table-list me-2"></i>Rekap Absensi Siswa</h5>
            <p class="text-secondary small mb-0">Ringkasan jumlah kehadiran per siswa dalam satu bulan.</p>
        </div>
        <div class="d-flex gap-2 no-print">
            <a href="input.php" class="btn btn-gold"><i class="fa-solid fa-user-check me-1"></i> Input Absensi</a>
            <button onclick="window.print()" class="btn btn-outline-custom"><i class="fa-solid fa-print me-1"></i> Cetak</button>
        </div>
    </div>

    <?php if (isset($error_db)): ?>
        <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i>Tabel belum tersedia. Jalankan: <a href="<?php echo $base_url; ?>database/migrate_absensi_jadwal.php" class="alert-link">migrate_absensi_jadwal.php</a></div>
    <?php endif; ?>

    <!-- Filter -->
    <form method="GET" class="row g-3 mb-4 align-items-end no-print">
        <div class="col-6 col-md-3">
            <label class="form-label form-label-custom">Kelas</label>
            <select name="kelas_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">-- Pilih Kelas --</option>
                <?php foreach ($kelas_list as $kl): ?>
                    <option value="<?php echo $kl['id']; ?>" <?php echo $filter_kelas == $kl['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($kl['nama_kelas']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Bulan</label>
            <select name="bulan" class="form-select form-control-custom bg-dark-select text-white">
                <?php for ($m=1;$m<=12;$m++): ?>
                    <option value="<?php echo $m; ?>" <?php echo $filter_bulan==$m?'selected':''; ?>><?php echo $bulan_names[$m]; ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Tahun</label>
            <input type="number" name="tahun" class="form-control form-control-custom" value="<?php echo $filter_tahun; ?>">
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Semester</label>
            <select name="semester_id" class="form-select form-control-custom bg-dark-select text-white">
                <?php foreach ($sem_list as $sm): ?>
                    <option value="<?php echo $sm['id']; ?>" <?php echo $filter_semester==$sm['id']?'selected':''; ?>>Sem <?php echo $sm['semester']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <input type="hidden" name="tahun_ajaran_id" value="<?php echo $filter_ta; ?>">
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom"><i class="fa-solid fa-filter me-1"></i> Filter</button>
        </div>
    </form>

    <?php if (!empty($rekap_data)): ?>
        <h6 class="fw-bold text-white mb-3">
            <?php echo htmlspecialchars($kelas_nama); ?> — <?php echo $bulan_names[$filter_bulan]; ?> <?php echo $filter_tahun; ?>
        </h6>
        <div class="table-responsive">
            <table class="table table-custom">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama Siswa</th>
                        <th>NIS</th>
                        <th style="text-align:center; color:#10B981;">Hadir</th>
                        <th style="text-align:center; color:#F59E0B;">Sakit</th>
                        <th style="text-align:center; color:#3B82F6;">Izin</th>
                        <th style="text-align:center; color:#EF4444;">Alfa</th>
                        <th style="text-align:center;">Total Hari</th>
                        <th style="text-align:center;">% Kehadiran</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach ($rekap_data as $sid => $r):
                        $total = $r['Hadir'] + $r['Sakit'] + $r['Izin'] + $r['Alfa'];
                        $pct   = $total > 0 ? round($r['Hadir'] / $total * 100) : 0;
                        $pct_color = $pct >= 80 ? '#10B981' : ($pct >= 60 ? '#F59E0B' : '#EF4444');
                    ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td>
                            <strong class="text-white"><?php echo htmlspecialchars($r['nama']); ?></strong>
                            <span class="badge ms-1" style="font-size:9px; background:<?php echo $r['gender']==='L'?'rgba(59,130,246,.2)':'rgba(236,72,153,.2)'; ?>; color:<?php echo $r['gender']==='L'?'#3B82F6':'#EC4899'; ?>;"><?php echo $r['gender']; ?></span>
                        </td>
                        <td><span class="font-monospace text-secondary" style="font-size:12px;"><?php echo htmlspecialchars($r['nis']); ?></span></td>
                        <td style="text-align:center; font-weight:700; color:#10B981;"><?php echo $r['Hadir']; ?></td>
                        <td style="text-align:center; font-weight:700; color:#F59E0B;"><?php echo $r['Sakit']; ?></td>
                        <td style="text-align:center; font-weight:700; color:#3B82F6;"><?php echo $r['Izin']; ?></td>
                        <td style="text-align:center; font-weight:700; color:#EF4444;"><?php echo $r['Alfa']; ?></td>
                        <td style="text-align:center;"><?php echo $total; ?></td>
                        <td style="text-align:center;">
                            <div style="display:flex; align-items:center; gap:8px; justify-content:center;">
                                <div style="flex:1; max-width:80px; height:6px; background:rgba(255,255,255,.1); border-radius:99px; overflow:hidden;">
                                    <div style="width:<?php echo $pct; ?>%; height:100%; background:<?php echo $pct_color; ?>; border-radius:99px; transition:width .3s;"></div>
                                </div>
                                <span style="font-weight:700; color:<?php echo $pct_color; ?>; font-size:13px; min-width:36px;"><?php echo $total > 0 ? $pct.'%' : '-'; ?></span>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr style="border-top:2px solid rgba(212,175,55,.3);">
                        <td colspan="3" class="fw-bold text-gold">TOTAL KELAS</td>
                        <?php
                        $tot_h = array_sum(array_column($rekap_data,'Hadir'));
                        $tot_s = array_sum(array_column($rekap_data,'Sakit'));
                        $tot_i = array_sum(array_column($rekap_data,'Izin'));
                        $tot_a = array_sum(array_column($rekap_data,'Alfa'));
                        $tot_all = $tot_h + $tot_s + $tot_i + $tot_a;
                        $avg_pct = $tot_all > 0 ? round($tot_h / $tot_all * 100) : 0;
                        ?>
                        <td style="text-align:center; font-weight:700; color:#10B981;"><?php echo $tot_h; ?></td>
                        <td style="text-align:center; font-weight:700; color:#F59E0B;"><?php echo $tot_s; ?></td>
                        <td style="text-align:center; font-weight:700; color:#3B82F6;"><?php echo $tot_i; ?></td>
                        <td style="text-align:center; font-weight:700; color:#EF4444;"><?php echo $tot_a; ?></td>
                        <td style="text-align:center; font-weight:700;"><?php echo $tot_all; ?></td>
                        <td style="text-align:center; font-weight:700; color:<?php echo $avg_pct>=80?'#10B981':($avg_pct>=60?'#F59E0B':'#EF4444'); ?>;"><?php echo $tot_all > 0 ? $avg_pct.'%' : '-'; ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    <?php elseif ($filter_kelas): ?>
        <div class="text-center py-5">
            <i class="fa-solid fa-inbox" style="font-size:48px; color:rgba(255,255,255,.15);"></i>
            <p class="text-secondary mt-3">Belum ada data absensi untuk bulan <?php echo $bulan_names[$filter_bulan]; ?> <?php echo $filter_tahun; ?>.</p>
        </div>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="fa-solid fa-hand-pointer" style="font-size:48px; color:rgba(255,255,255,.15);"></i>
            <p class="text-secondary mt-3">Pilih kelas untuk melihat rekap absensi.</p>
        </div>
    <?php endif; ?>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
