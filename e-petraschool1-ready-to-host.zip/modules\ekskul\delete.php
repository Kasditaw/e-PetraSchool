<?php
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin','Admin']);
$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }
try {
    $stmt = $pdo->prepare("SELECT nama,tahun_ajaran_id FROM ekskul WHERE id=?"); $stmt->execute([$id]);
    $eks = $stmt->fetch();
    if ($eks) {
        $pdo->prepare("DELETE FROM ekskul WHERE id=?")->execute([$id]);
        write_audit_log("Menghapus ekskul ID#$id: {$eks['nama']}.");
    }
} catch (Exception $e) {}
header('Location: index.php' . ($eks ? '?tahun_ajaran_id='.$eks['tahun_ajaran_id'] : ''));
exit;
