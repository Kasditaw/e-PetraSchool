<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris\lokasi.php

$page_title = 'Lokasi Inventaris';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_inventaris_access();

$error = '';
$success = '';

// Handle CRUD operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_role(['Super Admin', 'Admin']);
    check_csrf_request();
    
    $action = $_POST['action'] ?? '';
    
    // Add Room
    if ($action === 'add') {
        $kode_ruangan = strtoupper(trim($_POST['kode_ruangan'] ?? ''));
        $nama_ruangan = trim($_POST['nama_ruangan'] ?? '');
        $lantai = trim($_POST['lantai'] ?? '1');
        $kapasitas = intval($_POST['kapasitas'] ?? 30);
        $kondisi = $_POST['kondisi'] ?? 'Baik';
        $gedung = trim($_POST['gedung'] ?? '');
        $pj_id = $_POST['penanggung_jawab_id'] !== '' ? intval($_POST['penanggung_jawab_id']) : null;
        
        if (empty($kode_ruangan) || empty($nama_ruangan) || empty($gedung)) {
            $error = 'Field Kode Ruangan, Nama Ruangan, dan Gedung wajib diisi!';
        } else {
            try {
                // Check duplicate kode
                $chk = $pdo->prepare("SELECT COUNT(*) FROM ruangan WHERE kode_ruangan = ? OR nama_ruangan = ?");
                $chk->execute([$kode_ruangan, $nama_ruangan]);
                if ($chk->fetchColumn() > 0) {
                    $error = 'Kode Ruangan atau Nama Ruangan sudah terdaftar!';
                } else {
                    $stmt = $pdo->prepare("INSERT INTO ruangan (kode_ruangan, nama_ruangan, lantai, kapasitas, kondisi, gedung, penanggung_jawab_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$kode_ruangan, $nama_ruangan, $lantai, $kapasitas, $kondisi, $gedung, $pj_id]);
                    
                    write_audit_log("Menambahkan lokasi/ruangan inventaris baru: $nama_ruangan ($kode_ruangan) di $gedung.");
                    
                    $success = 'Lokasi ruangan berhasil ditambahkan!';
                }
            } catch (Exception $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
    
    // Edit Room
    if ($action === 'edit') {
        $id = intval($_POST['id'] ?? 0);
        $kode_ruangan = strtoupper(trim($_POST['kode_ruangan'] ?? ''));
        $nama_ruangan = trim($_POST['nama_ruangan'] ?? '');
        $lantai = trim($_POST['lantai'] ?? '1');
        $kapasitas = intval($_POST['kapasitas'] ?? 30);
        $kondisi = $_POST['kondisi'] ?? 'Baik';
        $gedung = trim($_POST['gedung'] ?? '');
        $pj_id = $_POST['penanggung_jawab_id'] !== '' ? intval($_POST['penanggung_jawab_id']) : null;
        
        if ($id <= 0 || empty($kode_ruangan) || empty($nama_ruangan) || empty($gedung)) {
            $error = 'Field ID, Kode Ruangan, Nama Ruangan, dan Gedung wajib diisi!';
        } else {
            try {
                // Check duplicate
                $chk = $pdo->prepare("SELECT COUNT(*) FROM ruangan WHERE (kode_ruangan = ? OR nama_ruangan = ?) AND id != ?");
                $chk->execute([$kode_ruangan, $nama_ruangan, $id]);
                if ($chk->fetchColumn() > 0) {
                    $error = 'Kode Ruangan atau Nama Ruangan sudah digunakan pada lokasi lain!';
                } else {
                    $stmt = $pdo->prepare("UPDATE ruangan SET kode_ruangan = ?, nama_ruangan = ?, lantai = ?, kapasitas = ?, kondisi = ?, gedung = ?, penanggung_jawab_id = ? WHERE id = ?");
                    $stmt->execute([$kode_ruangan, $nama_ruangan, $lantai, $kapasitas, $kondisi, $gedung, $pj_id, $id]);
                    
                    write_audit_log("Mengubah lokasi/ruangan inventaris ID $id menjadi: $nama_ruangan ($kode_ruangan) di $gedung.");
                    
                    $success = 'Lokasi ruangan berhasil diperbarui!';
                }
            } catch (Exception $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

// Handle Delete Room via GET
if (isset($_GET['delete_id'])) {
    require_role(['Super Admin', 'Admin']);
    $delete_id = intval($_GET['delete_id']);
    try {
        // Check if room has assets
        $chk = $pdo->prepare("SELECT COUNT(*) FROM inventaris WHERE ruangan_id = ? AND status_aktif = 'Aktif'");
        $chk->execute([$delete_id]);
        if ($chk->fetchColumn() > 0) {
            $error = 'Lokasi tidak dapat dihapus karena masih terdapat barang inventaris di dalamnya!';
        } else {
            // Check if room is used by active classes
            $chk_cls = $pdo->prepare("SELECT COUNT(*) FROM kelas WHERE lokasi_ruangan = (SELECT nama_ruangan FROM ruangan WHERE id = ?)");
            $chk_cls->execute([$delete_id]);
            if ($chk_cls->fetchColumn() > 0) {
                $error = 'Lokasi tidak dapat dihapus karena nama ruangan masih digunakan pada kelas aktif!';
            } else {
                $name_stmt = $pdo->prepare("SELECT nama_ruangan FROM ruangan WHERE id = ?");
                $name_stmt->execute([$delete_id]);
                $name = $name_stmt->fetchColumn();

                $stmt = $pdo->prepare("DELETE FROM ruangan WHERE id = ?");
                $stmt->execute([$delete_id]);
                
                write_audit_log("Menghapus lokasi ruangan: $name (ID: $delete_id).");
                
                $success = 'Lokasi ruangan berhasil dihapus!';
            }
        }
    } catch (Exception $e) {
        $error = 'Gagal menghapus lokasi ruangan: ' . $e->getMessage();
    }
}

// Load all rooms with penanggung jawab and total assets count
try {
    $rooms = $pdo->query("
        SELECT r.*, g.nama_guru, COALESCE(SUM(i.jumlah), 0) as total_aset 
        FROM ruangan r 
        LEFT JOIN guru g ON r.penanggung_jawab_id = g.id 
        LEFT JOIN inventaris i ON r.id = i.ruangan_id AND i.status_aktif = 'Aktif'
        GROUP BY r.id 
        ORDER BY r.gedung ASC, r.nama_ruangan ASC
    ")->fetchAll();

    // Fetch teachers list for Penanggung Jawab dropdown
    $teachers = $pdo->query("SELECT id, nip, nama_guru FROM guru ORDER BY nama_guru ASC")->fetchAll();
} catch (Exception $e) {
    $error = 'Gagal memuat data: ' . $e->getMessage();
    $rooms = [];
    $teachers = [];
}
?>

<div class="glass-card mb-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-location-dot me-2"></i> Lokasi Inventaris</h5>
            <p class="text-secondary small mb-0">Kelola ruang kelas, laboratorium, perpustakaan, UKS, dan gedung penempatan barang inventaris sekolah.</p>
        </div>
        <div>
            <?php if (has_role(['Super Admin', 'Admin'])): ?>
            <button class="btn btn-gold" data-bs-toggle="modal" data-bs-target="#addRoomModal"><i class="fa-solid fa-plus me-1"></i> Tambah Lokasi</button>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
    </div>
<?php endif; ?>

<?php if ($success !== ''): ?>
    <div class="alert alert-success border-0 text-white bg-success bg-opacity-25 small mb-4 py-2" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i> <?php echo htmlspecialchars($success); ?>
    </div>
<?php endif; ?>

<!-- Rooms Table -->
<div class="glass-card">
    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Ruangan</th>
                    <th>Nama Ruangan</th>
                    <th>Gedung / Lantai</th>
                    <th>Kapasitas Siswa</th>
                    <th>Penanggung Jawab</th>
                    <th>Kondisi Ruang</th>
                    <th style="text-align: center;">Jumlah Aset</th>
                    <?php if (has_role(['Super Admin', 'Admin'])): ?>
                    <th style="text-align: right;" class="no-print">Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (count($rooms) > 0): ?>
                    <?php $no = 1; foreach ($rooms as $rm): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><strong class="text-white font-monospace"><?php echo htmlspecialchars($rm['kode_ruangan']); ?></strong></td>
                            <td><strong class="text-white"><?php echo htmlspecialchars($rm['nama_ruangan']); ?></strong></td>
                            <td>
                                <span class="d-block text-white"><?php echo htmlspecialchars($rm['gedung'] ?: '-'); ?></span>
                                <span class="text-secondary small">Lantai <?php echo htmlspecialchars($rm['lantai']); ?></span>
                            </td>
                            <td><?php echo intval($rm['kapasitas']); ?> siswa</td>
                            <td>
                                <?php if ($rm['nama_guru']): ?>
                                    <span class="text-white"><i class="fa-solid fa-user-tie text-gold me-1"></i> <?php echo htmlspecialchars($rm['nama_guru']); ?></span>
                                <?php else: ?>
                                    <span class="text-secondary small">Belum Ditentukan</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php
                                $badge_class = 'badge-secondary';
                                if ($rm['kondisi'] === 'Baik') $badge_class = 'badge-success';
                                elseif ($rm['kondisi'] === 'Rusak Ringan') $badge_class = 'badge-warning';
                                elseif ($rm['kondisi'] === 'Rusak Berat') $badge_class = 'badge-danger';
                                ?>
                                <span class="badge <?php echo $badge_class; ?>"><?php echo htmlspecialchars($rm['kondisi']); ?></span>
                            </td>
                            <td style="text-align: center;"><span class="badge bg-dark border text-white"><?php echo intval($rm['total_aset']); ?> unit</span></td>
                            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                            <td style="text-align: right;" class="no-print">
                                <div class="d-flex gap-2 justify-content-end">
                                    <button class="btn btn-xs btn-outline-warning" 
                                            onclick="openEditModal(<?php echo $rm['id']; ?>, '<?php echo htmlspecialchars($rm['kode_ruangan'], ENT_QUOTES); ?>', '<?php echo htmlspecialchars($rm['nama_ruangan'], ENT_QUOTES); ?>', '<?php echo htmlspecialchars($rm['lantai'], ENT_QUOTES); ?>', <?php echo $rm['kapasitas']; ?>, '<?php echo $rm['kondisi']; ?>', '<?php echo htmlspecialchars($rm['gedung'] ?? '', ENT_QUOTES); ?>', '<?php echo htmlspecialchars($rm['penanggung_jawab_id'] ?? ''); ?>')">
                                        <i class="fa-solid fa-pen"></i> Edit
                                    </button>
                                    <button class="btn btn-xs btn-outline-danger" 
                                            onclick="confirmDeleteRoom(<?php echo $rm['id']; ?>, '<?php echo htmlspecialchars($rm['nama_ruangan'], ENT_QUOTES); ?>')">
                                        <i class="fa-solid fa-trash"></i> Hapus
                                    </button>
                                </div>
                            </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center text-secondary py-4">Data lokasi ruangan kosong.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Tambah Ruangan -->
<div class="modal fade" id="addRoomModal" tabindex="-1" aria-labelledby="addRoomModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content bg-dark-select text-white border-gold-subtle" style="background-color: #0f172a; border: 1px solid rgba(212, 175, 55, 0.2); border-radius: 12px;">
            <div class="modal-header border-bottom-gold" style="border-bottom: 1px solid rgba(212, 175, 55, 0.2);">
                <h5 class="modal-title text-gold" id="addRoomModalLabel"><i class="fa-solid fa-plus-circle me-2"></i> Tambah Lokasi Ruangan</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="lokasi.php">
                <?php csrf_input(); ?>
                <input type="hidden" name="action" value="add">
                
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="add_kode_ruangan" class="form-label form-label-custom">Kode Ruangan <span class="text-danger">*</span></label>
                            <input type="text" name="kode_ruangan" id="add_kode_ruangan" class="form-control form-control-custom" placeholder="Contoh: R101, LAB-KOMP" required>
                        </div>
                        <div class="col-md-6">
                            <label for="add_nama_ruangan" class="form-label form-label-custom">Nama Ruangan <span class="text-danger">*</span></label>
                            <input type="text" name="nama_ruangan" id="add_nama_ruangan" class="form-control form-control-custom" placeholder="Contoh: Ruang Kelas 1A, Lab Komputer" required>
                        </div>
                        <div class="col-md-6">
                            <label for="add_gedung" class="form-label form-label-custom">Gedung <span class="text-danger">*</span></label>
                            <input type="text" name="gedung" id="add_gedung" class="form-control form-control-custom" placeholder="Contoh: Gedung A, Gedung Olahraga" required>
                        </div>
                        <div class="col-md-3">
                            <label for="add_lantai" class="form-label form-label-custom">Lantai</label>
                            <input type="text" name="lantai" id="add_lantai" class="form-control form-control-custom" value="1">
                        </div>
                        <div class="col-md-3">
                            <label for="add_kapasitas" class="form-label form-label-custom">Kapasitas (Siswa)</label>
                            <input type="number" name="kapasitas" id="add_kapasitas" class="form-control form-control-custom" value="30">
                        </div>
                        <div class="col-md-6">
                            <label for="add_kondisi" class="form-label form-label-custom">Kondisi Ruangan</label>
                            <select name="kondisi" id="add_kondisi" class="form-select form-control-custom bg-dark-select text-white">
                                <option value="Baik" selected>Baik</option>
                                <option value="Rusak Ringan">Rusak Ringan</option>
                                <option value="Rusak Berat">Rusak Berat</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="add_pj" class="form-label form-label-custom">Penanggung Jawab (PJ)</label>
                            <select name="penanggung_jawab_id" id="add_pj" class="form-select form-control-custom bg-dark-select text-white">
                                <option value="">Belum Ditentukan...</option>
                                <?php foreach ($teachers as $tc): ?>
                                    <option value="<?php echo $tc['id']; ?>"><?php echo htmlspecialchars($tc['nama_guru']) . ' (' . htmlspecialchars($tc['nip']) . ')'; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-top-gold" style="border-top: 1px solid rgba(212, 175, 55, 0.2);">
                    <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-gold">Simpan Ruangan <i class="fa-solid fa-check ms-1"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit Ruangan -->
<div class="modal fade" id="editRoomModal" tabindex="-1" aria-labelledby="editRoomModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content bg-dark-select text-white border-gold-subtle" style="background-color: #0f172a; border: 1px solid rgba(212, 175, 55, 0.2); border-radius: 12px;">
            <div class="modal-header border-bottom-gold" style="border-bottom: 1px solid rgba(212, 175, 55, 0.2);">
                <h5 class="modal-title text-gold" id="editRoomModalLabel"><i class="fa-solid fa-pen-to-square me-2"></i> Edit Lokasi Ruangan</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="lokasi.php">
                <?php csrf_input(); ?>
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit_id">
                
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="edit_kode_ruangan" class="form-label form-label-custom">Kode Ruangan <span class="text-danger">*</span></label>
                            <input type="text" name="kode_ruangan" id="edit_kode_ruangan" class="form-control form-control-custom" required>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_nama_ruangan" class="form-label form-label-custom">Nama Ruangan <span class="text-danger">*</span></label>
                            <input type="text" name="nama_ruangan" id="edit_nama_ruangan" class="form-control form-control-custom" required>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_gedung" class="form-label form-label-custom">Gedung <span class="text-danger">*</span></label>
                            <input type="text" name="gedung" id="edit_gedung" class="form-control form-control-custom" required>
                        </div>
                        <div class="col-md-3">
                            <label for="edit_lantai" class="form-label form-label-custom">Lantai</label>
                            <input type="text" name="lantai" id="edit_lantai" class="form-control form-control-custom">
                        </div>
                        <div class="col-md-3">
                            <label for="edit_kapasitas" class="form-label form-label-custom">Kapasitas (Siswa)</label>
                            <input type="number" name="kapasitas" id="edit_kapasitas" class="form-control form-control-custom">
                        </div>
                        <div class="col-md-6">
                            <label for="edit_kondisi" class="form-label form-label-custom">Kondisi Ruangan</label>
                            <select name="kondisi" id="edit_kondisi" class="form-select form-control-custom bg-dark-select text-white">
                                <option value="Baik">Baik</option>
                                <option value="Rusak Ringan">Rusak Ringan</option>
                                <option value="Rusak Berat">Rusak Berat</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_pj" class="form-label form-label-custom">Penanggung Jawab (PJ)</label>
                            <select name="penanggung_jawab_id" id="edit_pj" class="form-select form-control-custom bg-dark-select text-white">
                                <option value="">Belum Ditentukan...</option>
                                <?php foreach ($teachers as $tc): ?>
                                    <option value="<?php echo $tc['id']; ?>"><?php echo htmlspecialchars($tc['nama_guru']) . ' (' . htmlspecialchars($tc['nip']) . ')'; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-top-gold" style="border-top: 1px solid rgba(212, 175, 55, 0.2);">
                    <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-gold">Simpan Perubahan <i class="fa-solid fa-check ms-1"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openEditModal(id, kode, nama, lantai, kapasitas, kondisi, gedung, pj_id) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_kode_ruangan').value = kode;
    document.getElementById('edit_nama_ruangan').value = nama;
    document.getElementById('edit_lantai').value = lantai;
    document.getElementById('edit_kapasitas').value = kapasitas;
    document.getElementById('edit_kondisi').value = kondisi;
    document.getElementById('edit_gedung').value = gedung;
    document.getElementById('edit_pj').value = pj_id;
    
    const editModal = new bootstrap.Modal(document.getElementById('editRoomModal'));
    editModal.show();
}

function confirmDeleteRoom(id, name) {
    Swal.fire({
        title: 'Hapus Ruangan?',
        text: `Apakah Anda yakin ingin menghapus lokasi ruangan "${name}"? Tindakan ini tidak dapat dibatalkan.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = `lokasi.php?delete_id=${id}`;
        }
    });
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
