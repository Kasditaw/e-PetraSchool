<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris\print_laporan.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
if (!has_role('Kepala Sekolah')) {
    require_inventaris_access();
}

$kategori_id = isset($_GET['kategori_id']) && $_GET['kategori_id'] !== '' ? intval($_GET['kategori_id']) : '';
$ruangan_id = isset($_GET['ruangan_id']) && $_GET['ruangan_id'] !== '' ? intval($_GET['ruangan_id']) : '';
$kondisi = isset($_GET['kondisi']) ? trim($_GET['kondisi']) : '';
$status_pinjam = isset($_GET['status_pinjam']) ? trim($_GET['status_pinjam']) : '';
$status_rusak = isset($_GET['status_rusak']) ? trim($_GET['status_rusak']) : '';
$tahun = isset($_GET['tahun']) && $_GET['tahun'] !== '' ? intval($_GET['tahun']) : '';

try {
    $query = "
        SELECT i.*, k.nama_kategori, r.nama_ruangan 
        FROM inventaris i 
        JOIN kategori_barang k ON i.kategori_id = k.id 
        LEFT JOIN ruangan r ON i.ruangan_id = r.id 
        WHERE i.status_aktif = 'Aktif'
    ";
    
    $params = [];
    
    if ($kategori_id !== '') {
        $query .= " AND i.kategori_id = :kategori_id";
        $params['kategori_id'] = $kategori_id;
    }
    if ($ruangan_id !== '') {
        $query .= " AND i.ruangan_id = :ruangan_id";
        $params['ruangan_id'] = $ruangan_id;
    }
    if ($kondisi !== '') {
        $query .= " AND i.kondisi = :kondisi";
        $params['kondisi'] = $kondisi;
    }
    if ($status_rusak === '1') {
        $query .= " AND i.kondisi IN ('Rusak Ringan', 'Rusak Berat')";
    }
    if ($tahun !== '') {
        $query .= " AND i.tahun_perolehan = :tahun";
        $params['tahun'] = $tahun;
    }
    if ($status_pinjam !== '') {
        if ($status_pinjam === 'Dipinjam') {
            $query .= " AND i.id IN (SELECT DISTINCT inventaris_id FROM peminjaman WHERE status = 'Dipinjam')";
        } elseif ($status_pinjam === 'Tersedia') {
            $query .= " AND i.id NOT IN (SELECT DISTINCT inventaris_id FROM peminjaman WHERE status = 'Dipinjam')";
        }
    }

    $query .= " ORDER BY i.kode_barang ASC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch filters names for printable labels
    $kategori_nama = 'Semua';
    if ($kategori_id !== '') {
        $stmt_cat = $pdo->prepare("SELECT nama_kategori FROM kategori_barang WHERE id = ?");
        $stmt_cat->execute([$kategori_id]);
        $kategori_nama = $stmt_cat->fetchColumn() ?: 'Semua';
    }

    $ruangan_nama = 'Semua';
    if ($ruangan_id !== '') {
        $stmt_rm = $pdo->prepare("SELECT nama_ruangan FROM ruangan WHERE id = ?");
        $stmt_rm->execute([$ruangan_id]);
        $ruangan_nama = $stmt_rm->fetchColumn() ?: 'Semua';
    }

    $indo_months = [
        'January' => 'Januari',
        'February' => 'Februari',
        'March' => 'Maret',
        'April' => 'April',
        'May' => 'Mei',
        'June' => 'Juni',
        'July' => 'Juli',
        'August' => 'Agustus',
        'September' => 'September',
        'October' => 'Oktober',
        'November' => 'November',
        'December' => 'Desember'
    ];
    $date_id = strtr(date('d F Y'), $indo_months);
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak Laporan Inventaris - SD Kristen Petra 1</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
            box-sizing: border-box;
        }
        body {
            font-family: 'Outfit', 'Helvetica Neue', Arial, sans-serif;
            color: #333;
            margin: 0;
            padding: 30px;
            font-size: 11px;
            background-color: #fff;
        }
        .kop-surat {
            border-bottom: 3px double #000;
            padding-bottom: 10px;
            margin-bottom: 20px;
            text-align: center;
        }
        .kop-surat h2 {
            margin: 0;
            font-size: 16px;
            font-weight: 700;
            letter-spacing: 0.5px;
        }
        .kop-surat h3 {
            margin: 3px 0 0 0;
            font-size: 12px;
            color: #555;
        }
        .kop-surat p {
            margin: 3px 0 0 0;
            font-size: 10px;
            color: #777;
        }
        .title-section {
            text-align: center;
            margin-bottom: 20px;
        }
        .title-section h4 {
            margin: 0;
            font-size: 13px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .filter-info {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            font-size: 10px;
            color: #555;
            background: #f8fafc;
            padding: 8px 12px;
            border-radius: 6px;
            margin-bottom: 15px;
            border: 1px solid #e2e8f0;
        }
        .table-laporan {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        .table-laporan th, .table-laporan td {
            border: 1px solid #cbd5e1;
            padding: 6px 8px;
            text-align: left;
        }
        .table-laporan th {
            background-color: #f1f5f9;
            font-weight: 600;
            color: #0f172a;
        }
        .table-laporan td {
            color: #334155;
        }
        .text-right {
            text-align: right !important;
        }
        .font-monospace {
            font-family: monospace;
        }
        .signature-section {
            margin-top: 50px;
            display: flex;
            justify-content: space-between;
            page-break-inside: avoid;
        }
        .signature-box {
            text-align: center;
            width: 200px;
        }
        .signature-box p {
            margin: 0;
        }
        .signature-space {
            height: 70px;
        }
        .print-btn-bar {
            position: fixed;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
            z-index: 1000;
        }
        .btn-print-action {
            background: #D4AF37;
            color: #000;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-family: 'Outfit', sans-serif;
            box-shadow: 0 4px 12px rgba(212, 175, 55, 0.3);
            transition: all 0.2s ease;
        }
        .btn-print-action:hover {
            background: #f3cd48;
            transform: translateY(-1px);
        }
        .btn-print-back {
            background: #ffffff;
            color: #334155;
            border: 1px solid #e2e8f0;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-family: 'Outfit', sans-serif;
            transition: all 0.2s ease;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        }
        .btn-print-back:hover {
            background: #f8fafc;
            border-color: #cbd5e1;
            transform: translateY(-1px);
        }
        @media print {
            body {
                padding: 0;
            }
            .print-btn-bar {
                display: none !important;
            }
        }
    </style>
</head>
<body>

    <div class="print-btn-bar no-print">
        <button onclick="window.close()" class="btn-print-back"><i class="fa-solid fa-xmark"></i> Tutup</button>
        <button onclick="window.print()" class="btn-print-action"><i class="fa-solid fa-print"></i> Cetak Dokumen</button>
    </div>

    <div class="kop-surat">
        <h2>SD KRISTEN PETRA 1 SURABAYA</h2>
        <h3>MANAJEMEN INVENTARIS & ASET SEKOLAH</h3>
        <p>Jl. Pucang Anom Timur No.5, Kertajaya, Kec. Gubeng, Kota Surabaya, Jawa Timur 60282</p>
    </div>

    <div class="title-section">
        <h4>Laporan Data Inventaris Aset Sekolah</h4>
    </div>

    <div class="filter-info">
        <div><strong>Kategori:</strong> <?php echo htmlspecialchars($kategori_nama); ?></div>
        <div><strong>Lokasi:</strong> <?php echo htmlspecialchars($ruangan_nama); ?></div>
        <div><strong>Kondisi:</strong> <?php echo htmlspecialchars($kondisi ?: 'Semua'); ?></div>
        <div><strong>Tahun Perolehan:</strong> <?php echo htmlspecialchars($tahun ?: 'Semua'); ?></div>
        <div><strong>Status Pinjam:</strong> <?php echo htmlspecialchars($status_pinjam ?: 'Semua'); ?></div>
        <?php if ($status_rusak === '1'): ?>
            <div><strong>Filter Tambahan:</strong> Hanya Aset Rusak</div>
        <?php endif; ?>
    </div>

    <table class="table-laporan">
        <thead>
            <tr>
                <th style="width: 30px;">No</th>
                <th>Kode Aset</th>
                <th>Nama Barang / Deskripsi</th>
                <th>Kategori</th>
                <th>Lokasi Ruangan</th>
                <th>Merk / Model</th>
                <th style="width: 80px;">Kondisi</th>
                <th style="width: 50px;">Tahun</th>
                <th style="width: 100px;" class="text-right">Harga Perolehan</th>
            </tr>
        </thead>
        <tbody>
            <?php if (count($assets) > 0): ?>
                <?php 
                $no = 1; 
                $total_investasi = 0;
                foreach ($assets as $ast): 
                    $total_investasi += $ast['harga'];
                ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td class="font-monospace fw-semibold"><?php echo htmlspecialchars($ast['kode_barang']); ?></td>
                        <td><strong><?php echo htmlspecialchars($ast['nama_barang']); ?></strong></td>
                        <td><?php echo htmlspecialchars($ast['nama_kategori']); ?></td>
                        <td><?php echo htmlspecialchars($ast['nama_ruangan'] ?: 'Gudang / Belum Alokasi'); ?></td>
                        <td><?php echo htmlspecialchars(($ast['merk'] ?: '-') . ($ast['tipe_model'] ? ' / ' . $ast['tipe_model'] : '')); ?></td>
                        <td><?php echo htmlspecialchars($ast['kondisi']); ?></td>
                        <td><?php echo htmlspecialchars($ast['tahun_perolehan'] ?: '-'); ?></td>
                        <td class="text-right font-monospace">Rp <?php echo number_format($ast['harga'], 0, ',', '.'); ?></td>
                    </tr>
                <?php endforeach; ?>
                <tr style="font-weight: bold; background-color: #f8fafc;">
                    <td colspan="8" class="text-right" style="padding: 8px;">Total Nilai Investasi Aset Terfilter:</td>
                    <td class="text-right font-monospace">Rp <?php echo number_format($total_investasi, 0, ',', '.'); ?></td>
                </tr>
            <?php else: ?>
                <tr>
                    <td colspan="9" style="text-align: center; padding: 20px; color: #777;">Tidak ada data aset yang cocok dengan kriteria filter.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="signature-section">
        <div class="signature-box">
            <p>Mengetahui,</p>
            <p><strong>Kepala Sekolah SD Kristen Petra 1</strong></p>
            <div class="signature-space"></div>
            <p>__________________________</p>
            <p>NIP. .........................</p>
        </div>
        
        <div class="signature-box">
            <p>Surabaya, <?php echo $date_id; ?></p>
            <p><strong>Penanggung Jawab Inventaris</strong></p>
            <div class="signature-space"></div>
            <p>__________________________</p>
            <p>NIP. .........................</p>
        </div>
    </div>

    <script>
        window.addEventListener('DOMContentLoaded', () => {
            setTimeout(() => {
                window.print();
            }, 600);
        });
    </script>
</body>
</html>
