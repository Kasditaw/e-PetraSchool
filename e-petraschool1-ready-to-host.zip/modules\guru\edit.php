<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\guru\edit.php

$page_title = 'Edit Guru';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';
$histori_success = '';
$histori_error = '';

try {
    // Load current teacher record along with user login details
    $stmt = $pdo->prepare("SELECT g.*, u.username, u.status_aktif FROM guru g LEFT JOIN users u ON g.id = u.guru_id WHERE g.id = ?");
    $stmt->execute([$id]);
    $teacher = $stmt->fetch();
    
    if (!$teacher) {
        die('<div class="alert alert-danger">Data guru tidak ditemukan!</div>');
    }
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

// ── Handle POST: tambah histori kepegawaian
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'tambah_histori') {
    check_csrf_request();
    $h_jenis      = $_POST['h_jenis'] ?? '';
    $h_tanggal    = $_POST['h_tanggal'] ?? '';
    $h_tujuan     = trim($_POST['h_tujuan'] ?? '');
    $h_keterangan = trim($_POST['h_keterangan'] ?? '');

    if (empty($h_jenis) || empty($h_tanggal)) {
        $histori_error = 'Jenis dan tanggal histori wajib diisi.';
    } else {
        try {
            $ins = $pdo->prepare("INSERT INTO guru_histori (guru_id, jenis, tanggal, tujuan, keterangan, created_by) VALUES (?, ?, ?, ?, ?, ?)");
            $ins->execute([$id, $h_jenis, $h_tanggal, $h_tujuan ?: null, $h_keterangan ?: null, $_SESSION['user_id'] ?? null]);

            // Jika Resign → set status Tidak Aktif; Aktif Kembali → set Aktif
            if ($h_jenis === 'Resign') {
                $pdo->prepare("UPDATE users SET status_aktif = 'Tidak Aktif' WHERE guru_id = ?")->execute([$id]);
            } elseif ($h_jenis === 'Aktif Kembali') {
                $pdo->prepare("UPDATE users SET status_aktif = 'Aktif' WHERE guru_id = ?")->execute([$id]);
            }

            write_audit_log("Menambah histori {$h_jenis} untuk guru: " . $teacher['nama_guru'] . " (NIP: " . $teacher['nip'] . ") pada {$h_tanggal}.");
            $histori_success = "Histori {$h_jenis} berhasil ditambahkan.";

            // Reload teacher (status mungkin berubah)
            $stmt2 = $pdo->prepare("SELECT g.*, u.username, u.status_aktif FROM guru g LEFT JOIN users u ON g.id = u.guru_id WHERE g.id = ?");
            $stmt2->execute([$id]);
            $teacher = $stmt2->fetch();
        } catch (Exception $e) {
            $histori_error = 'Gagal menyimpan histori: ' . $e->getMessage();
        }
    }
}

// ── Handle POST: hapus histori
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'hapus_histori') {
    check_csrf_request();
    $del_id = intval($_POST['histori_id'] ?? 0);
    if ($del_id > 0) {
        try {
            $pdo->prepare("DELETE FROM guru_histori WHERE id = ? AND guru_id = ?")->execute([$del_id, $id]);
            $histori_success = 'Histori berhasil dihapus.';
        } catch (Exception $e) {
            $histori_error = 'Gagal menghapus: ' . $e->getMessage();
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['action'])) {
    check_csrf_request();

    $nip = trim($_POST['nip'] ?? '');
    $nama_guru = trim($_POST['nama_guru'] ?? '');
    $gender = $_POST['gender'] ?? '';
    $pendidikan = trim($_POST['pendidikan'] ?? '');
    $jabatan = trim($_POST['jabatan'] ?? '');
    
    // Mapel selection handling
    $mapel_select = trim($_POST['mapel_select'] ?? '');
    $mapel_custom = trim($_POST['mapel_custom'] ?? '');
    $mapel = ($mapel_select === 'Lainnya') ? $mapel_custom : $mapel_select;
    if (empty($mapel)) {
        $mapel = '-';
    }

    $no_hp = trim($_POST['no_hp'] ?? '');
    $alamat = trim($_POST['alamat'] ?? '');
    $email = trim($_POST['email'] ?? '');
    
    // File upload handling
    $foto_name = $teacher['foto']; // Default
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['foto']['tmp_name'];
        $file_name = $_FILES['foto']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed_exts = ['jpg', 'jpeg', 'png'];
        $mime_type = mime_content_type($file_tmp);
        $allowed_mimes = ['image/jpeg', 'image/png', 'image/pjpeg'];
        
        if (in_array($file_ext, $allowed_exts) && in_array($mime_type, $allowed_mimes)) {
            $upload_dir = dirname(dirname(__DIR__)) . '/assets/uploads/guru/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            // Delete old photo
            if (!empty($teacher['foto']) && file_exists($upload_dir . $teacher['foto'])) {
                unlink($upload_dir . $teacher['foto']);
            }
            
            $foto_name = 'teacher_' . $nip . '_' . time() . '.' . $file_ext;
            if (move_uploaded_file($file_tmp, $upload_dir . $foto_name)) {
                // Success
            } else {
                $error = 'Gagal menyimpan file foto baru.';
            }
        } else {
            $error = 'Format file foto salah. Hanya menerima JPG, JPEG, atau PNG.';
        }
    }

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $status_aktif = $_POST['status_aktif'] ?? 'Aktif';

    if ($error === '') {
        if (empty($nip) || empty($nama_guru) || empty($gender) || empty($pendidikan) || empty($no_hp) || empty($email) || empty($username)) {
            $error = 'Field NIP, Nama, Gender, Pendidikan, No HP, Email, dan Username wajib diisi!';
        } else {
            try {
                // Check duplicate NIP on other records
                $chk1 = $pdo->prepare("SELECT COUNT(*) FROM guru WHERE nip = ? AND id != ?");
                $chk1->execute([$nip, $id]);
                if ($chk1->fetchColumn() > 0) {
                    $error = "NIP '$nip' sudah digunakan oleh guru lain!";
                } else {
                    // Check duplicate email on other records
                    $chk2 = $pdo->prepare("SELECT COUNT(*) FROM guru WHERE email = ? AND id != ?");
                    $chk2->execute([$email, $id]);
                    if ($chk2->fetchColumn() > 0) {
                        $error = "Email '$email' sudah digunakan oleh guru lain!";
                    } else {
                        // Check duplicate username on other users
                        $chk3 = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND (guru_id != ? OR guru_id IS NULL)");
                        $chk3->execute([$username, $id]);
                        if ($chk3->fetchColumn() > 0) {
                            $error = "Username '$username' sudah digunakan oleh pengguna lain!";
                        } else {
                            $pdo->beginTransaction();

                            // Update guru
                            $stmt = $pdo->prepare("UPDATE guru SET nip = ?, nama_guru = ?, gender = ?, pendidikan = ?, jabatan = ?, mapel = ?, no_hp = ?, alamat = ?, email = ?, foto = ? WHERE id = ?");
                            $stmt->execute([$nip, $nama_guru, $gender, $pendidikan, $jabatan, $mapel, $no_hp, $alamat, $email, $foto_name, $id]);

                            // Check if user account already exists
                            $check_user = $pdo->prepare("SELECT id FROM users WHERE guru_id = ?");
                            $check_user->execute([$id]);
                            $user_id = $check_user->fetchColumn();

                            if ($user_id) {
                                // Update user login info
                                if (!empty($password)) {
                                    $hashed_pass = password_hash($password, PASSWORD_BCRYPT);
                                    $stmt_user = $pdo->prepare("UPDATE users SET username = ?, password = ?, nama = ?, status_aktif = ? WHERE id = ?");
                                    $stmt_user->execute([$username, $hashed_pass, $nama_guru, $status_aktif, $user_id]);
                                } else {
                                    $stmt_user = $pdo->prepare("UPDATE users SET username = ?, nama = ?, status_aktif = ? WHERE id = ?");
                                    $stmt_user->execute([$username, $nama_guru, $status_aktif, $user_id]);
                                }
                            } else {
                                // Create new user login info
                                $hashed_pass = password_hash(!empty($password) ? $password : 'admin123', PASSWORD_BCRYPT);
                                $stmt_user = $pdo->prepare("INSERT INTO users (username, password, nama, role_id, guru_id, status_aktif) VALUES (?, ?, ?, 3, ?, ?)");
                                $stmt_user->execute([$username, $hashed_pass, $nama_guru, $id, $status_aktif]);
                            }

                            $pdo->commit();

                            write_audit_log("Mengubah data guru: $nama_guru (NIP: $nip) dan memperbarui akun login: $username.");
                            
                            echo "<script>
                                document.addEventListener('DOMContentLoaded', function() {
                                    Swal.fire('Berhasil', 'Data guru dan akun login berhasil diubah!', 'success').then(() => {
                                        window.location.href = 'index.php';
                                    });
                                });
                            </script>";
                        }
                    }
                }
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $error = 'Error database: ' . $e->getMessage();
            }
        }
    }
}
$mapel_list = [];
try {
    $mapel_list = $pdo->query("SELECT nama_mapel FROM mata_pelajaran WHERE status = 'Aktif' ORDER BY nama_mapel ASC")->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) {
    // fallback
}

$current_mapel = $teacher['mapel'] ?? '';
$is_standard = in_array($current_mapel, $mapel_list) || $current_mapel === 'Guru Kelas' || $current_mapel === '-' || $current_mapel === '';
$mapel_select_val = $is_standard ? $current_mapel : 'Lainnya';
$mapel_custom_val = $is_standard ? '' : $current_mapel;

// Load histori guru
$historis = [];
try {
    $h_stmt = $pdo->prepare("SELECT gh.*, u.nama AS dicatat_oleh FROM guru_histori gh LEFT JOIN users u ON gh.created_by = u.id WHERE gh.guru_id = ? ORDER BY gh.tanggal DESC, gh.created_at DESC");
    $h_stmt->execute([$id]);
    $historis = $h_stmt->fetchAll();
} catch (Exception $e) {
    // tabel mungkin belum ada, abaikan
}
?>

<div class="glass-card" style="max-width: 750px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-user-pen me-2"></i> Edit Data Guru</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="edit.php?id=<?php echo $id; ?>" enctype="multipart/form-data">
        <?php csrf_input(); ?>

        <div class="row g-3">
            <div class="col-12 col-md-6">
                <label for="nip" class="form-label form-label-custom">NIP (Nomor Induk Pegawai) <span class="text-danger">*</span></label>
                <input type="text" name="nip" id="nip" class="form-control form-control-custom" value="<?php echo htmlspecialchars($teacher['nip']); ?>" required>
            </div>
            
            <div class="col-12 col-md-6">
                <label for="nama_guru" class="form-label form-label-custom">Nama Lengkap Guru <span class="text-danger">*</span></label>
                <input type="text" name="nama_guru" id="nama_guru" class="form-control form-control-custom" value="<?php echo htmlspecialchars($teacher['nama_guru']); ?>" required>
            </div>

            <div class="col-12 col-md-4">
                <label for="gender" class="form-label form-label-custom">Jenis Kelamin <span class="text-danger">*</span></label>
                <select name="gender" id="gender" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="L" <?php echo $teacher['gender'] === 'L' ? 'selected' : ''; ?>>Laki-laki</option>
                    <option value="P" <?php echo $teacher['gender'] === 'P' ? 'selected' : ''; ?>>Perempuan</option>
                </select>
            </div>

            <div class="col-12 col-md-4">
                <label for="pendidikan" class="form-label form-label-custom">Pendidikan Terakhir <span class="text-danger">*</span></label>
                <input type="text" name="pendidikan" id="pendidikan" class="form-control form-control-custom" value="<?php echo htmlspecialchars($teacher['pendidikan']); ?>" required>
            </div>

            <div class="col-12 col-md-4">
                <label for="jabatan" class="form-label form-label-custom">Jabatan Kepegawaian</label>
                <input type="text" name="jabatan" id="jabatan" class="form-control form-control-custom" value="<?php echo htmlspecialchars($teacher['jabatan']); ?>">
            </div>

            <div class="col-12 col-md-6">
                <label for="mapel_select" class="form-label form-label-custom">Mata Pelajaran yang Diajar <span class="text-danger">*</span></label>
                <select name="mapel_select" id="mapel_select" class="form-select form-control-custom bg-dark-select text-white" onchange="toggleCustomMapelInput(this.value)" required>
                    <option value="" disabled <?php echo empty($mapel_select_val) ? 'selected' : ''; ?>>Pilih Mata Pelajaran...</option>
                    <option value="-" <?php echo $mapel_select_val === '-' ? 'selected' : ''; ?>>-</option>
                    <option value="Guru Kelas" <?php echo $mapel_select_val === 'Guru Kelas' ? 'selected' : ''; ?>>Guru Kelas</option>
                    <?php foreach ($mapel_list as $m_name): ?>
                        <option value="<?php echo htmlspecialchars($m_name); ?>" <?php echo $mapel_select_val === $m_name ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($m_name); ?>
                        </option>
                    <?php endforeach; ?>
                    <option value="Lainnya" <?php echo $mapel_select_val === 'Lainnya' ? 'selected' : ''; ?>>Lainnya (Input Manual)...</option>
                </select>
            </div>

            <div class="col-12 col-md-6 <?php echo $mapel_select_val === 'Lainnya' ? '' : 'd-none'; ?>" id="custom-mapel-container">
                <label for="mapel_custom" class="form-label form-label-custom">Mata Pelajaran Kustom <span class="text-danger">*</span></label>
                <input type="text" name="mapel_custom" id="mapel_custom" class="form-control form-control-custom" value="<?php echo htmlspecialchars($mapel_custom_val); ?>" placeholder="Ketik nama mata pelajaran kustom" <?php echo $mapel_select_val === 'Lainnya' ? 'required' : ''; ?>>
            </div>

            <div class="col-12 col-md-6">
                <label for="no_hp" class="form-label form-label-custom">Nomor HP / WhatsApp <span class="text-danger">*</span></label>
                <input type="text" name="no_hp" id="no_hp" class="form-control form-control-custom" value="<?php echo htmlspecialchars($teacher['no_hp']); ?>" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="email" class="form-label form-label-custom">Email Petra <span class="text-danger">*</span></label>
                <input type="email" name="email" id="email" class="form-control form-control-custom" value="<?php echo htmlspecialchars($teacher['email']); ?>" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="foto" class="form-label form-label-custom">Foto Guru</label>
                <div class="d-flex align-items-center gap-3">
                    <?php if (!empty($teacher['foto'])): ?>
                        <img src="<?php echo $base_url; ?>assets/uploads/guru/<?php echo $teacher['foto']; ?>" alt="Foto" class="rounded border" style="width: 45px; height: 55px; object-fit: cover;">
                    <?php endif; ?>
                    <input type="file" name="foto" id="foto" class="form-control form-control-custom" accept="image/*">
                </div>
            </div>

            <div class="col-12">
                <label for="alamat" class="form-label form-label-custom">Alamat Lengkap</label>
                <textarea name="alamat" id="alamat" class="form-control form-control-custom" rows="2"><?php echo htmlspecialchars($teacher['alamat']); ?></textarea>
            </div>

            <div class="col-12 mt-4">
                <h6 class="text-gold border-bottom border-secondary border-opacity-25 pb-2 mb-3"><i class="fa-solid fa-key me-2"></i> Akun Akses e-Jurnal</h6>
            </div>

            <div class="col-12 col-md-4">
                <label for="username" class="form-label form-label-custom">Username <span class="text-danger">*</span></label>
                <input type="text" name="username" id="username" class="form-control form-control-custom" value="<?php echo htmlspecialchars($teacher['username'] ?? ''); ?>" required autocomplete="off">
            </div>

            <div class="col-12 col-md-4">
                <label for="password" class="form-label form-label-custom">Password Baru (Kosongkan jika tidak diubah)</label>
                <input type="password" name="password" id="password" class="form-control form-control-custom" placeholder="Password baru" autocomplete="new-password">
            </div>

            <div class="col-12 col-md-4">
                <label for="status_aktif" class="form-label form-label-custom">Status Aktif <span class="text-danger">*</span></label>
                <div class="d-flex gap-2 align-items-start">
                    <select name="status_aktif" id="status_aktif" class="form-select form-control-custom bg-dark-select text-white" required>
                        <option value="Aktif" <?php echo ($teacher['status_aktif'] ?? 'Aktif') === 'Aktif' ? 'selected' : ''; ?>>Aktif</option>
                        <option value="Tidak Aktif" <?php echo ($teacher['status_aktif'] ?? '') === 'Tidak Aktif' ? 'selected' : ''; ?>>Tidak Aktif</option>
                    </select>
                    <button type="button" onclick="openHistoriModal()" class="btn btn-outline-custom text-gold flex-shrink-0" title="Tambah Histori Kepegawaian" style="white-space:nowrap;">
                        <i class="fa-solid fa-clock-rotate-left me-1"></i> Histori
                    </button>
                </div>
            </div>

            <div class="col-12 d-flex justify-content-end gap-2 mt-4">
                <a href="index.php" class="btn btn-outline-custom">Batal</a>
                <button type="submit" class="btn btn-gold">Simpan Perubahan <i class="fa-solid fa-check ms-1"></i></button>
            </div>
        </div>
    </form>
</div>

<!-- ═══════ SECTION: Riwayat Kepegawaian ═══════ -->
<div class="glass-card mt-4" id="histori-section" style="max-width: 750px; margin: 16px auto 0;">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h6 class="text-gold fw-bold mb-0"><i class="fa-solid fa-timeline me-2"></i>Riwayat Kepegawaian</h6>
        <button type="button" onclick="openHistoriModal()" class="btn btn-xs btn-gold">
            <i class="fa-solid fa-plus me-1"></i> Tambah
        </button>
    </div>

    <?php if (!empty($histori_success)): ?>
        <div class="alert alert-success border-0 bg-success bg-opacity-25 text-white small py-2 mb-3">
            <i class="fa-solid fa-check-circle me-1"></i> <?php echo htmlspecialchars($histori_success); ?>
        </div>
    <?php endif; ?>
    <?php if (!empty($histori_error)): ?>
        <div class="alert alert-danger border-0 bg-danger bg-opacity-25 text-white small py-2 mb-3">
            <i class="fa-solid fa-triangle-exclamation me-1"></i> <?php echo htmlspecialchars($histori_error); ?>
        </div>
    <?php endif; ?>

    <?php if (count($historis) > 0): ?>
        <div class="table-responsive">
            <table class="table table-custom mb-0" style="font-size:13px;">
                <thead>
                    <tr>
                        <th style="width:120px;">Tanggal</th>
                        <th style="width:110px;">Jenis</th>
                        <th>Tujuan / Instansi</th>
                        <th>Keterangan</th>
                        <th style="width:110px;">Dicatat Oleh</th>
                        <th style="width:60px;"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($historis as $h): ?>
                        <?php
                            $badge_h = 'badge-secondary';
                            if ($h['jenis'] === 'Mutasi')       $badge_h = 'badge-warning';
                            elseif ($h['jenis'] === 'Resign')   $badge_h = 'badge-danger';
                            elseif ($h['jenis'] === 'Aktif Kembali') $badge_h = 'badge-success';
                        ?>
                        <tr>
                            <td><span class="font-monospace text-white" style="font-size:12px;"><?php echo date('d/m/Y', strtotime($h['tanggal'])); ?></span></td>
                            <td><span class="badge <?php echo $badge_h; ?>"><?php echo htmlspecialchars($h['jenis']); ?></span></td>
                            <td class="text-secondary"><?php echo htmlspecialchars($h['tujuan'] ?? '-'); ?></td>
                            <td class="text-secondary"><?php echo htmlspecialchars($h['keterangan'] ?? '-'); ?></td>
                            <td class="text-secondary" style="font-size:11px;"><?php echo htmlspecialchars($h['dicatat_oleh'] ?? 'Sistem'); ?></td>
                            <td>
                                <form method="POST" action="edit.php?id=<?php echo $id; ?>" onsubmit="return confirm('Hapus histori ini?')" style="margin:0;">
                                    <?php csrf_input(); ?>
                                    <input type="hidden" name="action" value="hapus_histori">
                                    <input type="hidden" name="histori_id" value="<?php echo $h['id']; ?>">
                                    <button type="submit" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="text-center text-secondary py-3" style="font-size:13px;">
            <i class="fa-solid fa-inbox me-2 opacity-50"></i>Belum ada riwayat kepegawaian.
        </div>
    <?php endif; ?>
</div>

<!-- ═══════ MODAL: Tambah Histori ═══════ -->
<div class="modal fade" id="historiModal" tabindex="-1" aria-labelledby="historiModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="background:#0f172a; border:1px solid rgba(212,175,55,0.25); border-radius:14px;">
            <div class="modal-header" style="border-bottom:1px solid rgba(212,175,55,0.2);">
                <h6 class="modal-title text-gold fw-bold" id="historiModalLabel"><i class="fa-solid fa-timeline me-2"></i>Tambah Riwayat Kepegawaian</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="edit.php?id=<?php echo $id; ?>">
                <?php csrf_input(); ?>
                <input type="hidden" name="action" value="tambah_histori">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <label class="form-label form-label-custom">Jenis Riwayat <span class="text-danger">*</span></label>
                            <select name="h_jenis" id="h_jenis" class="form-select form-control-custom bg-dark-select text-white" required onchange="toggleTujuanField(this.value)">
                                <option value="" disabled selected>Pilih jenis...</option>
                                <option value="Mutasi">Mutasi</option>
                                <option value="Resign">Resign</option>
                                <option value="Aktif Kembali">Aktif Kembali</option>
                                <option value="Lainnya">Lainnya</option>
                            </select>
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label form-label-custom">Tanggal <span class="text-danger">*</span></label>
                            <input type="date" name="h_tanggal" class="form-control form-control-custom" value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        <div class="col-12" id="tujuan_field">
                            <label class="form-label form-label-custom">Tujuan / Instansi Baru</label>
                            <input type="text" name="h_tujuan" class="form-control form-control-custom" placeholder="Contoh: SD Petra 2 Surabaya">
                        </div>
                        <div class="col-12">
                            <label class="form-label form-label-custom">Keterangan</label>
                            <textarea name="h_keterangan" class="form-control form-control-custom" rows="2" placeholder="Keterangan tambahan..."></textarea>
                        </div>
                    </div>
                    <div class="mt-3 p-2 rounded" style="background:rgba(212,175,55,0.08); border:1px solid rgba(212,175,55,0.2); font-size:12px;" id="histori_info_box">
                        <i class="fa-solid fa-circle-info text-gold me-1"></i>
                        <span id="histori_info_text" class="text-secondary">Pilih jenis riwayat untuk melihat keterangan.</span>
                    </div>
                </div>
                <div class="modal-footer" style="border-top:1px solid rgba(212,175,55,0.2);">
                    <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-gold">Simpan <i class="fa-solid fa-check ms-1"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function toggleCustomMapelInput(val) {
    var container = document.getElementById('custom-mapel-container');
    var input = document.getElementById('mapel_custom');
    if (val === 'Lainnya') {
        container.classList.remove('d-none');
        input.setAttribute('required', 'required');
        input.focus();
    } else {
        container.classList.add('d-none');
        input.removeAttribute('required');
        input.value = '';
    }
}

function openHistoriModal() {
    var modalEl = document.getElementById('historiModal');
    var existingModal = bootstrap.Modal.getInstance(modalEl);
    if (existingModal) existingModal.dispose();
    var modal = new bootstrap.Modal(modalEl, { backdrop: true, keyboard: true });
    modal.show();
}

function toggleTujuanField(val) {
    var tujuanField = document.getElementById('tujuan_field');
    var infoText    = document.getElementById('histori_info_text');
    var msgs = {
        'Mutasi':        'Status guru akan tetap Aktif. Catat tujuan/instansi baru jika ada.',
        'Resign':        '⚠️ Status akun guru akan otomatis diubah menjadi <strong>Tidak Aktif</strong>.',
        'Aktif Kembali': '✅ Status akun guru akan otomatis diubah kembali menjadi <strong>Aktif</strong>.',
        'Lainnya':       'Catatan riwayat umum tanpa perubahan status otomatis.'
    };
    infoText.innerHTML = msgs[val] || 'Pilih jenis riwayat untuk melihat keterangan.';
    if (val === 'Resign' || val === 'Aktif Kembali') {
        tujuanField.style.display = 'none';
    } else {
        tujuanField.style.display = '';
    }
}

// ━━ CRITICAL FIX: Pindahkan modal ke <body> agar tidak terpengaruh
// stacking context dari animasi CSS (.animated-view / transform)
document.addEventListener('DOMContentLoaded', function () {
    var modal = document.getElementById('historiModal');
    if (modal && modal.parentElement !== document.body) {
        document.body.appendChild(modal);
    }

    // Hapus class animated-view setelah animasi selesai
    // agar transform tidak lagi block stacking context
    var animEl = document.querySelector('.animated-view');
    if (animEl) {
        animEl.addEventListener('animationend', function () {
            animEl.classList.remove('animated-view');
        }, { once: true });
    }
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
