<?php
// c:\xampp\htdocs\e-petraschool1\modules\dashboard\kepsek.php

$page_title = 'Dashboard Kepala Sekolah';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Kepala Sekolah','Super Admin','Admin']);

try {
    // === KPI UTAMA ===
    $total_siswa  = $pdo->query("SELECT COUNT(*) FROM siswa WHERE status_siswa='Aktif'")->fetchColumn();
    $total_guru   = $pdo->query("SELECT COUNT(*) FROM guru")->fetchColumn();
    $total_kelas  = $pdo->query("SELECT COUNT(*) FROM kelas WHERE status='Aktif'")->fetchColumn();
    $total_karyawan = $pdo->query("SELECT COUNT(*) FROM karyawan")->fetchColumn();

    // Jurnal menunggu verifikasi
    $jurnal_pending = $pdo->query("SELECT COUNT(*) FROM jurnal_mengajar WHERE status='Menunggu Verifikasi'")->fetchColumn();

    // === ABSENSI SISWA: 7 hari terakhir (jika tabel ada) ===
    $absensi_chart_labels = [];
    $absensi_chart_hadir  = [];
    $absensi_chart_alpha  = [];
    try {
        $absensi_7d = $pdo->query("
            SELECT tanggal, status, COUNT(*) AS jumlah
            FROM absensi_siswa
            WHERE tanggal >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
            GROUP BY tanggal, status
            ORDER BY tanggal ASC
        ")->fetchAll();
        $days_map = [];
        foreach ($absensi_7d as $r) {
            $days_map[$r['tanggal']][$r['status']] = $r['jumlah'];
        }
        // Fill 7 days
        for ($i = 6; $i >= 0; $i--) {
            $d = date('Y-m-d', strtotime("-$i days"));
            $absensi_chart_labels[] = date('d/m', strtotime($d));
            $absensi_chart_hadir[]  = intval($days_map[$d]['Hadir']  ?? 0);
            $absensi_chart_alpha[]  = intval($days_map[$d]['Alfa']   ?? 0) + intval($days_map[$d]['Sakit'] ?? 0) + intval($days_map[$d]['Izin'] ?? 0);
        }
    } catch (Exception $e) {}

    // === ABSENSI GURU: 7 hari terakhir ===
    $guru_chart_labels = [];
    $guru_chart_hadir  = [];
    $guru_chart_alpha  = [];
    try {
        $guru_7d = $pdo->query("
            SELECT tanggal, status, COUNT(*) AS jumlah
            FROM absensi_guru
            WHERE tanggal >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
            GROUP BY tanggal, status
            ORDER BY tanggal ASC
        ")->fetchAll();
        $guru_map = [];
        foreach ($guru_7d as $r) { $guru_map[$r['tanggal']][$r['status']] = $r['jumlah']; }
        for ($i = 6; $i >= 0; $i--) {
            $d = date('Y-m-d', strtotime("-$i days"));
            $guru_chart_labels[] = date('d/m', strtotime($d));
            $guru_chart_hadir[]  = intval($guru_map[$d]['Hadir'] ?? 0);
            $guru_chart_alpha[]  = intval(($guru_map[$d]['Alfa'] ?? 0)) + intval(($guru_map[$d]['Sakit'] ?? 0)) + intval(($guru_map[$d]['Izin'] ?? 0));
        }
    } catch (Exception $e) {}

    // === JURNAL: 5 terbaru ===
    $jurnal_terbaru = $pdo->query("
        SELECT j.*, g.nama_guru, k.nama_kelas
        FROM jurnal_mengajar j
        JOIN guru g ON j.guru_id=g.id
        LEFT JOIN kelas k ON j.kelas_id=k.id
        WHERE j.status='Menunggu Verifikasi'
        ORDER BY j.tanggal DESC
        LIMIT 5
    ")->fetchAll();

    // === REKAP RAPORT PER KELAS ===
    $raport_progress = [];
    try {
        $raport_progress = $pdo->query("
            SELECT k.id, k.nama_kelas,
                   (SELECT COUNT(*) FROM siswa s WHERE s.kelas_id=k.id AND s.status_siswa='Aktif') AS total_siswa,
                   (SELECT COUNT(DISTINCT r.siswa_id) FROM raport r JOIN siswa s2 ON r.siswa_id=s2.id WHERE s2.kelas_id=k.id) AS sudah_raport
            FROM kelas k WHERE k.status='Aktif' ORDER BY k.nama_kelas
        ")->fetchAll();
    } catch (Exception $e) {}

} catch (Exception $e) {
    $err = $e->getMessage();
}
?>

<div class="glass-card mb-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-gauge-high me-2"></i>Dashboard Kepala Sekolah</h5>
            <p class="text-secondary small mb-0">Ringkasan kondisi sekolah hari ini — <?php echo date('l, d F Y'); ?></p>
        </div>
        <a href="<?php echo $base_url; ?>modules/jurnal/verifikasi_ks.php" class="btn btn-gold">
            <i class="fa-solid fa-shield-halved me-1"></i> Panel Verifikasi Jurnal
            <?php if ($jurnal_pending > 0): ?><span class="badge ms-1" style="background:#EF4444;font-size:11px;"><?php echo $jurnal_pending; ?></span><?php endif; ?>
        </a>
    </div>

    <!-- KPI Cards -->
    <div class="row g-3 mb-4">
        <?php $kpis = [
            ['Siswa Aktif',   $total_siswa,     '#D4AF37', 'fa-users'],
            ['Guru',          $total_guru,      '#3B82F6', 'fa-chalkboard-user'],
            ['Kelas Aktif',   $total_kelas,     '#10B981', 'fa-door-open'],
            ['Karyawan',      $total_karyawan,  '#A855F7', 'fa-users-gear'],
        ];
        foreach ($kpis as $k): ?>
        <div class="col-6 col-md-3">
            <div style="background:<?php echo $k[2]; ?>15;border:1px solid <?php echo $k[2]; ?>33;border-radius:12px;padding:18px;display:flex;align-items:center;gap:14px;">
                <div style="width:44px;height:44px;border-radius:10px;background:<?php echo $k[2]; ?>22;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                    <i class="fa-solid <?php echo $k[3]; ?>" style="color:<?php echo $k[2]; ?>;font-size:18px;"></i>
                </div>
                <div>
                    <div class="fw-bold" style="font-size:26px;color:<?php echo $k[2]; ?>;"><?php echo $k[1]; ?></div>
                    <div class="text-secondary" style="font-size:11px;"><?php echo $k[0]; ?></div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Alert Jurnal Pending -->
    <?php if ($jurnal_pending > 0): ?>
    <div class="alert" style="background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.3);border-radius:10px;color:#FCA5A5;margin-bottom:24px;">
        <i class="fa-solid fa-triangle-exclamation me-2"></i>
        Ada <strong><?php echo $jurnal_pending; ?> jurnal mengajar</strong> yang menunggu verifikasi Anda.
        <a href="<?php echo $base_url; ?>modules/jurnal/verifikasi_ks.php" class="ms-2" style="color:#FCA5A5;font-weight:600;text-decoration:underline;">Verifikasi sekarang →</a>
    </div>
    <?php endif; ?>

    <!-- Charts -->
    <div class="row g-4 mb-4">
        <div class="col-md-6">
            <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:20px;">
                <h6 class="fw-bold text-white mb-3"><i class="fa-solid fa-clipboard-check me-2" style="color:#10B981;"></i>Absensi Siswa (7 Hari)</h6>
                <?php if (!empty($absensi_chart_labels)): ?>
                <canvas id="chartSiswa" height="160"></canvas>
                <?php else: ?><p class="text-secondary small text-center py-4">Belum ada data absensi siswa.</p><?php endif; ?>
            </div>
        </div>
        <div class="col-md-6">
            <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:20px;">
                <h6 class="fw-bold text-white mb-3"><i class="fa-solid fa-chalkboard-user me-2" style="color:#3B82F6;"></i>Absensi Guru (7 Hari)</h6>
                <?php if (!empty($guru_chart_labels)): ?>
                <canvas id="chartGuru" height="160"></canvas>
                <?php else: ?><p class="text-secondary small text-center py-4">Belum ada data absensi guru.</p><?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Jurnal Pending + Raport Progress -->
    <div class="row g-4">
        <div class="col-md-6">
            <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:20px;">
                <h6 class="fw-bold text-white mb-3"><i class="fa-solid fa-journal-whills me-2" style="color:#D4AF37;"></i>Jurnal Menunggu Verifikasi</h6>
                <?php if (empty($jurnal_terbaru)): ?>
                    <p class="text-secondary small text-center py-3"><i class="fa-solid fa-check-circle text-success me-1"></i>Semua jurnal sudah diverifikasi!</p>
                <?php else: ?>
                    <?php foreach ($jurnal_terbaru as $j): ?>
                    <div style="padding:10px 12px;border-radius:8px;background:rgba(255,255,255,.04);margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;">
                        <div>
                            <div style="font-size:12px;font-weight:600;color:#fff;"><?php echo htmlspecialchars($j['nama_guru']); ?></div>
                            <div style="font-size:10px;color:#64748B;"><?php echo date('d M Y', strtotime($j['tanggal'])); ?> · <?php echo htmlspecialchars($j['nama_kelas']??''); ?></div>
                        </div>
                        <a href="<?php echo $base_url; ?>modules/jurnal/verifikasi_ks.php" class="btn btn-xs btn-outline-warning" style="font-size:10px;padding:3px 10px;">Verifikasi</a>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="col-md-6">
            <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.08);border-radius:12px;padding:20px;">
                <h6 class="fw-bold text-white mb-3"><i class="fa-solid fa-file-invoice me-2" style="color:#A855F7;"></i>Progress Pengisian Raport</h6>
                <?php if (empty($raport_progress)): ?>
                    <p class="text-secondary small">Data tidak tersedia.</p>
                <?php else: ?>
                    <?php foreach ($raport_progress as $kls):
                        $pct = $kls['total_siswa'] > 0 ? round($kls['sudah_raport']/$kls['total_siswa']*100) : 0;
                        $clr = $pct >= 80 ? '#10B981' : ($pct >= 40 ? '#F59E0B' : '#EF4444');
                    ?>
                    <div style="margin-bottom:12px;">
                        <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px;">
                            <span class="text-white fw-semibold"><?php echo htmlspecialchars($kls['nama_kelas']); ?></span>
                            <span style="color:<?php echo $clr; ?>; font-weight:700;"><?php echo $kls['sudah_raport']; ?>/<?php echo $kls['total_siswa']; ?> (<?php echo $pct; ?>%)</span>
                        </div>
                        <div style="height:6px;background:rgba(255,255,255,.08);border-radius:99px;overflow:hidden;">
                            <div style="width:<?php echo $pct; ?>%;height:100%;background:<?php echo $clr; ?>;border-radius:99px;transition:width .3s;"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php if (!empty($absensi_chart_labels) || !empty($guru_chart_labels)): ?>
<script>
<?php if (!empty($absensi_chart_labels)): ?>
new Chart(document.getElementById('chartSiswa'), {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($absensi_chart_labels); ?>,
        datasets: [
            { label: 'Hadir', data: <?php echo json_encode($absensi_chart_hadir); ?>, backgroundColor: 'rgba(16,185,129,.6)', borderColor: '#10B981', borderWidth: 1, borderRadius: 4 },
            { label: 'Tidak Hadir', data: <?php echo json_encode($absensi_chart_alpha); ?>, backgroundColor: 'rgba(239,68,68,.5)', borderColor: '#EF4444', borderWidth: 1, borderRadius: 4 }
        ]
    },
    options: { responsive: true, plugins: { legend: { labels: { color: '#94A3B8', font: { size: 11 } } } }, scales: { x: { ticks: { color: '#94A3B8' }, grid: { color: 'rgba(255,255,255,.05)' } }, y: { ticks: { color: '#94A3B8' }, grid: { color: 'rgba(255,255,255,.05)' } } } }
});
<?php endif; ?>
<?php if (!empty($guru_chart_labels)): ?>
new Chart(document.getElementById('chartGuru'), {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($guru_chart_labels); ?>,
        datasets: [
            { label: 'Hadir', data: <?php echo json_encode($guru_chart_hadir); ?>, backgroundColor: 'rgba(59,130,246,.6)', borderColor: '#3B82F6', borderWidth: 1, borderRadius: 4 },
            { label: 'Tidak Hadir', data: <?php echo json_encode($guru_chart_alpha); ?>, backgroundColor: 'rgba(245,158,11,.5)', borderColor: '#F59E0B', borderWidth: 1, borderRadius: 4 }
        ]
    },
    options: { responsive: true, plugins: { legend: { labels: { color: '#94A3B8', font: { size: 11 } } } }, scales: { x: { ticks: { color: '#94A3B8' }, grid: { color: 'rgba(255,255,255,.05)' } }, y: { ticks: { color: '#94A3B8' }, grid: { color: 'rgba(255,255,255,.05)' } } } }
});
<?php endif; ?>
</script>
<?php endif; ?>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
