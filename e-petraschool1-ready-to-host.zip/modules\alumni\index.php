<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\alumni\index.php

$page_title = 'Data Alumni';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

try {
    $query = "SELECT * FROM alumni WHERE 1=1";
    $params = [];

    if ($search !== '') {
        // PDO tidak mengizinkan named placeholder yang sama lebih dari sekali,
        // gunakan parameter unik untuk setiap kolom yang dicari.
        $query .= " AND (nama_alumni LIKE :s1 OR nis LIKE :s2 OR pekerjaan LIKE :s3 OR pendidikan_lanjutan LIKE :s4)";
        $like = "%$search%";
        $params = ['s1' => $like, 's2' => $like, 's3' => $like, 's4' => $like];
    }

    $query .= " ORDER BY tahun_lulus DESC, nama_alumni ASC";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $alumni = $stmt->fetchAll();

} catch (Exception $e) {
    $alumni = [];
    echo '<div class="alert alert-danger">Gagal memuat data alumni: ' . $e->getMessage() . '</div>';
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-award me-2"></i> Penelusuran Alumni (Graduates)</h5>
            <p class="text-secondary small mb-0">Kelola dan pantau informasi karir serta studi lanjutan dari para lulusan SD Kristen Petra 1.</p>
        </div>
        
        <div class="d-flex gap-2">
            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                <a href="import_class.php" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-cloud-arrow-down me-1"></i> Tarik dari Kelas</a>
                <a href="create.php" class="btn btn-gold"><i class="fa-solid fa-plus me-1"></i> Tambah Alumni</a>
            <?php endif; ?>
            <a href="../laporan/export.php?type=alumni" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-excel me-1"></i> Ekspor Excel</a>
            <a href="../laporan/print.php?type=alumni" target="_blank" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-pdf me-1"></i> Cetak PDF</a>
        </div>
    </div>

    <!-- Search Form -->
    <form method="GET" action="index.php" class="row g-2 mb-4 no-print">
        <div class="col-12 col-md-4">
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari NIS, nama alumni, sekolah baru..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">Cari</button>
        </div>
        <?php if ($search !== ''): ?>
            <div class="col-auto">
                <a href="index.php" class="btn btn-outline-danger">Reset</a>
            </div>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIS</th>
                    <th>Nama Alumni</th>
                    <th>Tahun Lulus</th>
                    <th>Alamat Domisili</th>
                    <th>No. HP</th>
                    <th>Pekerjaan / Aktivitas</th>
                    <th>Pendidikan Lanjutan</th>
                    <?php if (has_role(['Super Admin', 'Admin'])): ?>
                        <th class="no-print">Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($alumni)): ?>
                    <?php $no = 1; foreach ($alumni as $al): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><strong class="text-white font-monospace"><?php echo htmlspecialchars($al['nis']); ?></strong></td>
                            <td class="fw-semibold text-white"><?php echo htmlspecialchars($al['nama_alumni']); ?></td>
                            <td><span class="badge badge-secondary"><?php echo intval($al['tahun_lulus']); ?></span></td>
                            <td><?php echo htmlspecialchars($al['alamat']); ?></td>
                            <td><?php echo htmlspecialchars($al['no_hp']); ?></td>
                            <td><span class="text-gold"><?php echo htmlspecialchars($al['pekerjaan']); ?></span></td>
                            <td><i class="fa-solid fa-school me-1 text-gold"></i> <?php echo htmlspecialchars($al['pendidikan_lanjutan']); ?></td>
                            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                <td class="no-print">
                                    <div class="d-flex gap-2">
                                        <a href="edit.php?id=<?php echo $al['id']; ?>" class="btn btn-xs btn-outline-warning" title="Edit"><i class="fa-solid fa-pen"></i> Edit</a>
                                        <button onclick="confirmDelete('delete.php?id=<?php echo $al['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i> Hapus</button>
                                    </div>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="<?php echo has_role(['Super Admin', 'Admin']) ? 9 : 8; ?>" class="text-center text-secondary py-4">Data alumni kosong.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
