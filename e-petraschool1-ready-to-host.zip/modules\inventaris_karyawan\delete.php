<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris_karyawan\delete.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_once dirname(dirname(__DIR__)) . '/config/csrf.php';

require_role(['Super Admin', 'Admin']);
check_csrf_request();

$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$karyawan_id = isset($_POST['karyawan_id']) ? intval($_POST['karyawan_id']) : 0;

if ($id > 0 && $karyawan_id > 0) {
    try {
        // Fetch details for logging
        $stmt_get = $pdo->prepare("
            SELECT i.nama_barang, i.kode_barang 
            FROM inventaris_karyawan ik 
            JOIN inventaris i ON ik.inventaris_id = i.id 
            WHERE ik.id = ?
        ");
        $stmt_get->execute([$id]);
        $asset = $stmt_get->fetch();
        
        $stmt_del = $pdo->prepare("DELETE FROM inventaris_karyawan WHERE id = ? AND karyawan_id = ?");
        $stmt_del->execute([$id, $karyawan_id]);
        
        if ($asset) {
            write_audit_log("Menghapus data penugasan aset " . $asset['nama_barang'] . " (" . $asset['kode_barang'] . ") dari karyawan ID: $karyawan_id.");
        }
    } catch (Exception $e) {
        error_log("Failed to delete assignment: " . $e->getMessage());
    }
}

header("Location: index.php?karyawan_id=" . $karyawan_id);
exit;
?>
