<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris\histori.php

$page_title = 'Histori Inventaris';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_inventaris_access();

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$aktivitas_filter = isset($_GET['aktivitas']) ? trim($_GET['aktivitas']) : '';
$date_start = isset($_GET['date_start']) ? trim($_GET['date_start']) : '';
$date_end = isset($_GET['date_end']) ? trim($_GET['date_end']) : '';

try {
    $query = "
        SELECT h.*, i.nama_barang, i.kode_barang 
        FROM histori_inventaris h 
        LEFT JOIN inventaris i ON h.inventaris_id = i.id 
        WHERE 1=1
    ";
    
    $params = [];
    
    if ($search !== '') {
        $query .= " AND (i.nama_barang LIKE :search OR i.kode_barang LIKE :search OR h.keterangan LIKE :search OR h.pengguna LIKE :search)";
        $params['search'] = "%$search%";
    }
    
    if ($aktivitas_filter !== '') {
        $query .= " AND h.aktivitas = :aktivitas";
        $params['aktivitas'] = $aktivitas_filter;
    }
    
    if ($date_start !== '') {
        $query .= " AND DATE(h.tanggal) >= :date_start";
        $params['date_start'] = $date_start;
    }
    
    if ($date_end !== '') {
        $query .= " AND DATE(h.tanggal) <= :date_end";
        $params['date_end'] = $date_end;
    }

    $query .= " ORDER BY h.tanggal DESC, h.id DESC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $logs = $stmt->fetchAll();
} catch (Exception $e) {
    $logs = [];
    $error = 'Database error: ' . $e->getMessage();
}

// Fetch activities for dropdown
$activities = ['Pengadaan', 'Update', 'Perawatan', 'Mutasi', 'Peminjaman', 'Pengembalian', 'Penghapusan'];
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-clock-rotate-left me-2"></i> Log Histori & Aktivitas Inventaris</h5>
            <p class="text-secondary small mb-0">Lacak riwayat lengkap transaksi pengadaan, perawatan, mutasi penempatan, peminjaman, hingga penghapusan aset.</p>
        </div>
    </div>

    <!-- Filter Form -->
    <form method="GET" action="histori.php" class="row g-2 mb-4 no-print align-items-end">
        <div class="col-12 col-md-3">
            <label for="search" class="form-label form-label-custom small text-secondary">Cari Kata Kunci</label>
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" id="search" class="form-control form-control-custom" placeholder="Cari barang, operator..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        <div class="col-12 col-md-2">
            <label for="aktivitas" class="form-label form-label-custom small text-secondary">Filter Aktivitas</label>
            <select name="aktivitas" id="aktivitas" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua Aktivitas</option>
                <?php foreach ($activities as $act): ?>
                    <option value="<?php echo $act; ?>" <?php echo $aktivitas_filter === $act ? 'selected' : ''; ?>><?php echo $act; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label for="date_start" class="form-label form-label-custom small text-secondary">Mulai Tanggal</label>
            <input type="date" name="date_start" id="date_start" class="form-control form-control-custom" value="<?php echo htmlspecialchars($date_start); ?>">
        </div>
        <div class="col-6 col-md-2">
            <label for="date_end" class="form-label form-label-custom small text-secondary">Sampai Tanggal</label>
            <input type="date" name="date_end" id="date_end" class="form-control form-control-custom" value="<?php echo htmlspecialchars($date_end); ?>">
        </div>
        <div class="col-auto d-flex gap-2">
            <button type="submit" class="btn btn-outline-custom">Filter</button>
            <?php if ($search !== '' || $aktivitas_filter !== '' || $date_start !== '' || $date_end !== ''): ?>
                <a href="histori.php" class="btn btn-outline-danger">Reset</a>
            <?php endif; ?>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>Waktu / Tanggal</th>
                    <th>Barang Aset</th>
                    <th>Aktivitas</th>
                    <th>Operator</th>
                    <th>Keterangan Detail</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($logs) > 0): ?>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td class="font-monospace small text-white" style="width: 160px;">
                                <?php echo date('d M Y H:i', strtotime($log['tanggal'])); ?>
                            </td>
                            <td style="width: 250px;">
                                <?php if ($log['nama_barang']): ?>
                                    <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                        <a href="edit.php?id=<?php echo $log['inventaris_id']; ?>" class="text-white fw-bold text-decoration-none hover-gold">
                                            <?php echo htmlspecialchars($log['nama_barang']); ?>
                                        </a>
                                    <?php else: ?>
                                        <strong class="text-white"><?php echo htmlspecialchars($log['nama_barang']); ?></strong>
                                    <?php endif; ?>
                                    <span class="text-secondary small d-block font-monospace"><?php echo htmlspecialchars($log['kode_barang']); ?></span>
                                <?php else: ?>
                                    <span class="text-secondary small">Aset telah dihapus</span>
                                <?php endif; ?>
                            </td>
                            <td style="width: 140px;">
                                <?php 
                                $act = $log['aktivitas'];
                                $badgeClass = 'bg-secondary';
                                if ($act === 'Pengadaan') $badgeClass = 'bg-success';
                                elseif ($act === 'Update') $badgeClass = 'bg-info';
                                elseif ($act === 'Perawatan') $badgeClass = 'bg-warning text-dark';
                                elseif ($act === 'Mutasi') $badgeClass = 'bg-primary';
                                elseif ($act === 'Peminjaman') $badgeClass = 'bg-orange';
                                elseif ($act === 'Pengembalian') $badgeClass = 'bg-teal';
                                elseif ($act === 'Penghapusan') $badgeClass = 'bg-danger';
                                ?>
                                <span class="badge <?php echo $badgeClass; ?>"><?php echo htmlspecialchars($act); ?></span>
                            </td>
                            <td class="fw-semibold text-white" style="width: 120px;">
                                <?php echo htmlspecialchars($log['pengguna']); ?>
                            </td>
                            <td class="small text-secondary">
                                <?php echo htmlspecialchars($log['keterangan']); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center text-secondary py-4">Belum ada catatan aktivitas/histori inventaris.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<style>
.hover-gold:hover {
    color: #D4AF37 !important;
}
.bg-orange {
    background-color: #fd7e14 !important;
    color: #fff;
}
.bg-teal {
    background-color: #20c997 !important;
    color: #fff;
}
</style>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
