<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\kelas\index.php

$page_title = 'Data Kelas';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$error = '';
$success = '';

// Handle class creation directly from this page if user is Super Admin or Admin
if ($_SERVER['REQUEST_METHOD'] === 'POST' && has_role(['Super Admin', 'Admin'])) {
    check_csrf_request();

    $action = $_POST['action'] ?? 'create_class';

    if ($action === 'quick_assign') {
        $class_id = intval($_POST['class_id'] ?? 0);
        $wali_kelas_id = $_POST['wali_kelas_id'] !== '' ? intval($_POST['wali_kelas_id']) : null;

        try {
            // Fetch class name for logging
            $class_stmt = $pdo->prepare("SELECT nama_kelas FROM kelas WHERE id = ?");
            $class_stmt->execute([$class_id]);
            $class_name = $class_stmt->fetchColumn() ?: "ID $class_id";

            $stmt = $pdo->prepare("UPDATE kelas SET wali_kelas_id = ? WHERE id = ?");
            $stmt->execute([$wali_kelas_id, $class_id]);

            // Fetch teacher name for logging
            $teacher_name = 'Belum Ditentukan';
            if ($wali_kelas_id) {
                $teacher_stmt = $pdo->prepare("SELECT nama_guru FROM guru WHERE id = ?");
                $teacher_stmt->execute([$wali_kelas_id]);
                $teacher_name = $teacher_stmt->fetchColumn() ?: "ID $wali_kelas_id";
            }

            write_audit_log("Mengatur Guru Kelas untuk $class_name: $teacher_name.");

            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire('Berhasil', 'Guru kelas berhasil diperbarui!', 'success').then(() => {
                        window.location.href = 'index.php';
                    });
                });
            </script>";
            exit;
        } catch (Exception $e) {
            $error = 'Gagal menyimpan data: ' . $e->getMessage();
        }
    } else {
        $kode_kelas = strtoupper(trim($_POST['kode_kelas'] ?? ''));
        $nama_kelas = trim($_POST['nama_kelas'] ?? '');
        $wali_kelas_id = $_POST['wali_kelas_id'] !== '' ? intval($_POST['wali_kelas_id']) : null;
        $lokasi_ruangan = trim($_POST['lokasi_ruangan'] ?? '');
        $tingkat = $_POST['tingkat'] ?? '1';
        $kapasitas = isset($_POST['kapasitas']) ? intval($_POST['kapasitas']) : 40;
        $status = $_POST['status'] ?? 'Aktif';

        if (empty($kode_kelas) || empty($nama_kelas) || empty($lokasi_ruangan)) {
            $error = 'Semua field wajib diisi!';
        } else {
            try {
                // Check if code already exists
                $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM kelas WHERE kode_kelas = ?");
                $check_stmt->execute([$kode_kelas]);
                if ($check_stmt->fetchColumn() > 0) {
                    $error = "Kode kelas '$kode_kelas' sudah digunakan!";
                } else {
                    // Insert new class
                    $stmt = $pdo->prepare("INSERT INTO kelas (kode_kelas, nama_kelas, wali_kelas_id, lokasi_ruangan, tingkat, kapasitas, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$kode_kelas, $nama_kelas, $wali_kelas_id, $lokasi_ruangan, $tingkat, $kapasitas, $status]);
                    
                    write_audit_log("Menambahkan kelas baru: $nama_kelas (Kode: $kode_kelas, Tingkat: $tingkat, Kapasitas: $kapasitas, Status: $status).");
                    
                    echo "<script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire('Berhasil', 'Data kelas berhasil ditambahkan!', 'success').then(() => {
                                window.location.href = 'index.php';
                            });
                        });
                    </script>";
                    exit;
                }
            } catch (Exception $e) {
                $error = 'Gagal menyimpan data: ' . $e->getMessage();
            }
        }
    }
}

// Fetch all teachers for Wali Kelas dropdown
try {
    $teachers_stmt = $pdo->query("SELECT id, nip, nama_guru FROM guru ORDER BY nama_guru ASC");
    $teachers = $teachers_stmt->fetchAll();
} catch (Exception $e) {
    $teachers = [];
}

try {
    // Select classes, joining with guru to get Wali Kelas, and subquery for count of students
    $query = "SELECT k.*, g.nama_guru, 
              (SELECT COUNT(*) FROM siswa s WHERE s.kelas_id = k.id AND s.status_siswa = 'Aktif') as total_siswa_aktif 
              FROM kelas k 
              LEFT JOIN guru g ON k.wali_kelas_id = g.id";
    
    if ($search !== '') {
        $query .= " WHERE k.nama_kelas LIKE :search OR k.kode_kelas LIKE :search OR k.lokasi_ruangan LIKE :search OR g.nama_guru LIKE :search";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['search' => "%$search%"]);
    } else {
        $stmt = $pdo->query($query);
    }
    
    $classes = $stmt->fetchAll();
} catch (Exception $e) {
    echo '<div class="alert alert-danger">Gagal memuat data kelas: ' . $e->getMessage() . '</div>';
}
?>

<div class="row g-4">
    <?php if (has_role(['Super Admin', 'Admin'])): ?>
        <!-- Col-lg-4: Input Form Kelas -->
        <div class="col-lg-4 no-print">
            <div class="glass-card">
                <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-plus me-2"></i> Input Kelas Baru</h5>
                
                <?php if ($error !== ''): ?>
                    <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
                        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="index.php">
                    <?php csrf_input(); ?>

                    <div class="mb-3">
                        <label for="kode_kelas" class="form-label form-label-custom">Kode Kelas</label>
                        <input type="text" name="kode_kelas" id="kode_kelas" class="form-control form-control-custom" placeholder="Contoh: K1A" required>
                    </div>

                    <div class="mb-3">
                        <label for="nama_kelas" class="form-label form-label-custom">Nama Kelas</label>
                        <input type="text" name="nama_kelas" id="nama_kelas" class="form-control form-control-custom" placeholder="Contoh: Kelas 1A" required>
                    </div>

                    <div class="mb-3">
                        <label for="tingkat" class="form-label form-label-custom">Tingkat</label>
                        <select name="tingkat" id="tingkat" class="form-select form-control-custom bg-dark-select text-white" required>
                            <option value="1">Kelas 1</option>
                            <option value="2">Kelas 2</option>
                            <option value="3">Kelas 3</option>
                            <option value="4">Kelas 4</option>
                            <option value="5">Kelas 5</option>
                            <option value="6">Kelas 6</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="wali_kelas_id" class="form-label form-label-custom">Guru Kelas / Wali Kelas</label>
                        <select name="wali_kelas_id" id="wali_kelas_id" class="form-select form-control-custom bg-dark-select text-white">
                            <option value="">Pilih Guru Kelas / Wali Kelas (Opsional)...</option>
                            <?php foreach ($teachers as $teacher): ?>
                                <option value="<?php echo $teacher['id']; ?>"><?php echo htmlspecialchars($teacher['nama_guru']) . ' (' . htmlspecialchars($teacher['nip']) . ')'; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="kapasitas" class="form-label form-label-custom">Kapasitas</label>
                        <input type="number" name="kapasitas" id="kapasitas" class="form-control form-control-custom" placeholder="Contoh: 40" value="40" required>
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label form-label-custom">Status</label>
                        <select name="status" id="status" class="form-select form-control-custom bg-dark-select text-white" required>
                            <option value="Aktif">Aktif</option>
                            <option value="Nonaktif">Nonaktif</option>
                        </select>
                    </div>

                    <div class="mb-4">
                        <label for="lokasi_ruangan" class="form-label form-label-custom">Lokasi Ruangan</label>
                        <input type="text" name="lokasi_ruangan" id="lokasi_ruangan" class="form-control form-control-custom" placeholder="Contoh: Gedung A Lantai 1 R.101" required>
                    </div>

                    <button type="submit" class="btn btn-gold w-100">Simpan Kelas <i class="fa-solid fa-check ms-1"></i></button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <!-- Col-lg-8: Class List Table -->
    <div class="<?php echo has_role(['Super Admin', 'Admin']) ? 'col-lg-8' : 'col-12'; ?>">
        <div class="glass-card">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
                <div>
                    <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-school-flag me-2"></i> Daftar Rombongan Belajar / Kelas</h5>
                    <p class="text-secondary small mb-0">Kelola informasi kelas, lokasi ruangan, dan guru kelas / wali kelas SD Kristen Petra 1.</p>
                </div>
            </div>

            <!-- Search Form -->
            <form method="GET" action="index.php" class="row g-2 mb-4 no-print">
                <div class="col-12 col-md-6">
                    <div class="search-input-container">
                        <i class="fa-solid fa-magnifying-glass"></i>
                        <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari kode, nama kelas, guru..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-outline-custom">Cari</button>
                </div>
                <?php if ($search !== ''): ?>
                    <div class="col-auto">
                        <a href="index.php" class="btn btn-outline-danger">Reset</a>
                    </div>
                <?php endif; ?>
            </form>

            <div class="table-responsive">
                <table class="table table-custom">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Kelas</th>
                            <th>Nama Kelas</th>
                            <th>Tingkat</th>
                            <th>Guru Kelas / Wali Kelas</th>
                            <th>Kapasitas Terisi</th>
                            <th>Lokasi Ruangan</th>
                            <th>Status</th>
                            <th class="no-print">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($classes) > 0): ?>
                            <?php $no = 1; foreach ($classes as $class): ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><span class="badge badge-secondary"><?php echo htmlspecialchars($class['kode_kelas']); ?></span></td>
                                    <td class="fw-bold text-white"><?php echo htmlspecialchars($class['nama_kelas']); ?></td>
                                    <td class="text-white">Kelas <?php echo htmlspecialchars($class['tingkat']); ?></td>
                                    <td>
                                        <?php if ($class['nama_guru']): ?>
                                            <span class="text-white"><?php echo htmlspecialchars($class['nama_guru']); ?></span>
                                            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                                <button onclick="openAssignTeacherModal(<?php echo $class['id']; ?>, '<?php echo htmlspecialchars($class['nama_kelas'], ENT_QUOTES); ?>', '<?php echo $class['wali_kelas_id']; ?>')" class="btn btn-link text-warning p-0 ms-2" title="Ganti Guru Kelas" style="text-decoration: none;">
                                                    <i class="fa-solid fa-user-pen"></i>
                                                </button>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-secondary small">Belum Ditentukan</span>
                                            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                                <button onclick="openAssignTeacherModal(<?php echo $class['id']; ?>, '<?php echo htmlspecialchars($class['nama_kelas'], ENT_QUOTES); ?>', '')" class="btn btn-xs btn-outline-gold ms-2" title="Pilih Guru Kelas">
                                                    <i class="fa-solid fa-plus-circle me-1"></i> Pilih Guru
                                                </button>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $class['total_siswa_aktif'] >= $class['kapasitas'] ? 'badge-danger' : 'badge-success'; ?>">
                                            <?php echo $class['total_siswa_aktif']; ?> / <?php echo $class['kapasitas']; ?> Siswa
                                        </span>
                                    </td>
                                    <td><i class="fa-solid fa-location-dot me-1 text-gold"></i> <?php echo htmlspecialchars($class['lokasi_ruangan']); ?></td>
                                    <td>
                                        <span class="badge <?php echo $class['status'] === 'Aktif' ? 'badge-success' : 'badge-danger'; ?>">
                                            <?php echo htmlspecialchars($class['status']); ?>
                                        </span>
                                    </td>
                                    <td class="no-print">
                                        <div class="d-flex gap-2">
                                            <a href="detail.php?id=<?php echo $class['id']; ?>" class="btn btn-xs btn-outline-info" title="Detail"><i class="fa-solid fa-eye"></i> Detail</a>
                                            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                                <a href="edit.php?id=<?php echo $class['id']; ?>" class="btn btn-xs btn-outline-warning" title="Edit"><i class="fa-solid fa-pen"></i> Edit</a>
                                                <button onclick="confirmDelete('delete.php?id=<?php echo $class['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i> Hapus</button>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="<?php echo has_role(['Super Admin', 'Admin']) ? 7 : 6; ?>" class="text-center text-secondary py-4">Data kelas tidak ditemukan.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Quick Assign Teacher -->
<div class="modal fade" id="quickAssignModal" tabindex="-1" aria-labelledby="quickAssignModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark-select text-white border-gold-subtle" style="background-color: #0f172a; border: 1px solid rgba(212, 175, 55, 0.2);">
            <div class="modal-header border-bottom-gold" style="border-bottom: 1px solid rgba(212, 175, 55, 0.2);">
                <h5 class="modal-title text-gold" id="quickAssignModalLabel"><i class="fa-solid fa-user-tie me-2"></i> Atur Guru Kelas</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="index.php">
                <?php csrf_input(); ?>
                <input type="hidden" name="action" value="quick_assign">
                <input type="hidden" name="class_id" id="modal_class_id" value="">
                
                <div class="modal-body">
                    <p class="small text-secondary mb-3">Pilih guru dari data guru yang ada untuk ditugaskan sebagai Guru Kelas pada kelas ini.</p>
                    
                    <div class="mb-3">
                        <label for="modal_kelas_name" class="form-label form-label-custom">Nama Kelas</label>
                        <input type="text" id="modal_kelas_name" class="form-control form-control-custom" readonly>
                    </div>

                    <div class="mb-3">
                        <label for="modal_wali_kelas_id" class="form-label form-label-custom">Guru Kelas / Wali Kelas</label>
                        <select name="wali_kelas_id" id="modal_wali_kelas_id" class="form-select form-control-custom bg-dark-select text-white">
                            <option value="">Pilih Guru Kelas (Opsional)...</option>
                            <?php foreach ($teachers as $teacher): ?>
                                <option value="<?php echo $teacher['id']; ?>"><?php echo htmlspecialchars($teacher['nama_guru']) . ' (' . htmlspecialchars($teacher['nip']) . ')'; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-top-gold" style="border-top: 1px solid rgba(212, 175, 55, 0.2);">
                    <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-gold">Simpan Perubahan <i class="fa-solid fa-check ms-1"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openAssignTeacherModal(classId, className, currentTeacherId) {
    // Set hidden fields and readonly input
    document.getElementById('modal_class_id').value = classId;
    document.getElementById('modal_kelas_name').value = className;

    // Pre-select the current teacher in the dropdown
    var selectEl = document.getElementById('modal_wali_kelas_id');
    var teacherIdStr = String(currentTeacherId);
    selectEl.value = teacherIdStr;
    // Fallback: loop through options to find matching value
    if (selectEl.value !== teacherIdStr) {
        for (var i = 0; i < selectEl.options.length; i++) {
            if (selectEl.options[i].value === teacherIdStr) {
                selectEl.selectedIndex = i;
                break;
            }
        }
    }

    // Dispose existing modal instance if any, then open fresh
    var modalEl = document.getElementById('quickAssignModal');
    var existingModal = bootstrap.Modal.getInstance(modalEl);
    if (existingModal) {
        existingModal.dispose();
    }
    var myModal = new bootstrap.Modal(modalEl);
    myModal.show();
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
