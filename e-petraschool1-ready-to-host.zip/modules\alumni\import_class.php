<?php
// c:\xampp\htdocs\e-petraschool1\modules\alumni\import_class.php

$page_title = 'Tarik Alumni dari Kelas';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';
$success = '';

// Get all classes
try {
    $classes_stmt = $pdo->query("SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas ASC");
    $classes = $classes_stmt->fetchAll();
} catch (Exception $e) {
    $error = 'Gagal memuat daftar kelas: ' . $e->getMessage();
    $classes = [];
}

// Select active class
$filter_class_id = isset($_GET['kelas_id']) ? intval($_GET['kelas_id']) : 0;
// If no class selected but classes exist, default to the first class VI (e.g. Kelas VI A or VI B) or just the first class
if ($filter_class_id === 0 && !empty($classes)) {
    // Try to find Kelas VI A or similar
    foreach ($classes as $cl) {
        if (stripos($cl['nama_kelas'], 'VI') !== false || stripos($cl['nama_kelas'], '6') !== false) {
            $filter_class_id = $cl['id'];
            break;
        }
    }
    // Fallback to the first class in the list
    if ($filter_class_id === 0) {
        $filter_class_id = $classes[0]['id'];
    }
}

// Load students in the selected class
$students = [];
if ($filter_class_id > 0) {
    try {
        $student_stmt = $pdo->prepare("
            SELECT id, nis, nama_lengkap, alamat, no_hp_ortu 
            FROM siswa 
            WHERE kelas_id = ? AND status_siswa = 'Aktif'
            ORDER BY nama_lengkap ASC
        ");
        $student_stmt->execute([$filter_class_id]);
        $students = $student_stmt->fetchAll();
    } catch (Exception $e) {
        $error = 'Gagal memuat data siswa: ' . $e->getMessage();
    }
}

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'import_alumni') {
    check_csrf_request();

    $post_class_id = intval($_POST['kelas_id'] ?? 0);
    $tahun_lulus = intval($_POST['tahun_lulus'] ?? date('Y'));
    $pekerjaan = trim($_POST['pekerjaan'] ?? 'Siswa SMP');
    $siswa_ids = $_POST['siswa_ids'] ?? [];

    if ($post_class_id <= 0) {
        $error = 'Kelas asal tidak valid!';
    } elseif (empty($siswa_ids)) {
        $error = 'Harap pilih minimal satu siswa untuk ditarik datanya!';
    } elseif ($tahun_lulus <= 0) {
        $error = 'Tahun lulus tidak valid!';
    } else {
        try {
            $pdo->beginTransaction();

            $insert_alumni = $pdo->prepare("
                INSERT INTO alumni (nis, nama_alumni, tahun_lulus, alamat, no_hp, pekerjaan, pendidikan_lanjutan)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                    nama_alumni = VALUES(nama_alumni),
                    tahun_lulus = VALUES(tahun_lulus),
                    alamat = VALUES(alamat),
                    no_hp = VALUES(no_hp),
                    pekerjaan = VALUES(pekerjaan),
                    pendidikan_lanjutan = VALUES(pendidikan_lanjutan)
            ");

            $update_siswa = $pdo->prepare("
                UPDATE siswa 
                SET status_siswa = 'Alumni', kelas_id = NULL 
                WHERE id = ? AND kelas_id = ?
            ");

            $count = 0;
            foreach ($siswa_ids as $siswa_id) {
                $siswa_id = intval($siswa_id);
                
                // Fetch student details to verify class and get nis/name
                $check_stmt = $pdo->prepare("SELECT nis, nama_lengkap FROM siswa WHERE id = ? AND kelas_id = ? AND status_siswa = 'Aktif'");
                $check_stmt->execute([$siswa_id, $post_class_id]);
                $siswa = $check_stmt->fetch();

                if ($siswa) {
                    $nis = $siswa['nis'];
                    $nama_alumni = $siswa['nama_lengkap'];
                    
                    // Retrieve individual overrides from POST
                    $no_hp = trim($_POST['no_hp'][$siswa_id] ?? '');
                    $alamat = trim($_POST['alamat'][$siswa_id] ?? '');
                    $pendidikan_lanjutan = trim($_POST['pendidikan_lanjutan'][$siswa_id] ?? '');

                    // Fallbacks for empty values
                    if ($no_hp === '') {
                        $no_hp = '-';
                    }
                    if ($alamat === '') {
                        $alamat = '-';
                    }
                    if ($pendidikan_lanjutan === '') {
                        $pendidikan_lanjutan = '-';
                    }

                    // Insert to alumni
                    $insert_alumni->execute([
                        $nis,
                        $nama_alumni,
                        $tahun_lulus,
                        $alamat,
                        $no_hp,
                        $pekerjaan,
                        $pendidikan_lanjutan
                    ]);

                    // Update student status and class_id to NULL
                    $update_siswa->execute([$siswa_id, $post_class_id]);
                    $count++;
                }
            }

            // Sync kelas.jumlah_siswa count
            $update_class_count = $pdo->prepare("
                UPDATE kelas 
                SET jumlah_siswa = (SELECT COUNT(*) FROM siswa WHERE kelas_id = ? AND status_siswa = 'Aktif')
                WHERE id = ?
            ");
            $update_class_count->execute([$post_class_id, $post_class_id]);

            $pdo->commit();

            // Log activity
            $class_name = $pdo->query("SELECT nama_kelas FROM kelas WHERE id = $post_class_id")->fetchColumn() ?: "ID $post_class_id";
            write_audit_log("Menarik data $count siswa dari $class_name sebagai alumni angkatan tahun $tahun_lulus.");

            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire('Berhasil', '$count siswa berhasil ditarik menjadi data alumni!', 'success').then(() => {
                        window.location.href = 'index.php';
                    });
                });
            </script>";
            exit;

        } catch (Exception $e) {
            $pdo->rollBack();
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>

<div class="glass-card mb-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-cloud-arrow-down me-2"></i> Tarik Data Alumni dari Kelas</h5>
            <p class="text-secondary small mb-0">Impor siswa aktif dari kelas tertentu secara massal menjadi alumni, memperbarui status mereka secara otomatis.</p>
        </div>
        <div>
            <a href="index.php" class="btn btn-outline-custom"><i class="fa-solid fa-arrow-left me-1"></i> Kembali</a>
        </div>
    </div>
</div>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
    </div>
<?php endif; ?>

<!-- Filter & Configuration Panel -->
<div class="row g-4 mb-4">
    <!-- Filter Kelas -->
    <div class="col-md-4">
        <div class="glass-card h-100" style="background: rgba(18, 28, 54, 0.2);">
            <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-filter me-1"></i> 1. Pilih Kelas Asal</h6>
            <form method="GET" id="class-filter-form">
                <div class="mb-0">
                    <label class="form-label form-label-custom">Kelas Asal Siswa</label>
                    <select name="kelas_id" class="form-select form-control-custom bg-dark-select text-white" onchange="document.getElementById('class-filter-form').submit()">
                        <option value="">-- Pilih Kelas --</option>
                        <?php foreach ($classes as $cl): ?>
                            <option value="<?php echo $cl['id']; ?>" <?php echo $filter_class_id == $cl['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cl['nama_kelas']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </form>
        </div>
    </div>

    <!-- Parameter Kelulusan -->
    <div class="col-md-8">
        <div class="glass-card h-100" style="background: rgba(18, 28, 54, 0.2);">
            <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-gear me-1"></i> 2. Pengaturan Default Kelulusan</h6>
            <div class="row g-3">
                <div class="col-sm-4">
                    <label class="form-label form-label-custom">Tahun Lulus</label>
                    <input type="number" id="global_tahun_lulus" class="form-control form-control-custom" value="<?php echo date('Y'); ?>">
                </div>
                <div class="col-sm-8">
                    <label class="form-label form-label-custom">Pekerjaan / Status Default</label>
                    <input type="text" id="global_pekerjaan" class="form-control form-control-custom" value="Siswa SMP">
                </div>
                <div class="col-12">
                    <label class="form-label form-label-custom">Pendidikan Lanjutan Default</label>
                    <div class="input-group">
                        <input type="text" id="global_pendidikan_lanjutan" class="form-control form-control-custom" placeholder="Contoh: SMP Kristen Petra 1 Surabaya" value="SMP Kristen Petra 1 Surabaya">
                        <button class="btn btn-outline-custom text-gold" type="button" id="apply-global-btn"><i class="fa-solid fa-wand-magic-sparkles me-1"></i> Terapkan ke Semua</button>
                    </div>
                    <span class="text-secondary small d-block mt-1">Mengisi otomatis kolom "Pendidikan Lanjutan" untuk semua siswa di tabel bawah.</span>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Form Eksekusi Tarik Data -->
<form method="POST" id="import-form">
    <?php csrf_input(); ?>
    <input type="hidden" name="action" value="import_alumni">
    <input type="hidden" name="kelas_id" value="<?php echo $filter_class_id; ?>">
    <input type="hidden" name="tahun_lulus" id="form_tahun_lulus" value="<?php echo date('Y'); ?>">
    <input type="hidden" name="pekerjaan" id="form_pekerjaan" value="Siswa SMP">

    <div class="glass-card mb-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="text-gold fw-bold mb-0"><i class="fa-solid fa-users me-2"></i> 3. Pilih Siswa & Sesuaikan Data Lengkap (Total: <?php echo count($students); ?>)</h6>
            <?php if (count($students) > 0): ?>
                <div>
                    <input type="checkbox" id="select-all" class="form-check-input me-1" checked> 
                    <label for="select-all" class="small text-secondary cursor-pointer">Pilih Semua</label>
                </div>
            <?php endif; ?>
        </div>

        <div class="table-responsive">
            <table class="table table-custom align-middle">
                <thead>
                    <tr>
                        <th style="width: 50px;">Pilih</th>
                        <th style="width: 180px;">Identitas Siswa</th>
                        <th>No. HP Alumni</th>
                        <th>Alamat Domisili</th>
                        <th>Pendidikan Lanjutan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($students) > 0): ?>
                        <?php foreach ($students as $std): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" name="siswa_ids[]" value="<?php echo $std['id']; ?>" class="form-check-input siswa-chk" checked>
                                </td>
                                <td>
                                    <strong class="text-white d-block"><?php echo htmlspecialchars($std['nama_lengkap']); ?></strong>
                                    <span class="text-secondary small font-monospace">NIS: <?php echo htmlspecialchars($std['nis']); ?></span>
                                </td>
                                <td>
                                    <input type="text" name="no_hp[<?php echo $std['id']; ?>]" class="form-control form-control-custom py-1 px-2 text-white font-monospace" style="font-size: 13px;" value="<?php echo htmlspecialchars($std['no_hp_ortu'] !== '' ? $std['no_hp_ortu'] : '081234567890'); ?>" required>
                                </td>
                                <td>
                                    <input type="text" name="alamat[<?php echo $std['id']; ?>]" class="form-control form-control-custom py-1 px-2 text-white" style="font-size: 13px;" value="<?php echo htmlspecialchars($std['alamat']); ?>">
                                </td>
                                <td>
                                    <input type="text" name="pendidikan_lanjutan[<?php echo $std['id']; ?>]" class="form-control form-control-custom row-pend-lanjutan py-1 px-2 text-white" style="font-size: 13px;" value="SMP Kristen Petra 1 Surabaya" required>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center text-secondary py-5">
                                <i class="fa-solid fa-folder-open d-block fs-3 mb-2 text-secondary"></i>
                                Tidak ada data siswa aktif pada kelas terpilih.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if (count($students) > 0): ?>
            <div class="mt-4 text-end">
                <button type="submit" class="btn btn-gold py-2 px-4 fw-bold" onclick="return confirmImport(event)">
                    Tarik Data Alumni <i class="fa-solid fa-circle-chevron-right ms-1"></i>
                </button>
            </div>
        <?php endif; ?>
    </div>
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const selectAllCheckbox = document.getElementById('select-all');
    const studentCheckboxes = document.querySelectorAll('.siswa-chk');
    const globalPendidikanLanjutan = document.getElementById('global_pendidikan_lanjutan');
    const applyGlobalBtn = document.getElementById('apply-global-btn');
    const rowPendidikanLanjutan = document.querySelectorAll('.row-pend-lanjutan');

    // Select all / Deselect all
    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function() {
            studentCheckboxes.forEach(chk => {
                chk.checked = this.checked;
            });
        });
    }

    // Individual checkbox check/uncheck updates header checkbox state
    studentCheckboxes.forEach(chk => {
        chk.addEventListener('change', function() {
            if (!this.checked) {
                if (selectAllCheckbox) selectAllCheckbox.checked = false;
            } else {
                const allChecked = Array.from(studentCheckboxes).every(c => c.checked);
                if (selectAllCheckbox) selectAllCheckbox.checked = allChecked;
            }
        });
    });

    // Apply global pendidikan lanjutan value to all row fields
    if (applyGlobalBtn) {
        applyGlobalBtn.addEventListener('click', function() {
            const globalValue = globalPendidikanLanjutan.value.trim();
            if (globalValue === '') {
                Swal.fire('Perhatian', 'Harap isi terlebih dahulu nilai default pendidikan lanjutan!', 'warning');
                return;
            }
            rowPendidikanLanjutan.forEach(input => {
                input.value = globalValue;
            });
            
            // Micro-animation feedback
            Swal.fire({
                icon: 'success',
                title: 'Tersinkronisasi',
                text: 'Pendidikan lanjutan default berhasil diterapkan ke semua baris!',
                timer: 1500,
                showConfirmButton: false
            });
        });
    }
});

function confirmImport(event) {
    event.preventDefault();
    
    const form = document.getElementById('import-form');
    if (!form.checkValidity()) {
        form.reportValidity();
        return false;
    }
    
    // Check if any student is selected
    const selectedCount = document.querySelectorAll('.siswa-chk:checked').length;
    if (selectedCount === 0) {
        Swal.fire('Error', 'Harap pilih minimal satu siswa untuk diluluskan!', 'error');
        return false;
    }

    // Sync global inputs to hidden fields in form
    const globalTahunLulus = document.getElementById('global_tahun_lulus').value;
    const globalPekerjaan = document.getElementById('global_pekerjaan').value;

    document.getElementById('form_tahun_lulus').value = globalTahunLulus;
    document.getElementById('form_pekerjaan').value = globalPekerjaan;

    Swal.fire({
        title: 'Konfirmasi Penarikan Data',
        text: `Apakah Anda yakin ingin memproses kelulusan ${selectedCount} siswa terpilih menjadi Alumni? Data ini akan masuk ke database Alumni dan status siswa akan diubah menjadi Alumni secara permanen.`,
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#D4AF37',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, Luluskan & Tarik Data!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('import-form').submit();
        }
    });
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
