<?php
// c:\xampp\htdocs\e-petraschool1\modules\karyawan\import.php

$page_title = 'Import Data Karyawan via CSV';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin','Admin']);

$error=''; $success=''; $preview=[]; $errors_detail=[];

if (isset($_GET['template'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="template_import_karyawan.csv"');
    $out = fopen('php://output','w');
    fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));
    fputcsv($out,['nip','nama','jenis_kelamin','tempat_lahir','tanggal_lahir','agama','no_hp','email','alamat','pendidikan_terakhir','jabatan','unit_kerja','status_kepegawaian']);
    fputcsv($out,['198801012012011001','Sari Dewi','Perempuan','Malang','1988-01-01','Kristen','081234567890','sari@sd.sch.id','Jl. Contoh No.2','D3','Staf TU','Tata Usaha','Tetap']);
    fclose($out); exit;
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
    check_csrf_request();
    $action = $_POST['action']??'preview';
    if (!isset($_FILES['csv_file'])||$_FILES['csv_file']['error']!==UPLOAD_ERR_OK) { $error='File CSV wajib diunggah!'; }
    else {
        $ext = strtolower(pathinfo($_FILES['csv_file']['name'],PATHINFO_EXTENSION));
        if ($ext!=='csv') { $error='Hanya file .csv yang diterima!'; }
        else {
            $handle = fopen($_FILES['csv_file']['tmp_name'],'r');
            $header = fgetcsv($handle);
            if ($header) $header[0]=ltrim($header[0],"\xEF\xBB\xBF");
            $missing = array_diff(['nip','nama','jenis_kelamin'],$header);
            if (!empty($missing)) { $error='Kolom wajib tidak ada: '.implode(', ',$missing); }
            else {
                $rows=[]; $rn=1;
                while (($row=fgetcsv($handle))!==false) {
                    $rn++;
                    $data=array_combine($header,array_pad($row,count($header),''));
                    if (empty(trim($data['nama']??''))) { $errors_detail[]="Baris $rn: nama kosong, dilewati."; continue; }
                    $rows[]=$data;
                }
                fclose($handle);
                if ($action==='preview') { $preview=$rows; }
                elseif ($action==='import') {
                    $saved=0; $skip=0;
                    $ins=$pdo->prepare("INSERT INTO karyawan (nip,nama,jenis_kelamin,tempat_lahir,tanggal_lahir,agama,no_hp,email,alamat,pendidikan_terakhir,jabatan,unit_kerja,status_kepegawaian)
                                         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                                         ON DUPLICATE KEY UPDATE nama=VALUES(nama),no_hp=VALUES(no_hp)");
                    foreach ($rows as $d) {
                        try {
                            $tgl=!empty($d['tanggal_lahir'])?date('Y-m-d',strtotime($d['tanggal_lahir'])):null;
                            $ins->execute([trim($d['nip']??''),trim($d['nama']),trim($d['jenis_kelamin']??'Perempuan'),trim($d['tempat_lahir']??''),$tgl,trim($d['agama']??''),trim($d['no_hp']??''),trim($d['email']??''),trim($d['alamat']??''),trim($d['pendidikan_terakhir']??''),trim($d['jabatan']??''),trim($d['unit_kerja']??''),trim($d['status_kepegawaian']??'')]);
                            $saved++;
                        } catch (Exception $e) { $errors_detail[]="Error {$d['nama']}: ".$e->getMessage(); $skip++; }
                    }
                    write_audit_log("Import karyawan via CSV: $saved berhasil, $skip gagal.");
                    $success="Import selesai! $saved karyawan berhasil".($skip?" ($skip gagal)":'').".";
                }
            }
        }
    }
}
?>
<div class="glass-card" style="max-width:900px;margin:0 auto;">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-file-csv me-2"></i>Import Data Karyawan via CSV</h5>
            <p class="text-secondary small mb-0">Upload file CSV untuk menambah data karyawan secara massal.</p>
        </div>
        <div class="d-flex gap-2">
            <a href="?template=1" class="btn btn-outline-custom"><i class="fa-solid fa-download me-1"></i> Unduh Template</a>
            <a href="index.php" class="btn btn-outline-custom"><i class="fa-solid fa-arrow-left me-1"></i> Kembali</a>
        </div>
    </div>
    <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><i class="fa-solid fa-check-circle me-2"></i><?php echo htmlspecialchars($success); ?></div><?php endif; ?>
    <?php if (!empty($errors_detail)): ?><div class="alert alert-warning"><strong>Peringatan:</strong><ul class="mb-0 mt-1" style="font-size:12px;"><?php foreach ($errors_detail as $ed): ?><li><?php echo htmlspecialchars($ed); ?></li><?php endforeach; ?></ul></div><?php endif; ?>
    <div style="background:rgba(59,130,246,.08);border:1px solid rgba(59,130,246,.2);border-radius:10px;padding:16px;margin-bottom:24px;">
        <h6 class="fw-bold" style="color:#3B82F6;font-size:13px;"><i class="fa-solid fa-circle-info me-2"></i>Petunjuk</h6>
        <ol style="font-size:12px;color:#94A3B8;margin:8px 0 0;padding-left:20px;">
            <li>Unduh template, isi data, simpan sebagai CSV</li>
            <li>Kolom <strong class="text-white">nip, nama, jenis_kelamin</strong> wajib diisi</li>
            <li>Format tanggal: <strong class="text-white">YYYY-MM-DD</strong></li>
            <li>NIP duplikat akan diupdate, bukan ditolak</li>
        </ol>
    </div>
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
        <div class="row g-3 mb-4 align-items-end">
            <div class="col-md-6"><label class="form-label form-label-custom">File CSV *</label><input type="file" name="csv_file" class="form-control form-control-custom" accept=".csv" required></div>
            <div class="col-auto"><button type="submit" name="action" value="preview" class="btn btn-outline-custom"><i class="fa-solid fa-eye me-1"></i> Preview</button></div>
        </div>
        <?php if (!empty($preview)): ?>
        <div class="table-responsive mb-3">
            <p class="fw-bold text-gold mb-2">Preview <?php echo count($preview); ?> baris:</p>
            <table class="table table-custom" style="font-size:11px;">
                <thead><tr><th>#</th><th>NIP</th><th>Nama</th><th>JK</th><th>Jabatan</th><th>Unit Kerja</th></tr></thead>
                <tbody><?php $n=1; foreach ($preview as $p): ?><tr><td><?php echo $n++; ?></td><td class="font-monospace"><?php echo htmlspecialchars($p['nip']??''); ?></td><td><?php echo htmlspecialchars($p['nama']); ?></td><td><?php echo htmlspecialchars($p['jenis_kelamin']??''); ?></td><td><?php echo htmlspecialchars($p['jabatan']??''); ?></td><td><?php echo htmlspecialchars($p['unit_kerja']??''); ?></td></tr><?php endforeach; ?></tbody>
            </table>
        </div>
        <button type="submit" name="action" value="import" class="btn btn-gold"><i class="fa-solid fa-file-import me-1"></i> Import <?php echo count($preview); ?> Karyawan</button>
        <?php endif; ?>
    </form>
</div>
<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
