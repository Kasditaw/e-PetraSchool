<?php
// c:\xampp\htdocs\e-petraschool1\modules\raport\save.php

header('Content-Type: application/json');

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_once dirname(dirname(__DIR__)) . '/config/csrf.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Metode HTTP tidak diizinkan.']);
    exit;
}

try {
    // Parse JSON request
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) {
        throw new Exception("Data tidak valid atau kosong.");
    }

    // Validate CSRF
    $csrf_token = $input['csrf_token'] ?? '';
    if (!validate_csrf_token($csrf_token)) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'Token keamanan (CSRF) tidak valid atau telah kadaluarsa.']);
        exit;
    }

    // Validate minimal required fields
    $siswa_id = intval($input['siswa_id'] ?? 0);
    $kelas_id = intval($input['kelas_id'] ?? 0);
    $semester = trim($input['semester'] ?? '');
    $tahun_ajaran = trim($input['tahun_ajaran'] ?? '');
    
    if ($siswa_id <= 0 || $kelas_id <= 0 || empty($semester) || empty($tahun_ajaran)) {
        throw new Exception("Data identitas siswa atau periode tidak lengkap.");
    }

    $no_absen = !empty($input['no_absen']) ? intval($input['no_absen']) : null;
    $kode_siswa = !empty($input['kode_siswa']) ? trim($input['kode_siswa']) : null;
    
    // Grades & Ekskul formatted to JSON
    $academic_grades = json_encode($input['academic_grades'] ?? [], JSON_UNESCAPED_UNICODE);
    $ekstrakurikuler = json_encode($input['ekstrakurikuler'] ?? [], JSON_UNESCAPED_UNICODE);
    $slo = json_encode($input['slo'] ?? [], JSON_UNESCAPED_UNICODE);
    
    $kokurikuler_predikat = !empty($input['kokurikuler_predikat']) ? trim($input['kokurikuler_predikat']) : null;
    $kokurikuler_deskripsi = !empty($input['kokurikuler_deskripsi']) ? trim($input['kokurikuler_deskripsi']) : null;
    
    $sakit = trim($input['sakit'] ?? '0');
    $izin = trim($input['izin'] ?? '0');
    $alpa = trim($input['alpa'] ?? '0');
    
    $catatan_wali = !empty($input['catatan_wali']) ? trim($input['catatan_wali']) : null;
    $status_draft = intval($input['status_draft'] ?? 1); // 1 = Draft, 0 = Final
 
    // Check if report card entry already exists for active period
    $check_stmt = $pdo->prepare("SELECT id FROM raport_siswa WHERE siswa_id = ? AND semester = ? AND tahun_ajaran = ? LIMIT 1");
    $check_stmt->execute([$siswa_id, $semester, $tahun_ajaran]);
    $existing_id = $check_stmt->fetchColumn();
 
    if ($existing_id) {
        // Update
        $up_stmt = $pdo->prepare("
            UPDATE raport_siswa 
            SET kelas_id = ?, no_absen = ?, kode_siswa = ?, academic_grades = ?, ekstrakurikuler = ?,
                slo = ?, kokurikuler_predikat = ?, kokurikuler_deskripsi = ?, sakit = ?, izin = ?, alpa = ?,
                catatan_wali = ?, status_draft = ?
            WHERE id = ?
        ");
        $up_stmt->execute([
            $kelas_id, $no_absen, $kode_siswa, $academic_grades, $ekstrakurikuler,
            $slo, $kokurikuler_predikat, $kokurikuler_deskripsi, $sakit, $izin, $alpa,
            $catatan_wali, $status_draft, $existing_id
        ]);
        $action_msg = "memperbarui";
    } else {
        // Insert new record
        $in_stmt = $pdo->prepare("
            INSERT INTO raport_siswa (
                siswa_id, kelas_id, semester, tahun_ajaran, no_absen, kode_siswa, academic_grades, ekstrakurikuler,
                slo, kokurikuler_predikat, kokurikuler_deskripsi, sakit, izin, alpa, catatan_wali, status_draft
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $in_stmt->execute([
            $siswa_id, $kelas_id, $semester, $tahun_ajaran, $no_absen, $kode_siswa, $academic_grades, $ekstrakurikuler,
            $slo, $kokurikuler_predikat, $kokurikuler_deskripsi, $sakit, $izin, $alpa, $catatan_wali, $status_draft
        ]);
        $action_msg = "menyimpan";
    }

    // Log to Audit Log
    $status_label = $status_draft === 1 ? 'sebagai draf' : 'secara final';
    write_audit_log("Berhasil $action_msg data rapor siswa ID: $siswa_id $status_label untuk Semester: $semester TA: $tahun_ajaran.");

    echo json_encode([
        'status' => 'success',
        'message' => "Rapor berhasil disimpan " . ($status_draft === 1 ? 'sebagai draf sementara.' : 'secara final.')
    ]);

} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>
