<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris\print_qr_massal.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_inventaris_access();

$ids_str = isset($_GET['ids']) ? trim($_GET['ids']) : '';
if (empty($ids_str)) {
    die('ID barang tidak ditemukan.');
}

// Parse IDs into integer array
$ids = array_filter(array_map('intval', explode(',', $ids_str)));

if (count($ids) === 0) {
    die('ID barang tidak valid.');
}

try {
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("
        SELECT i.*, k.nama_kategori, r.nama_ruangan 
        FROM inventaris i 
        JOIN kategori_barang k ON i.kategori_id = k.id 
        LEFT JOIN ruangan r ON i.ruangan_id = r.id 
        WHERE i.id IN ($placeholders) AND i.status_aktif = 'Aktif'
    ");
    $stmt->execute($ids);
    $assets = $stmt->fetchAll();

    if (count($assets) === 0) {
        die('Data aset tidak ditemukan.');
    }

    // Log mass printing
    write_audit_log("Mencetak label QR Code massal untuk " . count($assets) . " aset.");
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Label Massal (<?php echo count($assets); ?> Aset)</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&display=swap" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
            box-sizing: border-box;
        }
        body {
            background-color: #f8fafc !important;
            color: #0f172a !important;
            margin: 0;
            padding: 20px;
            font-family: 'Outfit', sans-serif;
        }
        .print-btn-bar {
            position: fixed;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
            z-index: 1000;
        }
        .btn-print-action {
            background: #D4AF37;
            color: #000;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-family: 'Outfit', sans-serif;
            box-shadow: 0 4px 12px rgba(212, 175, 55, 0.3);
            transition: all 0.2s ease;
        }
        .btn-print-action:hover {
            background: #f3cd48;
            transform: translateY(-1px);
        }
        .btn-print-back {
            background: #ffffff;
            color: #334155;
            border: 1px solid #e2e8f0;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-family: 'Outfit', sans-serif;
            transition: all 0.2s ease;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        }
        .btn-print-back:hover {
            background: #f8fafc;
            border-color: #cbd5e1;
            transform: translateY(-1px);
        }
        
        /* Labels sheet grid container */
        .labels-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 15px;
            max-width: 1000px;
            margin: 60px auto 0 auto;
        }
        
        .barcode-card-print {
            background: #ffffff;
            border: 1px solid #cbd5e1;
            color: #0f172a;
            padding: 15px;
            border-radius: 8px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            page-break-inside: avoid;
        }
        
        .card-header {
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 4px;
            margin-bottom: 8px;
            text-align: center;
        }
        
        .card-body-content {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .qr-wrapper {
            background: #fff;
            padding: 2px;
            border: 1px solid #ddd;
            flex-shrink: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .info-wrapper {
            text-align: left;
            font-size: 11px;
            color: #000;
            line-height: 1.35;
            min-width: 0;
        }

        @media print {
            body {
                background: #ffffff !important;
                padding: 0;
            }
            .print-btn-bar {
                display: none !important;
            }
            .labels-grid {
                grid-template-columns: repeat(3, 1fr);
                gap: 8px;
                margin: 0;
            }
            .barcode-card-print {
                border: 1px dashed #000 !important;
                border-radius: 0;
                box-shadow: none !important;
            }
        }
    </style>
</head>
<body>

    <div class="print-btn-bar no-print">
        <a href="qrcode.php" class="btn-print-back"><i class="fa-solid fa-chevron-left"></i> Kembali</a>
        <button onclick="window.print()" class="btn-print-action"><i class="fa-solid fa-print"></i> Cetak Sekarang</button>
    </div>

    <div class="labels-grid">
        <?php foreach ($assets as $asset): ?>
            <div class="barcode-card-print">
                <div class="card-header">
                    <span class="fw-bold d-block" style="font-size: 10px; color: #000; letter-spacing: 0.5px;">PROPERTI SD KRISTEN PETRA 1</span>
                </div>
                <div class="card-body-content">
                    <div class="qr-wrapper">
                        <canvas class="qr-canvas" data-code="<?php echo htmlspecialchars($asset['kode_barang']); ?>"></canvas>
                    </div>
                    
                    <div class="info-wrapper">
                        <div style="font-weight: 700; font-size: 12px; color: #000; text-transform: uppercase; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"><?php echo htmlspecialchars($asset['nama_barang']); ?></div>
                        <div style="font-family: monospace; font-weight: 700; color: #d32f2f; font-size: 10px; margin-bottom: 2px;"><?php echo htmlspecialchars($asset['kode_barang']); ?></div>
                        <div style="font-size: 9px; margin-bottom: 1px;"><span style="color: #666;">Kondisi: </span><strong style="font-family: monospace; font-size: 8px; border: 1px solid #000; padding: 0px 3px;"><?php echo htmlspecialchars($asset['kondisi']); ?></strong></div>
                        <div style="font-size: 9px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"><span style="color: #666;">Lokasi: </span><strong><?php echo htmlspecialchars($asset['nama_ruangan'] ?? 'Belum Alokasi'); ?></strong></div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <!-- QRious QR Code CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const canvases = document.querySelectorAll('.qr-canvas');
            canvases.forEach(canvas => {
                const code = canvas.getAttribute('data-code');
                new QRious({
                    element: canvas,
                    value: code,
                    size: 60,
                    background: '#ffffff',
                    foreground: '#000000',
                    level: 'H'
                });
            });

            // Auto print on load if not preview
            <?php if (!isset($_GET['preview'])): ?>
                setTimeout(() => {
                    window.print();
                }, 800);
            <?php endif; ?>
        });
    </script>
</body>
</html>
