<?php
// c:\xampp\htdocs\e-petraschool1\modules\tahun_ajaran\edit.php

$page_title = 'Edit Tahun Ajaran';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';

try {
    $stmt = $pdo->prepare("SELECT * FROM tahun_ajaran WHERE id = ?");
    $stmt->execute([$id]);
    $year = $stmt->fetch();
    
    if (!$year) {
        die('<div class="alert alert-danger">Data tahun ajaran tidak ditemukan!</div>');
    }
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $tahun_ajaran = trim($_POST['tahun_ajaran'] ?? '');
    $status = $_POST['status'] ?? 'Tidak Aktif';

    if (empty($tahun_ajaran)) {
        $error = 'Tahun ajaran wajib diisi!';
    } else {
        try {
            // Check duplicate
            $chk = $pdo->prepare("SELECT COUNT(*) FROM tahun_ajaran WHERE tahun_ajaran = ? AND id != ?");
            $chk->execute([$tahun_ajaran, $id]);
            if ($chk->fetchColumn() > 0) {
                $error = "Tahun ajaran '$tahun_ajaran' sudah ada!";
            } else {
                $pdo->beginTransaction();

                if ($status === 'Aktif') {
                    // Set all others to inactive
                    $pdo->exec("UPDATE tahun_ajaran SET status = 'Tidak Aktif'");
                }

                $stmt = $pdo->prepare("UPDATE tahun_ajaran SET tahun_ajaran = ?, status = ? WHERE id = ?");
                $stmt->execute([$tahun_ajaran, $status, $id]);
                
                $pdo->commit();

                write_audit_log("Mengubah data tahun ajaran: $tahun_ajaran (Status: $status).");
                
                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Tahun ajaran berhasil diubah!', 'success').then(() => {
                            window.location.href = 'index.php';
                        });
                    });
                </script>";
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = 'Error database: ' . $e->getMessage();
        }
    }
}
?>

<div class="glass-card" style="max-width: 600px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-pen me-2"></i> Edit Tahun Ajaran</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="edit.php?id=<?php echo $id; ?>">
        <?php csrf_input(); ?>

        <div class="mb-3">
            <label for="tahun_ajaran" class="form-label form-label-custom">Tahun Ajaran</label>
            <input type="text" name="tahun_ajaran" id="tahun_ajaran" class="form-control form-control-custom" value="<?php echo htmlspecialchars($year['tahun_ajaran']); ?>" required>
        </div>

        <div class="mb-4">
            <label for="status" class="form-label form-label-custom">Status</label>
            <select name="status" id="status" class="form-select form-control-custom bg-dark-select text-white">
                <option value="Tidak Aktif" <?php echo $year['status'] === 'Tidak Aktif' ? 'selected' : ''; ?>>Tidak Aktif</option>
                <option value="Aktif" <?php echo $year['status'] === 'Aktif' ? 'selected' : ''; ?>>Aktif</option>
            </select>
        </div>

        <div class="d-flex justify-content-end gap-2">
            <a href="index.php" class="btn btn-outline-custom">Batal</a>
            <button type="submit" class="btn btn-gold">Simpan Perubahan <i class="fa-solid fa-check ms-1"></i></button>
        </div>
    </form>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
