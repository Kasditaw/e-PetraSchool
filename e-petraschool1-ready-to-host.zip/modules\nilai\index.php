<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\nilai\index.php

$page_title = 'Nilai Siswa';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$filter_kelas = isset($_GET['kelas_id']) ? $_GET['kelas_id'] : '';

try {
    // Fetch classes for filter
    $classes_stmt = $pdo->query("SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas ASC");
    $classes = $classes_stmt->fetchAll();

    // Query for grades
    $query = "SELECT n.*, s.nama_lengkap, s.nis, k.nama_kelas, g.nama_guru 
              FROM nilai n 
              JOIN siswa s ON n.siswa_id = s.id 
              JOIN guru g ON n.guru_id = g.id
              LEFT JOIN kelas k ON s.kelas_id = k.id 
              WHERE 1=1";
    $params = [];

    if ($search !== '') {
        $query .= " AND (s.nama_lengkap LIKE :search OR s.nis LIKE :search OR n.mata_pelajaran LIKE :search OR g.nama_guru LIKE :search)";
        $params['search'] = "%$search%";
    }

    if ($filter_kelas !== '') {
        $query .= " AND s.kelas_id = :kelas_id";
        $params['kelas_id'] = intval($filter_kelas);
    }

    $query .= " ORDER BY k.nama_kelas ASC, s.nama_lengkap ASC, n.mata_pelajaran ASC";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $grades = $stmt->fetchAll();

} catch (Exception $e) {
    echo '<div class="alert alert-danger">Gagal memuat ledger nilai: ' . $e->getMessage() . '</div>';
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-book-open-reader me-2"></i> Pengelolaan Nilai Akademik Siswa</h5>
            <p class="text-secondary small mb-0">Kelola ledger nilai tugas, UTS, UAS, dan predikat kelulusan siswa SD Kristen Petra 1.</p>
        </div>
        <div class="d-flex gap-2">
            <?php if (has_role(['Super Admin', 'Admin', 'Guru'])): ?>
                <a href="create.php" class="btn btn-gold"><i class="fa-solid fa-plus me-1"></i> Input Nilai</a>
            <?php endif; ?>
            <a href="../laporan/export.php?type=nilai<?php echo $filter_kelas !== '' ? '&kelas_id=' . urlencode($filter_kelas) : ''; ?>" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-excel me-1"></i> Ekspor Excel</a>
            <a href="../laporan/print.php?type=nilai<?php echo $filter_kelas !== '' ? '&kelas_id=' . urlencode($filter_kelas) : ''; ?>" target="_blank" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-pdf me-1"></i> Cetak PDF</a>
        </div>
    </div>

    <!-- Filter & Search Form -->
    <form method="GET" action="index.php" class="row g-3 mb-4 no-print align-items-end">
        <div class="col-12 col-md-4">
            <label class="form-label form-label-custom">Pencarian</label>
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari siswa, mapel, guru..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        
        <div class="col-12 col-sm-6 col-md-3">
            <label class="form-label form-label-custom">Filter Kelas</label>
            <select name="kelas_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua Kelas</option>
                <?php foreach ($classes as $cl): ?>
                    <option value="<?php echo $cl['id']; ?>" <?php echo $filter_kelas == $cl['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($cl['nama_kelas']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">Filter</button>
        </div>
        
        <?php if ($search !== '' || $filter_kelas !== ''): ?>
            <div class="col-auto">
                <a href="index.php" class="btn btn-outline-danger">Reset</a>
            </div>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>Siswa</th>
                    <th>Kelas</th>
                    <th>Mata Pelajaran</th>
                    <th>Guru Pengajar</th>
                    <th>Semester / TA</th>
                    <th style="text-align: center;">Tugas (30%)</th>
                    <th style="text-align: center;">UTS (30%)</th>
                    <th style="text-align: center;">UAS (40%)</th>
                    <th style="text-align: center; color: #D4AF37;">Nilai Akhir</th>
                    <th style="text-align: center;">Predikat</th>
                    <?php if (has_role(['Super Admin', 'Admin', 'Guru'])): ?>
                        <th class="no-print">Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (count($grades) > 0): ?>
                    <?php foreach ($grades as $gr): ?>
                        <tr>
                            <td>
                                <strong class="text-white d-block"><?php echo htmlspecialchars($gr['nama_lengkap']); ?></strong>
                                <span class="text-secondary small font-monospace">NIS: <?php echo htmlspecialchars($gr['nis']); ?></span>
                            </td>
                            <td><?php echo htmlspecialchars($gr['nama_kelas'] ?? 'Tanpa Kelas'); ?></td>
                            <td class="fw-semibold text-white"><?php echo htmlspecialchars($gr['mata_pelajaran']); ?></td>
                            <td><?php echo htmlspecialchars($gr['nama_guru']); ?></td>
                            <td><span class="badge badge-secondary">Smtr <?php echo htmlspecialchars($gr['semester']); ?> (<?php echo htmlspecialchars($gr['tahun_ajaran']); ?>)</span></td>
                            <td style="text-align: center;"><?php echo number_format($gr['nilai_tugas'], 2); ?></td>
                            <td style="text-align: center;"><?php echo number_format($gr['nilai_uts'], 2); ?></td>
                            <td style="text-align: center;"><?php echo number_format($gr['nilai_uas'], 2); ?></td>
                            <td style="text-align: center; font-weight: bold; color: var(--color-gold);"><?php echo number_format($gr['nilai_akhir'], 2); ?></td>
                            <td style="text-align: center;">
                                <?php 
                                    $pred_class = 'badge-secondary';
                                    if ($gr['predikat'] === 'A') $pred_class = 'badge-success';
                                    elseif ($gr['predikat'] === 'B') $pred_class = 'badge-success';
                                    elseif ($gr['predikat'] === 'C') $pred_class = 'badge-warning';
                                    elseif ($gr['predikat'] === 'D') $pred_class = 'badge-danger';
                                    elseif ($gr['predikat'] === 'E') $pred_class = 'badge-danger';
                                ?>
                                <span class="badge <?php echo $pred_class; ?>" style="font-size: 12px; padding: 4px 10px;"><?php echo htmlspecialchars($gr['predikat']); ?></span>
                            </td>
                            <?php if (has_role(['Super Admin', 'Admin', 'Guru'])): ?>
                                <td class="no-print">
                                    <div class="d-flex gap-2">
                                        <a href="edit.php?id=<?php echo $gr['id']; ?>" class="btn btn-xs btn-outline-warning" title="Edit"><i class="fa-solid fa-pen"></i> Edit</a>
                                        <button onclick="confirmDelete('delete.php?id=<?php echo $gr['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i> Hapus</button>
                                    </div>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="<?php echo has_role(['Super Admin', 'Admin', 'Guru']) ? 11 : 10; ?>" class="text-center text-secondary py-4">Belum ada ledger nilai terinput.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
