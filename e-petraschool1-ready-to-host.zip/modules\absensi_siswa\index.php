<?php
// c:\xampp\htdocs\e-petraschool1\modules\absensi_siswa\index.php

$page_title = 'Absensi Siswa';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$filter_kelas    = isset($_GET['kelas_id'])       ? intval($_GET['kelas_id'])       : 0;
$filter_bulan    = isset($_GET['bulan'])           ? intval($_GET['bulan'])           : intval(date('m'));
$filter_tahun    = isset($_GET['tahun'])           ? intval($_GET['tahun'])           : intval(date('Y'));
$filter_ta       = isset($_GET['tahun_ajaran_id']) ? intval($_GET['tahun_ajaran_id']): 0;
$filter_semester = isset($_GET['semester_id'])     ? intval($_GET['semester_id'])    : 0;

try {
    $kelas_list = $pdo->query("SELECT id, nama_kelas FROM kelas WHERE status = 'Aktif' ORDER BY nama_kelas ASC")->fetchAll();
    $ta_list    = $pdo->query("SELECT id, tahun_ajaran, status FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();
    $sem_list   = $pdo->query("SELECT id, semester, status FROM semester ORDER BY semester ASC")->fetchAll();

    if (!$filter_ta) { foreach ($ta_list  as $t) { if ($t['status'] === 'Aktif') { $filter_ta = $t['id']; break; } } }
    if (!$filter_semester) { foreach ($sem_list as $s) { if ($s['status'] === 'Aktif') { $filter_semester = $s['id']; break; } } }
    if (!$filter_kelas && count($kelas_list) > 0) { $filter_kelas = $kelas_list[0]['id']; }

    // Daftar siswa kelas yang dipilih
    $siswa_list = [];
    if ($filter_kelas) {
        $s_stmt = $pdo->prepare("SELECT id, nis, nama_lengkap, gender FROM siswa WHERE kelas_id = ? AND status_siswa = 'Aktif' ORDER BY nama_lengkap ASC");
        $s_stmt->execute([$filter_kelas]);
        $siswa_list = $s_stmt->fetchAll();
    }

    // Daftar tanggal dalam bulan ini
    $days_in_month = cal_days_in_month(CAL_GREGORIAN, $filter_bulan, $filter_tahun);

    // Rekap absensi untuk bulan ini
    $absensi_data = [];
    if ($filter_kelas && !empty($siswa_list)) {
        $siswa_ids = array_column($siswa_list, 'id');
        $placeholders = implode(',', array_fill(0, count($siswa_ids), '?'));
        $start_date = "$filter_tahun-" . str_pad($filter_bulan,2,'0',STR_PAD_LEFT) . "-01";
        $end_date   = "$filter_tahun-" . str_pad($filter_bulan,2,'0',STR_PAD_LEFT) . "-" . str_pad($days_in_month,2,'0',STR_PAD_LEFT);

        $ab_stmt = $pdo->prepare("
            SELECT siswa_id, tanggal, status, keterangan
            FROM absensi_siswa
            WHERE siswa_id IN ($placeholders) AND tanggal BETWEEN ? AND ?
            ORDER BY tanggal ASC
        ");
        $ab_stmt->execute(array_merge($siswa_ids, [$start_date, $end_date]));
        $raw = $ab_stmt->fetchAll();

        foreach ($raw as $row) {
            $absensi_data[$row['siswa_id']][$row['tanggal']] = ['status' => $row['status'], 'keterangan' => $row['keterangan']];
        }
    }

    // Hitung rekap per siswa
    $status_colors = ['Hadir' => '#10B981', 'Sakit' => '#F59E0B', 'Izin' => '#3B82F6', 'Alfa' => '#EF4444'];
    $status_codes  = ['Hadir' => 'H', 'Sakit' => 'S', 'Izin' => 'I', 'Alfa' => 'A'];

} catch (Exception $e) {
    $siswa_list = [];
    $error_db = $e->getMessage();
}

$bulan_names = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
?>

<div class="glass-card">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-clipboard-check me-2"></i>Absensi Siswa</h5>
            <p class="text-secondary small mb-0">Rekap kehadiran siswa per kelas dan bulan di SD Kristen Petra 1.</p>
        </div>
        <?php if (has_role(['Super Admin', 'Admin'])): ?>
        <div class="d-flex gap-2 flex-wrap">
            <a href="input.php<?php echo $filter_kelas ? '?kelas_id='.$filter_kelas.'&tahun_ajaran_id='.$filter_ta.'&semester_id='.$filter_semester : ''; ?>" class="btn btn-gold">
                <i class="fa-solid fa-user-check me-1"></i> Input Absensi
            </a>
            <a href="rekap.php<?php echo $filter_kelas ? '?kelas_id='.$filter_kelas.'&bulan='.$filter_bulan.'&tahun='.$filter_tahun.'&tahun_ajaran_id='.$filter_ta.'&semester_id='.$filter_semester : ''; ?>" class="btn btn-outline-custom">
                <i class="fa-solid fa-table-list me-1"></i> Rekap Bulanan
            </a>
        </div>
        <?php endif; ?>
    </div>

    <?php if (isset($error_db)): ?>
        <div class="alert alert-danger">
            <i class="fa-solid fa-triangle-exclamation me-2"></i>
            Tabel belum tersedia. Jalankan: <a href="<?php echo $base_url; ?>database/migrate_absensi_jadwal.php" class="alert-link fw-bold">migrate_absensi_jadwal.php</a>
        </div>
    <?php endif; ?>

    <!-- Filters -->
    <form method="GET" class="row g-3 mb-4 align-items-end">
        <div class="col-6 col-md-3">
            <label class="form-label form-label-custom">Kelas</label>
            <select name="kelas_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">-- Pilih Kelas --</option>
                <?php foreach ($kelas_list as $kl): ?>
                    <option value="<?php echo $kl['id']; ?>" <?php echo $filter_kelas == $kl['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($kl['nama_kelas']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Bulan</label>
            <select name="bulan" class="form-select form-control-custom bg-dark-select text-white">
                <?php for ($m = 1; $m <= 12; $m++): ?>
                    <option value="<?php echo $m; ?>" <?php echo $filter_bulan == $m ? 'selected' : ''; ?>><?php echo $bulan_names[$m]; ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Tahun</label>
            <input type="number" name="tahun" class="form-control form-control-custom" value="<?php echo $filter_tahun; ?>" min="2020" max="2035">
        </div>
        <input type="hidden" name="tahun_ajaran_id" value="<?php echo $filter_ta; ?>">
        <input type="hidden" name="semester_id" value="<?php echo $filter_semester; ?>">
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom"><i class="fa-solid fa-filter me-1"></i> Filter</button>
        </div>
    </form>

    <!-- Legend -->
    <div class="d-flex gap-3 mb-3 flex-wrap">
        <?php foreach ($status_colors as $st => $clr): ?>
            <span style="display:inline-flex; align-items:center; gap:6px; font-size:12px; color:#94A3B8;">
                <span style="width:18px; height:18px; background:<?php echo $clr; ?>33; border:1px solid <?php echo $clr; ?>; border-radius:4px; display:inline-flex; align-items:center; justify-content:center; font-weight:700; color:<?php echo $clr; ?>; font-size:10px;"><?php echo $status_codes[$st]; ?></span>
                <?php echo $st; ?>
            </span>
        <?php endforeach; ?>
        <span style="font-size:12px; color:#94A3B8; margin-left:8px;">· = Libur/Tidak Input</span>
    </div>

    <?php if (empty($siswa_list)): ?>
        <div class="text-center py-5">
            <i class="fa-solid fa-users-slash" style="font-size:48px; color:rgba(255,255,255,.15);"></i>
            <p class="text-secondary mt-3">Pilih kelas terlebih dahulu untuk melihat data absensi.</p>
        </div>
    <?php else: ?>
        <!-- Title -->
        <?php
        $kelas_nama = '';
        foreach ($kelas_list as $kl) { if ($kl['id'] == $filter_kelas) { $kelas_nama = $kl['nama_kelas']; break; } }
        ?>
        <h6 class="fw-bold text-white mb-3">
            Rekap Absensi — <?php echo htmlspecialchars($kelas_nama); ?> — <?php echo $bulan_names[$filter_bulan]; ?> <?php echo $filter_tahun; ?>
            <span class="badge ms-2" style="background:rgba(212,175,55,.15); color:#D4AF37; font-size:11px;"><?php echo count($siswa_list); ?> siswa</span>
        </h6>

        <!-- Matrix Table -->
        <div class="table-responsive" style="overflow-x:auto;">
            <table class="table table-custom" style="font-size:11px; min-width: 900px;">
                <thead>
                    <tr>
                        <th style="min-width:180px; position:sticky; left:0; background:var(--bg-card, #0d1b35); z-index:2;">Nama Siswa</th>
                        <?php for ($d = 1; $d <= $days_in_month; $d++):
                            $date_str = "$filter_tahun-" . str_pad($filter_bulan,2,'0',STR_PAD_LEFT) . "-" . str_pad($d,2,'0',STR_PAD_LEFT);
                            $dow = date('N', strtotime($date_str)); // 1=Mon..7=Sun
                            $is_weekend = ($dow == 7); // Minggu
                        ?>
                            <th style="text-align:center; padding:4px 3px; min-width:24px; <?php echo $is_weekend ? 'color:#EF4444;' : ''; ?>">
                                <?php echo $d; ?>
                                <div style="font-size:8px; color:#64748B; font-weight:400;"><?php echo ['','S','S','R','K','J','S','M'][$dow]; ?></div>
                            </th>
                        <?php endfor; ?>
                        <th style="text-align:center; color:#10B981; min-width:36px;">H</th>
                        <th style="text-align:center; color:#F59E0B; min-width:36px;">Sk</th>
                        <th style="text-align:center; color:#3B82F6; min-width:36px;">Iz</th>
                        <th style="text-align:center; color:#EF4444; min-width:36px;">A</th>
                        <th style="text-align:center; min-width:40px;">%Hdr</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($siswa_list as $siswa):
                        $totals = ['Hadir'=>0,'Sakit'=>0,'Izin'=>0,'Alfa'=>0];
                        $total_input = 0;
                        for ($d = 1; $d <= $days_in_month; $d++) {
                            $date_str = "$filter_tahun-" . str_pad($filter_bulan,2,'0',STR_PAD_LEFT) . "-" . str_pad($d,2,'0',STR_PAD_LEFT);
                            $dow = date('N', strtotime($date_str));
                            if ($dow == 7) continue;
                            if (isset($absensi_data[$siswa['id']][$date_str])) {
                                $st = $absensi_data[$siswa['id']][$date_str]['status'];
                                $totals[$st]++;
                                $total_input++;
                            }
                        }
                        $pct_hadir = $total_input > 0 ? round($totals['Hadir'] / $total_input * 100) : 0;
                    ?>
                    <tr>
                        <td style="position:sticky; left:0; background:var(--bg-card, #0d1b35); z-index:1; white-space:nowrap;">
                            <strong class="text-white" style="font-size:12px;"><?php echo htmlspecialchars($siswa['nama_lengkap']); ?></strong>
                            <div class="text-secondary" style="font-size:9px;"><?php echo htmlspecialchars($siswa['nis']); ?></div>
                        </td>
                        <?php for ($d = 1; $d <= $days_in_month; $d++):
                            $date_str = "$filter_tahun-" . str_pad($filter_bulan,2,'0',STR_PAD_LEFT) . "-" . str_pad($d,2,'0',STR_PAD_LEFT);
                            $dow = date('N', strtotime($date_str));
                            $is_sunday = ($dow == 7);
                            $ab = $absensi_data[$siswa['id']][$date_str] ?? null;
                            $status = $ab ? $ab['status'] : null;
                            $clr = $status ? $status_colors[$status] : null;
                        ?>
                            <td style="text-align:center; padding:3px 2px;">
                                <?php if ($is_sunday): ?>
                                    <span style="color:#1e293b; font-size:10px;">—</span>
                                <?php elseif ($status): ?>
                                    <span style="display:inline-flex; align-items:center; justify-content:center; width:20px; height:20px; background:<?php echo $clr; ?>22; border:1px solid <?php echo $clr; ?>; border-radius:4px; font-weight:700; color:<?php echo $clr; ?>; font-size:9px;" title="<?php echo $status . ($ab['keterangan'] ? ': '.$ab['keterangan'] : ''); ?>">
                                        <?php echo $status_codes[$status]; ?>
                                    </span>
                                <?php else: ?>
                                    <span style="color:#334155; font-size:10px;">·</span>
                                <?php endif; ?>
                            </td>
                        <?php endfor; ?>
                        <td style="text-align:center; color:#10B981; font-weight:700;"><?php echo $totals['Hadir']; ?></td>
                        <td style="text-align:center; color:#F59E0B; font-weight:700;"><?php echo $totals['Sakit']; ?></td>
                        <td style="text-align:center; color:#3B82F6; font-weight:700;"><?php echo $totals['Izin']; ?></td>
                        <td style="text-align:center; color:#EF4444; font-weight:700;"><?php echo $totals['Alfa']; ?></td>
                        <td style="text-align:center;">
                            <span style="font-weight:700; color:<?php echo $pct_hadir >= 80 ? '#10B981' : ($pct_hadir >= 60 ? '#F59E0B' : '#EF4444'); ?>;">
                                <?php echo $total_input > 0 ? $pct_hadir . '%' : '-'; ?>
                            </span>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
