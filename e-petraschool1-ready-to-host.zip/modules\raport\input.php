<?php
// c:\xampp\htdocs\e-petraschool1\modules\raport\input.php

$page_title = 'Input Rapor Siswa';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin', 'Kepala Sekolah', 'Guru']);

// Dapatkan semester dan tahun ajaran aktif dari sistem
try {
    $active_sem_stmt = $pdo->query("SELECT semester FROM semester WHERE status = 'Aktif' LIMIT 1");
    $active_sem_db = $active_sem_stmt->fetchColumn();
    $active_sem = ($active_sem_db === 'Ganjil' || $active_sem_db === '1') ? '1' : '2';

    $active_ta_stmt = $pdo->query("SELECT tahun_ajaran FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1");
    $active_ta = $active_ta_stmt->fetchColumn() ?: '2025/2026';
} catch (Exception $e) {
    $active_sem = '1';
    $active_ta = '2025/2026';
}

$selected_sem = isset($_GET['semester']) ? $_GET['semester'] : $active_sem;
$selected_ta = $active_ta;

$siswa_id = isset($_GET['siswa_id']) ? intval($_GET['siswa_id']) : 0;
$current_siswa = null;
$raport_data = null;
$next_siswa_id = null;
$selected_kelas_id = isset($_GET['kelas_id']) ? intval($_GET['kelas_id']) : 0;

// Fetch all classes for context header selection
try {
    $classes_stmt = $pdo->query("SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas ASC");
    $classes = $classes_stmt->fetchAll();
} catch (Exception $e) {
    $classes = [];
}

// Fetch list of students if a class is selected
$students_in_class = [];
if ($siswa_id > 0) {
    try {
        // Fetch current student details
        $siswa_stmt = $pdo->prepare("SELECT s.*, k.nama_kelas, k.tingkat, k.wali_kelas_id, g.nama_guru as nama_wali 
                                     FROM siswa s 
                                     LEFT JOIN kelas k ON s.kelas_id = k.id 
                                     LEFT JOIN guru g ON k.wali_kelas_id = g.id 
                                     WHERE s.id = ? AND s.status_siswa = 'Aktif' LIMIT 1");
        $siswa_stmt->execute([$siswa_id]);
        $current_siswa = $siswa_stmt->fetch();
        
        if ($current_siswa) {
            $selected_kelas_id = intval($current_siswa['kelas_id']);
            
            // Get all other active students in the same class
            $students_stmt = $pdo->prepare("SELECT id, nama_lengkap FROM siswa WHERE kelas_id = ? AND status_siswa = 'Aktif' ORDER BY nama_lengkap ASC");
            $students_stmt->execute([$selected_kelas_id]);
            $students_in_class = $students_stmt->fetchAll();
            
            // Fetch next student ID in alphabetical order
            $next_stmt = $pdo->prepare("SELECT id FROM siswa WHERE kelas_id = ? AND status_siswa = 'Aktif' AND nama_lengkap > (SELECT nama_lengkap FROM siswa WHERE id = ?) ORDER BY nama_lengkap ASC LIMIT 1");
            $next_stmt->execute([$selected_kelas_id, $siswa_id]);
            $next_siswa_id = $next_stmt->fetchColumn();
            
            // Circle back to first student if we reached the end
            if (!$next_siswa_id && count($students_in_class) > 1) {
                if ($students_in_class[0]['id'] != $siswa_id) {
                    $next_siswa_id = $students_in_class[0]['id'];
                }
            }
            
            // Fetch existing report card data
            $raport_stmt = $pdo->prepare("SELECT * FROM raport_siswa WHERE siswa_id = ? AND semester = ? AND tahun_ajaran = ? LIMIT 1");
            $raport_stmt->execute([$siswa_id, $selected_sem, $selected_ta]);
            $raport_data = $raport_stmt->fetch();

            // Fetch ALL historical report data (all other semesters/TAs) for the history tab
            $hist_stmt = $pdo->prepare(
                "SELECT tahun_ajaran, semester, academic_grades, ekstrakurikuler,
                        kokurikuler_deskripsi, sakit, izin, alpa
                 FROM raport_siswa
                 WHERE siswa_id = ?
                   AND NOT (tahun_ajaran = ? AND semester = ?)
                 ORDER BY tahun_ajaran DESC, semester ASC"
            );
            $hist_stmt->execute([$siswa_id, $selected_ta, $selected_sem]);
            $hist_rows = $hist_stmt->fetchAll();

            // Group by tahun_ajaran => [ semester => data ]
            $hist_by_ta = [];
            foreach ($hist_rows as $hr) {
                $ta  = $hr['tahun_ajaran'];
                $sem = $hr['semester'];
                $hist_by_ta[$ta][$sem] = [
                    'grades'     => json_decode($hr['academic_grades'], true) ?: [],
                    'ekskul'     => json_decode($hr['ekstrakurikuler'], true) ?: [],
                    'kokurikuler'=> $hr['kokurikuler_deskripsi'],
                    'sakit'      => $hr['sakit'],
                    'izin'       => $hr['izin'],
                    'alpa'       => $hr['alpa'],
                ];
            }
            krsort($hist_by_ta); // terbaru dulu
        }
    } catch (Exception $e) {
        $current_siswa = null;
    }
} else if ($selected_kelas_id > 0) {
    try {
        // Get all active students in the selected class
        $students_stmt = $pdo->prepare("SELECT id, nama_lengkap FROM siswa WHERE kelas_id = ? AND status_siswa = 'Aktif' ORDER BY nama_lengkap ASC");
        $students_stmt->execute([$selected_kelas_id]);
        $students_in_class = $students_stmt->fetchAll();
    } catch (Exception $e) {
        $students_in_class = [];
    }
}

// Default 10 subjects specified in the user concept
$default_subjects = [
    'Agama' => 'Pendidikan Agama',
    'Pancasila' => 'Pancasila',
    'Bahasa Indonesia' => 'Bahasa Indonesia',
    'Matematika' => 'Matematika',
    'IPAS' => 'IPAS',
    'PJOK' => 'PJOK',
    'Seni Budaya' => 'Seni Budaya',
    'Bhs. Inggris' => 'Bhs. Inggris',
    'Bhs. Jawa' => 'Bhs. Jawa',
    'Bhs. Mandarin' => 'Bhs. Mandarin'
];

$tingkat = '';
if ($current_siswa) {
    $tingkat = $current_siswa['tingkat'] ?? '';
} else if ($selected_kelas_id > 0) {
    try {
        $tingkat_stmt = $pdo->prepare("SELECT tingkat FROM kelas WHERE id = ? LIMIT 1");
        $tingkat_stmt->execute([$selected_kelas_id]);
        $tingkat = $tingkat_stmt->fetchColumn() ?: '';
    } catch (Exception $e) {}
}

if ($tingkat === '1' || $tingkat === '2') {
    unset($default_subjects['IPAS']);
}

// Populate existing values or set defaults
$saved_grades = [];
$saved_ekskul = [];
$saved_slo = [];
if ($raport_data) {
    $saved_grades = json_decode($raport_data['academic_grades'], true) ?: [];
    $saved_ekskul = json_decode($raport_data['ekstrakurikuler'], true) ?: [];
    $saved_slo = json_decode($raport_data['slo'] ?? '[]', true) ?: [];
}

// Make sure $hist_by_ta is always defined
if (!isset($hist_by_ta)) $hist_by_ta = [];
?>

<!-- Custom CSS for tab forms -->
<style>
    .raport-input-card {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 1rem;
        padding: 1.5rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.02);
    }
    .nav-pills .nav-link {
        background-color: #ffffff !important;
        color: #475569 !important;
        border: 1px solid #e2e8f0 !important;
        transition: all 0.2s ease;
    }
    .nav-pills .nav-link.active {
        background-color: #6366f1 !important;
        color: #ffffff !important;
        border-color: #6366f1 !important;
        box-shadow: 0 4px 12px rgba(99, 102, 241, 0.2);
    }
    .nav-pills .nav-link:hover:not(.active) {
        background-color: #f8fafc !important;
    }
    .form-section-title {
        color: #1e293b;
        font-weight: 700;
        font-size: 13px;
        border-left: 3px solid #6366f1;
        padding-left: 8px;
        margin-bottom: 15px;
        margin-top: 10px;
    }
    .subject-grade-row {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 0.75rem;
        padding: 1rem;
        margin-bottom: 1rem;
        transition: all 0.2s ease;
    }
    .subject-grade-row:hover {
        border-color: #cbd5e1;
        background: #f1f5f9;
    }
    .ekskul-item-row {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 0.75rem;
        padding: 1rem;
        margin-bottom: 1rem;
        position: relative;
    }
    .ekskul-item-row .btn-remove-ekskul {
        position: absolute;
        top: 10px;
        right: 10px;
    }
</style>

<div class="container-fluid px-4 py-2">
    
    <!-- Redesigned Premium Header -->
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 mb-4">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center shadow-md shadow-indigo-600/20">
                <i class="fa-solid fa-file-signature text-white text-xl"></i>
            </div>
            <div>
                <h5 class="text-slate-800 font-bold text-lg mb-0 font-sans tracking-wide">Input Rapor Siswa</h5>
                <p class="text-slate-500 text-xs mb-0">Lengkapi data rapor semester <?php echo $selected_sem; ?> tahun ajaran <?php echo htmlspecialchars($selected_ta); ?></p>
            </div>
        </div>
        <div>
            <a href="index.php?semester=<?php echo $selected_sem; ?>" class="btn btn-outline-secondary px-3 py-1.5 font-bold text-3xs rounded-lg">
                <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Daftar
            </a>
        </div>
    </div>

    <!-- Header Selector Panel -->
    <div class="raport-input-card mb-4 bg-slate-50">
        <div class="row g-3">
            <div class="col-12 col-md-6">
                <label class="form-label text-slate-600 text-2xs font-semibold uppercase tracking-wider block mb-1">Pilih Kelas</label>
                <select id="select-kelas" class="form-select border-slate-300 text-slate-800">
                    <option value="">-- Pilih Kelas --</option>
                    <?php foreach ($classes as $cl): ?>
                        <option value="<?php echo $cl['id']; ?>" <?php echo $selected_kelas_id === intval($cl['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($cl['nama_kelas']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12 col-md-6">
                <label class="form-label text-slate-600 text-2xs font-semibold uppercase tracking-wider block mb-1">Pilih Siswa</label>
                <select id="select-siswa" class="form-select border-slate-300 text-slate-800" <?php echo empty($students_in_class) ? 'disabled' : ''; ?>>
                    <option value="">-- Pilih Siswa --</option>
                    <?php foreach ($students_in_class as $st): ?>
                        <option value="<?php echo $st['id']; ?>" <?php echo $siswa_id === intval($st['id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($st['nama_lengkap']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </div>

    <?php if ($siswa_id > 0 && $current_siswa): ?>
        <!-- Main Form Wrapper -->
        <form id="form-input-raport">
            <!-- Hidden context fields -->
            <input type="hidden" name="siswa_id" value="<?php echo $siswa_id; ?>">
            <input type="hidden" name="kelas_id" value="<?php echo $selected_kelas_id; ?>">
            <input type="hidden" name="semester" value="<?php echo $selected_sem; ?>">
            <input type="hidden" name="tahun_ajaran" value="<?php echo htmlspecialchars($selected_ta); ?>">
            <input type="hidden" id="csrf-token-val" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">

            <div class="raport-input-card">
                <!-- Tab navigations -->
                <ul class="nav nav-pills gap-2 border-b border-slate-200 pb-3 mb-4" id="raportTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active font-semibold text-xs py-2 px-4 rounded-lg" id="tab-identitas-btn" data-bs-toggle="pill" data-bs-target="#tab-identitas" type="button" role="tab" aria-selected="true"><i class="fa-solid fa-user me-1.5"></i> Identitas</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link font-semibold text-xs py-2 px-4 rounded-lg" id="tab-akademik-btn" data-bs-toggle="pill" data-bs-target="#tab-akademik" type="button" role="tab" aria-selected="false"><i class="fa-solid fa-graduation-cap me-1.5"></i> Akademik</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link font-semibold text-xs py-2 px-4 rounded-lg" id="tab-ekskul-btn" data-bs-toggle="pill" data-bs-target="#tab-ekskul" type="button" role="tab" aria-selected="false"><i class="fa-solid fa-star me-1.5"></i> Ekstrakurikuler</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link font-semibold text-xs py-2 px-4 rounded-lg" id="tab-kokurikuler-btn" data-bs-toggle="pill" data-bs-target="#tab-kokurikuler" type="button" role="tab" aria-selected="false"><i class="fa-solid fa-lightbulb me-1.5"></i> Kokurikuler (P5)</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link font-semibold text-xs py-2 px-4 rounded-lg" id="tab-slo-btn" data-bs-toggle="pill" data-bs-target="#tab-slo" type="button" role="tab" aria-selected="false"><i class="fa-solid fa-heart-pulse me-1.5"></i> SLO</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link font-semibold text-xs py-2 px-4 rounded-lg" id="tab-kehadiran-btn" data-bs-toggle="pill" data-bs-target="#tab-kehadiran" type="button" role="tab" aria-selected="false"><i class="fa-solid fa-clock me-1.5"></i> Kehadiran & Catatan</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link font-semibold text-xs py-2 px-4 rounded-lg position-relative" id="tab-histori-btn" data-bs-toggle="pill" data-bs-target="#tab-histori" type="button" role="tab" aria-selected="false">
                            <i class="fa-solid fa-clock-rotate-left me-1.5"></i> Histori Nilai
                            <?php if (!empty($hist_by_ta)): ?>
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-indigo-500 text-white" style="font-size:9px;padding:2px 5px;"><?php echo count($hist_by_ta); ?></span>
                            <?php endif; ?>
                        </button>
                    </li>
                </ul>

                <!-- Tab contents -->
                <div class="tab-content pt-2" id="raportTabsContent">
                    
                    <!-- TAB 1: IDENTITAS SISWA -->
                    <div class="tab-pane fade show active" id="tab-identitas" role="tabpanel">
                        <div class="form-section-title">Identitas Dasar Siswa</div>
                        <div class="row g-3">
                            <div class="col-12 col-sm-6">
                                <label class="form-label text-slate-500 text-2xs font-semibold uppercase tracking-wider block mb-1">Nama Lengkap</label>
                                <input type="text" class="form-control bg-slate-50" value="<?php echo htmlspecialchars($current_siswa['nama_lengkap']); ?>" readonly>
                            </div>
                            <div class="col-12 col-sm-6">
                                <label class="form-label text-slate-500 text-2xs font-semibold uppercase tracking-wider block mb-1">No. Absen</label>
                                <input type="number" name="no_absen" class="form-control" placeholder="Input angka No. Absen..." value="<?php echo $raport_data ? htmlspecialchars($raport_data['no_absen']) : ''; ?>">
                            </div>
                            <div class="col-12 col-sm-6">
                                <label class="form-label text-slate-500 text-2xs font-semibold uppercase tracking-wider block mb-1">NISN</label>
                                <input type="text" class="form-control bg-slate-50" value="<?php echo htmlspecialchars($current_siswa['nisn']); ?>" readonly>
                            </div>
                            <div class="col-12 col-sm-6">
                                <label class="form-label text-slate-500 text-2xs font-semibold uppercase tracking-wider block mb-1">NIS</label>
                                <input type="text" class="form-control bg-slate-50" value="<?php echo htmlspecialchars($current_siswa['nis']); ?>" readonly>
                            </div>
                            <div class="col-12 col-sm-6">
                                <label class="form-label text-slate-500 text-2xs font-semibold uppercase tracking-wider block mb-1">Kode Siswa</label>
                                <input type="text" name="kode_siswa" class="form-control" placeholder="Input Kode Siswa..." value="<?php echo $raport_data ? htmlspecialchars($raport_data['kode_siswa']) : ''; ?>">
                            </div>
                            <div class="col-12 col-sm-6">
                                <label class="form-label text-slate-500 text-2xs font-semibold uppercase tracking-wider block mb-1">Wali Kelas</label>
                                <input type="text" class="form-control bg-slate-50" value="<?php echo htmlspecialchars($current_siswa['nama_wali'] ?? 'Belum Ditentukan'); ?>" readonly>
                            </div>
                        </div>
                    </div>

                    <!-- TAB 2: NILAI AKADEMIK -->
                    <div class="tab-pane fade" id="tab-akademik" role="tabpanel">
                        <div class="flex justify-between items-center mb-3">
                            <div class="form-section-title mb-0">Nilai Pencapaian Akademik Siswa</div>
                            <button type="button" id="btn-add-subject" class="btn btn-outline-indigo px-3 py-1.5 font-bold text-3xs rounded-lg">
                                <i class="fa-solid fa-plus me-1"></i> Tambah Mapel
                            </button>
                        </div>
                        <div id="grades-subjects-container">
                            <!-- subject grade rows loaded dynamically via JS -->
                        </div>
                    </div>

                    <!-- TAB 3: EKSTRAKURIKULER -->
                    <div class="tab-pane fade" id="tab-ekskul" role="tabpanel">
                        <div class="flex justify-between items-center mb-3">
                            <div class="form-section-title mb-0">Partisipasi Aktivitas Ekstrakurikuler</div>
                            <button type="button" id="btn-add-ekskul" class="btn btn-outline-indigo px-3 py-1.5 font-bold text-3xs rounded-lg">
                                <i class="fa-solid fa-plus me-1"></i> Tambah Aktivitas
                            </button>
                        </div>
                        <div id="ekskul-rows-container">
                            <!-- ekskul rows loaded dynamically via JS -->
                        </div>
                    </div>

                    <!-- TAB 4: KOKURIKULER / P5 -->
                    <div class="tab-pane fade" id="tab-kokurikuler" role="tabpanel">
                        <div class="form-section-title">Nilai Kokurikuler / Proyek P5</div>
                        <div class="row g-3">
                            <div class="col-12 col-md-4">
                                <label class="form-label text-slate-500 text-2xs font-semibold uppercase tracking-wider block mb-1">Predikat Kokurikuler</label>
                                <input type="text" name="kokurikuler_predikat" class="form-control" placeholder="e.g. Berkembang Sesuai Harapan / BSH" value="<?php echo $raport_data ? htmlspecialchars($raport_data['kokurikuler_predikat']) : ''; ?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label text-slate-500 text-2xs font-semibold uppercase tracking-wider block mb-1">Deskripsi Proyek Kokurikuler</label>
                                <textarea name="kokurikuler_deskripsi" class="form-control text-xs" rows="4" placeholder="Tuliskan deskripsi pencapaian proyek P5 siswa..."><?php echo $raport_data ? htmlspecialchars($raport_data['kokurikuler_deskripsi']) : ''; ?></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- TAB SLO: STUDENT LEARNING OUTCOMES -->
                    <div class="tab-pane fade" id="tab-slo" role="tabpanel">
                        <div class="form-section-title">Student Learning Outcomes (SLO)</div>
                        <div class="row g-3">
                            <?php
                            $slo_aspects = [
                                'spiritual' => 'Relationship with God (Relasi dengan Tuhan)',
                                'physical' => 'Physical Growth (Pertumbuhan Fisik)',
                                'emotional' => 'Emotional Intelligence (Kecerdasan Emosional)',
                                'talent' => 'Talent Development (Pengembangan Bakat)',
                                'academic' => 'Academic Excellence (Keunggulan Akademik)'
                            ];
                            foreach ($slo_aspects as $key => $label):
                                $aspect_data = $saved_slo[$key] ?? ['predikat' => 'B', 'deskripsi' => ''];
                                $predikat = $aspect_data['predikat'] ?? 'B';
                                $deskripsi = $aspect_data['deskripsi'] ?? '';
                            ?>
                                <div class="col-12 border border-slate-100 rounded-xl p-3 bg-slate-50/50 mb-2">
                                    <div class="row g-3">
                                        <div class="col-12 col-md-4">
                                            <label class="form-label text-slate-800 font-bold text-2xs block mb-1"><?php echo htmlspecialchars($label); ?></label>
                                            <select name="slo[<?php echo $key; ?>][predikat]" class="form-select border-slate-300 text-slate-800">
                                                <option value="A" <?php echo $predikat === 'A' ? 'selected' : ''; ?>>A (Sangat Baik)</option>
                                                <option value="B" <?php echo $predikat === 'B' ? 'selected' : ''; ?>>B (Baik)</option>
                                                <option value="C" <?php echo $predikat === 'C' ? 'selected' : ''; ?>>C (Cukup)</option>
                                                <option value="D" <?php echo $predikat === 'D' ? 'selected' : ''; ?>>D (Kurang)</option>
                                            </select>
                                        </div>
                                        <div class="col-12 col-md-8">
                                            <label class="form-label text-slate-500 text-3xs font-semibold uppercase tracking-wider block mb-1">Deskripsi Capaian</label>
                                            <textarea name="slo[<?php echo $key; ?>][deskripsi]" class="form-control text-xs" rows="2" placeholder="Tuliskan perkembangan aspek <?php echo strtolower(explode(' (', $label)[0]); ?> siswa..."><?php echo htmlspecialchars($deskripsi); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- TAB 5: KEHADIRAN & CATATAN -->
                    <div class="tab-pane fade" id="tab-kehadiran" role="tabpanel">
                        <div class="row g-4">
                            <div class="col-12 col-md-5">
                                <div class="form-section-title">Absensi & Kehadiran</div>
                                <div class="row g-3">
                                    <div class="col-4">
                                        <label class="form-label text-slate-500 text-3xs font-semibold uppercase tracking-wider block mb-1">Sakit (Hari)</label>
                                        <input type="text" name="sakit" class="form-control" value="<?php echo $raport_data ? htmlspecialchars($raport_data['sakit']) : '0'; ?>">
                                    </div>
                                    <div class="col-4">
                                        <label class="form-label text-slate-500 text-3xs font-semibold uppercase tracking-wider block mb-1">Izin (Hari)</label>
                                        <input type="text" name="izin" class="form-control" value="<?php echo $raport_data ? htmlspecialchars($raport_data['izin']) : '0'; ?>">
                                    </div>
                                    <div class="col-4">
                                        <label class="form-label text-slate-500 text-3xs font-semibold uppercase tracking-wider block mb-1">Alpa (Hari)</label>
                                        <input type="text" name="alpa" class="form-control" value="<?php echo $raport_data ? htmlspecialchars($raport_data['alpa']) : '0'; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-7">
                                <div class="form-section-title">Catatan Wali Kelas</div>
                                <label class="form-label text-slate-500 text-2xs font-semibold uppercase tracking-wider block mb-1">Pesan Wali Kelas</label>
                                <textarea name="catatan_wali" class="form-control text-xs" rows="4" placeholder="Tuliskan pesan perkembangan belajar siswa..."><?php echo $raport_data ? htmlspecialchars($raport_data['catatan_wali']) : ''; ?></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- TAB 6: HISTORI NILAI LINTAS TAHUN AJARAN -->
                    <div class="tab-pane fade" id="tab-histori" role="tabpanel">
                        <div class="form-section-title"><i class="fa-solid fa-clock-rotate-left me-2"></i>Arsip Histori Nilai — <?php echo htmlspecialchars($current_siswa['nama_lengkap']); ?></div>

                        <?php if (empty($hist_by_ta)): ?>
                            <div class="text-center py-8 text-slate-400">
                                <i class="fa-solid fa-folder-open d-block mb-2" style="font-size:2rem;opacity:.5"></i>
                                <p class="mb-0 text-sm">Belum ada data rapor dari tahun ajaran sebelumnya.</p>
                            </div>
                        <?php else: ?>
                            <div class="accordion" id="accordionHistori">
                            <?php $acc_idx = 0; foreach ($hist_by_ta as $ta => $semesters): ?>
                                <?php
                                    // Hitung rata-rata per semester
                                    $avg = [];
                                    foreach ($semesters as $sem_num => $sdata) {
                                        $scores = array_filter(array_column($sdata['grades'], 'score'));
                                        $avg[$sem_num] = count($scores) > 0 ? round(array_sum($scores) / count($scores), 1) : null;
                                    }
                                    $acc_id = 'hist-' . preg_replace('/[^a-z0-9]/i', '', $ta);
                                    $is_open = $acc_idx === 0; // buka accordion pertama secara default
                                ?>
                                <div class="accordion-item border border-slate-200 rounded-xl mb-3 overflow-hidden" style="border-radius:0.75rem!important">
                                    <h2 class="accordion-header" id="hd-<?php echo $acc_id; ?>">
                                        <button class="accordion-button <?php echo $is_open ? '' : 'collapsed'; ?> fw-bold text-slate-800 text-sm"
                                                type="button" data-bs-toggle="collapse"
                                                data-bs-target="#cl-<?php echo $acc_id; ?>"
                                                aria-expanded="<?php echo $is_open ? 'true' : 'false'; ?>"
                                                style="background:#f8fafc;">
                                            <i class="fa-solid fa-folder-open me-2 text-indigo-500"></i>
                                            Tahun Ajaran <?php echo htmlspecialchars($ta); ?>
                                            <?php foreach ($avg as $sn => $av): ?>
                                                <span class="ms-3 badge rounded-pill" style="background:rgba(99,102,241,.12);color:#6366f1;font-size:10px;font-weight:600;padding:3px 9px;">Sem <?php echo $sn; ?>: Rata-rata <?php echo $av !== null ? $av : '—'; ?></span>
                                            <?php endforeach; ?>
                                        </button>
                                    </h2>
                                    <div id="cl-<?php echo $acc_id; ?>" class="accordion-collapse collapse <?php echo $is_open ? 'show' : ''; ?>" aria-labelledby="hd-<?php echo $acc_id; ?>">
                                        <div class="accordion-body p-3" style="background:#fff">

                                            <!-- Semester tabs inside accordion -->
                                            <?php
                                                // Collect all subject keys across all semesters in this TA
                                                $all_subjects_ta = [];
                                                foreach ($semesters as $sdata) {
                                                    foreach (array_keys($sdata['grades']) as $sk) {
                                                        $all_subjects_ta[$sk] = true;
                                                    }
                                                }
                                                $all_subjects_ta = array_keys($all_subjects_ta);
                                                // Fallback to default subjects if no grades found
                                                if (empty($all_subjects_ta)) {
                                                    $all_subjects_ta = array_keys($default_subjects);
                                                }
                                            ?>

                                            <!-- Grades table -->
                                            <div class="table-responsive mb-3">
                                                <table class="table table-sm" style="font-size:12px;border-collapse:collapse;">
                                                    <thead>
                                                        <tr style="background:#f1f5f9;">
                                                            <th style="padding:8px 10px;border:1px solid #e2e8f0;color:#475569;font-weight:700;">Mata Pelajaran</th>
                                                            <?php foreach ($semesters as $sn => $sdata): ?>
                                                                <th colspan="2" style="padding:8px 10px;border:1px solid #e2e8f0;color:#6366f1;font-weight:700;text-align:center;">Semester <?php echo $sn; ?></th>
                                                            <?php endforeach; ?>
                                                        </tr>
                                                        <tr style="background:#f8fafc;">
                                                            <th style="padding:6px 10px;border:1px solid #e2e8f0;color:#94a3b8;font-size:10px;"></th>
                                                            <?php foreach ($semesters as $sn => $sdata): ?>
                                                                <th style="padding:6px 10px;border:1px solid #e2e8f0;color:#94a3b8;font-size:10px;text-align:center;">Nilai</th>
                                                                <th style="padding:6px 10px;border:1px solid #e2e8f0;color:#94a3b8;font-size:10px;">Capaian Tertinggi</th>
                                                            <?php endforeach; ?>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach ($all_subjects_ta as $subj): ?>
                                                            <tr>
                                                                <td style="padding:7px 10px;border:1px solid #e2e8f0;font-weight:600;color:#334155;white-space:nowrap;"><?php echo htmlspecialchars($default_subjects[$subj] ?? $subj); ?></td>
                                                                <?php foreach ($semesters as $sn => $sdata): ?>
                                                                    <?php $g = $sdata['grades'][$subj] ?? []; ?>
                                                                    <td style="padding:7px 10px;border:1px solid #e2e8f0;text-align:center;">
                                                                        <?php if (!empty($g['score'])): ?>
                                                                            <?php
                                                                                $sc = intval($g['score']);
                                                                                $color = $sc >= 90 ? '#10b981' : ($sc >= 75 ? '#6366f1' : '#f59e0b');
                                                                            ?>
                                                                            <span style="display:inline-block;min-width:36px;padding:2px 7px;border-radius:9999px;background:<?php echo $color; ?>18;color:<?php echo $color; ?>;font-weight:700;font-size:12px;"><?php echo $sc; ?></span>
                                                                        <?php else: ?>
                                                                            <span style="color:#cbd5e1;">—</span>
                                                                        <?php endif; ?>
                                                                    </td>
                                                                    <td style="padding:7px 10px;border:1px solid #e2e8f0;color:#475569;font-size:11px;max-width:250px;">
                                                                        <?php echo htmlspecialchars($g['desc_max'] ?? ''); ?>
                                                                    </td>
                                                                <?php endforeach; ?>
                                                            </tr>
                                                        <?php endforeach; ?>
                                                        <!-- Row rata-rata -->
                                                        <tr style="background:#f0f4ff;">
                                                            <td style="padding:8px 10px;border:1px solid #e2e8f0;font-weight:700;color:#6366f1;">📊 Rata-rata</td>
                                                            <?php foreach ($semesters as $sn => $sdata): ?>
                                                                <td colspan="2" style="padding:8px 10px;border:1px solid #e2e8f0;font-weight:700;color:#6366f1;">
                                                                    <?php echo isset($avg[$sn]) ? $avg[$sn] : '—'; ?>
                                                                </td>
                                                            <?php endforeach; ?>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>

                                            <!-- Absensi & Ekskul ringkasan -->
                                            <div class="row g-2 mt-1">
                                                <?php foreach ($semesters as $sn => $sdata): ?>
                                                    <div class="col-12 col-md-6">
                                                        <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:.5rem;padding:10px 14px;font-size:12px;">
                                                            <div class="fw-bold text-slate-600 mb-2" style="font-size:11px;letter-spacing:.04em;">SEM <?php echo $sn; ?> — KEHADIRAN & EKSKUL</div>
                                                            <span class="me-3">🤒 Sakit: <strong><?php echo intval($sdata['sakit']); ?> hr</strong></span>
                                                            <span class="me-3">📋 Izin: <strong><?php echo intval($sdata['izin']); ?> hr</strong></span>
                                                            <span>❌ Alpa: <strong><?php echo intval($sdata['alpa']); ?> hr</strong></span>
                                                            <?php if (!empty($sdata['ekskul'])): ?>
                                                                <div class="mt-2">
                                                                    <?php foreach ($sdata['ekskul'] as $ek): ?>
                                                                        <span style="display:inline-block;background:rgba(99,102,241,.08);color:#6366f1;border:1px solid rgba(99,102,241,.2);border-radius:9999px;padding:1px 10px;font-size:10px;font-weight:600;margin:2px 2px 0 0;">
                                                                            ⭐ <?php echo htmlspecialchars($ek['nama'] ?? ''); ?> (<?php echo htmlspecialchars($ek['predikat'] ?? ''); ?>)
                                                                        </span>
                                                                    <?php endforeach; ?>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            <?php $acc_idx++; endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>

                </div>

                <!-- Footer button actions -->
                <div class="flex justify-between items-center border-t border-slate-200 pt-3 mt-4">
                    <div>
                        <a href="index.php" class="btn btn-outline-secondary px-4 font-semibold text-xs py-2 rounded-lg">Batal</a>
                        <?php if ($raport_data): ?>
                            <a href="print.php?siswa_id=<?php echo $siswa_id; ?>&semester=<?php echo $selected_sem; ?>" target="_blank" class="btn btn-success px-4 font-semibold text-xs py-2 rounded-lg ms-2">
                                <i class="fa-solid fa-print me-1"></i> Cetak Rapor
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="flex gap-2">
                        <button type="button" id="btn-save-draft" class="btn btn-outline-indigo px-4 font-semibold text-xs py-2 rounded-lg">
                            <i class="fa-solid fa-floppy-disk me-1"></i> Simpan Draf
                        </button>
                        <button type="button" id="btn-save-final" class="btn btn-indigo px-4 font-semibold text-xs py-2 rounded-lg">
                            <i class="fa-solid fa-circle-check me-1"></i> Simpan & Lanjut
                        </button>
                    </div>
                </div>

            </div>
        </form>
    <?php elseif ($siswa_id > 0): ?>
        <div class="alert alert-warning raport-input-card text-center">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> Siswa yang Anda cari tidak ditemukan atau berstatus tidak aktif.
        </div>
    <?php else: ?>
        <div class="raport-input-card text-center py-8 text-slate-500">
            <i class="fa-solid fa-folder-open d-block text-lg mb-2 text-indigo-600 opacity-60"></i>
            Silakan pilih kelas dan siswa pada kolom dropdown di atas untuk memulai pengisian nilai rapor.
        </div>
    <?php endif; ?>

</div>

<!-- Dropdown redirection script -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    
    // Dropdown kelas change
    const selectKelas = document.getElementById('select-kelas');
    const selectSiswa = document.getElementById('select-siswa');
    
    if (selectKelas) {
        selectKelas.addEventListener('change', (e) => {
            const classId = e.target.value;
            const semester = new URLSearchParams(window.location.search).get('semester') || '';
            if (classId) {
                // Redirect to reload list of students for selected class
                window.location.href = `input.php?kelas_id=${classId}${semester ? '&semester=' + encodeURIComponent(semester) : ''}`;
            } else {
                window.location.href = `input.php${semester ? '?semester=' + encodeURIComponent(semester) : ''}`;
            }
        });
    }

    if (selectSiswa) {
        selectSiswa.addEventListener('change', (e) => {
            const studentId = e.target.value;
            const semester = new URLSearchParams(window.location.search).get('semester') || '';
            if (studentId) {
                window.location.href = `input.php?siswa_id=${studentId}${semester ? '&semester=' + encodeURIComponent(semester) : ''}`;
            }
        });
    }
    
    // Dynamic ekskul activities loader
    const ekskulRowsContainer = document.getElementById('ekskul-rows-container');
    const btnAddEkskul = document.getElementById('btn-add-ekskul');
    
    // Existing saved ekskuls
    const savedEkskuls = <?php echo json_encode($saved_ekskul); ?>;
    
    function createEkskulRow(data = {}) {
        const rowCount = ekskulRowsContainer.querySelectorAll('.ekskul-item-row').length;
        if (rowCount >= 5) {
            Swal.fire({
                title: 'Batas Ekskul',
                text: 'Maksimal ekskul yang dapat ditambahkan adalah 5 aktivitas.',
                icon: 'warning'
            });
            return;
        }

        const nama = data.nama || data.name || '';
        const predikat = data.predikat || data.predicate || data.grade || 'B';
        const deskripsi = data.deskripsi || data.description || '';

        const div = document.createElement('div');
        div.className = 'ekskul-item-row';
        div.innerHTML = `
            <button type="button" class="btn btn-outline-danger btn-xs btn-remove-ekskul font-bold" title="Hapus">
                <i class="fa-solid fa-xmark"></i> Hapus
            </button>
            <div class="row g-3">
                <div class="col-12 col-md-4">
                    <label class="form-label text-slate-500 text-3xs font-semibold uppercase tracking-wider block mb-1">Nama Ekstrakurikuler</label>
                    <input type="text" name="ekskul[${rowCount}][nama]" class="form-control" placeholder="Pramuka / K-Pop / Basket..." value="${nama}" required>
                </div>
                <div class="col-12 col-md-3">
                    <label class="form-label text-slate-500 text-3xs font-semibold uppercase tracking-wider block mb-1">Predikat</label>
                    <select name="ekskul[${rowCount}][predikat]" class="form-select">
                        <option value="A" ${predikat === 'A' ? 'selected' : ''}>A (Sangat Baik)</option>
                        <option value="B" ${predikat === 'B' ? 'selected' : ''}>B (Baik)</option>
                        <option value="C" ${predikat === 'C' ? 'selected' : ''}>C (Cukup)</option>
                        <option value="D" ${predikat === 'D' ? 'selected' : ''}>D (Kurang)</option>
                    </select>
                </div>
                <div class="col-12 col-md-5">
                    <label class="form-label text-slate-500 text-3xs font-semibold uppercase tracking-wider block mb-1">Deskripsi</label>
                    <textarea name="ekskul[${rowCount}][deskripsi]" class="form-control text-xs" rows="1" placeholder="Mampu menguasai materi ekskul...">${deskripsi}</textarea>
                </div>
            </div>
        `;

        div.querySelector('.btn-remove-ekskul').addEventListener('click', () => {
            div.remove();
            reindexEkskulRows();
        });

        ekskulRowsContainer.appendChild(div);
    }

    function reindexEkskulRows() {
        const rows = ekskulRowsContainer.querySelectorAll('.ekskul-item-row');
        rows.forEach((row, idx) => {
            row.querySelector('[name*="[nama]"]').setAttribute('name', `ekskul[${idx}][nama]`);
            row.querySelector('[name*="[predikat]"]').setAttribute('name', `ekskul[${idx}][predikat]`);
            row.querySelector('[name*="[deskripsi]"]').setAttribute('name', `ekskul[${idx}][deskripsi]`);
        });
    }

    if (btnAddEkskul) {
        btnAddEkskul.addEventListener('click', () => {
            createEkskulRow();
        });
    }

    // Populate existing ekskuls
    if (savedEkskuls && savedEkskuls.length > 0) {
        savedEkskuls.forEach(data => createEkskulRow(data));
    }

    // Existing saved academic grades
    const savedGrades = <?php echo json_encode($saved_grades); ?>;

    const defaultSubjects = <?php echo json_encode($default_subjects); ?>;

    const gradesContainer = document.getElementById('grades-subjects-container');

    function syncGradesFromDOM() {
        if (!gradesContainer) return;
        const rows = gradesContainer.querySelectorAll('.subject-grade-row');
        rows.forEach(row => {
            const key = row.dataset.key;
            const score = row.querySelector(`[name="grades[${key}][score]"]`).value;
            const desc_max = row.querySelector(`[name="grades[${key}][desc_max]"]`).value;
            const desc_min = row.querySelector(`[name="grades[${key}][desc_min]"]`).value;
            savedGrades[key] = { score, desc_max, desc_min };
        });
    }

    function renderAcademicGrades() {
        if (!gradesContainer) return;
        gradesContainer.innerHTML = '';
        
        const keys = Object.keys(savedGrades).length > 0 ? Object.keys(savedGrades) : Object.keys(defaultSubjects);
        
        keys.forEach(key => {
            const subName = defaultSubjects[key] || key;
            const gradeData = savedGrades[key] || { score: '', desc_max: '', desc_min: '' };
            
            const row = document.createElement('div');
            row.className = 'subject-grade-row';
            row.dataset.key = key;
            row.innerHTML = `
                <div class="fw-bold text-slate-800 text-xs mb-3 flex items-center justify-between">
                    <div class="flex items-center gap-2">
                        <span class="w-2 h-2 rounded-full bg-indigo-500"></span> ${subName}
                    </div>
                    <button type="button" class="btn btn-outline-danger btn-xs btn-remove-subject font-bold py-0.5 px-2" style="font-size: 10px;" title="Hapus Mapel ini">
                        <i class="fa-solid fa-trash-can"></i> Hapus
                    </button>
                </div>
                <div class="row g-3">
                    <div class="col-12 col-md-2">
                        <label class="form-label text-slate-500 text-3xs font-semibold uppercase tracking-wider block mb-1">Nilai Akhir (Score)</label>
                        <input type="number" step="0.01" name="grades[${key}][score]" class="form-control" placeholder="e.g. 90" value="${gradeData.score || ''}">
                    </div>
                    <div class="col-12 col-md-5">
                        <label class="form-label text-slate-500 text-3xs font-semibold uppercase tracking-wider block mb-1">Capaian Tertinggi (Desc Max)</label>
                        <textarea name="grades[${key}][desc_max]" class="form-control text-xs" rows="2" placeholder="Menunjukkan penguasaan sangat baik dalam...">${gradeData.desc_max || ''}</textarea>
                    </div>
                    <div class="col-12 col-md-5">
                        <label class="form-label text-slate-500 text-3xs font-semibold uppercase tracking-wider block mb-1">Perlu Peningkatan (Desc Min)</label>
                        <textarea name="grades[${key}][desc_min]" class="form-control text-xs" rows="2" placeholder="Perlu bimbingan dan pendampingan materi...">${gradeData.desc_min || ''}</textarea>
                    </div>
                </div>
            `;
            
            row.querySelector('.btn-remove-subject').addEventListener('click', () => {
                Swal.fire({
                    title: 'Hapus Mata Pelajaran?',
                    text: `Apakah Anda yakin ingin menghapus mata pelajaran "${subName}" dari rapor ini?`,
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#ef4444',
                    cancelButtonColor: '#94a3b8',
                    confirmButtonText: 'Ya, Hapus!',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (result.isConfirmed) {
                        syncGradesFromDOM();
                        delete savedGrades[key];
                        renderAcademicGrades();
                    }
                });
            });
            
            gradesContainer.appendChild(row);
        });
    }

    const btnAddSubject = document.getElementById('btn-add-subject');
    if (btnAddSubject) {
        btnAddSubject.addEventListener('click', () => {
            Swal.fire({
                title: 'Tambah Mata Pelajaran',
                text: 'Masukkan nama mata pelajaran baru:',
                input: 'text',
                inputPlaceholder: 'Ketik nama mapel...',
                showCancelButton: true,
                confirmButtonColor: '#6366f1',
                confirmButtonText: 'Tambah',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    const mapelName = result.value.trim();
                    if (mapelName) {
                        // Check duplicate
                        if (savedGrades[mapelName] || Object.values(defaultSubjects).includes(mapelName)) {
                            Swal.fire('Error', 'Mata pelajaran tersebut sudah ada!', 'error');
                            return;
                        }
                        
                        syncGradesFromDOM();
                        savedGrades[mapelName] = { score: '', desc_max: '', desc_min: '' };
                        renderAcademicGrades();
                    }
                }
            });
        });
    }

    // Initialize academic grades
    renderAcademicGrades();

    // AJAX Save handler
    const form = document.getElementById('form-input-raport');
    const saveDraftBtn = document.getElementById('btn-save-draft');
    const saveFinalBtn = document.getElementById('btn-save-final');
    const nextSiswaId = '<?php echo $next_siswa_id; ?>';
    
    function saveRaport(isDraft) {
        const formData = new FormData(form);
        
        // Convert ekskul rows to json array to simplify backend
        const dataObj = {};
        formData.forEach((value, key) => {
            // Let the simple fields map normally
            if (!key.includes('grades') && !key.includes('ekskul') && !key.includes('slo')) {
                dataObj[key] = value;
            }
        });

        // Collect grades and ekskuls directly from form DOM
        const grades = {};
        form.querySelectorAll('.subject-grade-row').forEach(row => {
            const inputs = row.querySelectorAll('[name*="grades"]');
            if (inputs.length > 0) {
                // Find subject name key
                const match = inputs[0].getAttribute('name').match(/grades\[([^\]]+)\]/);
                if (match) {
                    const key = match[1];
                    grades[key] = {
                        score: row.querySelector(`[name="grades[${key}][score]"]`).value,
                        desc_max: row.querySelector(`[name="grades[${key}][desc_max]"]`).value,
                        desc_min: row.querySelector(`[name="grades[${key}][desc_min]"]`).value
                    };
                }
            }
        });
        dataObj['academic_grades'] = grades;

        const ekskuls = [];
        ekskulRowsContainer.querySelectorAll('.ekskul-item-row').forEach((row, idx) => {
            ekskuls.push({
                nama: row.querySelector(`[name="ekskul[${idx}][nama]"]`).value,
                predikat: row.querySelector(`[name="ekskul[${idx}][predikat]"]`).value,
                deskripsi: row.querySelector(`[name="ekskul[${idx}][deskripsi]"]`).value
            });
        });
        dataObj['ekstrakurikuler'] = ekskuls;

        // Collect SLO directly from form DOM
        const slo = {};
        form.querySelectorAll('[name^="slo["]').forEach(input => {
            const match = input.getAttribute('name').match(/slo\[([^\]]+)\]\[([^\]]+)\]/);
            if (match) {
                const aspect = match[1];
                const field = match[2];
                if (!slo[aspect]) {
                    slo[aspect] = {};
                }
                slo[aspect][field] = input.value;
            }
        });
        dataObj['slo'] = slo;
        dataObj['status_draft'] = isDraft ? 1 : 0;

        Swal.fire({
            title: isDraft ? 'Simpan Draf?' : 'Simpan Rapor Siswa?',
            text: isDraft ? 'Data rapor akan disimpan sebagai draf sementara.' : 'Data rapor akan disimpan secara final.',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#6366f1',
            confirmButtonText: 'Ya, Simpan!',
            cancelButtonText: 'Batal',
            showLoaderOnConfirm: true,
            preConfirm: () => {
                return fetch('save.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(dataObj)
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Koneksi server gagal');
                    }
                    return response.json();
                })
                .catch(error => {
                    Swal.showValidationMessage(`Gagal menyimpan: ${error}`);
                });
            },
            allowOutsideClick: () => !Swal.isLoading()
        }).then((result) => {
            if (result.isConfirmed) {
                const res = result.value;
                if (res.status === 'success') {
                    Swal.fire({
                        title: 'Berhasil Disimpan!',
                        text: res.message,
                        icon: 'success',
                        timer: 1500,
                        showConfirmButton: false
                    }).then(() => {
                        // Check if we should move to the next student or reload
                        if (!isDraft && nextSiswaId) {
                            const semester = new URLSearchParams(window.location.search).get('semester') || '';
                            window.location.href = `input.php?siswa_id=${nextSiswaId}${semester ? '&semester=' + encodeURIComponent(semester) : ''}`;
                        } else {
                            window.location.reload();
                        }
                    });
                } else {
                    Swal.fire('Error', res.message || 'Gagal menyimpan.', 'error');
                }
            }
        });
    }

    if (saveDraftBtn) {
        saveDraftBtn.addEventListener('click', () => {
            saveRaport(true);
        });
    }

    if (saveFinalBtn) {
        saveFinalBtn.addEventListener('click', () => {
            saveRaport(false);
        });
    }

});
</script>

<?php 
// Helper query logic to load students when a class is selected but no student is selected
if ($selected_kelas_id > 0 && $siswa_id === 0 && !empty($classes)) {
    // Execute dynamic select trigger in browser
    try {
        $first_student_stmt = $pdo->prepare("SELECT id FROM siswa WHERE kelas_id = ? AND status_siswa = 'Aktif' ORDER BY nama_lengkap ASC LIMIT 1");
        $first_student_stmt->execute([$selected_kelas_id]);
        $first_student_id = $first_student_stmt->fetchColumn();
        if ($first_student_id) {
            echo "<script>window.location.href = 'input.php?siswa_id=" . $first_student_id . "&semester=" . urlencode($selected_sem) . "';</script>";
        }
    } catch (Exception $e) {}
}

require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; 
?>
