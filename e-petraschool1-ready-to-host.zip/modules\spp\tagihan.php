<?php
// c:\xampp\htdocs\e-petraschool1\modules\spp\tagihan.php

$page_title = 'Buat Tagihan SPP Massal';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin','Admin']);

$bulan_names = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
$error = ''; $success = '';

$filter_kelas = isset($_GET['kelas_id']) ? intval($_GET['kelas_id']) : 0;
$filter_bulan = isset($_GET['bulan'])    ? intval($_GET['bulan'])    : intval(date('m'));
$filter_tahun = isset($_GET['tahun'])    ? intval($_GET['tahun'])    : intval(date('Y'));

try {
    $kelas_list = $pdo->query("SELECT id,nama_kelas FROM kelas WHERE status='Aktif' ORDER BY nama_kelas ASC")->fetchAll();
    $siswa_list = [];
    if ($filter_kelas) {
        $ss = $pdo->prepare("SELECT id,nis,nama_lengkap FROM siswa WHERE kelas_id=? AND status_siswa='Aktif' ORDER BY nama_lengkap ASC");
        $ss->execute([$filter_kelas]); $siswa_list = $ss->fetchAll();
    }
} catch (Exception $e) { $error = $e->getMessage(); }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($error)) {
    check_csrf_request();
    $kelas_id  = intval($_POST['kelas_id'] ?? 0);
    $bulan     = intval($_POST['bulan'] ?? 0);
    $tahun     = intval($_POST['tahun'] ?? 0);
    $tagihans  = $_POST['tagihan'] ?? [];

    if (!$kelas_id || !$bulan || !$tahun || empty($tagihans)) {
        $error = 'Data tidak lengkap!';
    } else {
        $saved = 0; $skipped = 0;
        foreach ($tagihans as $siswa_id => $data) {
            $nominal = floatval(str_replace(['.', ','], ['', '.'], $data['nominal'] ?? '0'));
            if ($nominal <= 0) continue;
            $ket = trim($data['keterangan'] ?? '');
            try {
                $pdo->prepare("INSERT INTO spp_tagihan (siswa_id,kelas_id,bulan,tahun,nominal,keterangan,dibuat_oleh) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE nominal=VALUES(nominal),keterangan=VALUES(keterangan)")
                    ->execute([intval($siswa_id),$kelas_id,$bulan,$tahun,$nominal,$ket,$_SESSION['user_id']]);
                $saved++;
            } catch (Exception $e) { $skipped++; }
        }
        write_audit_log("Membuat tagihan SPP massal: $saved siswa, bulan $bulan/$tahun.");
        $success = "Berhasil membuat $saved tagihan SPP!" . ($skipped?" ($skipped dilewati)":'');
    }
}
?>
<div class="glass-card" style="max-width:900px;margin:0 auto;">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-file-invoice-dollar me-2"></i>Buat Tagihan SPP Massal</h5>
            <p class="text-secondary small mb-0">Buat tagihan SPP untuk seluruh siswa dalam satu kelas sekaligus.</p>
        </div>
        <a href="index.php" class="btn btn-outline-custom"><i class="fa-solid fa-arrow-left me-1"></i> Kembali</a>
    </div>
    <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><i class="fa-solid fa-check-circle me-2"></i><?php echo htmlspecialchars($success); ?></div><?php endif; ?>

    <!-- Selector -->
    <form method="GET" class="row g-3 mb-4 align-items-end">
        <div class="col-6 col-md-3">
            <label class="form-label form-label-custom">Kelas *</label>
            <select name="kelas_id" class="form-select form-control-custom bg-dark-select text-white" required>
                <option value="">-- Pilih Kelas --</option>
                <?php foreach ($kelas_list as $kl): ?><option value="<?php echo $kl['id']; ?>" <?php echo $filter_kelas==$kl['id']?'selected':''; ?>><?php echo htmlspecialchars($kl['nama_kelas']); ?></option><?php endforeach; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Bulan *</label>
            <select name="bulan" class="form-select form-control-custom bg-dark-select text-white">
                <?php for ($m=1;$m<=12;$m++): ?><option value="<?php echo $m; ?>" <?php echo $filter_bulan==$m?'selected':''; ?>><?php echo $bulan_names[$m]; ?></option><?php endfor; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Tahun *</label>
            <input type="number" name="tahun" class="form-control form-control-custom" value="<?php echo $filter_tahun; ?>">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom"><i class="fa-solid fa-search me-1"></i> Tampilkan Siswa</button>
        </div>
    </form>

    <?php if (!empty($siswa_list)): ?>
    <!-- Global Nominal -->
    <div class="d-flex gap-3 align-items-center mb-3 p-3" style="background:rgba(212,175,55,.08);border:1px solid rgba(212,175,55,.2);border-radius:10px;">
        <label class="fw-bold text-gold" style="font-size:13px; white-space:nowrap;"><i class="fa-solid fa-wand-magic-sparkles me-2"></i>Isi Nominal Semua:</label>
        <input type="number" id="global_nominal" class="form-control form-control-custom" style="max-width:160px;" placeholder="Mis: 250000" oninput="setAllNominal(this.value)">
        <span class="text-secondary small">Isi di sini lalu langsung terapkan ke semua siswa</span>
    </div>

    <form method="POST" action="tagihan.php?kelas_id=<?php echo $filter_kelas; ?>&bulan=<?php echo $filter_bulan; ?>&tahun=<?php echo $filter_tahun; ?>">
        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
        <input type="hidden" name="kelas_id" value="<?php echo $filter_kelas; ?>">
        <input type="hidden" name="bulan" value="<?php echo $filter_bulan; ?>">
        <input type="hidden" name="tahun" value="<?php echo $filter_tahun; ?>">
        <div class="table-responsive">
            <table class="table table-custom" style="font-size:13px;">
                <thead><tr><th>#</th><th>Nama Siswa</th><th>NIS</th><th>Nominal (Rp)</th><th>Keterangan</th></tr></thead>
                <tbody>
                    <?php $no=1; foreach ($siswa_list as $s): ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><strong class="text-white"><?php echo htmlspecialchars($s['nama_lengkap']); ?></strong></td>
                        <td class="font-monospace text-secondary"><?php echo htmlspecialchars($s['nis']); ?></td>
                        <td><input type="number" name="tagihan[<?php echo $s['id']; ?>][nominal]" class="form-control form-control-custom nominal-input" style="font-size:12px;" placeholder="0" min="0" step="1000"></td>
                        <td><input type="text" name="tagihan[<?php echo $s['id']; ?>][keterangan]" class="form-control form-control-custom" style="font-size:12px;" placeholder="Opsional..."></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="d-flex gap-3 mt-3">
            <button type="submit" class="btn btn-gold"><i class="fa-solid fa-file-invoice me-1"></i> Buat Tagihan</button>
            <a href="index.php?kelas_id=<?php echo $filter_kelas; ?>&bulan=<?php echo $filter_bulan; ?>&tahun=<?php echo $filter_tahun; ?>" class="btn btn-outline-custom">Lihat Tagihan</a>
        </div>
    </form>
    <?php else: ?>
        <div class="text-center py-5"><i class="fa-solid fa-hand-pointer" style="font-size:48px;color:rgba(255,255,255,.15);"></i><p class="text-secondary mt-3">Pilih kelas dan periode untuk mulai membuat tagihan.</p></div>
    <?php endif; ?>
</div>
<script>
function setAllNominal(val) {
    document.querySelectorAll('.nominal-input').forEach(inp => inp.value = val);
}
</script>
<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
