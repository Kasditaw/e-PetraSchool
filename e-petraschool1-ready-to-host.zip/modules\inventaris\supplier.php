<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris\supplier.php

$page_title = 'Supplier & Vendor';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_inventaris_access();

$error = '';
$success = '';

// Handle CRUD operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_role(['Super Admin', 'Admin']);
    check_csrf_request();
    
    $action = $_POST['action'] ?? '';
    
    // Add Supplier
    if ($action === 'add') {
        $nama_supplier = trim($_POST['nama_supplier'] ?? '');
        $alamat = trim($_POST['alamat'] ?? '');
        $no_telp = trim($_POST['no_telp'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $pic = trim($_POST['pic'] ?? '');
        
        if (empty($nama_supplier)) {
            $error = 'Nama Supplier wajib diisi!';
        } else {
            try {
                // Check duplicate supplier name
                $chk = $pdo->prepare("SELECT COUNT(*) FROM supplier WHERE nama_supplier = ?");
                $chk->execute([$nama_supplier]);
                if ($chk->fetchColumn() > 0) {
                    $error = 'Nama Supplier/Vendor sudah terdaftar!';
                } else {
                    $stmt = $pdo->prepare("INSERT INTO supplier (nama_supplier, alamat, no_telp, email, pic) VALUES (?, ?, ?, ?, ?)");
                    $stmt->execute([$nama_supplier, $alamat, $no_telp, $email, $pic]);
                    
                    write_audit_log("Menambahkan supplier/vendor baru: $nama_supplier.");
                    
                    $success = 'Supplier/Vendor berhasil ditambahkan!';
                }
            } catch (Exception $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
    
    // Edit Supplier
    if ($action === 'edit') {
        $id = intval($_POST['id'] ?? 0);
        $nama_supplier = trim($_POST['nama_supplier'] ?? '');
        $alamat = trim($_POST['alamat'] ?? '');
        $no_telp = trim($_POST['no_telp'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $pic = trim($_POST['pic'] ?? '');
        
        if ($id <= 0 || empty($nama_supplier)) {
            $error = 'ID dan Nama Supplier wajib diisi!';
        } else {
            try {
                // Check duplicate name
                $chk = $pdo->prepare("SELECT COUNT(*) FROM supplier WHERE nama_supplier = ? AND id != ?");
                $chk->execute([$nama_supplier, $id]);
                if ($chk->fetchColumn() > 0) {
                    $error = 'Nama Supplier/Vendor sudah digunakan pada data lain!';
                } else {
                    $stmt = $pdo->prepare("UPDATE supplier SET nama_supplier = ?, alamat = ?, no_telp = ?, email = ?, pic = ? WHERE id = ?");
                    $stmt->execute([$nama_supplier, $alamat, $no_telp, $email, $pic, $id]);
                    
                    write_audit_log("Mengubah supplier/vendor ID $id menjadi: $nama_supplier.");
                    
                    $success = 'Supplier/Vendor berhasil diperbarui!';
                }
            } catch (Exception $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

// Handle Delete Supplier via GET
if (isset($_GET['delete_id'])) {
    require_role(['Super Admin', 'Admin']);
    $delete_id = intval($_GET['delete_id']);
    try {
        // Fetch name for audit log
        $name_stmt = $pdo->prepare("SELECT nama_supplier FROM supplier WHERE id = ?");
        $name_stmt->execute([$delete_id]);
        $name = $name_stmt->fetchColumn();

        $stmt = $pdo->prepare("DELETE FROM supplier WHERE id = ?");
        $stmt->execute([$delete_id]);
        
        write_audit_log("Menghapus supplier/vendor: $name (ID: $delete_id).");
        
        $success = 'Supplier/Vendor berhasil dihapus!';
    } catch (Exception $e) {
        $error = 'Gagal menghapus supplier/vendor: ' . $e->getMessage();
    }
}

// Load all suppliers
try {
    $suppliers = $pdo->query("SELECT * FROM supplier ORDER BY nama_supplier ASC")->fetchAll();
} catch (Exception $e) {
    $error = 'Gagal memuat supplier: ' . $e->getMessage();
    $suppliers = [];
}
?>

<div class="glass-card mb-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-truck-field me-2"></i> Supplier / Vendor Aset</h5>
            <p class="text-secondary small mb-0">Kelola daftar penyedia pengadaan barang, mebel, elektronik, dan sarana prasarana sekolah.</p>
        </div>
        <div>
            <?php if (has_role(['Super Admin', 'Admin'])): ?>
            <button class="btn btn-gold" data-bs-toggle="modal" data-bs-target="#addSupplierModal"><i class="fa-solid fa-plus me-1"></i> Tambah Supplier</button>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
    </div>
<?php endif; ?>

<?php if ($success !== ''): ?>
    <div class="alert alert-success border-0 text-white bg-success bg-opacity-25 small mb-4 py-2" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i> <?php echo htmlspecialchars($success); ?>
    </div>
<?php endif; ?>

<!-- Suppliers Table -->
<div class="glass-card">
    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th style="width: 80px;">No</th>
                    <th>Nama Supplier / Vendor</th>
                    <th>Alamat</th>
                    <th>Kontak / Telp</th>
                    <th>Email</th>
                    <th>PIC (Contact Person)</th>
                    <?php if (has_role(['Super Admin', 'Admin'])): ?>
                    <th style="text-align: right; width: 180px;" class="no-print">Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (count($suppliers) > 0): ?>
                    <?php $no = 1; foreach ($suppliers as $sup): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><strong class="text-white"><?php echo htmlspecialchars($sup['nama_supplier']); ?></strong></td>
                            <td><span class="text-secondary small"><?php echo htmlspecialchars($sup['alamat'] ?: '-'); ?></span></td>
                            <td><span class="text-white font-monospace"><?php echo htmlspecialchars($sup['no_telp'] ?: '-'); ?></span></td>
                            <td><span class="text-white"><?php echo htmlspecialchars($sup['email'] ?: '-'); ?></span></td>
                             <td><span class="text-gold"><i class="fa-solid fa-user me-1 text-gold" style="font-size: 10px;"></i> <?php echo htmlspecialchars($sup['pic'] ?: '-'); ?></span></td>
                            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                            <td style="text-align: right;" class="no-print">
                                <div class="d-flex gap-2 justify-content-end">
                                    <button class="btn btn-xs btn-outline-warning" 
                                            onclick="openEditModal(<?php echo $sup['id']; ?>, '<?php echo htmlspecialchars($sup['nama_supplier'], ENT_QUOTES); ?>', '<?php echo htmlspecialchars($sup['alamat'] ?? '', ENT_QUOTES); ?>', '<?php echo htmlspecialchars($sup['no_telp'] ?? '', ENT_QUOTES); ?>', '<?php echo htmlspecialchars($sup['email'] ?? '', ENT_QUOTES); ?>', '<?php echo htmlspecialchars($sup['pic'] ?? '', ENT_QUOTES); ?>')">
                                        <i class="fa-solid fa-pen"></i> Edit
                                    </button>
                                    <button class="btn btn-xs btn-outline-danger" 
                                             onclick="confirmDeleteSupplier(<?php echo $sup['id']; ?>, '<?php echo htmlspecialchars($sup['nama_supplier'], ENT_QUOTES); ?>')">
                                        <i class="fa-solid fa-trash"></i> Hapus
                                    </button>
                                </div>
                            </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center text-secondary py-4">Data supplier/vendor kosong.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Tambah Supplier -->
<div class="modal fade" id="addSupplierModal" tabindex="-1" aria-labelledby="addSupplierModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content bg-dark-select text-white border-gold-subtle" style="background-color: #0f172a; border: 1px solid rgba(212, 175, 55, 0.2); border-radius: 12px;">
            <div class="modal-header border-bottom-gold" style="border-bottom: 1px solid rgba(212, 175, 55, 0.2);">
                <h5 class="modal-title text-gold" id="addSupplierModalLabel"><i class="fa-solid fa-plus-circle me-2"></i> Tambah Supplier / Vendor</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="supplier.php">
                <?php csrf_input(); ?>
                <input type="hidden" name="action" value="add">
                
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="add_nama_supplier" class="form-label form-label-custom">Nama Supplier / Vendor <span class="text-danger">*</span></label>
                            <input type="text" name="nama_supplier" id="add_nama_supplier" class="form-control form-control-custom" placeholder="Nama CV/PT/Toko Penyedia" required>
                        </div>
                        <div class="col-md-6">
                            <label for="add_pic" class="form-label form-label-custom">PIC (Contact Person)</label>
                            <input type="text" name="pic" id="add_pic" class="form-control form-control-custom" placeholder="Nama Narahubung">
                        </div>
                        <div class="col-md-6">
                            <label for="add_no_telp" class="form-label form-label-custom">Nomor Telepon</label>
                            <input type="text" name="no_telp" id="add_no_telp" class="form-control form-control-custom" placeholder="Contoh: 0812345678">
                        </div>
                        <div class="col-md-6">
                            <label for="add_email" class="form-label form-label-custom">Email</label>
                            <input type="email" name="email" id="add_email" class="form-control form-control-custom" placeholder="Contoh: sales@vendor.com">
                        </div>
                        <div class="col-12">
                            <label for="add_alamat" class="form-label form-label-custom">Alamat Lengkap</label>
                            <textarea name="alamat" id="add_alamat" class="form-control form-control-custom" rows="3" placeholder="Alamat kantor/toko supplier"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-top-gold" style="border-top: 1px solid rgba(212, 175, 55, 0.2);">
                    <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-gold">Simpan Supplier <i class="fa-solid fa-check ms-1"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit Supplier -->
<div class="modal fade" id="editSupplierModal" tabindex="-1" aria-labelledby="editSupplierModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content bg-dark-select text-white border-gold-subtle" style="background-color: #0f172a; border: 1px solid rgba(212, 175, 55, 0.2); border-radius: 12px;">
            <div class="modal-header border-bottom-gold" style="border-bottom: 1px solid rgba(212, 175, 55, 0.2);">
                <h5 class="modal-title text-gold" id="editSupplierModalLabel"><i class="fa-solid fa-pen-to-square me-2"></i> Edit Supplier / Vendor</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="supplier.php">
                <?php csrf_input(); ?>
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit_id">
                
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="edit_nama_supplier" class="form-label form-label-custom">Nama Supplier / Vendor <span class="text-danger">*</span></label>
                            <input type="text" name="nama_supplier" id="edit_nama_supplier" class="form-control form-control-custom" required>
                        </div>
                        <div class="col-md-6">
                            <label for="edit_pic" class="form-label form-label-custom">PIC (Contact Person)</label>
                            <input type="text" name="pic" id="edit_pic" class="form-control form-control-custom">
                        </div>
                        <div class="col-md-6">
                            <label for="edit_no_telp" class="form-label form-label-custom">Nomor Telepon</label>
                            <input type="text" name="no_telp" id="edit_no_telp" class="form-control form-control-custom">
                        </div>
                        <div class="col-md-6">
                            <label for="edit_email" class="form-label form-label-custom">Email</label>
                            <input type="email" name="email" id="edit_email" class="form-control form-control-custom">
                        </div>
                        <div class="col-12">
                            <label for="edit_alamat" class="form-label form-label-custom">Alamat Lengkap</label>
                            <textarea name="alamat" id="edit_alamat" class="form-control form-control-custom" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-top-gold" style="border-top: 1px solid rgba(212, 175, 55, 0.2);">
                    <button type="button" class="btn btn-outline-custom" data-bs-toggle="modal" data-bs-target="#editSupplierModal">Batal</button>
                    <button type="submit" class="btn btn-gold">Simpan Perubahan <i class="fa-solid fa-check ms-1"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openEditModal(id, nama, alamat, telp, email, pic) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_nama_supplier').value = nama;
    document.getElementById('edit_alamat').value = alamat;
    document.getElementById('edit_no_telp').value = telp;
    document.getElementById('edit_email').value = email;
    document.getElementById('edit_pic').value = pic;
    
    const editModal = new bootstrap.Modal(document.getElementById('editSupplierModal'));
    editModal.show();
}

function confirmDeleteSupplier(id, name) {
    Swal.fire({
        title: 'Hapus Supplier?',
        text: `Apakah Anda yakin ingin menghapus data supplier/vendor "${name}"?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = `supplier.php?delete_id=${id}`;
        }
    });
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
