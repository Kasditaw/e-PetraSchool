<?php
// c:\xampp\htdocs\e-petraschool1\config\db.php

// ── Load Environment Configuration ──────────────────────────────────────────
$env_path = __DIR__ . '/env.php';
if (file_exists($env_path)) {
    $env = require $env_path;
} else {
    // Fallback defaults for local XAMPP development
    $env = [
        'APP_ENV'     => 'development',
        'DB_HOST'     => 'localhost',
        'DB_NAME'     => 'db_petraschool',
        'DB_USER'     => 'root',
        'DB_PASS'     => '',
        'DB_CHARSET'  => 'utf8mb4',
    ];
}

// ── Production Error Handling ────────────────────────────────────────────────
if (($env['APP_ENV'] ?? 'development') === 'production') {
    ini_set('display_errors', 0);
    ini_set('display_startup_errors', 0);
    error_reporting(E_ALL);
    ini_set('log_errors', 1);
    // Log to a file in the same directory (protected by .htaccess)
    ini_set('error_log', dirname(__DIR__) . '/error.log');
} else {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
}

// ── Database Connection ─────────────────────────────────────────────────────
$host    = $env['DB_HOST'] ?? 'localhost';
$db      = $env['DB_NAME'] ?? 'db_petraschool';
$user    = $env['DB_USER'] ?? 'root';
$pass    = $env['DB_PASS'] ?? '';
$charset = $env['DB_CHARSET'] ?? 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    // ── Development Mode: Auto-create database if it doesn't exist ──────────
    if (($env['APP_ENV'] ?? 'development') === 'development') {
        // Hubungkan ke MySQL server terlebih dahulu tanpa database
        $pdo = new PDO("mysql:host=$host;charset=$charset", $user, $pass, $options);

        // Buat database jika belum ada
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `$db`");

        // Periksa apakah tabel 'roles' sudah ada
        $stmt = $pdo->query("SHOW TABLES LIKE 'roles'");
        if ($stmt->rowCount() == 0) {
            // Jika tabel 'roles' tidak ada, berarti database belum diinisialisasi.
            $pdo->exec("DROP DATABASE IF EXISTS `$db`");
            $pdo->exec("CREATE DATABASE `$db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `$db`");

            // Lakukan auto-import skema dan dummy data dari database.sql
            $sql_path = dirname(__DIR__) . '/database/database.sql';
            if (file_exists($sql_path)) {
                $sql = file_get_contents($sql_path);

                // Bersihkan komentar SQL
                $sql = preg_replace('/--.*\n/', '', $sql);

                // Pecah kueri berdasarkan karakter titik koma (;)
                $queries = explode(';', $sql);

                foreach ($queries as $query) {
                    $query = trim($query);
                    if ($query !== '') {
                        $pdo->exec($query);
                    }
                }
            }
        }
    } else {
        // ── Production Mode: Connect directly to existing database ──────────
        $pdo = new PDO($dsn, $user, $pass, $options);
    }
} catch (\PDOException $e) {
    // Log technical error details to PHP error log (not shown to users)
    error_log("Database connection failed: " . $e->getMessage());

    // If this is an AJAX/JSON request, respond with JSON error instead of plain text
    $isAjax = (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
              || (isset($_GET['action']) && $_SERVER['REQUEST_METHOD'] === 'POST');
    if ($isAjax) {
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Koneksi database gagal. Silakan hubungi administrator.']);
        exit;
    }

    // Show a generic, safe message to the user (HTML page context)
    die("Koneksi database gagal. Silakan hubungi administrator sistem.");
}
?>
