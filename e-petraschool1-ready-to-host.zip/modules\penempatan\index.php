<?php
// c:\xampp\htdocs\e-petraschool1\modules\penempatan\index.php

$page_title = 'Penempatan Kelas';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';
$success = '';

try {
    // Fetch all academic years
    $years = $pdo->query("SELECT * FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();
    $active_year = $pdo->query("SELECT id, status FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1")->fetch();
    $active_year_id = $active_year['id'] ?? 0;
    
    // Selected parameters
    $filter_year_id = isset($_GET['tahun_ajaran_id']) ? intval($_GET['tahun_ajaran_id']) : $active_year_id;
    
    // Fetch all classes
    $classes = $pdo->query("SELECT id, nama_kelas FROM kelas WHERE status = 'Aktif' ORDER BY nama_kelas ASC")->fetchAll();
    $filter_class_id = isset($_GET['kelas_id']) ? intval($_GET['kelas_id']) : ($classes[0]['id'] ?? 0);

    // Handle assignments (Place Students)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'place_students') {
        check_csrf_request();
        
        $target_class = intval($_POST['class_id'] ?? 0);
        $target_year = intval($_POST['year_id'] ?? 0);
        $selected_siswa = $_POST['siswa_ids'] ?? [];

        if ($target_class > 0 && $target_year > 0 && !empty($selected_siswa)) {
            $pdo->beginTransaction();
            
            $place_stmt = $pdo->prepare("INSERT IGNORE INTO riwayat_kelas (siswa_id, kelas_id, tahun_ajaran_id, tanggal_masuk, status) VALUES (?, ?, ?, ?, 'Aktif')");
            $sync_stmt = $pdo->prepare("UPDATE siswa SET kelas_id = ? WHERE id = ?");
            
            $today = date('Y-m-d');
            $count = 0;
            
            foreach ($selected_siswa as $siswa_id) {
                $place_stmt->execute([intval($siswa_id), $target_class, $target_year, $today]);
                if ($place_stmt->rowCount() > 0) {
                    $count++;
                    // If target year is active, sync with student's current class_id
                    if ($target_year === $active_year_id) {
                        $sync_stmt->execute([$target_class, intval($siswa_id)]);
                    }
                }
            }
            
            $pdo->commit();
            write_audit_log("Menempatkan $count siswa ke Kelas ID $target_class (Tahun Ajaran ID $target_year).");
            
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire('Berhasil', '$count siswa berhasil ditempatkan!', 'success').then(() => {
                        window.location.href = 'index.php?kelas_id=$target_class&tahun_ajaran_id=$target_year';
                    });
                });
            </script>";
            exit;
        } else {
            $error = 'Harap pilih kelas, tahun ajaran, dan minimal satu siswa!';
        }
    }

    // Handle removal (Remove Student)
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'remove_student') {
        check_csrf_request();
        
        $hist_id = intval($_POST['history_id'] ?? 0);
        $target_class = intval($_POST['class_id'] ?? 0);
        $target_year = intval($_POST['year_id'] ?? 0);
        
        // Fetch placement details
        $find_stmt = $pdo->prepare("SELECT siswa_id FROM riwayat_kelas WHERE id = ?");
        $find_stmt->execute([$hist_id]);
        $placement = $find_stmt->fetch();
        
        if ($placement) {
            $siswa_id = $placement['siswa_id'];
            
            $pdo->beginTransaction();
            
            // Delete record
            $del_stmt = $pdo->prepare("DELETE FROM riwayat_kelas WHERE id = ?");
            $del_stmt->execute([$hist_id]);
            
            // If target year is active, set student's class to NULL
            if ($target_year === $active_year_id) {
                $unsync_stmt = $pdo->prepare("UPDATE siswa SET kelas_id = NULL WHERE id = ? AND kelas_id = ?");
                $unsync_stmt->execute([$siswa_id, $target_class]);
            }
            
            $pdo->commit();
            write_audit_log("Menghapus penempatan kelas untuk Siswa ID $siswa_id dari Kelas ID $target_class (Tahun Ajaran ID $target_year).");
            
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire('Berhasil', 'Penempatan siswa berhasil dihapus!', 'success').then(() => {
                        window.location.href = 'index.php?kelas_id=$target_class&tahun_ajaran_id=$target_year';
                    });
                });
            </script>";
            exit;
        }
    }

    // Load placed students
    $placed_stmt = $pdo->prepare("
        SELECT r.id as history_id, s.id as siswa_id, s.nis, s.nisn, s.nama_lengkap, s.gender, r.tanggal_masuk 
        FROM riwayat_kelas r
        JOIN siswa s ON r.siswa_id = s.id
        WHERE r.kelas_id = ? AND r.tahun_ajaran_id = ?
        ORDER BY s.nama_lengkap ASC
    ");
    $placed_stmt->execute([$filter_class_id, $filter_year_id]);
    $placed_students = $placed_stmt->fetchAll();

    // Load unplaced students
    $unplaced_stmt = $pdo->prepare("
        SELECT id, nis, nisn, nama_lengkap, gender 
        FROM siswa 
        WHERE status_siswa = 'Aktif' 
        AND id NOT IN (SELECT siswa_id FROM riwayat_kelas WHERE tahun_ajaran_id = ?)
        ORDER BY nama_lengkap ASC
    ");
    $unplaced_stmt->execute([$filter_year_id]);
    $unplaced_students = $unplaced_stmt->fetchAll();

} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}
?>

<div class="glass-card mb-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-user-tag me-2"></i> Penempatan Kelas Siswa</h5>
            <p class="text-secondary small mb-0">Kelola distribusi siswa ke rombel kelas sesuai tahun ajaran akademik.</p>
        </div>
        <div class="d-flex gap-2">
            <a href="kenaikan.php" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-angles-up me-1"></i> Kenaikan Kelas Massal</a>
        </div>
    </div>
</div>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
    </div>
<?php endif; ?>

<!-- Filter Panel -->
<div class="glass-card mb-4" style="background: rgba(18, 28, 54, 0.15);">
    <form method="GET" action="index.php" class="row g-3 align-items-end">
        <div class="col-12 col-md-4">
            <label class="form-label form-label-custom">Tahun Ajaran</label>
            <select name="tahun_ajaran_id" class="form-select form-control-custom bg-dark-select text-white">
                <?php foreach ($years as $yr): ?>
                    <option value="<?php echo $yr['id']; ?>" <?php echo $filter_year_id == $yr['id'] ? 'selected' : ''; ?>>
                        Tahun Ajaran <?php echo htmlspecialchars($yr['tahun_ajaran']); ?> <?php echo $yr['status'] === 'Aktif' ? '(Aktif)' : ''; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-md-4">
            <label class="form-label form-label-custom">Kelas Tujuan</label>
            <select name="kelas_id" class="form-select form-control-custom bg-dark-select text-white">
                <?php foreach ($classes as $cl): ?>
                    <option value="<?php echo $cl['id']; ?>" <?php echo $filter_class_id == $cl['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($cl['nama_kelas']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">Tampilkan Siswa</button>
        </div>
    </form>
</div>

<div class="row g-4">
    <!-- Placed Students List (Left Column) -->
    <div class="col-lg-6">
        <div class="glass-card h-100">
            <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-user-check me-2"></i> Siswa Terdaftar di Kelas ini (<?php echo count($placed_students); ?>)</h6>
            
            <div class="table-responsive">
                <table class="table table-custom">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIS / Nama</th>
                            <th>L/P</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($placed_students) > 0): ?>
                            <?php $no = 1; foreach ($placed_students as $std): ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td>
                                        <strong class="text-white d-block"><?php echo htmlspecialchars($std['nama_lengkap']); ?></strong>
                                        <span class="text-secondary small font-monospace">NIS: <?php echo htmlspecialchars($std['nis']); ?></span>
                                    </td>
                                    <td><?php echo htmlspecialchars($std['gender']); ?></td>
                                    <td>
                                        <form method="POST" action="index.php?kelas_id=<?php echo $filter_class_id; ?>&tahun_ajaran_id=<?php echo $filter_year_id; ?>" onsubmit="return confirm('Apakah Anda yakin ingin mengeluarkan siswa ini dari kelas?')">
                                            <?php csrf_input(); ?>
                                            <input type="hidden" name="action" value="remove_student">
                                            <input type="hidden" name="history_id" value="<?php echo $std['history_id']; ?>">
                                            <input type="hidden" name="class_id" value="<?php echo $filter_class_id; ?>">
                                            <input type="hidden" name="year_id" value="<?php echo $filter_year_id; ?>">
                                            <button type="submit" class="btn btn-xs btn-outline-danger" title="Keluarkan dari kelas"><i class="fa-solid fa-user-minus"></i> Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center text-secondary py-4">Belum ada siswa terdaftar pada kelas ini.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Unplaced Students Placement (Right Column) -->
    <div class="col-lg-6">
        <div class="glass-card h-100">
            <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-user-slash me-2"></i> Siswa Belum Ditempatkan (<?php echo count($unplaced_students); ?>)</h6>
            
            <form method="POST" action="index.php?kelas_id=<?php echo $filter_class_id; ?>&tahun_ajaran_id=<?php echo $filter_year_id; ?>">
                <?php csrf_input(); ?>
                <input type="hidden" name="action" value="place_students">
                <input type="hidden" name="class_id" value="<?php echo $filter_class_id; ?>">
                <input type="hidden" name="year_id" value="<?php echo $filter_year_id; ?>">

                <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                    <table class="table table-custom">
                        <thead>
                            <tr>
                                <th style="width: 40px;">
                                    <input type="checkbox" id="select-all" class="form-check-input">
                                </th>
                                <th>NIS / Nama</th>
                                <th>L/P</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($unplaced_students) > 0): ?>
                                <?php foreach ($unplaced_students as $std): ?>
                                    <tr>
                                        <td>
                                            <input type="checkbox" name="siswa_ids[]" value="<?php echo $std['id']; ?>" class="form-check-input siswa-chk">
                                        </td>
                                        <td>
                                            <strong class="text-white d-block"><?php echo htmlspecialchars($std['nama_lengkap']); ?></strong>
                                            <span class="text-secondary small font-monospace">NIS: <?php echo htmlspecialchars($std['nis']); ?></span>
                                        </td>
                                        <td><?php echo htmlspecialchars($std['gender']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="3" class="text-center text-secondary py-4">Semua siswa aktif sudah terdaftar di kelas.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if (count($unplaced_students) > 0): ?>
                    <div class="mt-4 text-end">
                        <button type="submit" class="btn btn-gold w-100">Tempatkan Siswa Terpilih <i class="fa-solid fa-user-check ms-1"></i></button>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('select-all')?.addEventListener('change', function(e) {
    const chks = document.querySelectorAll('.siswa-chk');
    chks.forEach(chk => {
        chk.checked = e.target.checked;
    });
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
