<?php
// c:\xampp\htdocs\e-petraschool1\modules\semester\delete.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    try {
        // Fetch info for audit log
        $stmt = $pdo->prepare("SELECT semester FROM semester WHERE id = ?");
        $stmt->execute([$id]);
        $sm = $stmt->fetch();

        if ($sm) {
            // Delete semester
            $delete_stmt = $pdo->prepare("DELETE FROM semester WHERE id = ?");
            $delete_stmt->execute([$id]);
            
            write_audit_log("Menghapus semester: " . $sm['semester'] . ".");
        }
    } catch (Exception $e) {
        error_log("Failed to delete semester: " . $e->getMessage());
    }
}

header("Location: index.php");
exit;
?>
