<?php
// c:\xampp\htdocs\e-petraschool1\modules\jurnal\verifikasi.php

$page_title = 'Verifikasi Jurnal Mengajar';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin', 'Kepala Sekolah']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';

try {
    // Load journal info
    $jurnal_stmt = $pdo->prepare("SELECT j.*, g.nama_guru, g.nip, s.semester, t.tahun_ajaran 
                                  FROM jurnal_mengajar j
                                  JOIN guru g ON j.guru_id = g.id
                                  JOIN semester s ON j.semester_id = s.id
                                  JOIN tahun_ajaran t ON j.tahun_ajaran_id = t.id
                                  WHERE j.id = ?");
    $jurnal_stmt->execute([$id]);
    $jurnal = $jurnal_stmt->fetch();

    if (!$jurnal) {
        die('<div class="alert alert-danger">Jurnal mengajar tidak ditemukan!</div>');
    }

    // Load classes & subjects
    $details_stmt = $pdo->prepare("SELECT d.*, m.nama_mapel, m.kode_mapel, k.nama_kelas 
                                  FROM jurnal_mengajar_detail d
                                  LEFT JOIN mata_pelajaran m ON d.mapel_id = m.id
                                  LEFT JOIN kelas k ON d.kelas_id = k.id
                                  WHERE d.jurnal_id = ?
                                  ORDER BY d.jam_ke ASC");
    $details_stmt->execute([$id]);
    $details = $details_stmt->fetchAll();

    // Load existing verification
    $ver_stmt = $pdo->prepare("SELECT v.*, u.nama as nama_verifikator 
                               FROM verifikasi_jurnal v 
                               LEFT JOIN users u ON v.verifikator_id = u.id 
                               WHERE v.jurnal_id = ?");
    $ver_stmt->execute([$id]);
    $verification = $ver_stmt->fetch();

} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!has_role('Kepala Sekolah')) {
        die('<div class="alert alert-danger">Akses ditolak! Hanya Kepala Sekolah yang dapat melakukan verifikasi.</div>');
    }
    check_csrf_request();

    $status = $_POST['status'] ?? '';
    $catatan = trim($_POST['catatan'] ?? '');
    $verifikator_id = $_SESSION['user_id'];
    $signature_data = $_POST['signature_data'] ?? ''; // base64 string
    
    // File upload fallback
    if (isset($_FILES['signature_file']) && $_FILES['signature_file']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['signature_file']['tmp_name'];
        $file_name = $_FILES['signature_file']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed_exts = ['jpg', 'jpeg', 'png'];
        if (in_array($file_ext, $allowed_exts)) {
            $data = file_get_contents($file_tmp);
            $signature_data = 'data:image/' . $file_ext . ';base64,' . base64_encode($data);
        }
    }

    // Preserve existing signature if not provided
    if (empty($signature_data) && $verification && !empty($verification['tanda_tangan'])) {
        $signature_data = $verification['tanda_tangan'];
    }

    if (empty($status)) {
        $error = 'Pilihan status verifikasi wajib dipilih!';
    } else {
        try {
            $pdo->beginTransaction();

            // Update status in jurnal_mengajar
            $upd = $pdo->prepare("UPDATE jurnal_mengajar SET status = ? WHERE id = ?");
            $upd->execute([$status, $id]);

            // Save in verifikasi_jurnal
            $save_ver = $pdo->prepare("INSERT INTO verifikasi_jurnal (jurnal_id, verifikator_id, catatan, tanda_tangan) 
                                       VALUES (?, ?, ?, ?) 
                                       ON DUPLICATE KEY UPDATE verifikator_id = ?, catatan = ?, tanda_tangan = ?, tanggal_verifikasi = CURRENT_TIMESTAMP");
            $save_ver->execute([$id, $verifikator_id, $catatan, $signature_data, $verifikator_id, $catatan, $signature_data]);

            // Fetch teacher user ID to send notification
            $usr_stmt = $pdo->prepare("SELECT id FROM users WHERE guru_id = ? LIMIT 1");
            $usr_stmt->execute([$jurnal['guru_id']]);
            $teacher_user_id = $usr_stmt->fetchColumn();

            if ($teacher_user_id) {
                $pesan = "Jurnal mengajar Anda tanggal <strong>" . date('d/m/Y', strtotime($jurnal['tanggal'])) . "</strong> telah <strong>" . $status . "</strong>.";
                if (!empty($catatan)) {
                    $pesan .= " Catatan Kepala Sekolah: <em>\"" . htmlspecialchars($catatan) . "\"</em>";
                }
                
                $ins_notif = $pdo->prepare("INSERT INTO notifikasi (user_id, pesan) VALUES (?, ?)");
                $ins_notif->execute([$teacher_user_id, $pesan]);
            }

            $pdo->commit();

            write_audit_log("Melakukan verifikasi jurnal ID: $id dengan status: $status.");

            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire('Berhasil', 'Verifikasi jurnal berhasil disimpan!', 'success').then(() => {
                        window.location.href = 'index.php';
                    });
                });
            </script>";

        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = 'Database Error: ' . $e->getMessage();
        }
    }
}
?>

<div class="row g-4">
    <!-- Left column: Journal detail viewer -->
    <div class="col-lg-8">
        <div class="glass-card">
            <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom border-secondary border-opacity-10">
                <h5 class="text-gold fw-bold mb-0"><i class="fa-solid fa-book-open me-2"></i> Rincian Jurnal Mengajar</h5>
                <span class="badge badge-secondary"><?php echo htmlspecialchars($jurnal['status']); ?></span>
            </div>

            <!-- Identity grid -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <span class="text-secondary small d-block">Nama Guru</span>
                    <strong class="text-white"><?php echo htmlspecialchars($jurnal['nama_guru']); ?></strong>
                </div>
                <div class="col-6 col-md-3">
                    <span class="text-secondary small d-block">NIP</span>
                    <strong class="text-white font-monospace"><?php echo htmlspecialchars($jurnal['nip']); ?></strong>
                </div>
                <div class="col-6 col-md-3">
                    <span class="text-secondary small d-block">Hari & Tanggal</span>
                    <strong class="text-white"><?php echo htmlspecialchars($jurnal['hari']) . ', ' . date('d M Y', strtotime($jurnal['tanggal'])); ?></strong>
                </div>
                <div class="col-6 col-md-3">
                    <span class="text-secondary small d-block">Tahun Ajaran / Semester</span>
                    <strong class="text-white"><?php echo htmlspecialchars($jurnal['tahun_ajaran'] . ' - ' . $jurnal['semester']); ?></strong>
                </div>
            </div>

            <!-- Hourly activities -->
            <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-list-check me-2"></i> Kegiatan Belajar Mengajar Harian</h6>
            <div class="table-responsive mb-4">
                <table class="table table-custom table-bordered" style="border-color: var(--border-color);">
                    <thead>
                        <tr>
                            <th style="width: 80px; text-align: center;">Jam Ke</th>
                            <th>Mata Pelajaran</th>
                            <th>Kelas</th>
                            <th>Materi Pembelajaran</th>
                            <th>Kegiatan Pembelajaran</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($details) > 0): ?>
                            <?php foreach ($details as $d): ?>
                                <tr>
                                    <td class="text-center fw-bold text-white"># <?php echo $d['jam_ke']; ?></td>
                                    <td class="fw-semibold text-white"><?php echo htmlspecialchars($d['nama_mapel'] ?? '-'); ?></td>
                                    <td><?php echo htmlspecialchars($d['nama_kelas'] ?? '-'); ?></td>
                                    <td><?php echo htmlspecialchars($d['materi']); ?></td>
                                    <td><?php echo htmlspecialchars($d['kegiatan']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-secondary py-3">Tidak ada detail KBM yang diisi.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <!-- Signatures display -->
            <div class="row g-3">
                <div class="col-6">
                    <span class="text-secondary small d-block mb-2">Tanda Tangan Guru</span>
                    <?php if (!empty($jurnal['tanda_tangan'])): ?>
                        <div class="p-2 bg-white rounded border d-inline-block" style="width: 150px; height: 80px; display: flex; align-items: center; justify-content: center;">
                            <img src="<?php echo $jurnal['tanda_tangan']; ?>" alt="Signature" style="max-width: 100%; max-height: 100%; object-fit: contain;">
                        </div>
                    <?php else: ?>
                        <span class="text-secondary small italic">Tidak ada tanda tangan.</span>
                    <?php endif; ?>
                </div>

                <div class="col-6">
                    <span class="text-secondary small d-block mb-2">Tanda Tangan Verifikator (Kepala Sekolah)</span>
                    <?php if ($verification && !empty($verification['nama_verifikator'])): ?>
                        <?php if (!empty($verification['tanda_tangan'])): ?>
                            <div class="p-2 bg-white rounded border d-inline-block mb-2" style="width: 150px; height: 80px; display: flex; align-items: center; justify-content: center;">
                                <img src="<?php echo $verification['tanda_tangan']; ?>" alt="Signature" style="max-width: 100%; max-height: 100%; object-fit: contain;">
                            </div>
                        <?php endif; ?>
                        <strong class="text-white d-block"><?php echo htmlspecialchars($verification['nama_verifikator']); ?></strong>
                        <span class="text-secondary small"><?php echo date('d/m/Y H:i', strtotime($verification['tanggal_verifikasi'])); ?></span>
                    <?php else: ?>
                        <span class="text-secondary small italic">Belum diverifikasi.</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Right column: Verification Form -->
    <div class="col-lg-4">
        <div class="glass-card">
            <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-clipboard-check me-2"></i> Rubrik Verifikasi & Supervisi</h5>

            <?php if (has_role('Kepala Sekolah')): ?>
                <?php if ($error !== ''): ?>
                    <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
                        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="verifikasi.php?id=<?php echo $id; ?>" enctype="multipart/form-data" id="verifikasi-form">
                    <?php csrf_input(); ?>

                    <div class="mb-3">
                        <label for="status" class="form-label form-label-custom">Status Verifikasi <span class="text-danger">*</span></label>
                        <select name="status" id="status" class="form-select form-control-custom bg-dark-select text-white" required>
                            <option value="" disabled selected>Pilih...</option>
                            <option value="Disetujui" <?php echo $jurnal['status'] === 'Disetujui' ? 'selected' : ''; ?>>Disetujui (Approve)</option>
                            <option value="Revisi" <?php echo $jurnal['status'] === 'Revisi' ? 'selected' : ''; ?>>Revisi (Perlu Perbaikan)</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="catatan" class="form-label form-label-custom">Catatan Kepala Sekolah / Supervisi Akademik</label>
                        <textarea name="catatan" id="catatan" class="form-control form-control-custom" rows="3" placeholder="Masukkan saran supervisi atau alasan jika status Revisi..."><?php echo htmlspecialchars($verification['catatan'] ?? ''); ?></textarea>
                    </div>

                    <!-- Signature Section -->
                    <div class="mb-3">
                        <label class="form-label form-label-custom">Tanda Tangan Digital Verifikator <span class="text-danger">*</span></label>
                        <div class="glass-card mb-2 p-0 position-relative" style="background: rgba(0,0,0,0.4); border: 2px dashed var(--border-color); overflow: hidden;">
                            <canvas id="sig-canvas" width="450" height="180" style="cursor: crosshair; touch-action: none; width: 100%; display: block;"></canvas>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <button type="button" class="btn btn-xs btn-outline-warning" id="btn-clear-sig"><i class="fa-solid fa-rotate-left me-1"></i> Bersihkan</button>
                            <span class="text-secondary small">Gambar tanda tangan di atas.</span>
                        </div>
                        <input type="hidden" name="signature_data" id="signature_data">
                    </div>

                    <div class="mb-4">
                        <label class="form-label form-label-custom">Alternatif: Unggah Tanda Tangan (Format Gambar)</label>
                        <div class="p-3 rounded border border-secondary border-opacity-10 bg-dark bg-opacity-25 text-center d-flex flex-column align-items-center justify-content-center">
                            <i class="fa-solid fa-file-image text-secondary mb-2" style="font-size: 24px;"></i>
                            <input type="file" name="signature_file" id="signature_file" class="form-control form-control-custom w-100" accept="image/*">
                            <span class="text-secondary small mt-1">Pilih file scan/foto jika tidak ingin menggambar.</span>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-gold w-100 py-2.5" id="btn-submit-verifikasi">Simpan Hasil Verifikasi <i class="fa-solid fa-circle-check ms-1"></i></button>
                </form>
            <?php else: ?>
                <div class="alert alert-info py-3 text-center mb-0">
                    <i class="fa-solid fa-info-circle me-1"></i> Hanya Kepala Sekolah yang dapat melakukan verifikasi jurnal ini.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Signature Canvas Drawing Script -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const canvas = document.getElementById('sig-canvas');
    const ctx = canvas.getContext('2d');
    const clearBtn = document.getElementById('btn-clear-sig');
    const signatureInput = document.getElementById('signature_data');
    const form = document.getElementById('verifikasi-form');
    const fileInput = document.getElementById('signature_file');
    
    ctx.strokeStyle = "#000000"; // Black color brush
    ctx.lineWidth = 3;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';

    let drawing = false;
    let lastX = 0;
    let lastY = 0;

    // Get Mouse/Touch Position relative to Canvas
    function getPos(e) {
        const rect = canvas.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        
        return {
            x: (clientX - rect.left) * (canvas.width / rect.width),
            y: (clientY - rect.top) * (canvas.height / rect.height)
        };
    }

    function startDrawing(e) {
        drawing = true;
        const pos = getPos(e);
        lastX = pos.x;
        lastY = pos.y;
    }

    function draw(e) {
        if (!drawing) return;
        e.preventDefault();
        const pos = getPos(e);

        ctx.beginPath();
        ctx.moveTo(lastX, lastY);
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();

        lastX = pos.x;
        lastY = pos.y;
    }

    function stopDrawing() {
        drawing = false;
    }

    // Mouse Events
    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseout', stopDrawing);

    // Touch Events for Mobile
    canvas.addEventListener('touchstart', startDrawing);
    canvas.addEventListener('touchmove', draw);
    canvas.addEventListener('touchend', stopDrawing);

    // Clear Canvas
    clearBtn.addEventListener('click', function() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        signatureInput.value = '';
    });

    // On Form Submit, extract canvas image data
    form.addEventListener('submit', function(e) {
        const isBlank = isCanvasBlank(canvas);
        const hasExistingSig = <?php echo ($verification && !empty($verification['tanda_tangan'])) ? 'true' : 'false'; ?>;
        const statusVal = document.getElementById('status').value;

        if (!isBlank) {
            const dataUrl = canvas.toDataURL('image/png');
            signatureInput.value = dataUrl;
        }

        // Require signature only if status is "Disetujui" and there is no signature yet
        if (statusVal === 'Disetujui' && isBlank && !hasExistingSig && fileInput.files.length === 0) {
            e.preventDefault();
            Swal.fire({
                icon: 'warning',
                title: 'Tanda Tangan Diperlukan',
                text: 'Harap bubuhkan tanda tangan Anda terlebih dahulu untuk menyetujui jurnal mengajar ini!'
            });
        }
    });

    function isCanvasBlank(c) {
        const blank = document.createElement('canvas');
        blank.width = c.width;
        blank.height = c.height;
        return c.toDataURL() === blank.toDataURL();
    }
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
