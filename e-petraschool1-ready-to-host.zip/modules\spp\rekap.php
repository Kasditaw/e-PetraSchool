<?php
// c:\xampp\htdocs\e-petraschool1\modules\spp\rekap.php

$page_title = 'Rekap SPP Bulanan';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$filter_bulan = isset($_GET['bulan']) ? intval($_GET['bulan']) : intval(date('m'));
$filter_tahun = isset($_GET['tahun']) ? intval($_GET['tahun']) : intval(date('Y'));
$filter_kelas = isset($_GET['kelas_id']) ? intval($_GET['kelas_id']) : 0;
$bulan_names  = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

try {
    $kelas_list = $pdo->query("SELECT id,nama_kelas FROM kelas WHERE status='Aktif' ORDER BY nama_kelas ASC")->fetchAll();

    $q = "SELECT t.*, s.nama_lengkap, s.nis, k.nama_kelas,
                 COALESCE((SELECT SUM(p.jumlah_bayar) FROM spp_pembayaran p WHERE p.tagihan_id=t.id),0) AS total_bayar
          FROM spp_tagihan t JOIN siswa s ON t.siswa_id=s.id LEFT JOIN kelas k ON t.kelas_id=k.id
          WHERE t.bulan=? AND t.tahun=?";
    $params = [$filter_bulan,$filter_tahun];
    if ($filter_kelas) { $q .= " AND t.kelas_id=?"; $params[] = $filter_kelas; }
    $q .= " ORDER BY k.nama_kelas, s.nama_lengkap";
    $stmt = $pdo->prepare($q); $stmt->execute($params);
    $rekap = $stmt->fetchAll();

    $total_nominal  = array_sum(array_column($rekap,'nominal'));
    $total_terbayar = array_sum(array_column($rekap,'total_bayar'));
    $lunas  = count(array_filter($rekap,fn($r)=>$r['status']==='Lunas'));
    $belum  = count(array_filter($rekap,fn($r)=>$r['status']==='Belum Bayar'));
    $cicil  = count(array_filter($rekap,fn($r)=>$r['status']==='Cicil'));

} catch (Exception $e) { $rekap=[]; $error_db=$e->getMessage(); }
?>
<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-table-list me-2"></i>Rekap SPP — <?php echo $bulan_names[$filter_bulan]; ?> <?php echo $filter_tahun; ?></h5>
            <p class="text-secondary small mb-0">Ringkasan status pembayaran SPP semua siswa per bulan.</p>
        </div>
        <div class="d-flex gap-2 no-print">
            <button onclick="window.print()" class="btn btn-outline-custom"><i class="fa-solid fa-print me-1"></i> Cetak</button>
            <a href="index.php" class="btn btn-gold"><i class="fa-solid fa-arrow-left me-1"></i> Kembali</a>
        </div>
    </div>

    <?php if (isset($error_db)): ?><div class="alert alert-danger">Tabel belum tersedia. Jalankan: <a href="<?php echo $base_url; ?>database/migrate_ekskul_spp.php" class="alert-link">migrate_ekskul_spp.php</a></div><?php endif; ?>

    <!-- Filter -->
    <form method="GET" class="row g-3 mb-4 align-items-end no-print">
        <div class="col-6 col-md-3"><label class="form-label form-label-custom">Bulan</label><select name="bulan" class="form-select form-control-custom bg-dark-select text-white"><?php for ($m=1;$m<=12;$m++): ?><option value="<?php echo $m; ?>" <?php echo $filter_bulan==$m?'selected':''; ?>><?php echo $bulan_names[$m]; ?></option><?php endfor; ?></select></div>
        <div class="col-6 col-md-2"><label class="form-label form-label-custom">Tahun</label><input type="number" name="tahun" class="form-control form-control-custom" value="<?php echo $filter_tahun; ?>"></div>
        <div class="col-6 col-md-3"><label class="form-label form-label-custom">Kelas</label><select name="kelas_id" class="form-select form-control-custom bg-dark-select text-white"><option value="">Semua</option><?php foreach ($kelas_list as $kl): ?><option value="<?php echo $kl['id']; ?>" <?php echo $filter_kelas==$kl['id']?'selected':''; ?>><?php echo htmlspecialchars($kl['nama_kelas']); ?></option><?php endforeach; ?></select></div>
        <div class="col-auto"><button type="submit" class="btn btn-outline-custom"><i class="fa-solid fa-filter me-1"></i> Filter</button></div>
    </form>

    <!-- Stats -->
    <?php if (!empty($rekap)): ?>
    <div class="row g-3 mb-4">
        <?php foreach (['Total Tagihan'=>[count($rekap),'#D4AF37','money-bill-wave'],'Lunas'=>[$lunas,'#10B981','check-circle'],'Belum Bayar'=>[$belum,'#EF4444','xmark-circle'],'Cicil'=>[$cicil,'#F59E0B','circle-half-stroke']] as $lbl=>$v): ?>
        <div class="col-6 col-md-3"><div style="background:<?php echo $v[1]; ?>12;border:1px solid <?php echo $v[1]; ?>33;border-radius:10px;padding:14px;text-align:center;"><div class="fw-bold" style="font-size:22px;color:<?php echo $v[1]; ?>"><?php echo $v[0]; ?></div><div class="text-secondary small"><?php echo $lbl; ?></div></div></div>
        <?php endforeach; ?>
    </div>
    <div class="row g-3 mb-4">
        <div class="col-6"><div style="background:rgba(255,255,255,.04);border-radius:10px;padding:14px;"><div class="text-secondary small">Total Tagihan (Nominal)</div><div class="fw-bold text-white" style="font-size:16px;">Rp <?php echo number_format($total_nominal,0,',','.'); ?></div></div></div>
        <div class="col-6"><div style="background:rgba(16,185,129,.07);border-radius:10px;padding:14px;"><div class="text-secondary small">Total Terbayar</div><div class="fw-bold" style="font-size:16px;color:#10B981;">Rp <?php echo number_format($total_terbayar,0,',','.'); ?></div></div></div>
    </div>
    <div class="table-responsive">
        <table class="table table-custom" style="font-size:12px;">
            <thead><tr><th>#</th><th>Siswa</th><th>Kelas</th><th style="text-align:right;">Nominal</th><th style="text-align:right;">Terbayar</th><th style="text-align:right;">Sisa</th><th style="text-align:center;">Status</th></tr></thead>
            <tbody>
                <?php $no=1; $sc_map=['Lunas'=>'#10B981','Belum Bayar'=>'#EF4444','Cicil'=>'#F59E0B'];
                foreach ($rekap as $r):
                    $sisa=$r['nominal']-$r['total_bayar']; $sc=$sc_map[$r['status']]??'#94A3B8';
                ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><strong class="text-white"><?php echo htmlspecialchars($r['nama_lengkap']); ?></strong><div class="font-monospace text-secondary" style="font-size:10px;"><?php echo htmlspecialchars($r['nis']); ?></div></td>
                    <td style="font-size:11px;"><?php echo htmlspecialchars($r['nama_kelas']??'-'); ?></td>
                    <td style="text-align:right;">Rp <?php echo number_format($r['nominal'],0,',','.'); ?></td>
                    <td style="text-align:right;color:#10B981;">Rp <?php echo number_format($r['total_bayar'],0,',','.'); ?></td>
                    <td style="text-align:right;color:<?php echo $sisa>0?'#EF4444':'#10B981'; ?>;">Rp <?php echo number_format($sisa,0,',','.'); ?></td>
                    <td style="text-align:center;"><span class="badge" style="background:<?php echo $sc; ?>22;color:<?php echo $sc; ?>;border:1px solid <?php echo $sc; ?>44;font-size:10px;"><?php echo $r['status']; ?></span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot><tr style="border-top:2px solid rgba(212,175,55,.3);">
                <td colspan="3" class="fw-bold text-gold">TOTAL</td>
                <td style="text-align:right;font-weight:700;">Rp <?php echo number_format($total_nominal,0,',','.'); ?></td>
                <td style="text-align:right;font-weight:700;color:#10B981;">Rp <?php echo number_format($total_terbayar,0,',','.'); ?></td>
                <td style="text-align:right;font-weight:700;color:#EF4444;">Rp <?php echo number_format($total_nominal-$total_terbayar,0,',','.'); ?></td>
                <td></td>
            </tr></tfoot>
        </table>
    </div>
    <?php else: ?>
        <div class="text-center py-5"><i class="fa-solid fa-inbox" style="font-size:48px;color:rgba(255,255,255,.15);"></i><p class="text-secondary mt-3">Belum ada data tagihan SPP untuk periode ini.</p></div>
    <?php endif; ?>
</div>
<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
