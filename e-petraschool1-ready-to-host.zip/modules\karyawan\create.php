<?php
// c:\xampp\htdocs\e-petraschool1\modules\karyawan\create.php

$page_title = 'Tambah Karyawan';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';

try {
    $roles_stmt = $pdo->query("SELECT id, nama_role FROM roles WHERE nama_role != 'Super Admin' ORDER BY id");
    $roles = $roles_stmt->fetchAll();
} catch (Exception $e) {
    $error = 'Gagal memuat roles: ' . $e->getMessage();
    $roles = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $nik = trim($_POST['nik'] ?? '');
    $nama = trim($_POST['nama'] ?? '');
    $jabatan = trim($_POST['jabatan'] ?? '');
    $unit_kerja = trim($_POST['unit_kerja'] ?? '');
    $no_hp = trim($_POST['no_hp'] ?? '');
    $alamat = trim($_POST['alamat'] ?? '');
    $tanggal_masuk = $_POST['tanggal_masuk'] ?? '';
    $status = $_POST['status'] ?? 'Tetap';

    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role_id = intval($_POST['role_id'] ?? 0);
    $status_aktif = $_POST['status_aktif'] ?? 'Aktif';

    if (empty($nik) || empty($nama) || empty($jabatan) || empty($unit_kerja) || empty($no_hp) || empty($tanggal_masuk) || empty($username) || empty($password) || $role_id <= 0) {
        $error = 'Field NIP, Nama, Jabatan, Unit Kerja, No HP, Tanggal Masuk, Username, Password, dan Hak Akses wajib diisi!';
    } else {
        try {
            // Check duplicate NIP
            $chk = $pdo->prepare("SELECT COUNT(*) FROM karyawan WHERE nik = ?");
            $chk->execute([$nik]);
            if ($chk->fetchColumn() > 0) {
                $error = "NIP '$nik' sudah terdaftar!";
            } else {
                // Check duplicate username
                $chk_user = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
                $chk_user->execute([$username]);
                if ($chk_user->fetchColumn() > 0) {
                    $error = "Username '$username' sudah digunakan!";
                } else {
                    $pdo->beginTransaction();

                    // Insert karyawan
                    $stmt = $pdo->prepare("INSERT INTO karyawan (nik, nama, jabatan, unit_kerja, no_hp, alamat, tanggal_masuk, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$nik, $nama, $jabatan, $unit_kerja, $no_hp, $alamat, $tanggal_masuk, $status]);
                    $karyawan_id = $pdo->lastInsertId();

                    // Insert user login
                    $hashed_pass = password_hash($password, PASSWORD_BCRYPT);
                    $stmt_user = $pdo->prepare("INSERT INTO users (username, password, nama, role_id, karyawan_id, status_aktif) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt_user->execute([$username, $hashed_pass, $nama, $role_id, $karyawan_id, $status_aktif]);

                    $pdo->commit();

                    write_audit_log("Menambahkan data karyawan baru: $nama (NIP: $nik) dan membuat akun login: $username.");

                    echo "<script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire('Berhasil', 'Data karyawan dan akun login berhasil disimpan!', 'success').then(() => {
                                window.location.href = 'index.php';
                            });
                        });
                    </script>";
                }
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>

<div class="glass-card" style="max-width: 750px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-user-plus me-2"></i> Tambah Data Karyawan Baru</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="create.php">
        <?php csrf_input(); ?>

        <div class="row g-3">
            <div class="col-12 col-md-6">
                <label for="nik" class="form-label form-label-custom">NIP (Nomor Induk Pegawai) <span class="text-danger">*</span></label>
                <input type="text" name="nik" id="nik" class="form-control form-control-custom" placeholder="Contoh: 198504152010011002" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="nama" class="form-label form-label-custom">Nama Lengkap Karyawan <span class="text-danger">*</span></label>
                <input type="text" name="nama" id="nama" class="form-control form-control-custom" placeholder="Nama lengkap sesuai KTP" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="jabatan" class="form-label form-label-custom">Jabatan Pekerjaan <span class="text-danger">*</span></label>
                <input type="text" name="jabatan" id="jabatan" class="form-control form-control-custom" placeholder="Contoh: Staf TU, Satpam, Janitor" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="unit_kerja" class="form-label form-label-custom">Unit Kerja / Divisi <span class="text-danger">*</span></label>
                <input type="text" name="unit_kerja" id="unit_kerja" class="form-control form-control-custom" placeholder="Contoh: Tata Usaha, Perpustakaan, Keamanan" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="no_hp" class="form-label form-label-custom">Nomor HP / WA <span class="text-danger">*</span></label>
                <input type="text" name="no_hp" id="no_hp" class="form-control form-control-custom" placeholder="Contoh: 0812345678" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="tanggal_masuk" class="form-label form-label-custom">Tanggal Masuk Bekerja <span class="text-danger">*</span></label>
                <input type="date" name="tanggal_masuk" id="tanggal_masuk" class="form-control form-control-custom" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="status" class="form-label form-label-custom">Status Kepegawaian <span class="text-danger">*</span></label>
                <select name="status" id="status" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="Tetap" selected>Tetap</option>
                    <option value="Kontrak">Kontrak</option>
                    <option value="Harian">Harian</option>
                </select>
            </div>

            <div class="col-12">
                <label for="alamat" class="form-label form-label-custom">Alamat Lengkap</label>
                <textarea name="alamat" id="alamat" class="form-control form-control-custom" rows="2" placeholder="Alamat tinggal lengkap saat ini"></textarea>
            </div>

            <div class="col-12 col-md-12 mt-4">
                <h6 class="text-gold border-bottom border-secondary border-opacity-25 pb-2 mb-3"><i class="fa-solid fa-key me-2"></i> Akun Akses Sistem</h6>
            </div>

            <div class="col-12 col-md-3">
                <label for="username" class="form-label form-label-custom">Username <span class="text-danger">*</span></label>
                <input type="text" name="username" id="username" class="form-control form-control-custom" placeholder="Masukkan username" required autocomplete="off">
            </div>

            <div class="col-12 col-md-3">
                <label for="password" class="form-label form-label-custom">Password <span class="text-danger">*</span></label>
                <input type="password" name="password" id="password" class="form-control form-control-custom" placeholder="Masukkan password" required autocomplete="new-password">
            </div>

            <div class="col-12 col-md-3">
                <label for="role_id" class="form-label form-label-custom">Hak Akses <span class="text-danger">*</span></label>
                <select name="role_id" id="role_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="" disabled selected>Pilih Role...</option>
                    <?php foreach ($roles as $role): ?>
                        <option value="<?php echo $role['id']; ?>"><?php echo htmlspecialchars($role['nama_role']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-12 col-md-3">
                <label for="status_aktif" class="form-label form-label-custom">Status Aktif <span class="text-danger">*</span></label>
                <select name="status_aktif" id="status_aktif" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="Aktif" selected>Aktif</option>
                    <option value="Tidak Aktif">Tidak Aktif</option>
                </select>
            </div>

            <div class="col-12 d-flex justify-content-end gap-2 mt-4">
                <a href="index.php" class="btn btn-outline-custom">Batal</a>
                <button type="submit" class="btn btn-gold">Simpan <i class="fa-solid fa-check ms-1"></i></button>
            </div>
        </div>
    </form>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
