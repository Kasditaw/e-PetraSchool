<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\karyawan\index.php

$page_title = 'Data Karyawan';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

try {
    $query = "SELECT * FROM karyawan WHERE 1=1";
    $params = [];

    if ($search !== '') {
        $query .= " AND (nama LIKE :search OR nik LIKE :search OR jabatan LIKE :search OR unit_kerja LIKE :search)";
        $params['search'] = "%$search%";
    }

    $query .= " ORDER BY nama ASC";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $employees = $stmt->fetchAll();

} catch (Exception $e) {
    echo '<div class="alert alert-danger">Gagal memuat data karyawan: ' . $e->getMessage() . '</div>';
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-users-gear me-2"></i> Pengelolaan Data Karyawan</h5>
            <p class="text-secondary small mb-0">Kelola data staf tata usaha, satpam, kebersihan, pustakawan, dan medis SD Kristen Petra 1.</p>
        </div>
        
        <div class="d-flex gap-2 flex-wrap">
            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                <a href="create.php" class="btn btn-gold"><i class="fa-solid fa-plus me-1"></i> Tambah Karyawan</a>
                <a href="import.php" class="btn btn-outline-custom" style="color:#10B981;"><i class="fa-solid fa-file-csv me-1"></i> Import CSV</a>
            <?php endif; ?>
            <a href="../laporan/export.php?type=karyawan" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-excel me-1"></i> Ekspor Excel</a>
            <a href="../laporan/print.php?type=karyawan" target="_blank" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-pdf me-1"></i> Cetak PDF</a>
        </div>

    </div>

    <!-- Search Form -->
    <form method="GET" action="index.php" class="row g-2 mb-4 no-print">
        <div class="col-12 col-md-4">
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari NIK, nama, unit kerja..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">Cari</button>
        </div>
        <?php if ($search !== ''): ?>
            <div class="col-auto">
                <a href="index.php" class="btn btn-outline-danger">Reset</a>
            </div>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIK</th>
                    <th>Nama Lengkap</th>
                    <th>Jabatan</th>
                    <th>Unit Kerja</th>
                    <th>No. HP</th>
                    <th>Tanggal Masuk</th>
                    <th>Status</th>
                    <?php if (has_role(['Super Admin', 'Admin']) || can_access_inventaris()): ?>
                        <th class="no-print" style="width: 240px;">Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (count($employees) > 0): ?>
                    <?php $no = 1; foreach ($employees as $emp): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><strong class="text-white font-monospace"><?php echo htmlspecialchars($emp['nik']); ?></strong></td>
                            <td class="fw-semibold text-white"><?php echo htmlspecialchars($emp['nama']); ?></td>
                            <td><?php echo htmlspecialchars($emp['jabatan']); ?></td>
                            <td><span class="text-gold"><?php echo htmlspecialchars($emp['unit_kerja']); ?></span></td>
                            <td><?php echo htmlspecialchars($emp['no_hp']); ?></td>
                            <td><?php echo date('d M Y', strtotime($emp['tanggal_masuk'])); ?></td>
                            <td>
                                <?php 
                                    $badge_class = 'badge-secondary';
                                    if ($emp['status'] === 'Tetap') $badge_class = 'badge-success';
                                    elseif ($emp['status'] === 'Kontrak') $badge_class = 'badge-warning';
                                    elseif ($emp['status'] === 'Harian') $badge_class = 'badge-secondary';
                                ?>
                                <span class="badge <?php echo $badge_class; ?>"><?php echo $emp['status']; ?></span>
                            </td>
                            <?php if (has_role(['Super Admin', 'Admin']) || can_access_inventaris()): ?>
                                <td class="no-print">
                                    <div class="d-flex gap-2">
                                        <?php if (can_access_inventaris()): ?>
                                            <a href="../inventaris_karyawan/index.php?karyawan_id=<?php echo $emp['id']; ?>" class="btn btn-xs btn-outline-info" title="Inventaris"><i class="fa-solid fa-boxes-stacked"></i> Inventaris</a>
                                        <?php endif; ?>
                                        <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                            <a href="edit.php?id=<?php echo $emp['id']; ?>" class="btn btn-xs btn-outline-warning" title="Edit"><i class="fa-solid fa-pen"></i> Edit</a>
                                            <button onclick="confirmDelete('delete.php?id=<?php echo $emp['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i> Hapus</button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="<?php echo (has_role(['Super Admin', 'Admin']) || can_access_inventaris()) ? 9 : 8; ?>" class="text-center text-secondary py-4">Data karyawan tidak ditemukan.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
