<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\siswa\index.php

$page_title = 'Data Siswa';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$filter_kelas = isset($_GET['kelas_id']) ? $_GET['kelas_id'] : '';
$filter_status = isset($_GET['status_siswa']) ? $_GET['status_siswa'] : '';
$error = '';
$success = '';

// Handle quick assign wali kelas directly from this page if user is Super Admin or Admin
if ($_SERVER['REQUEST_METHOD'] === 'POST' && has_role(['Super Admin', 'Admin'])) {
    check_csrf_request();

    $action = $_POST['action'] ?? '';

    if ($action === 'quick_assign') {
        $class_id = intval($_POST['class_id'] ?? 0);
        $wali_kelas_id = $_POST['wali_kelas_id'] !== '' ? intval($_POST['wali_kelas_id']) : null;

        try {
            // Fetch class name for logging
            $class_stmt = $pdo->prepare("SELECT nama_kelas FROM kelas WHERE id = ?");
            $class_stmt->execute([$class_id]);
            $class_name = $class_stmt->fetchColumn() ?: "ID $class_id";

            $stmt = $pdo->prepare("UPDATE kelas SET wali_kelas_id = ? WHERE id = ?");
            $stmt->execute([$wali_kelas_id, $class_id]);

            // Fetch teacher name for logging
            $teacher_name = 'Belum Ditentukan';
            if ($wali_kelas_id) {
                $teacher_stmt = $pdo->prepare("SELECT nama_guru FROM guru WHERE id = ?");
                $teacher_stmt->execute([$wali_kelas_id]);
                $teacher_name = $teacher_stmt->fetchColumn() ?: "ID $wali_kelas_id";
            }

            write_audit_log("Mengatur Guru Kelas untuk $class_name: $teacher_name.");

            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire('Berhasil', 'Guru kelas berhasil diperbarui!', 'success').then(() => {
                        window.location.href = 'index.php?kelas_id=" . $class_id . "';
                    });
                });
            </script>";
            exit;
        } catch (Exception $e) {
            $error = 'Gagal menyimpan data: ' . $e->getMessage();
        }
    }
}

try {
    // Fetch all classes for filter dropdown
    $classes_stmt = $pdo->query("SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas ASC");
    $classes = $classes_stmt->fetchAll();

    // Fetch class details if filtered
    $class_info = null;
    if ($filter_kelas !== '') {
        $class_stmt = $pdo->prepare("SELECT k.*, g.nama_guru FROM kelas k LEFT JOIN guru g ON k.wali_kelas_id = g.id WHERE k.id = ?");
        $class_stmt->execute([intval($filter_kelas)]);
        $class_info = $class_stmt->fetch() ?: null;
    }

    // Fetch all teachers for dropdown in modal
    $teachers = [];
    if (has_role(['Super Admin', 'Admin'])) {
        $teachers_stmt = $pdo->query("SELECT id, nip, nama_guru FROM guru ORDER BY nama_guru ASC");
        $teachers = $teachers_stmt->fetchAll();
    }

    // Fetch active academic year
    $active_year_id = $pdo->query("SELECT id FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1")->fetchColumn() ?: 0;

    // Build main query
    $query = "SELECT s.*, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON s.kelas_id = k.id WHERE 1=1";
    $count_query = "SELECT COUNT(*) FROM siswa s LEFT JOIN kelas k ON s.kelas_id = k.id WHERE 1=1";
    $params = [];

    if ($search !== '') {
        $filter_sql = " AND (s.nama_lengkap LIKE :search OR s.nis LIKE :search OR s.nisn LIKE :search OR s.nama_ayah LIKE :search OR s.nama_ibu LIKE :search)";
        $query .= $filter_sql;
        $count_query .= $filter_sql;
        $params['search'] = "%$search%";
    }

    if ($filter_kelas !== '') {
        $filter_sql = " AND s.kelas_id = :kelas_id";
        $query .= $filter_sql;
        $count_query .= $filter_sql;
        $params['kelas_id'] = intval($filter_kelas);
    }

    if ($filter_status !== '') {
        $filter_sql = " AND s.status_siswa = :status_siswa";
        $query .= $filter_sql;
        $count_query .= $filter_sql;
        $params['status_siswa'] = $filter_status;
    }

    // Count query
    $stmt_count = $pdo->prepare($count_query);
    $stmt_count->execute($params);
    $total_items = intval($stmt_count->fetchColumn());

    // Pagination variables
    $limit = 10;
    $total_pages = max(1, ceil($total_items / $limit));
    $page = isset($_GET['page']) ? max(1, min($total_pages, intval($_GET['page']))) : 1;
    $offset = ($page - 1) * $limit;

    $query .= " ORDER BY s.nama_lengkap ASC LIMIT $limit OFFSET $offset";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $students = $stmt->fetchAll();

} catch (Exception $e) {
    error_log("Database error in siswa index: " . $e->getMessage());
    echo '<div class="alert alert-danger">Gagal memuat data siswa. Silakan hubungi administrator.</div>';
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <?php if ($class_info): 
                $nama = $class_info['nama_kelas'];
                $nama_roman = preg_replace_callback('/(\d+)/', function($matches) {
                    $map = [1 => 'I', 2 => 'II', 3 => 'III', 4 => 'IV', 5 => 'V', 6 => 'VI'];
                    return $map[$matches[1]] ?? $matches[1];
                }, $nama);
                $nama_roman = preg_replace('/([I|V|X])([A-Z])/', '$1 $2', $nama_roman);
            ?>
                <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-school me-2"></i> <?php echo htmlspecialchars($nama_roman); ?></h5>
                <p class="text-secondary small mb-0">
                    Guru Kelas / Wali Kelas: 
                    <?php if ($class_info['nama_guru']): ?>
                        <strong class="text-white"><?php echo htmlspecialchars($class_info['nama_guru']); ?></strong>
                        <?php if (has_role(['Super Admin', 'Admin'])): ?>
                            <button onclick="openAssignTeacherModal(<?php echo $class_info['id']; ?>, '<?php echo htmlspecialchars($class_info['nama_kelas'], ENT_QUOTES); ?>', '<?php echo $class_info['wali_kelas_id']; ?>')" class="btn btn-link text-warning p-0 ms-2" title="Ganti Guru Kelas" style="text-decoration: none; font-size: 13px;">
                                <i class="fa-solid fa-user-pen"></i>
                            </button>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="text-secondary small">Belum Ditentukan</span>
                        <?php if (has_role(['Super Admin', 'Admin'])): ?>
                            <button onclick="openAssignTeacherModal(<?php echo $class_info['id']; ?>, '<?php echo htmlspecialchars($class_info['nama_kelas'], ENT_QUOTES); ?>', '')" class="btn btn-xs btn-outline-gold ms-2" title="Pilih Guru Kelas" style="padding: 1px 6px; font-size: 10px;">
                                <i class="fa-solid fa-plus-circle me-1"></i> Pilih Guru
                            </button>
                        <?php endif; ?>
                    <?php endif; ?>
                    <span class="mx-2 text-secondary">|</span>
                    Lokasi: <strong class="text-white"><i class="fa-solid fa-location-dot me-1 text-gold"></i> <?php echo htmlspecialchars($class_info['lokasi_ruangan']); ?></strong>
                </p>
            <?php else: ?>
                <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-user-graduate me-2"></i> Pengelolaan Data Siswa</h5>
                <p class="text-secondary small mb-0">Kelola dan telusuri data identitas siswa aktif maupun alumni SD Kristen Petra 1.</p>
            <?php endif; ?>
        </div>
        
        <div class="d-flex gap-2">
            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                <a href="create.php" class="btn btn-gold"><i class="fa-solid fa-user-plus me-1"></i> Tambah Siswa</a>
                <a href="import.php" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-import me-1"></i> Import Siswa</a>
                <a href="../penempatan/kenaikan.php<?php echo !empty($filter_kelas) ? '?origin_class_id=' . urlencode($filter_kelas) . '&origin_year_id=' . urlencode($active_year_id) : ''; ?>" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-angles-up me-1"></i> Naik/Pindah Kelas</a>
            <?php endif; ?>
            <a href="export_excel.php?kelas_id=<?php echo urlencode($filter_kelas); ?>&status_siswa=<?php echo urlencode($filter_status); ?>&search=<?php echo urlencode($search); ?>" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-excel me-1"></i> Ekspor Excel</a>
            <a href="../laporan/print.php?type=siswa" target="_blank" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-pdf me-1"></i> Cetak PDF</a>
        </div>
    </div>

    <!-- Filter & Search Form -->
    <form method="GET" action="index.php" class="row g-3 mb-4 no-print align-items-end">
        <div class="col-12 col-md-3">
            <label class="form-label form-label-custom">Pencarian</label>
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari NIS, nama, ortu..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        
        <div class="col-12 col-sm-6 col-md-3">
            <label class="form-label form-label-custom">Filter Kelas</label>
            <select name="kelas_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua Kelas</option>
                <?php foreach ($classes as $cl): ?>
                    <option value="<?php echo $cl['id']; ?>" <?php echo $filter_kelas == $cl['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($cl['nama_kelas']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-12 col-sm-6 col-md-3">
            <label class="form-label form-label-custom">Filter Status</label>
            <select name="status_siswa" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua Status</option>
                <option value="Aktif" <?php echo $filter_status === 'Aktif' ? 'selected' : ''; ?>>Aktif</option>
                <option value="Alumni" <?php echo $filter_status === 'Alumni' ? 'selected' : ''; ?>>Alumni</option>
                <option value="Pindahan" <?php echo $filter_status === 'Pindahan' ? 'selected' : ''; ?>>Pindahan</option>
                <option value="Keluar" <?php echo $filter_status === 'Keluar' ? 'selected' : ''; ?>>Keluar</option>
            </select>
        </div>

        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">Filter</button>
        </div>
        
        <?php if ($search !== '' || $filter_kelas !== '' || $filter_status !== ''): ?>
            <div class="col-auto">
                <a href="index.php" class="btn btn-outline-danger">Reset</a>
            </div>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>NIS / NISN</th>
                    <th>Nama Lengkap</th>
                    <th>Gender</th>
                    <th>Kelas</th>
                    <th>Agama</th>
                    <th>Status</th>
                    <th class="no-print">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($students) > 0): ?>
                    <?php foreach ($students as $student): ?>
                        <tr>
                            <td>
                                <strong class="text-white font-monospace d-block"><?php echo htmlspecialchars($student['nis']); ?></strong>
                                <span class="text-secondary small font-monospace"><?php echo htmlspecialchars($student['nisn']); ?></span>
                            </td>
                            <td class="fw-semibold text-white"><?php echo htmlspecialchars($student['nama_lengkap']); ?></td>
                            <td><?php echo $student['gender'] === 'L' ? 'Laki-laki' : 'Perempuan'; ?></td>
                            <td><?php echo htmlspecialchars($student['nama_kelas'] ?? 'Tanpa Kelas'); ?></td>
                            <td><?php echo htmlspecialchars($student['agama']); ?></td>
                            <td>
                                <?php 
                                    $badge_class = 'badge-secondary';
                                    if ($student['status_siswa'] === 'Aktif') $badge_class = 'badge-success';
                                    elseif ($student['status_siswa'] === 'Alumni') $badge_class = 'badge-secondary';
                                    elseif ($student['status_siswa'] === 'Pindahan') $badge_class = 'badge-warning';
                                    elseif ($student['status_siswa'] === 'Keluar') $badge_class = 'badge-danger';
                                ?>
                                <span class="badge <?php echo $badge_class; ?>"><?php echo $student['status_siswa']; ?></span>
                            </td>
                            <td class="no-print">
                                <div class="d-flex gap-2">
                                    <a href="history.php?id=<?php echo $student['id']; ?>" class="btn btn-xs btn-outline-info" title="Histori Kelas"><i class="fa-solid fa-clock-rotate-left"></i> Histori</a>
                                    <a href="print.php?id=<?php echo $student['id']; ?>" class="btn btn-xs btn-outline-custom text-gold" title="Cetak Kartu"><i class="fa-solid fa-address-card"></i> Kartu</a>
                                    
                                    <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                        <a href="edit.php?id=<?php echo $student['id']; ?>" class="btn btn-xs btn-outline-warning" title="Edit"><i class="fa-solid fa-pen"></i> Edit</a>
                                        <button onclick="confirmDelete('delete.php?id=<?php echo $student['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i> Hapus</button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center text-secondary py-4">Data siswa tidak ditemukan.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Pagination Navigation -->
    <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation" class="mt-4 no-print">
            <ul class="pagination justify-content-center">
                <!-- Previous Button -->
                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $page - 1; ?><?php echo $search !== '' ? '&search='.urlencode($search) : ''; ?><?php echo $filter_kelas !== '' ? '&kelas_id='.urlencode($filter_kelas) : ''; ?><?php echo $filter_status !== '' ? '&status_siswa='.urlencode($filter_status) : ''; ?>" aria-label="Previous" style="background: rgba(18, 28, 54, 0.6); color: #fff; border-color: rgba(255,255,255,0.08);">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                
                <!-- Page Numbers -->
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?php echo $page == $i ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?><?php echo $search !== '' ? '&search='.urlencode($search) : ''; ?><?php echo $filter_kelas !== '' ? '&kelas_id='.urlencode($filter_kelas) : ''; ?><?php echo $filter_status !== '' ? '&status_siswa='.urlencode($filter_status) : ''; ?>" style="<?php echo $page == $i ? 'background: linear-gradient(135deg, #D4AF37 0%, #F3CD48 100%); color: #000; font-weight: bold; border-color: #D4AF37;' : 'background: rgba(18, 28, 54, 0.6); color: #fff; border-color: rgba(255,255,255,0.08);'; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
                
                <!-- Next Button -->
                <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $page + 1; ?><?php echo $search !== '' ? '&search='.urlencode($search) : ''; ?><?php echo $filter_kelas !== '' ? '&kelas_id='.urlencode($filter_kelas) : ''; ?><?php echo $filter_status !== '' ? '&status_siswa='.urlencode($filter_status) : ''; ?>" aria-label="Next" style="background: rgba(18, 28, 54, 0.6); color: #fff; border-color: rgba(255,255,255,0.08);">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    <?php endif; ?>
</div>

<?php if (has_role(['Super Admin', 'Admin'])): ?>
<!-- Modal Quick Assign Teacher -->
<div class="modal fade" id="quickAssignModal" tabindex="-1" aria-labelledby="quickAssignModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark-select text-white border-gold-subtle" style="background-color: #0f172a; border: 1px solid rgba(212, 175, 55, 0.2);">
            <div class="modal-header border-bottom-gold" style="border-bottom: 1px solid rgba(212, 175, 55, 0.2);">
                <h5 class="modal-title text-gold" id="quickAssignModalLabel"><i class="fa-solid fa-user-tie me-2"></i> Atur Guru Kelas</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="index.php?kelas_id=<?php echo urlencode($filter_kelas); ?>">
                <?php csrf_input(); ?>
                <input type="hidden" name="action" value="quick_assign">
                <input type="hidden" name="class_id" id="modal_class_id" value="">
                
                <div class="modal-body">
                    <p class="small text-secondary mb-3">Pilih guru dari data guru yang ada untuk ditugaskan sebagai Guru Kelas pada kelas ini.</p>
                    
                    <div class="mb-3">
                        <label for="modal_kelas_name" class="form-label form-label-custom">Nama Kelas</label>
                        <input type="text" id="modal_kelas_name" class="form-control form-control-custom" readonly>
                    </div>

                    <div class="mb-3">
                        <label for="modal_wali_kelas_id" class="form-label form-label-custom">Guru Kelas / Wali Kelas</label>
                        <select name="wali_kelas_id" id="modal_wali_kelas_id" class="form-select form-control-custom bg-dark-select text-white">
                            <option value="">Pilih Guru Kelas (Opsional)...</option>
                            <?php foreach ($teachers as $teacher): ?>
                                <option value="<?php echo $teacher['id']; ?>"><?php echo htmlspecialchars($teacher['nama_guru']) . ' (' . htmlspecialchars($teacher['nip']) . ')'; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-top-gold" style="border-top: 1px solid rgba(212, 175, 55, 0.2);">
                    <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-gold">Simpan Perubahan <i class="fa-solid fa-check ms-1"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openAssignTeacherModal(classId, className, currentTeacherId) {
    // Set hidden fields and readonly input
    document.getElementById('modal_class_id').value = classId;
    document.getElementById('modal_kelas_name').value = className;

    // Pre-select the current teacher in the dropdown
    var selectEl = document.getElementById('modal_wali_kelas_id');
    var teacherIdStr = String(currentTeacherId);
    selectEl.value = teacherIdStr;
    // Fallback: loop through options to find matching value
    if (selectEl.value !== teacherIdStr) {
        for (var i = 0; i < selectEl.options.length; i++) {
            if (selectEl.options[i].value === teacherIdStr) {
                selectEl.selectedIndex = i;
                break;
            }
        }
    }

    // Dispose existing modal instance if any, then open fresh
    var modalEl = document.getElementById('quickAssignModal');
    var existingModal = bootstrap.Modal.getInstance(modalEl);
    if (existingModal) {
        existingModal.dispose();
    }
    var myModal = new bootstrap.Modal(modalEl);
    myModal.show();
}
</script>
<?php endif; ?>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
