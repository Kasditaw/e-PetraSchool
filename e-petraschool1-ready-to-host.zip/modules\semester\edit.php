<?php
// c:\xampp\htdocs\e-petraschool1\modules\semester\edit.php

$page_title = 'Edit Semester';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';

try {
    $stmt = $pdo->prepare("SELECT * FROM semester WHERE id = ?");
    $stmt->execute([$id]);
    $sem = $stmt->fetch();
    
    if (!$sem) {
        die('<div class="alert alert-danger">Data semester tidak ditemukan!</div>');
    }
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $semester = trim($_POST['semester'] ?? '');
    $status = $_POST['status'] ?? 'Tidak Aktif';

    if (empty($semester)) {
        $error = 'Semester wajib diisi!';
    } else {
        try {
            // Check duplicate
            $chk = $pdo->prepare("SELECT COUNT(*) FROM semester WHERE semester = ? AND id != ?");
            $chk->execute([$semester, $id]);
            if ($chk->fetchColumn() > 0) {
                $error = "Semester '$semester' sudah ada!";
            } else {
                $pdo->beginTransaction();

                if ($status === 'Aktif') {
                    // Set all others to inactive
                    $pdo->exec("UPDATE semester SET status = 'Tidak Aktif'");
                }

                $stmt = $pdo->prepare("UPDATE semester SET semester = ?, status = ? WHERE id = ?");
                $stmt->execute([$semester, $status, $id]);
                
                $pdo->commit();

                write_audit_log("Mengubah data semester: $semester (Status: $status).");
                
                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Semester berhasil diubah!', 'success').then(() => {
                            window.location.href = 'index.php';
                        });
                    });
                </script>";
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = 'Error database: ' . $e->getMessage();
        }
    }
}
?>

<div class="glass-card" style="max-width: 600px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-pen me-2"></i> Edit Semester</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="edit.php?id=<?php echo $id; ?>">
        <?php csrf_input(); ?>

        <div class="mb-3">
            <label for="semester" class="form-label form-label-custom">Semester</label>
            <input type="text" name="semester" id="semester" class="form-control form-control-custom" value="<?php echo htmlspecialchars($sem['semester']); ?>" required>
        </div>

        <div class="mb-4">
            <label for="status" class="form-label form-label-custom">Status</label>
            <select name="status" id="status" class="form-select form-control-custom bg-dark-select text-white">
                <option value="Tidak Aktif" <?php echo $sem['status'] === 'Tidak Aktif' ? 'selected' : ''; ?>>Tidak Aktif</option>
                <option value="Aktif" <?php echo $sem['status'] === 'Aktif' ? 'selected' : ''; ?>>Aktif</option>
            </select>
        </div>

        <div class="d-flex justify-content-end gap-2">
            <a href="index.php" class="btn btn-outline-custom">Batal</a>
            <button type="submit" class="btn btn-gold">Simpan Perubahan <i class="fa-solid fa-check ms-1"></i></button>
        </div>
    </form>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
