<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\peminjaman\index.php

$page_title = 'Peminjaman Barang';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_inventaris_access();

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

try {
    // Select borrowings joining with inventaris
    $query = "SELECT p.*, i.nama_barang, i.kode_barang 
              FROM peminjaman p 
              JOIN inventaris i ON p.inventaris_id = i.id";
    
    if ($search !== '') {
        $query .= " WHERE p.nama_peminjam LIKE :search OR p.kode_peminjaman LIKE :search OR i.nama_barang LIKE :search OR i.kode_barang LIKE :search";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['search' => "%$search%"]);
    } else {
        $stmt = $pdo->query($query);
    }
    
    $borrowings = $stmt->fetchAll();
} catch (Exception $e) {
    echo '<div class="alert alert-danger">Gagal memuat data peminjaman: ' . $e->getMessage() . '</div>';
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-handshake-angle me-2"></i> Transaksi Peminjaman Aset Sekolah</h5>
            <p class="text-secondary small mb-0">Catat dan pantau log peminjaman barang inventaris (seperti laptop, proyektor, dll.) oleh guru/staf.</p>
        </div>
        
        <div class="d-flex gap-2">
            <?php if (has_role(['Super Admin', 'Admin', 'Guru'])): ?>
                <a href="create.php" class="btn btn-gold"><i class="fa-solid fa-plus me-1"></i> Buat Peminjaman</a>
            <?php endif; ?>
            <a href="../laporan/export.php?type=peminjaman" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-excel me-1"></i> Ekspor Excel</a>
            <a href="../laporan/print.php?type=peminjaman" target="_blank" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-pdf me-1"></i> Cetak PDF</a>
        </div>
    </div>

    <!-- Search Form -->
    <form method="GET" action="index.php" class="row g-2 mb-4 no-print">
        <div class="col-12 col-md-4">
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari peminjam, kode, barang..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">Cari</button>
        </div>
        <?php if ($search !== ''): ?>
            <div class="col-auto">
                <a href="index.php" class="btn btn-outline-danger">Reset</a>
            </div>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Transaksi</th>
                    <th>Peminjam</th>
                    <th>Barang Aset</th>
                    <th>Tanggal Pinjam</th>
                    <th>Tanggal Kembali</th>
                    <th>Status</th>
                    <th class="no-print">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($borrowings) > 0): ?>
                    <?php $no = 1; foreach ($borrowings as $borrow): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><span class="badge badge-secondary"><?php echo htmlspecialchars($borrow['kode_peminjaman']); ?></span></td>
                            <td class="fw-semibold text-white"><?php echo htmlspecialchars($borrow['nama_peminjam']); ?></td>
                            <td>
                                <strong class="text-white"><?php echo htmlspecialchars($borrow['nama_barang']); ?></strong>
                                <span class="text-secondary small d-block font-monospace"><?php echo htmlspecialchars($borrow['kode_barang']); ?></span>
                            </td>
                            <td><?php echo date('d M Y', strtotime($borrow['tanggal_pinjam'])); ?></td>
                            <td><?php echo !empty($borrow['tanggal_kembali']) ? date('d M Y', strtotime($borrow['tanggal_kembali'])) : '<em class="text-secondary">Belum Dikembalikan</em>'; ?></td>
                            <td>
                                <?php if ($borrow['status'] === 'Dipinjam'): ?>
                                    <span class="badge badge-warning"><i class="fa-solid fa-clock me-1"></i> Dipinjam</span>
                                <?php else: ?>
                                    <span class="badge badge-success"><i class="fa-solid fa-circle-check me-1"></i> Dikembalikan</span>
                                <?php endif; ?>
                            </td>
                            <td class="no-print">
                                <div class="d-flex gap-2">
                                    <a href="edit.php?id=<?php echo $borrow['id']; ?>" class="btn btn-xs btn-outline-warning" title="Edit"><i class="fa-solid fa-pen"></i> Edit</a>
                                    
                                    <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                        <button onclick="confirmDelete('delete.php?id=<?php echo $borrow['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i> Hapus</button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center text-secondary py-4">Data transaksi peminjaman kosong.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
