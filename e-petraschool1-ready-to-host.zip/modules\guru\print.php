<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\guru\print.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

try {
    $stmt = $pdo->prepare("SELECT * FROM guru WHERE id = ? LIMIT 1");
    $stmt->execute([$id]);
    $teacher = $stmt->fetch();

    if (!$teacher) {
        die('Data guru tidak ditemukan!');
    }

    // Log biodata printing
    write_audit_log("Mencetak biodata guru: " . $teacher['nama_guru'] . " (NIP: " . $teacher['nip'] . ").");

} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

function format_indo_date($date_str, $format = 'd F Y') {
    if (empty($date_str)) {
        return '-';
    }
    $time = is_numeric($date_str) ? $date_str : strtotime($date_str);
    if (!$time) {
        return '-';
    }
    $indo_months = [
        'January' => 'Januari',
        'February' => 'Februari',
        'March' => 'Maret',
        'April' => 'April',
        'May' => 'Mei',
        'June' => 'Juni',
        'July' => 'Juli',
        'August' => 'Agustus',
        'September' => 'September',
        'October' => 'Oktober',
        'November' => 'November',
        'December' => 'Desember',
        'Jan' => 'Jan',
        'Feb' => 'Feb',
        'Mar' => 'Mar',
        'Apr' => 'Apr',
        'May' => 'Mei',
        'Jun' => 'Jun',
        'Jul' => 'Jul',
        'Aug' => 'Agu',
        'Sep' => 'Sep',
        'Oct' => 'Okt',
        'Nov' => 'Nov',
        'Dec' => 'Des'
    ];
    $date_en = date($format, $time);
    return strtr($date_en, $indo_months);
}

// Compute base_url
$project_dir = str_replace('\\', '/', dirname(dirname(__DIR__)));
$web_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
$base_url = str_replace($web_root, '', $project_dir);
if (empty($base_url)) {
    $base_url = '/';
} else {
    if (substr($base_url, 0, 1) !== '/') {
        $base_url = '/' . $base_url;
    }
    if (substr($base_url, -1) !== '/') {
        $base_url .= '/';
    }
}
$base_url = str_replace('//', '/', $base_url);

// Embed logo as base64 so it always loads in print regardless of URL path
$logo_file = dirname(dirname(__DIR__)) . '/assets/images/logo.png';

if (file_exists($logo_file)) {
    $logo_data = base64_encode(file_get_contents($logo_file));
    $logo_src  = 'data:image/png;base64,' . $logo_data;
} else {
    $logo_src  = $base_url . 'assets/images/logo.png';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biodata Guru - <?php echo htmlspecialchars($teacher['nama_guru']); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
        body {
            background-color: #f8fafc !important;
            color: #0f172a !important;
            margin: 0;
            padding: 0;
            font-family: 'Outfit', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }
        .biodata-container {
            width: 210mm;
            min-height: 297mm;
            background-color: #ffffff !important;
            padding: 20mm;
            box-shadow: 0 4px 20px rgba(15, 23, 42, 0.05);
            margin: 30px auto;
            box-sizing: border-box;
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            position: relative;
        }
        .header-section {
            border-bottom: 3px double #0f172a;
            padding-bottom: 15px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .header-logo img {
            height: 70px;
            width: 70px;
            object-fit: contain;
        }
        .header-title h4 {
            margin: 0;
            font-weight: 700;
            color: #0f172a;
            font-size: 16px;
            text-transform: uppercase;
        }
        .header-title p {
            margin: 5px 0 0 0;
            font-size: 11px;
            color: #475569;
        }
        .teacher-photo {
            width: 130px;
            height: 170px;
            object-fit: cover;
            border: 1px solid #cbd5e1;
            border-radius: 6px;
        }
        .info-table {
            width: 100%;
            border-collapse: collapse;
        }
        .info-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #e2e8f0;
            font-size: 13.5px;
            color: #334155;
            line-height: 1.4;
        }
        .info-table td.label-col {
            font-weight: 600;
            width: 30%;
            color: #0f172a;
        }
        .print-btn-bar {
            position: fixed;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
            z-index: 1000;
        }
        .btn-print {
            background: #D4AF37;
            color: #000;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-family: 'Outfit', sans-serif;
            box-shadow: 0 4px 12px rgba(212, 175, 55, 0.3);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
        }
        .btn-print:hover {
            background: #f3cd48;
            transform: translateY(-1px);
        }
        .btn-back {
            background: #ffffff;
            color: #334155;
            border: 1px solid #e2e8f0;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-family: 'Outfit', sans-serif;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        }
        .btn-back:hover {
            background: #f8fafc;
            border-color: #cbd5e1;
            transform: translateY(-1px);
        }
        @media print {
            @page {
                size: 215mm 330mm;
                margin: 0;
            }
            body {
                background-color: #ffffff !important;
                padding: 0 !important;
                margin: 0 !important;
            }
            .biodata-container {
                width: 100% !important;
                min-height: auto !important;
                border: none !important;
                box-shadow: none !important;
                padding: 20mm !important;
                margin: 0 !important;
                background-color: #ffffff !important;
            }
            .print-btn-bar {
                display: none !important;
            }
        }
    </style>
</head>
<body>

    <div class="print-btn-bar no-print">
        <a href="index.php" class="btn-back"><i class="fa-solid fa-chevron-left"></i> Kembali</a>
        <button onclick="window.print()" class="btn-print"><i class="fa-solid fa-print"></i> Cetak Dokumen</button>
    </div>

    <div class="biodata-container">
        <!-- Header Kop Surat -->
        <div class="header-section">
            <div class="header-logo">
                <img src="<?php echo $logo_src; ?>" alt="Logo SD Kristen Petra 1" style="height: 70px; width: 70px; object-fit: contain;">
            </div>
            <div class="header-title">
                <h4>SD KRISTEN PETRA 1 SURABAYA</h4>
                <p>Jl. WR. Supratman No.46, DR. Soetomo, Kec. Tegalsari, Surabaya, Jawa Timur 60264 | Email: sd1@pppkpetra.sch.id</p>
            </div>
        </div>

        <h3 class="text-center fw-bold mb-4" style="color: #091124; letter-spacing: 0.5px;">BIODATA TENAGA PENDIDIK</h3>

        <div class="row align-items-start g-4">
            <!-- Photo column -->
            <div class="col-12 col-md-3 text-center">
                <?php 
                    $foto_url = !empty($teacher['foto']) ? $base_url . 'assets/uploads/guru/' . $teacher['foto'] : 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&h=150&q=80';
                ?>
                <img src="<?php echo $foto_url; ?>" class="teacher-photo shadow-sm mb-3" alt="Foto Guru">
                <p class="font-monospace fw-bold text-dark small">NIP: <?php echo htmlspecialchars($teacher['nip']); ?></p>
            </div>

            <!-- Detail column -->
            <div class="col-12 col-md-9">
                <table class="info-table">
                    <tr>
                        <td class="label-col">Nama Lengkap</td>
                        <td>: <?php echo htmlspecialchars($teacher['nama_guru']); ?></td>
                    </tr>
                    <tr>
                        <td class="label-col">Jenis Kelamin</td>
                        <td>: <?php echo $teacher['gender'] === 'L' ? 'Laki-laki' : 'Perempuan'; ?></td>
                    </tr>
                    <tr>
                        <td class="label-col">Pendidikan Terakhir</td>
                        <td>: <?php echo htmlspecialchars($teacher['pendidikan']); ?></td>
                    </tr>
                    <tr>
                        <td class="label-col">Jabatan Utama</td>
                        <td>: <?php echo htmlspecialchars($teacher['jabatan'] ?: '-'); ?></td>
                    </tr>
                    <tr>
                        <td class="label-col">Mata Pelajaran Utama</td>
                        <td>: <?php echo htmlspecialchars($teacher['mapel'] ?: '-'); ?></td>
                    </tr>
                    <tr>
                        <td class="label-col">Nomor HP / WhatsApp</td>
                        <td>: <?php echo htmlspecialchars($teacher['no_hp']); ?></td>
                    </tr>
                    <tr>
                        <td class="label-col">Alamat Email Petra</td>
                        <td>: <?php echo htmlspecialchars($teacher['email']); ?></td>
                    </tr>
                    <tr>
                        <td class="label-col">Alamat Domisili</td>
                        <td>: <?php echo htmlspecialchars($teacher['alamat'] ?: '-'); ?></td>
                    </tr>
                    <tr>
                        <td class="label-col">Tanggal Bergabung</td>
                        <td>: <?php echo format_indo_date($teacher['created_at'], 'd M Y'); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="row mt-5">
            <div class="col-6"></div>
            <div class="col-6 text-center" style="font-size: 13px;">
                <p class="mb-5">Surabaya, <?php echo format_indo_date(time(), 'd F Y'); ?><br>Kepala Sekolah,</p>
                <strong class="text-dark">Lilia, S.Pd., M.Psi.</strong><br>
                <span class="text-muted">NIP. -</span>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(() => {
                window.print();
            }, 500);
        });
    </script>
</body>
</html>
