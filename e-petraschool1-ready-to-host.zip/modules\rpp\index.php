<?php
// c:\xampp\htdocs\e-petraschool1\modules\rpp\index.php

$page_title = 'Administrasi Pembelajaran (RPP)';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

// Enforce login
check_login();

$error = '';
$grade = isset($_GET['grade']) ? intval($_GET['grade']) : 1;
if ($grade < 1 || $grade > 6) {
    $grade = 1;
}
$mapel_id = isset($_GET['mapel_id']) ? intval($_GET['mapel_id']) : 0;

$guru_id = $_SESSION['guru_id'] ?? 0;

// Helper function to check if a subject matches teacher's mapel
function isMapelMatchedForGuru($sub_nama, $sub_kode, $guru_mapel) {
    if (empty($guru_mapel) || $guru_mapel === '-' || $guru_mapel === 'Guru Kelas') {
        return true;
    }
    
    $parts = explode(',', $guru_mapel);
    foreach ($parts as $part) {
        $part = trim($part);
        if (empty($part)) continue;
        
        $sub_nama_clean = strtolower(trim($sub_nama));
        $sub_kode_clean = strtolower(trim($sub_kode));
        $part_clean = strtolower($part);
        
        if ($sub_nama_clean === $part_clean || $sub_kode_clean === $part_clean) {
            return true;
        }
        if (strpos($sub_nama_clean, $part_clean) !== false || strpos($part_clean, $sub_nama_clean) !== false) {
            return true;
        }
        if (strpos($sub_kode_clean, $part_clean) !== false || strpos($part_clean, $sub_kode_clean) !== false) {
            return true;
        }
        
        // "Guru Komputer" or "Komputer" or "IT" matches "IT", "ROBOTIK", "Teknologi Informasi"
        if (strpos($part_clean, 'komputer') !== false || $part_clean === 'it' || $part_clean === 'komputer') {
            if (strpos($sub_nama_clean, 'it') !== false || strpos($sub_nama_clean, 'robotik') !== false || strpos($sub_nama_clean, 'teknologi informasi') !== false || $sub_kode_clean === 'it' || $sub_kode_clean === 'robotik') {
                return true;
            }
        }
        
        // "Agama" or "Agama Kristen" or "Teologi" or "PAK" matches "Agama Kristen", "Pendidikan Agama Kristen", "PAK"
        if (strpos($part_clean, 'agama') !== false || strpos($part_clean, 'teologi') !== false || $part_clean === 'pak') {
            if (strpos($sub_nama_clean, 'agama') !== false || $sub_kode_clean === 'pak' || $sub_kode_clean === 'mp003') {
                return true;
            }
        }
    }
    return false;
}

// Fetch teachers list if Admin/Super Admin is editing on behalf
try {
    $teachers = $pdo->query("SELECT id, nama_guru, nip FROM guru ORDER BY nama_guru ASC")->fetchAll();
    
    // Fetch semesters
    $semesters_list = $pdo->query("SELECT * FROM semester ORDER BY semester ASC")->fetchAll();

    // Fetch active year
    $yr_stmt = $pdo->query("SELECT * FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1");
    $active_yr = $yr_stmt->fetch();
    
    // Fetch all years
    $years_list = $pdo->query("SELECT * FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();

    // Fetch mata_pelajaran
    $all_subjects = $pdo->query("SELECT * FROM mata_pelajaran WHERE status = 'Aktif' ORDER BY nama_mapel ASC")->fetchAll();
    
    // Fetch logged in guru profile
    $logged_in_guru = null;
    $allowed_mapel_ids = [];
    $assigned_mapel_ids = [];
    if ($guru_id > 0) {
        $stmt_g = $pdo->prepare("SELECT * FROM guru WHERE id = ?");
        $stmt_g->execute([$guru_id]);
        $logged_in_guru = $stmt_g->fetch();
        
        // Also fetch mapel assignments from kelas_mapel_guru
        $stmt_kmg = $pdo->prepare("SELECT DISTINCT mapel_id FROM kelas_mapel_guru WHERE guru_id = ?");
        $stmt_kmg->execute([$guru_id]);
        $assigned_mapel_ids = $stmt_kmg->fetchAll(PDO::FETCH_COLUMN);
    }
    
    $subjects = [];
    $is_admin = has_role(['Super Admin', 'Admin']);
    $guru_mapel = $logged_in_guru['mapel'] ?? '';
    
    foreach ($all_subjects as $sub) {
        if ($is_admin 
            || isMapelMatchedForGuru($sub['nama_mapel'], $sub['kode_mapel'], $guru_mapel)
            || in_array(intval($sub['id']), $assigned_mapel_ids)
        ) {
            $subjects[] = $sub;
            $allowed_mapel_ids[] = intval($sub['id']);
        }
    }
    
    $current_mapel = null;
    $default_sel_guru_id = $guru_id;
    if ($mapel_id > 0) {
        if (!in_array($mapel_id, $allowed_mapel_ids)) {
            die("Akses ditolak! Anda tidak memiliki wewenang untuk mengisi atau mengakses RPP mata pelajaran ini.");
        }
        $mapel_stmt = $pdo->prepare("SELECT * FROM mata_pelajaran WHERE id = ?");
        $mapel_stmt->execute([$mapel_id]);
        $current_mapel = $mapel_stmt->fetch();
        
        if ($current_mapel) {
            // Heuristic 1: Get the guru_id of the most recent document for this grade & mapel
            $last_doc_stmt = $pdo->prepare("SELECT guru_id FROM rpp_dokumen WHERE grade_level = ? AND mapel_id = ? ORDER BY created_at DESC LIMIT 1");
            $last_doc_stmt->execute([$grade, $mapel_id]);
            $last_guru = $last_doc_stmt->fetchColumn();
            if ($last_guru) {
                $default_sel_guru_id = $last_guru;
            } else {
                // Heuristic 2: Try to find a guru who has this mapel name in their profile mapel text
                $match_guru_stmt = $pdo->prepare("SELECT id FROM guru WHERE mapel LIKE ? OR mapel LIKE ? LIMIT 1");
                $match_guru_stmt->execute(['%' . $current_mapel['nama_mapel'] . '%', '%' . $current_mapel['kode_mapel'] . '%']);
                $matched_guru = $match_guru_stmt->fetchColumn();
                if ($matched_guru) {
                    $default_sel_guru_id = $matched_guru;
                }
            }
        }
    }
    
    // Fetch classes for the current grade level
    $classes_stmt = $pdo->prepare("SELECT * FROM kelas WHERE tingkat = ? AND status = 'Aktif' ORDER BY nama_kelas ASC");
    $classes_stmt->execute([$grade]);
    $available_classes = $classes_stmt->fetchAll();
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

// ── PROCESS CREATE / UPDATE ──
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    check_csrf_request();
    
    if (!has_role(['Super Admin', 'Admin', 'Guru'])) {
        die("Akses ditolak!");
    }
    
    $action = $_POST['action'];
    $target_grade = intval($_POST['grade_level'] ?? 1);
    $target_mapel = intval($_POST['mapel_id'] ?? 0);
    
    if (!in_array($target_mapel, $allowed_mapel_ids)) {
        die("Akses ditolak! Anda tidak memiliki wewenang untuk mengisi RPP mata pelajaran ini.");
    }
    $jenis_dokumen = trim($_POST['jenis_dokumen'] ?? '');
    $nama_dokumen = trim($_POST['nama_dokumen'] ?? '');
    $konten = trim($_POST['konten'] ?? '');
    $tahun_ajaran = trim($_POST['tahun_ajaran'] ?? '');
    $kelas_id = isset($_POST['kelas_id']) && $_POST['kelas_id'] !== '' ? intval($_POST['kelas_id']) : null;
    
    // Fallback uploader guru_id
    $uploader_guru_id = $guru_id;
    if (has_role(['Super Admin', 'Admin']) && isset($_POST['uploader_guru_id']) && !empty($_POST['uploader_guru_id'])) {
        $uploader_guru_id = intval($_POST['uploader_guru_id']);
    }
    
    if (empty($jenis_dokumen) || empty($tahun_ajaran) || empty($nama_dokumen) || empty($konten) || $target_mapel === 0 || empty($kelas_id)) {
        $error = 'Semua field wajib diisi (termasuk kelas)!';
    } else {
        try {
            if ($action === 'create') {
                $stmt = $pdo->prepare("INSERT INTO rpp_dokumen (guru_id, grade_level, mapel_id, kelas_id, jenis_dokumen, nama_dokumen, konten, tahun_ajaran) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $uploader_guru_id,
                    $target_grade,
                    $target_mapel,
                    $kelas_id,
                    $jenis_dokumen,
                    $nama_dokumen,
                    $konten,
                    $tahun_ajaran
                ]);
                write_audit_log("Membuat dokumen RPP: $nama_dokumen untuk Kelas $target_grade.");
                
                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Dokumen berhasil disimpan!', 'success').then(() => {
                            window.location.href = 'index.php?grade=$target_grade&mapel_id=$target_mapel';
                        });
                    });
                </script>";
                exit;
            } elseif ($action === 'update') {
                $doc_id = intval($_POST['doc_id'] ?? 0);
                
                // Fetch to check auth
                $chk = $pdo->prepare("SELECT * FROM rpp_dokumen WHERE id = ?");
                $chk->execute([$doc_id]);
                $existing_doc = $chk->fetch();
                
                if ($existing_doc) {
                    if (has_role(['Super Admin', 'Admin']) || (has_role('Guru') && $existing_doc['guru_id'] == $guru_id)) {
                        $upd = $pdo->prepare("UPDATE rpp_dokumen SET nama_dokumen = ?, konten = ?, jenis_dokumen = ?, tahun_ajaran = ?, kelas_id = ? WHERE id = ?");
                        $upd->execute([
                            $nama_dokumen,
                            $konten,
                            $jenis_dokumen,
                            $tahun_ajaran,
                            $kelas_id,
                            $doc_id
                        ]);
                        write_audit_log("Mengubah dokumen RPP: $nama_dokumen.");
                        
                        echo "<script>
                            document.addEventListener('DOMContentLoaded', function() {
                                Swal.fire('Berhasil', 'Dokumen berhasil diperbarui!', 'success').then(() => {
                                    window.location.href = 'index.php?grade=$target_grade&mapel_id=$target_mapel';
                                });
                            });
                        </script>";
                        exit;
                    } else {
                        $error = 'Anda tidak memiliki hak untuk mengubah dokumen ini!';
                    }
                }
            }
        } catch (Exception $e) {
            $error = 'Database Error: ' . $e->getMessage();
        }
    }
}

// ── PROCESS DELETE ──
if (isset($_GET['action']) && $_GET['action'] === 'delete') {
    if (!has_role(['Super Admin', 'Admin', 'Guru'])) {
        die("Akses ditolak!");
    }
    
    $doc_id = intval($_GET['doc_id'] ?? 0);
    if ($doc_id > 0) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM rpp_dokumen WHERE id = ?");
            $stmt->execute([$doc_id]);
            $doc = $stmt->fetch();
            
            if ($doc) {
                if (has_role(['Super Admin', 'Admin']) || (has_role('Guru') && $doc['guru_id'] == $guru_id)) {
                    $del = $pdo->prepare("DELETE FROM rpp_dokumen WHERE id = ?");
                    $del->execute([$doc_id]);
                    
                    write_audit_log("Menghapus dokumen RPP: " . $doc['nama_dokumen'] . ".");
                    
                    echo "<script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire('Berhasil', 'Dokumen berhasil dihapus!', 'success').then(() => {
                                window.location.href = 'index.php?grade=" . $doc['grade_level'] . "&mapel_id=" . $doc['mapel_id'] . "';
                            });
                        });
                    </script>";
                    exit;
                } else {
                    $error = 'Anda tidak memiliki hak untuk menghapus dokumen ini!';
                }
            }
        } catch (Exception $e) {
            $error = 'Error: ' . $e->getMessage();
        }
    }
}

// Mapping of emojis and titles
$emoji_map = [
    'PAK' => '📖',
    'PP' => '⚖️',
    'B.INDO' => '📝',
    'MATEMATIKA' => '🧮',
    'B.INGGRIS' => '🇬🇧',
    'BK' => '🧠',
    'PJOK' => '⚽',
    'B.JAWA' => '🎋',
    'MANDARIN' => '🈲',
    'IT' => '💻',
    'ROBOTIK' => '🤖',
    'SENI LUKIS' => '🎨',
    'SENI TARI' => '💃',
    'SENI MUSIK' => '🎵',
    'SENI SUARA' => '🎤',
    'KETERAMPILAN' => '🛠️',
    'IPAS' => '🔬',
];

// Grade compatibility logic
function isMapelAvailableForGrade($kode_mapel, $grade) {
    if ($kode_mapel === 'IPAS' && $grade < 3) {
        return false;
    }
    if ($kode_mapel === 'IT' && $grade > 4) {
        return false;
    }
    if ($kode_mapel === 'ROBOTIK' && $grade < 5) {
        return false;
    }
    return true;
}

function countFilesForGrade($grade, $pdo, $allowed_mapel_ids = null) {
    try {
        if ($allowed_mapel_ids !== null) {
            if (empty($allowed_mapel_ids)) {
                return 0;
            }
            $in_clause = implode(',', array_fill(0, count($allowed_mapel_ids), '?'));
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM rpp_dokumen WHERE grade_level = ? AND mapel_id IN ($in_clause)");
            $stmt->execute(array_merge([$grade], $allowed_mapel_ids));
        } else {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM rpp_dokumen WHERE grade_level = ?");
            $stmt->execute([$grade]);
        }
        return $stmt->fetchColumn();
    } catch (Exception $e) {
        return 0;
    }
}

// Global registry of all rendered documents to pass to JS
$rendered_docs_registry = [];

function renderDocList($grade, $mapel_id, $types, $pdo, $years_list) {
    global $current_mapel, $guru_id, $rendered_docs_registry;
    
    $type_titles = [
        'PROTA' => 'Program Tahunan (PROTA)',
        'PROSEM_1' => 'Program Semester 1 (PROSEM 1)',
        'ATP_1' => 'Alur Tujuan Pembelajaran (ATP) Semester 1',
        'RPP_DL_1' => 'RPP Deep Learning Semester 1',
        'PROSEM_2' => 'Program Semester 2 (PROSEM 2)',
        'ATP_2' => 'Alur Tujuan Pembelajaran (ATP) Semester 2',
        'RPP_DL_2' => 'RPP Deep Learning Semester 2',
        'RPP_PM_5' => 'RPP PM Bab 5',
        'RPP_PM_6' => 'RPP PM Bab 6',
        'RPP_PM_7' => 'RPP PM Bab 7',
        'RPP_PM_8' => 'RPP PM Bab 8',
        'MODUL_AJAR_S1' => 'Modul Ajar Semester 1 (Kurikulum Merdeka)',
        'MODUL_AJAR_S2' => 'Modul Ajar Semester 2 (Kurikulum Merdeka)',
    ];
    
    $in_clause = implode(',', array_fill(0, count($types), '?'));
    $query = "SELECT r.*, g.nama_guru, g.nip, k.nama_kelas 
              FROM rpp_dokumen r
              LEFT JOIN guru g ON r.guru_id = g.id
              LEFT JOIN kelas k ON r.kelas_id = k.id
              WHERE r.grade_level = ? AND r.mapel_id = ? AND r.jenis_dokumen IN ($in_clause)
              ORDER BY r.created_at DESC";
              
    $params = array_merge([$grade, $mapel_id], $types);
    try {
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $docs = $stmt->fetchAll();
    } catch (Exception $e) {
        $docs = [];
    }
    
    // Save to registry
    foreach ($docs as $d) {
        $rendered_docs_registry[$d['id']] = [
            'id' => $d['id'],
            'nama_dokumen' => $d['nama_dokumen'],
            'konten' => $d['konten'],
            'jenis_dokumen' => $d['jenis_dokumen'],
            'tahun_ajaran' => $d['tahun_ajaran'],
            'kelas_id' => $d['kelas_id'],
            'nama_kelas' => $d['nama_kelas'] ?? '-',
            'nama_guru' => $d['nama_guru'] ?? 'Administrator',
            'nip' => $d['nip'] ?? '-',
            'created_at' => date('d/m/Y H:i', strtotime($d['created_at'])),
            'grade_level' => $d['grade_level'],
            'mapel_name' => $current_mapel['nama_mapel'] ?? ''
        ];
    }
    ?>
    <div class="table-responsive mt-2">
        <table class="table table-custom table-bordered align-middle">
            <thead>
                <tr>
                    <th style="width: 200px;">Jenis Dokumen</th>
                    <th>Judul Dokumen</th>
                    <th style="width: 100px;">Kelas</th>
                    <th style="width: 110px;">Tahun Ajaran</th>
                    <th style="width: 140px;">Dibuat Oleh</th>
                    <th style="width: 130px;">Tanggal</th>
                    <th style="width: 120px; text-align: center;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($docs) > 0): ?>
                    <?php foreach ($docs as $d): ?>
                        <tr>
                            <td>
                                <strong class="text-white small d-block"><?php echo htmlspecialchars($type_titles[$d['jenis_dokumen']] ?? $d['jenis_dokumen']); ?></strong>
                            </td>
                            <td>
                                <span class="text-secondary small fw-semibold text-wrap d-inline-block">
                                    <i class="fa-regular fa-file-lines me-1 text-gold"></i> <?php echo htmlspecialchars($d['nama_dokumen']); ?>
                                </span>
                            </td>
                            <td><span class="badge bg-gold-dim text-gold font-monospace" style="font-size: 10.5px;"><?php echo htmlspecialchars($d['nama_kelas'] ?? '-'); ?></span></td>
                            <td><span class="badge bg-secondary font-monospace"><?php echo htmlspecialchars($d['tahun_ajaran']); ?></span></td>
                            <td><span class="text-secondary small"><?php echo htmlspecialchars($d['nama_guru'] ?? 'Administrator'); ?></span></td>
                            <td><span class="text-secondary small"><?php echo date('d/m/Y H:i', strtotime($d['created_at'])); ?></span></td>
                            <td class="text-center">
                                <div class="d-flex gap-1 justify-content-center">
                                    <button onclick="readDocument(<?php echo $d['id']; ?>)" class="btn btn-xs btn-outline-info" title="Lihat"><i class="fa-solid fa-eye"></i></button>
                                    <?php if (has_role(['Super Admin', 'Admin']) || (has_role('Guru') && $d['guru_id'] == $guru_id)): ?>
                                        <button onclick="editDocument(<?php echo $d['id']; ?>)" class="btn btn-xs btn-outline-warning" title="Ubah"><i class="fa-solid fa-pen"></i></button>
                                        <button onclick="confirmDelete('index.php?action=delete&doc_id=<?php echo $d['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i></button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <?php foreach ($types as $t): ?>
                        <tr class="opacity-50">
                            <td>
                                <span class="text-secondary small d-block"><?php echo htmlspecialchars($type_titles[$t] ?? $t); ?></span>
                            </td>
                            <td colspan="5" class="text-secondary small italic"><i class="fa-solid fa-info-circle me-1"></i> Belum ada dokumen dibuat</td>
                            <td class="text-center">
                                <?php if (has_role(['Super Admin', 'Admin', 'Guru'])): ?>
                                    <button class="btn btn-xs btn-gold" onclick="openCreateModal('<?php echo $t; ?>')"><i class="fa-solid fa-plus"></i> Buat Baru</button>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}
?>

<style>
    .list-group-custom .list-group-item {
        color: var(--text-2);
        background: var(--bg-card);
        border: 1px solid var(--border) !important;
        border-radius: var(--r-md) !important;
    }
    .list-group-custom .list-group-item:hover {
        background: var(--bg-hover);
        color: var(--accent);
    }
    .list-group-custom .list-group-item.active {
        background: var(--accent) !important;
        border-color: var(--accent) !important;
        color: #fff !important;
        box-shadow: var(--accent-shadow);
    }
    .hover-scale-up {
        transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
    }
    .hover-scale-up:hover {
        transform: scale(1.03) translateY(-3px);
        box-shadow: var(--shadow-md) !important;
        border-color: var(--accent-border) !important;
    }
    .nav-tabs-custom .nav-link {
        color: var(--text-2);
        border: none;
        border-bottom: 2px solid transparent;
        background: transparent;
        border-radius: 0;
    }
    .nav-tabs-custom .nav-link:hover {
        color: var(--accent);
        border-bottom-color: var(--accent-border);
    }
    .nav-tabs-custom .nav-link.active {
        color: var(--accent) !important;
        border-bottom: 2px solid var(--accent) !important;
        background: transparent !important;
    }
    body.dark-theme .swal2-popup {
        background-color: var(--bg-card) !important;
        color: var(--text-1) !important;
        border: 1px solid var(--border) !important;
    }
    #read-content table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
        margin-bottom: 20px;
        background: rgba(255, 255, 255, 0.02) !important;
        color: var(--text-1) !important;
        white-space: normal !important;
        font-family: var(--font-family-sans-serif, system-ui, -apple-system, sans-serif) !important;
    }
    #read-content table th, #read-content table td {
        border: 1px solid var(--border) !important;
        padding: 10px 14px;
        color: var(--text-1) !important;
        background: transparent !important;
    }
    #read-content table th {
        font-weight: 700;
        background: rgba(98, 87, 222, 0.1) !important;
        color: var(--accent-light) !important;
    }
    body.light-theme #read-content table th {
        background: rgba(98, 87, 222, 0.05) !important;
        color: var(--accent) !important;
    }
    .modal {
        background: rgba(0, 0, 0, 0.55) !important;
        backdrop-filter: blur(4px);
    }
    
    /* Table Builder Grid - Premium Spreadsheet Aesthetics */
    .builder-table-wrapper {
        border: 1px solid var(--border);
        border-radius: var(--r-md);
        overflow: hidden;
        background: rgba(0, 0, 0, 0.1);
        margin-top: 10px;
    }
    #builder-table {
        width: 100%;
        margin-bottom: 0;
        border-collapse: collapse;
    }
    #builder-table th {
        background: rgba(98, 87, 222, 0.12) !important;
        color: var(--text-1) !important;
        font-weight: 600;
        font-size: 12px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border: 1px solid var(--border) !important;
        padding: 10px 12px;
        vertical-align: middle;
    }
    #builder-table td {
        padding: 0 !important;
        border: 1px solid var(--border) !important;
        background: transparent !important;
    }
    .table-builder-field {
        width: 100%;
        height: 100%;
        border: none !important;
        background: transparent !important;
        color: var(--text-1) !important;
        padding: 10px 12px;
        font-size: 13px;
        border-radius: 0 !important;
        box-shadow: none !important;
        outline: none !important;
        transition: background-color 0.15s ease, box-shadow 0.15s ease;
    }
    .table-builder-field:focus {
        background: rgba(98, 87, 222, 0.06) !important;
        box-shadow: inset 0 0 0 1.5px var(--accent) !important;
    }
    textarea.table-builder-field {
        resize: vertical;
        min-height: 42px;
        display: block;
        line-height: 1.4;
    }
    #builder-table td.action-cell {
        padding: 4px !important;
        text-align: center;
        vertical-align: middle;
    }
    .btn-delete-row {
        background: rgba(239, 68, 68, 0.1);
        color: #ef4444;
        border: 1px solid rgba(239, 68, 68, 0.2);
        border-radius: var(--r-sm);
        padding: 4px 8px;
        font-size: 12px;
        transition: all 0.15s ease;
        cursor: pointer;
    }
    .btn-delete-row:hover {
        background: #ef4444;
        color: #fff;
        border-color: #ef4444;
    }
</style>

<div class="glass-card mb-4 p-3 no-print">
    <div class="row g-3 align-items-center">
        <div class="col-12 col-md-6">
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-folder-closed me-2"></i> Administrasi Pembelajaran (RPP)</h5>
            <p class="text-secondary small mb-0">Kelola kurikulum, silabus, PROTA, PROSEM, ATP, dan RPP guru SD Kristen Petra 1.</p>
        </div>
        <div class="col-12 col-md-6 d-flex gap-2 justify-content-md-end">
            <!-- Global Search bar -->
            <div class="search-input-container w-75">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" id="global-search" class="form-control form-control-custom" placeholder="Cari file administrasi...">
            </div>
            <button onclick="triggerSearch()" class="btn btn-outline-custom">Cari</button>
        </div>
    </div>
</div>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
    </div>
<?php endif; ?>

<div class="row g-4">
    <!-- Left Column: Tingkat Kelas List -->
    <div class="col-12 col-lg-3">
        <div class="glass-card">
            <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-graduation-cap me-2"></i> Tingkat Kelas</h6>
            <div class="list-group list-group-custom gap-2">
                <?php for ($i = 1; $i <= 6; $i++): 
                    $active_class = ($grade === $i) ? 'active' : '';
                ?>
                    <a href="index.php?grade=<?php echo $i; ?>" class="list-group-item list-group-item-action d-flex align-items-center justify-content-between rounded border-0 py-2.5 px-3 <?php echo $active_class; ?>" style="font-size: 13.5px; font-weight: 500; transition: all 0.2s;">
                        <span><i class="fa-solid fa-folder me-2"></i> Kelas <?php echo $i; ?></span>
                        <span class="badge bg-secondary rounded-pill" style="font-size: 10px;"><?php echo countFilesForGrade($i, $pdo, $is_admin ? null : $allowed_mapel_ids); ?> file</span>
                    </a>
                <?php endfor; ?>
            </div>
        </div>
    </div>

    <!-- Right Column: Subject Grid or Detail Tabs -->
    <?php if ($current_mapel === null): ?>
        <div class="col-12 col-lg-9">
            <div class="glass-card">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4 pb-2 border-bottom border-secondary border-opacity-10">
                    <div>
                        <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-folder-open me-2"></i> Kelas <?php echo $grade; ?></h5>
                        <p class="text-secondary small mb-0">Pilih mata pelajaran untuk mengelola administrasi berkas kurikulum.</p>
                    </div>
                </div>
                
                <div class="row g-3" id="mapel-grid">
                    <?php 
                    $shown_count = 0;
                    foreach ($subjects as $sub): 
                        if (!isMapelAvailableForGrade($sub['kode_mapel'], $grade)) continue;
                        $shown_count++;
                        $emoji = $emoji_map[$sub['kode_mapel']] ?? '📖';
                        
                        // Count docs
                        $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM rpp_dokumen WHERE grade_level = ? AND mapel_id = ?");
                        $count_stmt->execute([$grade, $sub['id']]);
                        $doc_count = $count_stmt->fetchColumn();
                    ?>
                        <div class="col-12 col-sm-6 col-md-4 col-xl-3 mapel-card" data-name="<?php echo htmlspecialchars($sub['nama_mapel']); ?>">
                            <a href="index.php?grade=<?php echo $grade; ?>&mapel_id=<?php echo $sub['id']; ?>" class="text-decoration-none">
                                <div class="glass-card text-center p-3 h-100 d-flex flex-column align-items-center justify-content-center hover-scale-up" style="cursor: pointer; min-height: 140px; background: rgba(255,255,255,0.03);">
                                    <div style="font-size: 2.2rem;" class="mb-2"><?php echo $emoji; ?></div>
                                    <strong class="text-white d-block text-truncate w-100" style="font-size: 13.5px;"><?php echo htmlspecialchars($sub['nama_mapel']); ?></strong>
                                    <span class="text-secondary font-monospace" style="font-size: 10px;"><?php echo htmlspecialchars($sub['kode_mapel']); ?></span>
                                    <span class="badge bg-gold-dim text-gold mt-2 font-monospace" style="font-size: 9.5px;"><?php echo $doc_count; ?> Berkas</span>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                    
                    <?php if ($shown_count === 0): ?>
                        <div class="text-center py-5">
                            <i class="fa-solid fa-ban text-secondary mb-3" style="font-size: 3rem; opacity: 0.5;"></i>
                            <p class="text-secondary mb-0">Tidak ada mata pelajaran aktif untuk jenjang ini.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="col-12 col-lg-9">
            <div class="glass-card">
                <!-- Breadcrumbs -->
                <nav aria-label="breadcrumb" class="mb-3">
                    <ol class="breadcrumb" style="font-size: 12.5px;">
                        <li class="breadcrumb-item"><a href="index.php?grade=<?php echo $grade; ?>" class="text-gold text-decoration-none"><i class="fa-solid fa-house-chimney"></i> Kelas <?php echo $grade; ?></a></li>
                        <li class="breadcrumb-item active text-white" aria-current="page"><?php echo htmlspecialchars($current_mapel['nama_mapel']); ?></li>
                    </ol>
                </nav>
                
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4 pb-2 border-bottom border-secondary border-opacity-10">
                    <div class="d-flex align-items-center gap-3">
                        <div style="font-size: 2.5rem;"><?php echo $emoji_map[$current_mapel['kode_mapel']] ?? '📖'; ?></div>
                        <div>
                            <h5 class="text-gold fw-bold mb-0"><?php echo htmlspecialchars($current_mapel['nama_mapel']); ?> — Kelas <?php echo $grade; ?></h5>
                            <p class="text-secondary small mb-0">Pilih Tab berkas untuk melihat, mengubah, atau membuat dokumen baru.</p>
                        </div>
                    </div>
                    <?php if (has_role(['Super Admin', 'Admin', 'Guru'])): ?>
                        <button class="btn btn-gold btn-sm" onclick="openCreateModal()"><i class="fa-solid fa-plus me-1"></i> Buat Dokumen Baru</button>
                    <?php endif; ?>
                </div>

                <!-- Tab Headers -->
                <ul class="nav nav-tabs nav-tabs-custom mb-3 border-secondary border-opacity-10" id="rppTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active py-2 px-3 fw-bold" id="umum-tab" data-bs-toggle="tab" data-bs-target="#umum-pane" type="button" role="tab" aria-controls="umum-pane" aria-selected="true" style="font-size: 13px;">Tab UMUM</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link py-2 px-3 fw-bold" id="sem1-tab" data-bs-toggle="tab" data-bs-target="#sem1-pane" type="button" role="tab" aria-controls="sem1-pane" aria-selected="false" style="font-size: 13px;">Tab SEMESTER 1</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link py-2 px-3 fw-bold" id="sem2-tab" data-bs-toggle="tab" data-bs-target="#sem2-pane" type="button" role="tab" aria-controls="sem2-pane" aria-selected="false" style="font-size: 13px;">Tab SEMESTER 2</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link py-2 px-3 fw-bold" id="pm-tab" data-bs-toggle="tab" data-bs-target="#pm-pane" type="button" role="tab" aria-controls="pm-pane" aria-selected="false" style="font-size: 13px;">Tab RPP PM (Pengayaan)</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link py-2 px-3 fw-bold d-flex align-items-center gap-2" id="modul-tab" data-bs-toggle="tab" data-bs-target="#modul-pane" type="button" role="tab" aria-controls="modul-pane" aria-selected="false" style="font-size: 13px;">
                            <i class="fa-solid fa-layer-group" style="color:#22c55e;"></i> Modul Ajar
                            <span class="badge rounded-pill" style="background:linear-gradient(135deg,#22c55e,#16a34a);font-size:8px;padding:2px 6px;letter-spacing:.3px;">K-Merdeka</span>
                        </button>
                    </li>
                </ul>

                <!-- Tab Content Panes -->
                <div class="tab-content" id="rppTabsContent">
                    <!-- Tab Umum Pane -->
                    <div class="tab-pane fade show active" id="umum-pane" role="tabpanel" aria-labelledby="umum-tab">
                        <?php renderDocList($grade, $mapel_id, ['PROTA'], $pdo, $years_list); ?>
                    </div>
                    <!-- Tab Sem 1 Pane -->
                    <div class="tab-pane fade" id="sem1-pane" role="tabpanel" aria-labelledby="sem1-tab">
                        <?php renderDocList($grade, $mapel_id, ['PROSEM_1', 'ATP_1', 'RPP_DL_1'], $pdo, $years_list); ?>
                    </div>
                    <!-- Tab Sem 2 Pane -->
                    <div class="tab-pane fade" id="sem2-pane" role="tabpanel" aria-labelledby="sem2-tab">
                        <?php renderDocList($grade, $mapel_id, ['PROSEM_2', 'ATP_2', 'RPP_DL_2'], $pdo, $years_list); ?>
                    </div>
                    <!-- Tab PM Pane -->
                    <div class="tab-pane fade" id="pm-pane" role="tabpanel" aria-labelledby="pm-tab">
                        <?php renderDocList($grade, $mapel_id, ['RPP_PM_5', 'RPP_PM_6', 'RPP_PM_7', 'RPP_PM_8'], $pdo, $years_list); ?>
                    </div>
                    <!-- Tab Modul Ajar Pane -->
                    <div class="tab-pane fade" id="modul-pane" role="tabpanel" aria-labelledby="modul-tab">
                        <div class="d-flex justify-content-between align-items-center mb-3 p-3 rounded" style="background:linear-gradient(135deg,rgba(34,197,94,0.07),rgba(16,163,74,0.03));border:1px solid rgba(34,197,94,0.2);">
                            <div>
                                <h6 class="fw-bold mb-1" style="color:#22c55e;"><i class="fa-solid fa-layer-group me-2"></i>Modul Ajar — Kurikulum Merdeka SD</h6>
                                <p class="text-secondary small mb-0">Rancangan pembelajaran lengkap sesuai regulasi Kemendikbud untuk T.A. 2026/2027 (Fase A, B, C).</p>
                            </div>
                            <?php if (has_role(['Super Admin', 'Admin', 'Guru'])): ?>
                                <div class="d-flex gap-2 flex-shrink-0">
                                    <button class="btn btn-sm fw-semibold" style="background:linear-gradient(135deg,#22c55e,#16a34a);color:#fff;" onclick="openModulAjarWizard('MODUL_AJAR_S1')">
                                        <i class="fa-solid fa-plus me-1"></i> Sem 1
                                    </button>
                                    <button class="btn btn-sm btn-outline-success fw-semibold" onclick="openModulAjarWizard('MODUL_AJAR_S2')">
                                        <i class="fa-solid fa-plus me-1"></i> Sem 2
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php renderModulAjarList($grade, $mapel_id, $pdo); ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<!-- JSON registry of rendered documents -->
<script>
    const docsRegistry = <?php echo json_encode($rendered_docs_registry); ?>;
</script>

<!-- Create / Edit Document Modal -->
<?php if (has_role(['Super Admin', 'Admin', 'Guru']) && $current_mapel !== null): ?>
<div class="modal fade" id="editorModal" tabindex="-1" aria-labelledby="editorModalLabel" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg" style="background: var(--bg-card); border-radius: var(--r-lg);">
            <div class="modal-header border-bottom border-secondary border-opacity-10 py-3">
                <h5 class="modal-title fw-bold text-gold" id="editorModalLabel"><i class="fa-solid fa-pen-to-square me-2"></i> Edit Dokumen RPP</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="index.php" id="editor-form" onsubmit="prepareRPPForm(event)">
                <div class="modal-body p-4">
                    <?php csrf_input(); ?>
                    <input type="hidden" name="action" id="form-action" value="create">
                    <input type="hidden" name="doc_id" id="form-doc-id" value="">
                    <input type="hidden" name="grade_level" value="<?php echo $grade; ?>">
                    <input type="hidden" name="mapel_id" value="<?php echo $mapel_id; ?>">
                    
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label for="nama_dokumen" class="form-label form-label-custom">Judul Dokumen <span class="text-danger">*</span></label>
                            <input type="text" name="nama_dokumen" id="nama_dokumen" class="form-control form-control-custom text-white" placeholder="Contoh: RPP Matematika Bab 1 Pecahan" required>
                        </div>
                        
                        <div class="col-md-2">
                            <label for="kelas_id" class="form-label form-label-custom">Kelas (Rombel) <span class="text-danger">*</span></label>
                            <select name="kelas_id" id="kelas_id" class="form-select form-control-custom bg-dark-select text-white" required>
                                <option value="">Pilih Kelas...</option>
                                <?php foreach ($available_classes as $kls): ?>
                                    <option value="<?php echo $kls['id']; ?>">
                                        <?php echo htmlspecialchars($kls['nama_kelas']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="col-md-3">
                            <label for="jenis_dokumen" class="form-label form-label-custom">Jenis Dokumen <span class="text-danger">*</span></label>
                            <select name="jenis_dokumen" id="jenis_dokumen" class="form-select form-control-custom bg-dark-select text-white" required>
                                <optgroup label="Tab UMUM">
                                    <option value="PROTA">Program Tahunan (PROTA)</option>
                                </optgroup>
                                <optgroup label="Tab SEMESTER 1">
                                    <option value="PROSEM_1">Program Semester 1 (PROSEM 1)</option>
                                    <option value="ATP_1">Alur Tujuan Pembelajaran (ATP) Semester 1</option>
                                    <option value="RPP_DL_1">RPP Deep Learning Semester 1</option>
                                </optgroup>
                                <optgroup label="Tab SEMESTER 2">
                                    <option value="PROSEM_2">Program Semester 2 (PROSEM 2)</option>
                                    <option value="ATP_2">Alur Tujuan Pembelajaran (ATP) Semester 2</option>
                                    <option value="RPP_DL_2">RPP Deep Learning Semester 2</option>
                                </optgroup>
                                <optgroup label="Tab RPP PM (Pengayaan)">
                                    <option value="RPP_PM_5">RPP PM Bab 5</option>
                                    <option value="RPP_PM_6">RPP PM Bab 6</option>
                                    <option value="RPP_PM_7">RPP PM Bab 7</option>
                                    <option value="RPP_PM_8">RPP PM Bab 8</option>
                                </optgroup>
                            </select>
                        </div>
                        
                        <div class="col-md-3">
                            <label for="tahun_ajaran" class="form-label form-label-custom">Tahun Ajaran <span class="text-danger">*</span></label>
                            <select name="tahun_ajaran" id="tahun_ajaran" class="form-select form-control-custom bg-dark-select text-white" required>
                                <?php foreach ($years_list as $yr): ?>
                                    <option value="<?php echo $yr['tahun_ajaran']; ?>" <?php echo ($active_yr['tahun_ajaran'] ?? '') === $yr['tahun_ajaran'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($yr['tahun_ajaran']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <?php if (has_role(['Super Admin', 'Admin'])): ?>
                            <div class="col-12">
                                <label class="form-label form-label-custom">Atas Nama Guru</label>
                                <select name="uploader_guru_id" class="form-select form-control-custom bg-dark-select text-white" required>
                                    <?php foreach ($teachers as $tc): ?>
                                        <option value="<?php echo $tc['id']; ?>" <?php echo $tc['id'] == $default_sel_guru_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($tc['nama_guru']) . ' (' . htmlspecialchars($tc['nip']) . ')'; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php endif; ?>

                        <div class="col-12">
                            <label class="form-label form-label-custom d-flex justify-content-between align-items-center mb-2.5">
                                <span>Isi Dokumen <span class="text-danger">*</span></span>
                                <div class="btn-group" role="group" aria-label="Mode Input">
                                    <input type="radio" class="btn-check" name="editor_mode" id="mode_text" value="text" checked onclick="switchEditorMode('text')">
                                    <label class="btn btn-outline-custom btn-xs font-monospace px-2.5" for="mode_text" style="font-size: 11.5px;"><i class="fa-solid fa-align-left me-1"></i> Editor Teks / HTML</label>
                                    
                                    <input type="radio" class="btn-check" name="editor_mode" id="mode_table" value="table" onclick="switchEditorMode('table')">
                                    <label class="btn btn-outline-custom btn-xs font-monospace px-2.5" for="mode_table" style="font-size: 11.5px;"><i class="fa-solid fa-table me-1"></i> Pembuat Tabel Dinamis</label>
                                </div>
                            </label>
                            
                            <!-- Standard Text Editor Container -->
                            <div id="text-editor-container">
                                <textarea name="konten" id="konten" class="form-control form-control-custom text-white" style="height: 380px; font-family: monospace, Courier, monospace; line-height: 1.5;" placeholder="Tulis atau paste isi dokumen administrasi / RPP Anda di sini..." required></textarea>
                            </div>
                            
                            <!-- Table Builder Container -->
                            <div id="table-builder-container" class="d-none p-3.5 rounded" style="background: rgba(255, 255, 255, 0.01); border: 1px solid var(--border); backdrop-filter: blur(2px);">
                                <!-- Table Builder Toolbar -->
                                <div class="row g-3 mb-3 align-items-end">
                                    <div class="col-12 col-md-4">
                                        <label class="form-label form-label-custom text-gold" style="font-size: 11px;">Pilih Template Tabel</label>
                                        <select class="form-select form-control-custom bg-dark-select text-white py-1.5" id="table-preset" onchange="applyTablePreset(this.value)">
                                            <option value="atp">Alur Tujuan Pembelajaran (ATP)</option>
                                            <option value="prota">Program Tahunan (PROTA)</option>
                                            <option value="prosem">Program Semester (PROSEM)</option>
                                            <option value="custom">Kustom (Buat Kolom Sendiri)</option>
                                        </select>
                                    </div>
                                    <div class="col-12 col-md-5" id="custom-headers-div" style="display:none;">
                                        <label class="form-label form-label-custom text-gold" style="font-size: 11px;">Tajuk Kolom (Pisah dengan koma)</label>
                                        <div class="d-flex gap-2">
                                            <input type="text" id="custom-headers-input" class="form-control form-control-custom py-1.5 text-white" placeholder="Contoh: No, Topik, Target, Keterangan">
                                            <button type="button" class="btn btn-gold btn-xs px-2" onclick="applyCustomHeaders()"><i class="fa-solid fa-check"></i> Set</button>
                                        </div>
                                    </div>
                                    <div class="col text-end">
                                        <button type="button" class="btn btn-outline-info btn-xs py-1.5" onclick="toggleExcelImportArea()"><i class="fa-solid fa-file-import me-1"></i> Impor dari Excel / Sheets</button>
                                    </div>
                                </div>
                                
                                <!-- Excel Import Area (Collapsible) -->
                                <div id="excel-import-area" class="d-none mb-3 p-3 rounded border border-info border-opacity-25" style="background: rgba(0, 180, 216, 0.03);">
                                    <label class="form-label form-label-custom text-info" style="font-size: 11.5px;"><i class="fa-solid fa-info-circle me-1"></i> Cara Impor dari Excel / Sheets:</label>
                                    <p class="text-secondary mb-2" style="font-size: 11px; line-height: 1.3;">Salin (Copy) sel-sel data dari lembar Excel Anda, lalu tempelkan (Paste) ke kolom di bawah ini. Tajuk kolom baris pertama di Excel tidak wajib, tetapi urutan kolom harus sesuai.</p>
                                    <textarea id="excel-paste-box" class="form-control form-control-custom text-white mb-2" style="height: 100px; font-size: 11px; font-family: monospace;" placeholder="Tempel (Paste) data Excel Anda di sini..."></textarea>
                                    <div class="text-end">
                                        <button type="button" class="btn btn-info btn-xs text-black font-semibold" onclick="processExcelImport()"><i class="fa-solid fa-check me-1"></i> Proses Impor Data</button>
                                    </div>
                                </div>
                                
                                <!-- Interactive Table Input Grid -->
                                <div class="table-responsive builder-table-wrapper" style="max-height: 350px; overflow-y: auto;">
                                    <table class="table align-middle mb-0" id="builder-table">
                                        <thead class="sticky-top">
                                            <tr id="builder-table-headers">
                                                <!-- Dyn columns -->
                                            </tr>
                                        </thead>
                                        <tbody id="builder-table-body">
                                            <!-- Dyn rows -->
                                        </tbody>
                                    </table>
                                </div>
                                
                                <!-- Control bar for rows -->
                                <div class="d-flex justify-content-between align-items-center mt-2.5">
                                    <button type="button" class="btn btn-xs btn-outline-custom" onclick="addBuilderRow()"><i class="fa-solid fa-plus me-1"></i> Tambah Baris Baru</button>
                                    <span class="text-secondary small" id="row-count-indicator">0 baris</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer border-top border-secondary border-opacity-10 py-2.5">
                    <button type="button" class="btn btn-outline-custom btn-sm" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-gold btn-sm"><i class="fa-solid fa-floppy-disk me-1"></i> Simpan Dokumen</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Read Document Modal -->
<div class="modal fade" id="readModal" tabindex="-1" aria-labelledby="readModalLabel" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content border-0 shadow-lg" style="background: var(--bg-card); border-radius: var(--r-lg);">
            <div class="modal-header border-bottom border-secondary border-opacity-10 py-3">
                <h5 class="modal-title fw-bold text-gold" id="readModalLabel"><i class="fa-solid fa-book-open me-2"></i> Pratinjau Dokumen</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <!-- Meta data info grid -->
                <div class="row g-3 mb-4 p-3 rounded" style="background: rgba(255,255,255,0.02); border: 1px solid var(--border);">
                    <div class="col-6 col-md-3">
                        <span class="text-secondary small d-block">Judul Dokumen</span>
                        <strong class="text-white" id="read-title">-</strong>
                    </div>
                    <div class="col-6 col-md-3">
                        <span class="text-secondary small d-block">Mata Pelajaran & Kelas</span>
                        <strong class="text-white" id="read-mapel">-</strong>
                    </div>
                    <div class="col-6 col-md-3">
                        <span class="text-secondary small d-block">Dibuat Oleh</span>
                        <strong class="text-white" id="read-author">-</strong>
                    </div>
                    <div class="col-6 col-md-3">
                        <span class="text-secondary small d-block">Tahun Ajaran & Tanggal</span>
                        <strong class="text-white" id="read-date">-</strong>
                    </div>
                </div>

                <!-- Document Content Viewer -->
                <h6 class="text-gold fw-bold mb-2"><i class="fa-solid fa-align-left me-1"></i> Isi Dokumen:</h6>
                <div class="p-3 rounded border border-secondary border-opacity-20 text-white" id="read-content" style="white-space: pre-wrap; font-family: monospace, Courier, monospace; min-height: 250px; max-height: 450px; overflow-y: auto; background: rgba(0,0,0,0.15); font-size: 13.5px; line-height: 1.6;">
                    -
                </div>
            </div>
            <div class="modal-footer border-top border-secondary border-opacity-10 py-2.5">
                <button type="button" class="btn btn-outline-custom btn-sm" data-bs-dismiss="modal">Tutup</button>
                <a href="" id="btn-print-link" target="_blank" class="btn btn-gold btn-sm"><i class="fa-solid fa-print me-1"></i> Cetak Dokumen</a>
            </div>
        </div>
    </div>
</div>

<?php
// ── RENDER MODUL AJAR LIST ──
function renderModulAjarList($grade, $mapel_id, $pdo) {
    global $guru_id;
    try {
        $stmt = $pdo->prepare("SELECT r.*, g.nama_guru, g.nip, k.nama_kelas
              FROM rpp_dokumen r
              LEFT JOIN guru g ON r.guru_id = g.id
              LEFT JOIN kelas k ON r.kelas_id = k.id
              WHERE r.grade_level = ? AND r.mapel_id = ? AND r.jenis_dokumen IN ('MODUL_AJAR_S1','MODUL_AJAR_S2')
              ORDER BY r.jenis_dokumen ASC, r.created_at DESC");
        $stmt->execute([$grade, $mapel_id]);
        $docs = $stmt->fetchAll();
    } catch (Exception $e) { $docs = []; }

    if (empty($docs)): ?>
        <div class="text-center py-5" style="opacity:.65;">
            <i class="fa-solid fa-layer-group text-secondary mb-3" style="font-size:3rem;"></i>
            <p class="text-secondary fw-semibold mb-1">Belum ada Modul Ajar dibuat</p>
            <p class="text-secondary small">Klik tombol "Sem 1" atau "Sem 2" di atas untuk mulai membuat modul ajar.</p>
        </div>
    <?php else: ?>
        <div class="row g-3">
        <?php foreach ($docs as $d):
            $ma = json_decode($d['konten'], true);
            $info = $ma['info_umum'] ?? [];
            $fase = $info['fase'] ?? '-';
            $model = $info['model_pembelajaran'] ?? '-';
            $alokasi = $info['alokasi_waktu'] ?? '-';
            $target = $info['target_peserta'] ?? '-';
            $p3str = is_array($info['profil_pelajar'] ?? null) ? implode(' • ', $info['profil_pelajar']) : '-';
            $is_s1 = $d['jenis_dokumen'] === 'MODUL_AJAR_S1';
            $badge_color = $is_s1 ? '#3b82f6' : '#8b5cf6';
            $label = $is_s1 ? 'Semester 1' : 'Semester 2';
            $can_edit = has_role(['Super Admin','Admin']) || (has_role('Guru') && $d['guru_id'] == $guru_id);
        ?>
            <div class="col-12 col-xl-6">
                <div class="glass-card p-3 h-100" style="border:1px solid rgba(34,197,94,0.15);background:rgba(34,197,94,0.015);">
                    <div class="d-flex justify-content-between align-items-start mb-2 gap-2">
                        <div class="flex-grow-1 min-width-0">
                            <span class="badge mb-1" style="background:<?php echo $badge_color;?>;font-size:10px;"><?php echo $label;?></span>
                            <h6 class="fw-bold text-white mb-1" style="font-size:14px;line-height:1.3;word-break:break-word;"><?php echo htmlspecialchars($d['nama_dokumen']);?></h6>
                            <span class="text-secondary" style="font-size:12px;"><?php echo htmlspecialchars($d['nama_guru'] ?? 'Administrator');?> &bull; <?php echo htmlspecialchars($d['nama_kelas'] ?? '-');?></span>
                        </div>
                        <div class="d-flex flex-column gap-1 flex-shrink-0">
                            <button onclick="readModulAjar(<?php echo $d['id'];?>)" class="btn btn-xs btn-outline-info"><i class="fa-solid fa-eye me-1"></i>Lihat</button>
                            <?php if ($can_edit): ?>
                                <button onclick="editModulAjar(<?php echo $d['id'];?>)" class="btn btn-xs btn-outline-warning"><i class="fa-solid fa-pen"></i></button>
                                <button onclick="confirmDelete('index.php?action=delete&doc_id=<?php echo $d['id'];?>')" class="btn btn-xs btn-outline-danger"><i class="fa-solid fa-trash"></i></button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row g-2 mb-2" style="font-size:11.5px;">
                        <div class="col-6"><span class="text-secondary d-block">Fase</span><span class="fw-semibold text-white"><?php echo htmlspecialchars($fase);?></span></div>
                        <div class="col-6"><span class="text-secondary d-block">Alokasi Waktu</span><span class="fw-semibold text-white"><?php echo htmlspecialchars($alokasi);?></span></div>
                        <div class="col-6"><span class="text-secondary d-block">Model</span><span class="fw-semibold text-white"><?php echo htmlspecialchars($model);?></span></div>
                        <div class="col-6"><span class="text-secondary d-block">Target Peserta</span><span class="fw-semibold text-white"><?php echo htmlspecialchars($target);?></span></div>
                        <?php if ($p3str !== '-'): ?>
                        <div class="col-12"><span class="text-secondary d-block">Profil Pelajar Pancasila</span><span class="fw-semibold" style="color:#22c55e;font-size:11px;"><?php echo htmlspecialchars($p3str);?></span></div>
                        <?php endif; ?>
                    </div>
                    <div class="pt-2 border-top border-secondary border-opacity-10 d-flex justify-content-between align-items-center">
                        <span class="text-secondary" style="font-size:10.5px;"><i class="fa-regular fa-clock me-1"></i><?php echo date('d/m/Y H:i', strtotime($d['created_at']));?></span>
                        <a href="print.php?id=<?php echo $d['id'];?>" target="_blank" class="btn btn-xs" style="background:rgba(34,197,94,0.12);color:#22c55e;border:1px solid rgba(34,197,94,0.25);"><i class="fa-solid fa-print me-1"></i>Cetak</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        </div>
    <?php endif;
}
?>

<!-- Modul Ajar Wizard Modal -->
<?php if (has_role(['Super Admin', 'Admin', 'Guru']) && $current_mapel !== null): ?>
<div class="modal fade" id="modulAjarModal" tabindex="-1" aria-labelledby="modulAjarModalLabel" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg" style="background:var(--bg-card);border-radius:var(--r-lg);">
            <div class="modal-header border-bottom border-secondary border-opacity-10 py-3" style="background:linear-gradient(135deg,rgba(34,197,94,0.08),transparent);">
                <div>
                    <h5 class="modal-title fw-bold mb-0" style="color:#22c55e;" id="modulAjarModalLabel"><i class="fa-solid fa-layer-group me-2"></i><span id="ma-modal-title">Buat Modul Ajar Baru</span></h5>
                    <small class="text-secondary">Kurikulum Merdeka — SD Kristen Petra 1 — T.A. 2026/2027</small>
                </div>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <!-- Progress Steps (now inside header area, compact) -->
            <div class="px-4 pt-2 pb-0 border-bottom border-secondary border-opacity-10" style="background:rgba(255,255,255,0.01);">
                <div class="d-flex align-items-center gap-2 mb-2">
                    <div id="dot-1" class="ma-dot" style="width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:11px;background:#22c55e;color:#fff;flex-shrink:0;transition:all .3s;">A</div>
                    <span id="sl-1" style="font-size:11px;font-weight:600;color:#22c55e;white-space:nowrap;">Informasi Umum</span>
                    <div id="ln-1" style="flex:1;height:2px;background:rgba(34,197,94,0.2);border-radius:2px;transition:background .3s;min-width:20px;"></div>
                    <div id="dot-2" class="ma-dot" style="width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:11px;background:rgba(255,255,255,0.08);color:var(--text-2);flex-shrink:0;transition:all .3s;">B</div>
                    <span id="sl-2" style="font-size:11px;font-weight:600;color:var(--text-2);white-space:nowrap;">Komponen Inti</span>
                    <div id="ln-2" style="flex:1;height:2px;background:rgba(255,255,255,0.06);border-radius:2px;transition:background .3s;min-width:20px;"></div>
                    <div id="dot-3" class="ma-dot" style="width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:11px;background:rgba(255,255,255,0.08);color:var(--text-2);flex-shrink:0;transition:all .3s;">C</div>
                    <span id="sl-3" style="font-size:11px;font-weight:600;color:var(--text-2);white-space:nowrap;">Lampiran</span>
                </div>
            </div>
            <form method="POST" action="index.php" id="modul-ajar-form" novalidate>
                <?php csrf_input(); ?>
                <input type="hidden" name="action" id="ma-action" value="create">
                <input type="hidden" name="doc_id" id="ma-doc-id" value="">
                <input type="hidden" name="grade_level" value="<?php echo $grade; ?>">
                <input type="hidden" name="mapel_id" value="<?php echo $mapel_id; ?>">
                <input type="hidden" name="jenis_dokumen" id="ma-jenis" value="MODUL_AJAR_S1">
                <input type="hidden" name="konten" id="ma-konten-hidden">
                <div class="modal-body p-3">

                    <!-- STEP A: Informasi Umum -->
                    <div id="ma-step-1" class="ma-step">
                        <div class="mb-3 p-2 rounded" style="background:rgba(34,197,94,0.06);border-left:3px solid #22c55e;">
                            <small class="fw-bold" style="color:#22c55e;">A. INFORMASI UMUM</small>
                            <p class="text-secondary small mb-0">Identitas modul, kompetensi awal, target peserta, dan Profil Pelajar Pancasila (P3).</p>
                        </div>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label form-label-custom">Judul Modul Ajar <span class="text-danger">*</span></label>
                                <input type="text" id="ma-nama-dokumen" name="nama_dokumen" class="form-control form-control-custom text-white" placeholder="Contoh: Modul Ajar Matematika — Pecahan Kelas 3A">
                            </div>
                            <div class="col-md-3">
                                <label class="form-label form-label-custom">Kelas (Rombel) <span class="text-danger">*</span></label>
                                <select name="kelas_id" id="ma-kelas-id" class="form-select form-control-custom bg-dark-select text-white">
                                    <option value="">Pilih Kelas...</option>
                                    <?php foreach ($available_classes as $kls): ?>
                                        <option value="<?php echo $kls['id']; ?>"><?php echo htmlspecialchars($kls['nama_kelas']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <label class="form-label form-label-custom">Tahun Ajaran <span class="text-danger">*</span></label>
                                <select name="tahun_ajaran" id="ma-tahun" class="form-select form-control-custom bg-dark-select text-white">
                                    <?php foreach ($years_list as $yr): ?>
                                        <option value="<?php echo $yr['tahun_ajaran']; ?>" <?php echo ($active_yr['tahun_ajaran'] ?? '') === $yr['tahun_ajaran'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($yr['tahun_ajaran']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label form-label-custom">Nama Penyusun</label>
                                <input type="text" id="ma-penyusun" class="form-control form-control-custom text-white" value="<?php echo htmlspecialchars($logged_in_guru['nama_guru'] ?? 'Administrator'); ?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label form-label-custom">Fase Kurikulum <span class="text-danger">*</span></label>
                                <select id="ma-fase" class="form-select form-control-custom bg-dark-select text-white">
                                    <option value="">Pilih Fase...</option>
                                    <option value="Fase A (Kelas 1-2)">Fase A (Kelas 1-2)</option>
                                    <option value="Fase B (Kelas 3-4)">Fase B (Kelas 3-4)</option>
                                    <option value="Fase C (Kelas 5-6)">Fase C (Kelas 5-6)</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label form-label-custom">Alokasi Waktu <span class="text-danger">*</span></label>
                                <input type="text" id="ma-alokasi" class="form-control form-control-custom text-white" placeholder="Contoh: 2 JP × 35 menit">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label form-label-custom">Model Pembelajaran</label>
                                <select id="ma-model" class="form-select form-control-custom bg-dark-select text-white">
                                    <option value="Problem Based Learning (PBL)">Problem Based Learning (PBL)</option>
                                    <option value="Project Based Learning (PJBL)">Project Based Learning (PJBL)</option>
                                    <option value="Discovery Learning">Discovery Learning</option>
                                    <option value="Inquiry Learning">Inquiry Learning</option>
                                    <option value="Cooperative Learning">Cooperative Learning</option>
                                    <option value="Direct Instruction">Direct Instruction</option>
                                    <option value="Deep Learning">Deep Learning</option>
                                    <option value="Blended Learning">Blended Learning</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label form-label-custom">Target Peserta Didik</label>
                                <select id="ma-target" class="form-select form-control-custom bg-dark-select text-white">
                                    <option value="Siswa reguler/tipikal">Siswa reguler/tipikal</option>
                                    <option value="Siswa dengan kesulitan belajar">Siswa dengan kesulitan belajar</option>
                                    <option value="Siswa dengan pencapaian tinggi">Siswa dengan pencapaian tinggi</option>
                                    <option value="Semua tipe peserta didik">Semua tipe peserta didik</option>
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label form-label-custom">Profil Pelajar Pancasila (P3) <span class="text-danger">*</span></label>
                                <div class="d-flex flex-wrap gap-2 p-3 rounded" style="background:rgba(255,255,255,0.02);border:1px solid var(--border);">
                                    <?php
                                    $p3_items = [
                                        ['🙏', 'Beriman, Bertakwa kepada Tuhan YME, & Berakhlak Mulia'],
                                        ['🌍', 'Berkebhinekaan Global'],
                                        ['🤝', 'Bergotong Royong'],
                                        ['💪', 'Mandiri'],
                                        ['🧠', 'Bernalar Kritis'],
                                        ['✨', 'Kreatif'],
                                    ];
                                    foreach ($p3_items as [$icon, $val]): ?>
                                        <label class="d-flex align-items-center gap-2 px-3 py-2 rounded" style="background:rgba(34,197,94,0.05);border:1px solid rgba(34,197,94,0.15);cursor:pointer;font-size:12px;">
                                            <input type="checkbox" class="ma-p3-check form-check-input" value="<?php echo htmlspecialchars($val); ?>" style="accent-color:#22c55e;margin-top:0;">
                                            <?php echo $icon; ?> <?php echo htmlspecialchars($val); ?>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <div class="col-12">
                                <label class="form-label form-label-custom">Kompetensi Awal (Prasyarat) <span class="text-danger">*</span></label>
                                <textarea id="ma-kompetensi-awal" class="form-control form-control-custom text-white" rows="3" placeholder="Kemampuan prasyarat yang harus dimiliki siswa. Contoh: Siswa sudah memahami konsep bilangan cacah dan operasi penjumlahan dasar."></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label form-label-custom">Sarana & Prasarana</label>
                                <textarea id="ma-sarana" class="form-control form-control-custom text-white" rows="2" placeholder="Contoh: Proyektor, papan tulis, LKPD cetak, kartu bilangan, buku siswa Kurikulum Merdeka."></textarea>
                            </div>
                            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                            <div class="col-12">
                                <label class="form-label form-label-custom">Atas Nama Guru</label>
                                <select name="uploader_guru_id" id="ma-uploader" class="form-select form-control-custom bg-dark-select text-white">
                                    <?php foreach ($teachers as $tc): ?>
                                        <option value="<?php echo $tc['id']; ?>" <?php echo $tc['id'] == $default_sel_guru_id ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($tc['nama_guru']) . ' (' . htmlspecialchars($tc['nip']) . ')'; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- STEP B: Komponen Inti -->
                    <div id="ma-step-2" class="ma-step d-none">
                        <div class="mb-3 p-2 rounded" style="background:rgba(59,130,246,0.06);border-left:3px solid #3b82f6;">
                            <small class="fw-bold" style="color:#3b82f6;">B. KOMPONEN INTI</small>
                            <p class="text-secondary small mb-0">Tujuan Pembelajaran, pemahaman bermakna, pertanyaan pemantik, skenario kegiatan, dan asesmen.</p>
                        </div>
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label form-label-custom">Tujuan Pembelajaran (TP) <span class="text-danger">*</span></label>
                                <textarea id="ma-tp" class="form-control form-control-custom text-white" rows="3" placeholder="Setelah mengikuti pembelajaran, siswa mampu... (tulis dengan kata kerja operasional yang terukur)"></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label form-label-custom">Pemahaman Bermakna <span class="text-danger">*</span></label>
                                <textarea id="ma-bermakna" class="form-control form-control-custom text-white" rows="2" placeholder="Manfaat nyata materi ini dalam kehidupan sehari-hari siswa. Contoh: Siswa menyadari bahwa pecahan digunakan saat membagi kue atau mengatur waktu secara adil."></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label form-label-custom">Pertanyaan Pemantik <span class="text-danger">*</span></label>
                                <textarea id="ma-pemantik" class="form-control form-control-custom text-white" rows="2" placeholder='Pertanyaan yang menumbuhkan rasa ingin tahu. Contoh: "Jika sebuah pizza dibagi 4 orang sama rata, masing-masing dapat berapa bagian?"'></textarea>
                            </div>
                            <div class="col-12">
                                <div class="p-3 rounded" style="background:rgba(255,255,255,0.02);border:1px solid var(--border);">
                                    <h6 class="fw-bold text-white mb-3" style="font-size:13px;"><i class="fa-solid fa-list-check me-2 text-gold"></i>Kegiatan Pembelajaran</h6>
                                    <div class="row g-3">
                                        <div class="col-12">
                                            <label class="form-label form-label-custom" style="color:#fbbf24;">📌 Pendahuluan (±10 menit) <span class="text-danger">*</span></label>
                                            <textarea id="ma-pendahuluan" class="form-control form-control-custom text-white" rows="4" placeholder="1. Guru memberi salam dan memimpin doa bersama.&#10;2. Guru mengecek kehadiran siswa.&#10;3. Guru menyampaikan tujuan pembelajaran.&#10;4. Guru mengajukan pertanyaan pemantik."></textarea>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label form-label-custom" style="color:#60a5fa;">⚡ Kegiatan Inti (±50 menit) <span class="text-danger">*</span></label>
                                            <textarea id="ma-inti" class="form-control form-control-custom text-white" rows="7" placeholder="1. [Mengamati] Guru menampilkan media pembelajaran...&#10;2. [Eksplorasi] Siswa melakukan aktivitas...&#10;3. [Diskusi Kelompok] Siswa berdiskusi berpasangan/kelompok...&#10;4. [Presentasi] Perwakilan kelompok mempresentasikan hasil...&#10;5. [Konfirmasi] Guru memberikan penguatan dan meluruskan miskonsepsi."></textarea>
                                        </div>
                                        <div class="col-12">
                                            <label class="form-label form-label-custom" style="color:#a3e635;">✅ Penutup (±10 menit) <span class="text-danger">*</span></label>
                                            <textarea id="ma-penutup" class="form-control form-control-custom text-white" rows="3" placeholder="1. Guru dan siswa membuat rangkuman pembelajaran.&#10;2. Guru melakukan refleksi bersama.&#10;3. Guru menginformasikan topik pertemuan berikutnya.&#10;4. Penutupan dengan doa bersama."></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label form-label-custom">Asesmen Formatif (Proses) <span class="text-danger">*</span></label>
                                <textarea id="ma-asesmen-formatif" class="form-control form-control-custom text-white" rows="4" placeholder="Penilaian selama proses belajar.&#10;Contoh:&#10;- Observasi diskusi kelompok (ceklis keaktifan)&#10;- Pertanyaan lisan saat eksplorasi&#10;- Jurnal refleksi diri siswa"></textarea>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label form-label-custom">Asesmen Sumatif (Hasil) <span class="text-danger">*</span></label>
                                <textarea id="ma-asesmen-sumatif" class="form-control form-control-custom text-white" rows="4" placeholder="Penilaian di akhir topik/unit.&#10;Contoh:&#10;- Tes tertulis 10 soal&#10;- Produk buatan siswa&#10;- Performa: presentasi"></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label form-label-custom">Diferensiasi Pembelajaran</label>
                                <textarea id="ma-diferensiasi" class="form-control form-control-custom text-white" rows="2" placeholder="Contoh:&#10;- Konten: Siswa tinggi mendapat soal HOTS, siswa kesulitan mendapat scaffolding visual.&#10;- Proses: Kelompok heterogen dengan peer tutor.&#10;- Produk: Siswa bebas memilih merepresentasikan pemahaman."></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- STEP C: Lampiran -->
                    <div id="ma-step-3" class="ma-step d-none">
                        <div class="mb-3 p-2 rounded" style="background:rgba(139,92,246,0.06);border-left:3px solid #8b5cf6;">
                            <small class="fw-bold" style="color:#8b5cf6;">C. LAMPIRAN</small>
                            <p class="text-secondary small mb-0">LKPD, bahan bacaan, rubrik penilaian, glosarium, dan referensi.</p>
                        </div>
                        <div class="row g-3">
                            <div class="col-12">
                                <label class="form-label form-label-custom">📋 LKPD (Lembar Kerja Peserta Didik)</label>
                                <textarea id="ma-lkpd" class="form-control form-control-custom text-white" rows="6" placeholder="Tulis instruksi dan soal LKPD di sini.&#10;---&#10;Nama    : _______________&#10;Kelas   : _______________&#10;&#10;Petunjuk: Perhatikan gambar dan isilah kolom berikut!&#10;1. ...&#10;2. ..."></textarea>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label form-label-custom">📚 Bahan Bacaan Guru</label>
                                <textarea id="ma-bacaan-guru" class="form-control form-control-custom text-white" rows="4" placeholder="Referensi dan bahan pengayaan untuk guru.&#10;Contoh:&#10;- Buku Panduan Guru (Kemendikbud 2022)&#10;- Modul Pelatihan IKM: Asesmen Formatif"></textarea>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label form-label-custom">📖 Bahan Bacaan Siswa</label>
                                <textarea id="ma-bacaan-siswa" class="form-control form-control-custom text-white" rows="4" placeholder="Bahan yang disiapkan untuk siswa.&#10;Contoh:&#10;- Buku Siswa Kelas 3, Bab 4 (hal. 72-80)&#10;- Kartu belajar (dicetak guru)"></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label form-label-custom">📊 Rubrik Penilaian</label>
                                <textarea id="ma-rubrik" class="form-control form-control-custom text-white" rows="5" placeholder="Contoh rubrik sederhana:&#10;| Kriteria | Sangat Baik (4) | Baik (3) | Cukup (2) | Perlu Bimbingan (1) |&#10;| Pemahaman | ... | ... | ... | ... |&#10;| Keaktifan | Selalu aktif | Sering aktif | Kadang | Pasif |"></textarea>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label form-label-custom">📝 Glosarium</label>
                                <textarea id="ma-glosarium" class="form-control form-control-custom text-white" rows="4" placeholder="Kosa kata kunci beserta artinya.&#10;Contoh:&#10;- Pecahan: bilangan yang menyatakan bagian dari keseluruhan.&#10;- Pembilang: angka di atas garis pecahan.&#10;- Penyebut: angka di bawah garis pecahan."></textarea>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label form-label-custom">📌 Daftar Pustaka</label>
                                <textarea id="ma-pustaka" class="form-control form-control-custom text-white" rows="4" placeholder="Sumber referensi.&#10;Contoh:&#10;Kemendikbud. (2022). Buku Siswa Matematika SD/MI Kelas 3. Jakarta.&#10;BSKAP. (2022). Capaian Pembelajaran SD. Jakarta.&#10;Platform Merdeka Mengajar: guru.kemdikbud.go.id"></textarea>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="modal-footer border-top border-secondary border-opacity-10 py-2" style="gap:8px;">
                    <button type="button" class="btn btn-outline-custom btn-sm" id="ma-btn-prev" onclick="maWizardPrev()" style="display:none;"><i class="fa-solid fa-chevron-left me-1"></i> Kembali</button>
                    <div class="flex-grow-1 text-center" id="ma-step-indicator" style="font-size:11px;color:var(--text-2);">Langkah 1 dari 3</div>
                    <button type="button" class="btn btn-outline-custom btn-sm" data-bs-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-sm fw-bold" id="ma-btn-next" onclick="maWizardNext()" style="background:linear-gradient(135deg,#22c55e,#16a34a);color:#fff;">Lanjut: Komponen Inti <i class="fa-solid fa-chevron-right ms-1"></i></button>
                    <button type="button" class="btn btn-sm fw-bold d-none" id="ma-btn-save" onclick="submitModulAjar()" style="background:linear-gradient(135deg,#22c55e,#16a34a);color:#fff;"><i class="fa-solid fa-floppy-disk me-1"></i> Simpan Modul Ajar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Modul Ajar View Modal -->
<div class="modal fade" id="readModulAjarModal" tabindex="-1" aria-labelledby="readModulAjarLabel" aria-hidden="true" data-bs-backdrop="false">
    <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content border-0 shadow-lg" style="background:var(--bg-card);border-radius:var(--r-lg);">
            <div class="modal-header border-bottom border-secondary border-opacity-10 py-3" style="background:linear-gradient(135deg,rgba(34,197,94,0.08),transparent);">
                <h5 class="modal-title fw-bold" style="color:#22c55e;" id="readModulAjarLabel"><i class="fa-solid fa-layer-group me-2"></i><span id="rma-title">Modul Ajar</span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4" id="rma-body"></div>
            <div class="modal-footer border-top border-secondary border-opacity-10 py-2">
                <button type="button" class="btn btn-outline-custom btn-sm" data-bs-dismiss="modal">Tutup</button>
                <a href="" id="rma-print-link" target="_blank" class="btn btn-sm" style="background:rgba(34,197,94,0.12);color:#22c55e;border:1px solid rgba(34,197,94,0.25);"><i class="fa-solid fa-print me-1"></i> Cetak Modul Ajar</a>
            </div>
        </div>
    </div>
</div>

<script>


    // Modal triggers and populating
    function openCreateModal(presetType = '') {
        const modal = new bootstrap.Modal(document.getElementById('editorModal'));
        
        // Reset form
        document.getElementById('form-action').value = 'create';
        document.getElementById('form-doc-id').value = '';
        document.getElementById('nama_dokumen').value = '';
        document.getElementById('konten').value = '';
        const kelasSelect = document.getElementById('kelas_id');
        if (kelasSelect) kelasSelect.value = '';
        document.getElementById('editorModalLabel').innerHTML = '<i class="fa-solid fa-plus-to-square me-2"></i> Buat Dokumen RPP Baru';
        
        // Table Builder resets
        const tbody = document.getElementById('builder-table-body');
        if (tbody) tbody.innerHTML = '';
        const presetSelect = document.getElementById('table-preset');
        if (presetSelect) presetSelect.value = 'atp';
        const customDiv = document.getElementById('custom-headers-div');
        if (customDiv) customDiv.style.display = 'none';
        
        // Default to text mode
        const modeText = document.getElementById('mode_text');
        if (modeText) modeText.checked = true;
        switchEditorMode('text');
        
        if (presetType !== '') {
            document.getElementById('jenis_dokumen').value = presetType;
        }
        modal.show();
    }

    function editDocument(id) {
        const doc = docsRegistry[id];
        if (!doc) return;

        const modal = new bootstrap.Modal(document.getElementById('editorModal'));
        
        // Populate form
        document.getElementById('form-action').value = 'update';
        document.getElementById('form-doc-id').value = doc.id;
        document.getElementById('nama_dokumen').value = doc.nama_dokumen;
        document.getElementById('jenis_dokumen').value = doc.jenis_dokumen;
        document.getElementById('tahun_ajaran').value = doc.tahun_ajaran;
        const kelasSelect = document.getElementById('kelas_id');
        if (kelasSelect) kelasSelect.value = doc.kelas_id || '';
        document.getElementById('konten').value = doc.konten;
        
        // Parse table if exists
        const hasTable = parseHTMLToTableBuilder(doc.konten);
        if (hasTable) {
            const modeTable = document.getElementById('mode_table');
            if (modeTable) modeTable.checked = true;
            switchEditorMode('table');
        } else {
            const modeText = document.getElementById('mode_text');
            if (modeText) modeText.checked = true;
            switchEditorMode('text');
        }
        
        document.getElementById('editorModalLabel').innerHTML = '<i class="fa-solid fa-pen-to-square me-2"></i> Ubah Dokumen Administrasi';

        modal.show();
    }

    function readDocument(id) {
        const doc = docsRegistry[id];
        if (!doc) return;

        const modal = new bootstrap.Modal(document.getElementById('readModal'));
        
        // Populate read fields
        document.getElementById('read-title').textContent = doc.nama_dokumen;
        document.getElementById('read-mapel').textContent = doc.mapel_name + ' — ' + doc.nama_kelas + ' (Kelas ' + doc.grade_level + ')';
        document.getElementById('read-author').textContent = doc.nama_guru + ' (NIP: ' + doc.nip + ')';
        document.getElementById('read-date').textContent = 'T.A. ' + doc.tahun_ajaran + ' (' + doc.created_at + ')';
        document.getElementById('read-content').innerHTML = doc.konten;

        // Set print link
        document.getElementById('btn-print-link').href = 'print.php?id=' + doc.id;

        modal.show();
    }

    // Client-side text filter search
    function triggerSearch() {
        const query = document.getElementById('global-search').value.trim().toLowerCase();
        
        // Search inside mapel cards
        const cards = document.querySelectorAll('.mapel-card');
        if (cards.length > 0) {
            cards.forEach(card => {
                const name = card.getAttribute('data-name').toLowerCase();
                if (name.includes(query)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }
        
        // Search inside tables
        const rows = document.querySelectorAll('.table-custom tbody tr');
        if (rows.length > 0) {
            rows.forEach(row => {
                if (row.classList.contains('opacity-50')) return;
                
                const text = row.innerText.toLowerCase();
                if (text.includes(query)) {
                    row.style.setProperty('display', '', 'important');
                } else {
                    row.style.setProperty('display', 'none', 'important');
                }
            });
        }
    }
    
    document.getElementById('global-search').addEventListener('input', triggerSearch);

    // ── TABLE BUILDER LOGIC ──
    const presets = {
        atp: ['NO', 'NO. ATP', 'ATP', 'JML', 'SMT'],
        prota: ['NO', 'Materi Pokok / Lingkup Materi', 'Alokasi Waktu (JP)', 'Semester'],
        prosem: ['NO', 'Materi / Tujuan Pembelajaran', 'Alokasi Waktu (JP)', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember']
    };
    
    let currentColumns = [];

    function switchEditorMode(mode) {
        if (mode === 'table') {
            document.getElementById('text-editor-container').classList.add('d-none');
            document.getElementById('table-builder-container').classList.remove('d-none');
            document.getElementById('konten').removeAttribute('required');
            
            // If table has no rows, init with default preset
            if (document.getElementById('builder-table-body').children.length === 0) {
                applyTablePreset(document.getElementById('table-preset').value);
            }
        } else {
            document.getElementById('text-editor-container').classList.remove('d-none');
            document.getElementById('table-builder-container').classList.add('d-none');
            document.getElementById('konten').setAttribute('required', 'required');
        }
    }

    function applyTablePreset(preset) {
        const customDiv = document.getElementById('custom-headers-div');
        if (preset === 'custom') {
            customDiv.style.display = 'block';
            return;
        } else {
            customDiv.style.display = 'none';
        }
        
        const cols = presets[preset] || [];
        setTableHeaders(cols);
    }

    function setTableHeaders(cols) {
        currentColumns = cols;
        const headersRow = document.getElementById('builder-table-headers');
        headersRow.innerHTML = '';
        
        cols.forEach(col => {
            const th = document.createElement('th');
            th.textContent = col;
            
            const colLower = col.toLowerCase();
            if (colLower === 'no') {
                th.style.width = '60px';
                th.style.textAlign = 'center';
            } else if (colLower === 'no. atp') {
                th.style.width = '90px';
                th.style.textAlign = 'center';
            } else if (colLower === 'jml' || colLower === 'alokasi waktu (jp)') {
                th.style.width = '95px';
                th.style.textAlign = 'center';
            } else if (colLower === 'smt' || colLower === 'semester') {
                th.style.width = '85px';
                th.style.textAlign = 'center';
            } else if (['juli', 'agustus', 'september', 'oktober', 'november', 'desember'].includes(colLower)) {
                th.style.width = '75px';
                th.style.textAlign = 'center';
            }
            headersRow.appendChild(th);
        });
        
        const thAksi = document.createElement('th');
        thAksi.textContent = 'AKSI';
        thAksi.style.width = '65px';
        thAksi.style.textAlign = 'center';
        headersRow.appendChild(thAksi);
        
        // If table is empty, seed 5 empty rows
        const tbody = document.getElementById('builder-table-body');
        if (tbody.children.length === 0) {
            for (let i = 0; i < 5; i++) {
                addBuilderRow();
            }
        } else {
            // Re-render rows to match new headers
            rebuildRowsWithNewHeaders();
        }
    }

    function addBuilderRow(data = {}) {
        const tbody = document.getElementById('builder-table-body');
        const tr = document.createElement('tr');
        
        currentColumns.forEach((col, colIdx) => {
            const td = document.createElement('td');
            
            const colLower = col.toLowerCase();
            const isLongText = ['atp', 'materi', 'tujuan', 'pembelajaran', 'keterangan', 'topik', 'deskripsi', 'lingkup'].some(kw => colLower.includes(kw));
            
            const input = document.createElement(isLongText ? 'textarea' : 'input');
            if (!isLongText) {
                input.type = 'text';
            } else {
                input.rows = 1;
                input.addEventListener('input', function() {
                    this.style.height = 'auto';
                    this.style.height = this.scrollHeight + 'px';
                });
            }
            
            input.className = 'table-builder-field';
            input.dataset.column = col;
            
            // Text alignment for specific column types
            if (['no', 'no. atp', 'jml', 'smt', 'semester', 'alokasi waktu (jp)', 'juli', 'agustus', 'september', 'oktober', 'november', 'desember'].includes(colLower)) {
                input.style.textAlign = 'center';
            }
            
            // Fill value if provided
            let val = '';
            if (Array.isArray(data)) {
                val = data[colIdx] !== undefined ? data[colIdx] : '';
            } else {
                val = data[col] !== undefined ? data[col] : '';
            }
            input.value = val;
            
            // Auto-increment NO column if empty
            if (colLower === 'no' && !input.value) {
                input.value = tbody.children.length + 1;
            }
            
            td.appendChild(input);
            tr.appendChild(td);
            
            // Trigger auto-adjust height for textarea after rendering
            if (isLongText) {
                setTimeout(() => {
                    input.style.height = 'auto';
                    input.style.height = input.scrollHeight + 'px';
                }, 0);
            }
        });
        
        // Action column with delete button
        const tdAksi = document.createElement('td');
        tdAksi.className = 'action-cell';
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'btn-delete-row';
        btn.innerHTML = '<i class="fa-solid fa-trash"></i>';
        btn.onclick = function() {
            tr.remove();
            updateRowCountIndicator();
            autoRenumberRows();
        };
        
        tdAksi.appendChild(btn);
        tr.appendChild(tdAksi);
        tbody.appendChild(tr);
        
        updateRowCountIndicator();
    }

    function autoRenumberRows() {
        const tbody = document.getElementById('builder-table-body');
        Array.from(tbody.children).forEach((tr, rowIdx) => {
            const noInput = tr.querySelector('.table-builder-field[data-column="NO"]');
            if (noInput) {
                noInput.value = rowIdx + 1;
            }
        });
    }

    function updateRowCountIndicator() {
        const tbody = document.getElementById('builder-table-body');
        document.getElementById('row-count-indicator').textContent = tbody.children.length + ' baris';
    }

    function rebuildRowsWithNewHeaders() {
        const tbody = document.getElementById('builder-table-body');
        const rows = Array.from(tbody.children);
        
        // Extract data from existing rows
        const rowData = rows.map(tr => {
            return Array.from(tr.querySelectorAll('.table-builder-field')).map(input => input.value);
        });
        
        tbody.innerHTML = '';
        rowData.forEach(data => {
            addBuilderRow(data);
        });
    }

    function applyCustomHeaders() {
        const inputVal = document.getElementById('custom-headers-input').value.trim();
        if (!inputVal) return;
        const cols = inputVal.split(',').map(s => s.trim()).filter(s => s.length > 0);
        if (cols.length > 0) {
            setTableHeaders(cols);
        }
    }

    function toggleExcelImportArea() {
        const el = document.getElementById('excel-import-area');
        el.classList.toggle('d-none');
    }

    function processExcelImport() {
        const pasteBox = document.getElementById('excel-paste-box');
        const text = pasteBox.value;
        if (!text.trim()) return;
        
        const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 0);
        const tbody = document.getElementById('builder-table-body');
        
        let startIdx = 0;
        if (lines.length > 0) {
            const firstLineCells = lines[0].split('\t').map(c => c.trim().toLowerCase());
            const matchCount = firstLineCells.filter(c => currentColumns.map(h => h.toLowerCase()).includes(c)).length;
            
            if (matchCount >= 2) {
                startIdx = 1;
            }
            
            const currentRows = Array.from(tbody.children);
            const isAllEmpty = currentRows.every(tr => Array.from(tr.querySelectorAll('.table-builder-field')).every(i => !i.value));
            if (isAllEmpty) {
                tbody.innerHTML = '';
            }
            
            for (let i = startIdx; i < lines.length; i++) {
                const cells = lines[i].split('\t').map(c => c.trim());
                addBuilderRow(cells);
            }
        }
        
        pasteBox.value = '';
        document.getElementById('excel-import-area').classList.add('d-none');
    }

    function generateHTMLFromTable() {
        const tbody = document.getElementById('builder-table-body');
        if (tbody.children.length === 0) return '';
        
        let html = '<table class="table-custom-render" style="width: 100%; border-collapse: collapse; border: 1px solid #ddd; margin: 15px 0;">\n';
        
        // Headers
        html += '  <thead>\n    <tr style="background-color: #f2f2f2;">\n';
        currentColumns.forEach(col => {
            html += `      <th style="border: 1px solid #ddd; padding: 10px; font-weight: bold; text-align: left;">${escapeHTML(col)}</th>\n`;
        });
        html += '    </tr>\n  </thead>\n';
        
        // Rows
        html += '  <tbody>\n';
        Array.from(tbody.children).forEach(tr => {
            html += '    <tr>\n';
            const inputs = tr.querySelectorAll('.table-builder-field');
            inputs.forEach(input => {
                html += `      <td style="border: 1px solid #ddd; padding: 10px;">${escapeHTML(input.value)}</td>\n`;
            });
            html += '    </tr>\n';
        });
        html += '  </tbody>\n</table>';
        
        return html;
    }

    function escapeHTML(str) {
        return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }

    function prepareRPPForm(event) {
        const mode = document.querySelector('input[name="editor_mode"]:checked').value;
        if (mode === 'table') {
            const htmlContent = generateHTMLFromTable();
            if (!htmlContent) {
                event.preventDefault();
                Swal.fire('Error', 'Tabel harus memiliki minimal 1 baris data!', 'error');
                return false;
            }
            document.getElementById('konten').value = htmlContent;
        }
        return true;
    }

    function parseHTMLToTableBuilder(html) {
        if (!html || !html.includes('<table')) return false;
        
        const temp = document.createElement('div');
        temp.innerHTML = html;
        const table = temp.querySelector('table');
        if (!table) return false;
        
        const ths = Array.from(table.querySelectorAll('thead th'));
        const trs = Array.from(table.querySelectorAll('tbody tr'));
        
        if (ths.length === 0) return false;
        
        const headers = ths.map(th => th.textContent.trim());
        
        let presetVal = 'custom';
        const atpStr = presets.atp.join(',').toLowerCase();
        const protaStr = presets.prota.join(',').toLowerCase();
        const prosemStr = presets.prosem.join(',').toLowerCase();
        const headerStr = headers.join(',').toLowerCase();
        
        if (headerStr === atpStr) presetVal = 'atp';
        else if (headerStr === protaStr) presetVal = 'prota';
        else if (headerStr === prosemStr) presetVal = 'prosem';
        
        const presetSelect = document.getElementById('table-preset');
        if (presetSelect) presetSelect.value = presetVal;
        
        const customDiv = document.getElementById('custom-headers-div');
        if (presetVal === 'custom') {
            if (customDiv) customDiv.style.display = 'block';
            const customInput = document.getElementById('custom-headers-input');
            if (customInput) customInput.value = headers.join(', ');
        } else {
            if (customDiv) customDiv.style.display = 'none';
        }
        
        currentColumns = headers;
        
        // Rebuild headers HTML
        const headersRow = document.getElementById('builder-table-headers');
        headersRow.innerHTML = '';
        headers.forEach(col => {
            const th = document.createElement('th');
            th.textContent = col;
            if (['no', 'no. atp', 'jml', 'smt'].includes(col.toLowerCase())) {
                th.style.width = '70px';
            }
            headersRow.appendChild(th);
        });
        const thAksi = document.createElement('th');
        thAksi.textContent = 'AKSI';
        thAksi.style.width = '50px';
        thAksi.style.textAlign = 'center';
        headersRow.appendChild(thAksi);
        
        // Populate rows
        const tbody = document.getElementById('builder-table-body');
        tbody.innerHTML = '';
        
        trs.forEach(tr => {
            const tds = Array.from(tr.querySelectorAll('td'));
            const rowData = tds.map(td => td.textContent.trim());
            addBuilderRow(rowData);
        });
        
        return true;
    }
</script>

<script>
// ── MODUL AJAR WIZARD JAVASCRIPT ──
let maCurrentStep = 1;
const modulAjarRegistry = {};
<?php
// Inject all modul ajar docs into JS registry for this grade+mapel
try {
    if ($current_mapel !== null) {
        $ma_inj = $pdo->prepare("SELECT r.*, g.nama_guru, g.nip, k.nama_kelas, m.nama_mapel FROM rpp_dokumen r LEFT JOIN guru g ON r.guru_id=g.id LEFT JOIN kelas k ON r.kelas_id=k.id LEFT JOIN mata_pelajaran m ON r.mapel_id=m.id WHERE r.grade_level=? AND r.mapel_id=? AND r.jenis_dokumen IN ('MODUL_AJAR_S1','MODUL_AJAR_S2')");
        $ma_inj->execute([$grade, $mapel_id]);
        foreach ($ma_inj->fetchAll() as $mad) {
            echo 'modulAjarRegistry[' . intval($mad['id']) . '] = ' . json_encode([
                'id'            => $mad['id'],
                'nama_dokumen'  => $mad['nama_dokumen'],
                'jenis_dokumen' => $mad['jenis_dokumen'],
                'tahun_ajaran'  => $mad['tahun_ajaran'],
                'kelas_id'      => $mad['kelas_id'],
                'nama_kelas'    => $mad['nama_kelas'] ?? '-',
                'nama_guru'     => $mad['nama_guru'] ?? 'Administrator',
                'nip'           => $mad['nip'] ?? '-',
                'nama_mapel'    => $mad['nama_mapel'] ?? '',
                'grade_level'   => $mad['grade_level'],
                'konten_raw'    => $mad['konten'],
            ], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT) . ";\n";
        }
    }
} catch (Exception $e) { echo '/* registry error: ' . addslashes($e->getMessage()) . ' */'; }
?>

function openModulAjarWizard(jenis) {
    document.getElementById('ma-action').value = 'create';
    document.getElementById('ma-doc-id').value = '';
    document.getElementById('ma-jenis').value = jenis;
    document.getElementById('ma-modal-title').textContent = 'Buat Modul Ajar — ' + (jenis === 'MODUL_AJAR_S1' ? 'Semester 1' : 'Semester 2');

    // Reset all fields
    ['ma-nama-dokumen','ma-penyusun','ma-fase','ma-alokasi','ma-kompetensi-awal','ma-sarana',
     'ma-tp','ma-bermakna','ma-pemantik','ma-pendahuluan','ma-inti','ma-penutup',
     'ma-asesmen-formatif','ma-asesmen-sumatif','ma-diferensiasi',
     'ma-lkpd','ma-bacaan-guru','ma-bacaan-siswa','ma-rubrik','ma-glosarium','ma-pustaka'
    ].forEach(id => { const el = document.getElementById(id); if(el) el.value = ''; });
    document.querySelectorAll('.ma-p3-check').forEach(cb => cb.checked = false);
    const kelasEl = document.getElementById('ma-kelas-id');
    if (kelasEl) kelasEl.selectedIndex = 0;

    maGoToStep(1);
    new bootstrap.Modal(document.getElementById('modulAjarModal')).show();
}

function maGoToStep(step) {
    maCurrentStep = step;
    document.querySelectorAll('.ma-step').forEach((el, i) => {
        el.classList.toggle('d-none', i + 1 !== step);
    });
    const stepLabels = ['Langkah 1 dari 3 — Informasi Umum', 'Langkah 2 dari 3 — Komponen Inti', 'Langkah 3 dari 3 — Lampiran'];
    const ind = document.getElementById('ma-step-indicator');
    if (ind) ind.textContent = stepLabels[step - 1] || '';

    const dotBg = ['#22c55e', 'rgba(255,255,255,0.08)', 'rgba(255,255,255,0.08)'];
    const dotColor = ['#fff', 'var(--text-2)', 'var(--text-2)'];
    const dotLabels = ['A','B','C'];
    for (let i = 1; i <= 3; i++) {
        const dot = document.getElementById('dot-' + i);
        const sl  = document.getElementById('sl-' + i);
        if (!dot) continue;
        if (i < step) {
            dot.style.background = '#22c55e'; dot.style.color = '#fff';
            dot.innerHTML = '<i class="fa-solid fa-check" style="font-size:11px;"></i>';
            if (sl) sl.style.color = '#22c55e';
        } else if (i === step) {
            dot.style.background = '#22c55e'; dot.style.color = '#fff';
            dot.textContent = dotLabels[i-1];
            if (sl) sl.style.color = '#22c55e';
        } else {
            dot.style.background = 'rgba(255,255,255,0.08)'; dot.style.color = 'var(--text-2)';
            dot.textContent = dotLabels[i-1];
            if (sl) sl.style.color = 'var(--text-2)';
        }
    }
    for (let i = 1; i <= 2; i++) {
        const ln = document.getElementById('ln-' + i);
        if (ln) ln.style.background = i < step ? 'rgba(34,197,94,0.5)' : 'rgba(255,255,255,0.06)';
    }
    const prev = document.getElementById('ma-btn-prev');
    const next = document.getElementById('ma-btn-next');
    const save = document.getElementById('ma-btn-save');
    if (prev) prev.style.display = step > 1 ? 'inline-flex' : 'none';
    if (step === 3) {
        if (next) next.classList.add('d-none');
        if (save) save.classList.remove('d-none');
    } else {
        if (next) { next.classList.remove('d-none'); next.innerHTML = step === 1 ? 'Lanjut: Komponen Inti <i class="fa-solid fa-chevron-right ms-1"></i>' : 'Lanjut: Lampiran <i class="fa-solid fa-chevron-right ms-1"></i>'; }
        if (save) save.classList.add('d-none');
    }
}

function maWizardNext() {
    if (maCurrentStep === 1) {
        const req1 = ['ma-nama-dokumen','ma-kelas-id','ma-fase','ma-alokasi','ma-kompetensi-awal'];
        const empty = req1.find(id => !document.getElementById(id)?.value?.trim());
        if (empty) { Swal.fire({title:'Field Wajib',text:'Harap isi semua field bertanda (*) pada bagian A.',icon:'warning',confirmButtonColor:'#22c55e'}); return; }
        if (document.querySelectorAll('.ma-p3-check:checked').length === 0) {
            Swal.fire({title:'Profil Pelajar Pancasila',text:'Pilih minimal 1 dimensi Profil Pelajar Pancasila.',icon:'warning',confirmButtonColor:'#22c55e'}); return;
        }
    }
    if (maCurrentStep === 2) {
        const req2 = ['ma-tp','ma-bermakna','ma-pemantik','ma-pendahuluan','ma-inti','ma-penutup','ma-asesmen-formatif','ma-asesmen-sumatif'];
        const empty = req2.find(id => !document.getElementById(id)?.value?.trim());
        if (empty) { Swal.fire({title:'Field Wajib',text:'Harap isi semua field bertanda (*) pada bagian B.',icon:'warning',confirmButtonColor:'#22c55e'}); return; }
    }
    if (maCurrentStep < 3) maGoToStep(maCurrentStep + 1);
}

function maWizardPrev() {
    if (maCurrentStep > 1) maGoToStep(maCurrentStep - 1);
}

function submitModulAjar() {
    const g = id => document.getElementById(id)?.value || '';
    const p3 = Array.from(document.querySelectorAll('.ma-p3-check:checked')).map(cb => cb.value);
    const payload = {
        info_umum: {
            nama_penyusun: g('ma-penyusun'),
            institusi: 'SD Kristen Petra 1 Surabaya',
            tahun_pelajaran: g('ma-tahun'),
            fase: g('ma-fase'),
            alokasi_waktu: g('ma-alokasi'),
            model_pembelajaran: g('ma-model'),
            target_peserta: g('ma-target'),
            profil_pelajar: p3,
            kompetensi_awal: g('ma-kompetensi-awal'),
            sarana: g('ma-sarana'),
        },
        komponen_inti: {
            tujuan_pembelajaran: g('ma-tp'),
            pemahaman_bermakna: g('ma-bermakna'),
            pertanyaan_pemantik: g('ma-pemantik'),
            pendahuluan: g('ma-pendahuluan'),
            inti: g('ma-inti'),
            penutup: g('ma-penutup'),
            asesmen_formatif: g('ma-asesmen-formatif'),
            asesmen_sumatif: g('ma-asesmen-sumatif'),
            diferensiasi: g('ma-diferensiasi'),
        },
        lampiran: {
            lkpd: g('ma-lkpd'),
            bahan_bacaan_guru: g('ma-bacaan-guru'),
            bahan_bacaan_siswa: g('ma-bacaan-siswa'),
            rubrik: g('ma-rubrik'),
            glosarium: g('ma-glosarium'),
            daftar_pustaka: g('ma-pustaka'),
        }
    };
    document.getElementById('ma-konten-hidden').value = JSON.stringify(payload, null, 2);
    document.getElementById('modul-ajar-form').submit();
}

function editModulAjar(id) {
    const doc = modulAjarRegistry[id];
    if (!doc) { Swal.fire('Error','Data tidak ditemukan.','error'); return; }
    document.getElementById('ma-action').value = 'update';
    document.getElementById('ma-doc-id').value = id;
    document.getElementById('ma-jenis').value = doc.jenis_dokumen;
    document.getElementById('ma-modal-title').textContent = 'Ubah Modul Ajar — ' + (doc.jenis_dokumen === 'MODUL_AJAR_S1' ? 'Semester 1' : 'Semester 2');

    let data = {};
    try { data = JSON.parse(doc.konten_raw); } catch(e) {}
    const info = data.info_umum || {};
    const inti = data.komponen_inti || {};
    const lamp = data.lampiran || {};
    const sv = (id, val) => { const el = document.getElementById(id); if(el) el.value = val || ''; };

    sv('ma-nama-dokumen', doc.nama_dokumen);
    sv('ma-kelas-id', doc.kelas_id);
    sv('ma-tahun', doc.tahun_ajaran);
    sv('ma-penyusun', info.nama_penyusun);
    sv('ma-fase', info.fase);
    sv('ma-alokasi', info.alokasi_waktu);
    sv('ma-model', info.model_pembelajaran);
    sv('ma-target', info.target_peserta);
    sv('ma-kompetensi-awal', info.kompetensi_awal);
    sv('ma-sarana', info.sarana);
    sv('ma-tp', inti.tujuan_pembelajaran);
    sv('ma-bermakna', inti.pemahaman_bermakna);
    sv('ma-pemantik', inti.pertanyaan_pemantik);
    sv('ma-pendahuluan', inti.pendahuluan);
    sv('ma-inti', inti.inti);
    sv('ma-penutup', inti.penutup);
    sv('ma-asesmen-formatif', inti.asesmen_formatif);
    sv('ma-asesmen-sumatif', inti.asesmen_sumatif);
    sv('ma-diferensiasi', inti.diferensiasi);
    sv('ma-lkpd', lamp.lkpd);
    sv('ma-bacaan-guru', lamp.bahan_bacaan_guru);
    sv('ma-bacaan-siswa', lamp.bahan_bacaan_siswa);
    sv('ma-rubrik', lamp.rubrik);
    sv('ma-glosarium', lamp.glosarium);
    sv('ma-pustaka', lamp.daftar_pustaka);

    const p3a = Array.isArray(info.profil_pelajar) ? info.profil_pelajar : [];
    document.querySelectorAll('.ma-p3-check').forEach(cb => { cb.checked = p3a.includes(cb.value); });

    maGoToStep(1);
    new bootstrap.Modal(document.getElementById('modulAjarModal')).show();
}

function readModulAjar(id) {
    const doc = modulAjarRegistry[id];
    if (!doc) return;
    let data = {};
    try { data = JSON.parse(doc.konten_raw); } catch(e) {}
    const info = data.info_umum || {};
    const inti = data.komponen_inti || {};
    const lamp = data.lampiran || {};
    const p3str = Array.isArray(info.profil_pelajar) ? info.profil_pelajar.join(' &bull; ') : '-';
    const esc = s => (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    const nl = s => (s||'').replace(/\n/g,'<br>');

    const secBlock = (title, color, icon, txt) => {
        if (!txt || !txt.trim()) return '';
        return `<div class="mb-3"><div class="d-flex align-items-center gap-2 mb-2"><span style="font-size:11px;font-weight:700;color:${color};letter-spacing:.4px;text-transform:uppercase;"><i class="${icon} me-1"></i>${title}</span></div><div class="p-3 rounded" style="background:rgba(255,255,255,0.025);border:1px solid rgba(255,255,255,0.07);font-size:13px;line-height:1.7;color:var(--text-1);">${nl(esc(txt))}</div></div>`;
    };
    const metaField = (label, val) => val ? `<div class="col-6 col-md-3"><span class="text-secondary d-block" style="font-size:10.5px;">${esc(label)}</span><div class="fw-semibold text-white" style="font-size:13px;">${esc(val)}</div></div>` : '';

    const html = `
    <div class="row g-2 p-3 rounded mb-4" style="background:linear-gradient(135deg,rgba(34,197,94,0.06),rgba(16,163,74,0.02));border:1px solid rgba(34,197,94,0.18);">
        ${metaField('Mata Pelajaran', doc.nama_mapel)} ${metaField('Kelas', doc.nama_kelas)}
        ${metaField('Penyusun', info.nama_penyusun || doc.nama_guru)} ${metaField('Fase', info.fase)}
        ${metaField('Alokasi Waktu', info.alokasi_waktu)} ${metaField('Model', info.model_pembelajaran)}
        ${metaField('Target Peserta', info.target_peserta)} ${metaField('Tahun Ajaran', doc.tahun_ajaran)}
        ${p3str !== '-' ? '<div class="col-12 mt-1"><span class="text-secondary d-block" style="font-size:10.5px;">Profil Pelajar Pancasila</span><div class="fw-semibold" style="color:#22c55e;font-size:12px;">' + p3str + '</div></div>' : ''}
    </div>
    <h6 class="fw-bold mb-3" style="color:#22c55e;font-size:13px;border-bottom:1px solid rgba(34,197,94,0.2);padding-bottom:6px;"><i class="fa-solid fa-circle-info me-2"></i>A. INFORMASI UMUM</h6>
    ${secBlock('Kompetensi Awal', '#fbbf24', 'fa-solid fa-star-half-stroke', info.kompetensi_awal)}
    ${secBlock('Sarana & Prasarana', '#60a5fa', 'fa-solid fa-toolbox', info.sarana)}
    <h6 class="fw-bold mb-3 mt-4" style="color:#3b82f6;font-size:13px;border-bottom:1px solid rgba(59,130,246,0.2);padding-bottom:6px;"><i class="fa-solid fa-list-check me-2"></i>B. KOMPONEN INTI</h6>
    ${secBlock('Tujuan Pembelajaran (TP)', '#a78bfa', 'fa-solid fa-bullseye', inti.tujuan_pembelajaran)}
    ${secBlock('Pemahaman Bermakna', '#34d399', 'fa-solid fa-lightbulb', inti.pemahaman_bermakna)}
    ${secBlock('Pertanyaan Pemantik', '#f59e0b', 'fa-solid fa-circle-question', inti.pertanyaan_pemantik)}
    ${secBlock('📌 Pendahuluan', '#fbbf24', 'fa-solid fa-play-circle', inti.pendahuluan)}
    ${secBlock('⚡ Kegiatan Inti', '#60a5fa', 'fa-solid fa-bolt', inti.inti)}
    ${secBlock('✅ Penutup', '#a3e635', 'fa-solid fa-stop-circle', inti.penutup)}
    ${secBlock('Asesmen Formatif', '#f472b6', 'fa-solid fa-clipboard-check', inti.asesmen_formatif)}
    ${secBlock('Asesmen Sumatif', '#fb923c', 'fa-solid fa-file-check', inti.asesmen_sumatif)}
    ${inti.diferensiasi ? secBlock('Diferensiasi Pembelajaran','#c084fc','fa-solid fa-sliders',inti.diferensiasi) : ''}
    <h6 class="fw-bold mb-3 mt-4" style="color:#8b5cf6;font-size:13px;border-bottom:1px solid rgba(139,92,246,0.2);padding-bottom:6px;"><i class="fa-solid fa-paperclip me-2"></i>C. LAMPIRAN</h6>
    ${secBlock('LKPD', '#e879f9', 'fa-solid fa-file-lines', lamp.lkpd)}
    ${secBlock('Bahan Bacaan Guru', '#38bdf8', 'fa-solid fa-book', lamp.bahan_bacaan_guru)}
    ${secBlock('Bahan Bacaan Siswa', '#4ade80', 'fa-solid fa-book-open', lamp.bahan_bacaan_siswa)}
    ${secBlock('Rubrik Penilaian', '#f87171', 'fa-solid fa-table-list', lamp.rubrik)}
    ${secBlock('Glosarium', '#fbbf24', 'fa-solid fa-spell-check', lamp.glosarium)}
    ${secBlock('Daftar Pustaka', '#94a3b8', 'fa-solid fa-bookmark', lamp.daftar_pustaka)}
    `;
    document.getElementById('rma-title').textContent = doc.nama_dokumen;
    document.getElementById('rma-body').innerHTML = html;
    document.getElementById('rma-print-link').href = 'print.php?id=' + doc.id;
    new bootstrap.Modal(document.getElementById('readModulAjarModal')).show();
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>

