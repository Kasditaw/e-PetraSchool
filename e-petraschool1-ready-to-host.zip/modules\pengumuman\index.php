<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\pengumuman\index.php

$page_title = 'Pengumuman Sekolah';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

try {
    $query = "SELECT p.*, u.nama FROM pengumuman p LEFT JOIN users u ON p.penulis_id = u.id WHERE 1=1";
    $params = [];

    if ($search !== '') {
        $query .= " AND (p.judul LIKE :search OR p.isi LIKE :search OR u.nama LIKE :search)";
        $params['search'] = "%$search%";
    }

    $query .= " ORDER BY p.tanggal DESC, p.id DESC";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $announcements = $stmt->fetchAll();

} catch (Exception $e) {
    echo '<div class="alert alert-danger">Gagal memuat pengumuman: ' . $e->getMessage() . '</div>';
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-bullhorn me-2"></i> Papan Pengumuman Sekolah</h5>
            <p class="text-secondary small mb-0">Kelola dan publikasikan pengumuman resmi serta agenda kalender akademik SD Kristen Petra 1.</p>
        </div>
        
        <div class="d-flex gap-2">
            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                <a href="create.php" class="btn btn-gold"><i class="fa-solid fa-plus me-1"></i> Buat Pengumuman</a>
            <?php endif; ?>
            <a href="../laporan/export.php?type=pengumuman" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-excel me-1"></i> Ekspor Excel</a>
            <a href="../laporan/print.php?type=pengumuman" target="_blank" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-pdf me-1"></i> Cetak PDF</a>
        </div>
    </div>

    <!-- Search Form -->
    <form method="GET" action="index.php" class="row g-2 mb-4 no-print">
        <div class="col-12 col-md-4">
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari judul, isi pengumuman..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">Cari</button>
        </div>
        <?php if ($search !== ''): ?>
            <div class="col-auto">
                <a href="index.php" class="btn btn-outline-danger">Reset</a>
            </div>
        <?php endif; ?>
    </form>

    <div class="row g-4">
        <?php if (count($announcements) > 0): ?>
            <?php foreach ($announcements as $ann): ?>
                <div class="col-12 col-md-6">
                    <div class="glass-card h-100 mb-0 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                        <div>
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <span class="badge badge-secondary"><i class="fa-solid fa-calendar-days me-1"></i> <?php echo date('d M Y', strtotime($ann['tanggal'])); ?></span>
                                <span class="small text-secondary"><i class="fa-solid fa-pen-nib me-1"></i> <?php echo htmlspecialchars($ann['nama'] ?? 'Admin'); ?></span>
                            </div>
                            <h5 class="text-white fw-bold mb-3"><?php echo htmlspecialchars($ann['judul']); ?></h5>
                            <p class="text-secondary small" style="line-height: 1.6; text-align: justify;"><?php echo nl2br(htmlspecialchars($ann['isi'])); ?></p>
                        </div>
                        
                        <div class="mt-4 pt-3 border-top border-secondary border-opacity-10 d-flex justify-content-between align-items-center flex-wrap gap-2">
                            <div>
                                <?php if (!empty($ann['lampiran'])): ?>
                                    <a href="<?php echo $base_url; ?>assets/uploads/pengumuman/<?php echo $ann['lampiran']; ?>" target="_blank" class="btn btn-xs btn-outline-custom text-gold" title="Download Lampiran">
                                        <i class="fa-solid fa-file-arrow-download me-1"></i> Lampiran Dokumen
                                    </a>
                                <?php else: ?>
                                    <span class="small text-secondary"><em>Tidak ada lampiran</em></span>
                                <?php endif; ?>
                            </div>
                            
                            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                <div class="d-flex gap-2 no-print">
                                    <a href="edit.php?id=<?php echo $ann['id']; ?>" class="btn btn-xs btn-outline-warning" title="Edit"><i class="fa-solid fa-pen"></i> Edit</a>
                                    <button onclick="confirmDelete('delete.php?id=<?php echo $ann['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i> Hapus</button>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12">
                <p class="text-center text-secondary py-4">Belum ada pengumuman yang diunggah.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
