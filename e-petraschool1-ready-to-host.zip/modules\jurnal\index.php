<?php
// c:\xampp\htdocs\e-petraschool1\modules\jurnal\index.php

$page_title = 'Jurnal Mengajar Guru';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$filter_status = isset($_GET['status']) ? $_GET['status'] : '';
$filter_tanggal = isset($_GET['tanggal']) ? $_GET['tanggal'] : '';
$filter_guru = isset($_GET['guru_id']) ? $_GET['guru_id'] : '';

$role = $_SESSION['role'];
$user_id = $_SESSION['user_id'];
$guru_id = $_SESSION['guru_id'];

try {
    // Fetch teachers list for filter
    $teachers = $pdo->query("SELECT id, nama_guru, nip FROM guru ORDER BY nama_guru ASC")->fetchAll();

    // Base query
    $query = "SELECT j.*, g.nama_guru, g.nip, s.semester, t.tahun_ajaran, v.catatan 
              FROM jurnal_mengajar j
              JOIN guru g ON j.guru_id = g.id
              JOIN semester s ON j.semester_id = s.id
              JOIN tahun_ajaran t ON j.tahun_ajaran_id = t.id
              LEFT JOIN verifikasi_jurnal v ON j.id = v.jurnal_id
              WHERE 1=1";
    $params = [];

    // Role restrictions
    if (has_role('Guru')) {
        $query .= " AND j.guru_id = :session_guru_id";
        $params['session_guru_id'] = $guru_id;
    } elseif (has_role('Admin')) {
        $query .= " AND j.status = 'Disetujui'";
        if ($filter_guru !== '') {
            $query .= " AND j.guru_id = :filter_guru_id";
            $params['filter_guru_id'] = intval($filter_guru);
        }
    } else {
        if ($filter_guru !== '') {
            $query .= " AND j.guru_id = :filter_guru_id";
            $params['filter_guru_id'] = intval($filter_guru);
        }
        if ($filter_status !== '') {
            $query .= " AND j.status = :status";
            $params['status'] = $filter_status;
        }
    }

    if ($search !== '') {
        $query .= " AND (g.nama_guru LIKE :search OR j.jabatan LIKE :search OR j.hari LIKE :search)";
        $params['search'] = "%$search%";
    }

    if ($filter_tanggal !== '') {
        $query .= " AND j.tanggal = :tanggal";
        $params['tanggal'] = $filter_tanggal;
    }

    $query .= " ORDER BY j.tanggal DESC, j.created_at DESC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $journals = $stmt->fetchAll();

} catch (Exception $e) {
    echo '<div class="alert alert-danger">Gagal memuat jurnal: ' . $e->getMessage() . '</div>';
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-journal-whills me-2"></i> Jurnal Mengajar Harian Guru</h5>
            <p class="text-secondary small mb-0">Kelola dan pantau aktivitas mengajar harian guru SD Kristen Petra 1.</p>
        </div>
        
        <?php if (has_role('Guru')): ?>
            <a href="create.php" class="btn btn-gold"><i class="fa-solid fa-plus me-1"></i> Input Jurnal Hari Ini</a>
        <?php endif; ?>
    </div>

    <!-- Filter Form -->
    <form method="GET" action="index.php" class="row g-3 mb-4 no-print align-items-end">
        <?php if (!has_role('Guru')): ?>
            <div class="col-12 col-md-3">
                <label class="form-label form-label-custom">Filter Guru</label>
                <select name="guru_id" class="form-select form-control-custom bg-dark-select text-white">
                    <option value="">Semua Guru</option>
                    <?php foreach ($teachers as $tc): ?>
                        <option value="<?php echo $tc['id']; ?>" <?php echo $filter_guru == $tc['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($tc['nama_guru']) . ' (' . htmlspecialchars($tc['nip']) . ')'; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        <?php endif; ?>

        <div class="col-12 col-sm-6 col-md-2">
            <label class="form-label form-label-custom">Filter Tanggal</label>
            <input type="date" name="tanggal" class="form-control form-control-custom" value="<?php echo htmlspecialchars($filter_tanggal); ?>">
        </div>

        <?php if (!has_role('Admin')): ?>
            <div class="col-12 col-sm-6 col-md-2">
                <label class="form-label form-label-custom">Filter Status</label>
                <select name="status" class="form-select form-control-custom bg-dark-select text-white">
                    <option value="">Semua Status</option>
                    <option value="Menunggu Verifikasi" <?php echo $filter_status === 'Menunggu Verifikasi' ? 'selected' : ''; ?>>Menunggu Verifikasi</option>
                    <option value="Disetujui" <?php echo $filter_status === 'Disetujui' ? 'selected' : ''; ?>>Disetujui</option>
                    <option value="Revisi" <?php echo $filter_status === 'Revisi' ? 'selected' : ''; ?>>Revisi</option>
                </select>
            </div>
        <?php endif; ?>

        <div class="col-12 col-md-3">
            <label class="form-label form-label-custom">Pencarian</label>
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari guru, jabatan..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>

        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">Filter</button>
        </div>
        
        <?php if ($search !== '' || $filter_status !== '' || $filter_tanggal !== '' || $filter_guru !== ''): ?>
            <div class="col-auto">
                <a href="index.php" class="btn btn-outline-danger">Reset</a>
            </div>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Hari & Tanggal</th>
                    <?php if (!has_role('Guru')): ?>
                        <th>Nama Guru</th>
                    <?php endif; ?>
                    <th>Jabatan</th>
                    <th>T.A / Sem.</th>
                    <th style="text-align: center;">Status</th>
                    <th>Catatan Supervisi</th>
                    <th class="no-print">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($journals) > 0): ?>
                    <?php $no = 1; foreach ($journals as $j): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td>
                                <strong class="text-white d-block"><?php echo htmlspecialchars($j['hari']); ?></strong>
                                <span class="text-secondary small"><?php echo date('d M Y', strtotime($j['tanggal'])); ?></span>
                            </td>
                            <?php if (!has_role('Guru')): ?>
                                <td>
                                    <strong class="text-white d-block"><?php echo htmlspecialchars($j['nama_guru']); ?></strong>
                                    <span class="text-secondary small font-monospace">NIP: <?php echo htmlspecialchars($j['nip']); ?></span>
                                </td>
                            <?php endif; ?>
                            <td><?php echo htmlspecialchars($j['jabatan']); ?></td>
                            <td>
                                <span class="badge badge-secondary"><?php echo htmlspecialchars($j['tahun_ajaran']); ?></span>
                                <span class="badge badge-secondary"><?php echo htmlspecialchars($j['semester']); ?></span>
                            </td>
                            <td style="text-align: center;">
                                <?php if ($j['status'] === 'Disetujui'): ?>
                                    <span class="badge badge-success">
                                        <i class="fa-solid fa-circle-check me-1"></i> Terverifikasi
                                    </span>
                                <?php elseif ($j['status'] === 'Menunggu Verifikasi'): ?>
                                    <span class="badge badge-warning">
                                        <i class="fa-solid fa-clock me-1"></i> Menunggu Verifikasi
                                    </span>
                                <?php elseif ($j['status'] === 'Revisi'): ?>
                                    <span class="badge badge-danger">
                                        <i class="fa-solid fa-triangle-exclamation me-1"></i> Revisi
                                    </span>
                                <?php else: ?>
                                    <span class="badge badge-secondary">
                                        <?php echo htmlspecialchars($j['status']); ?>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="text-secondary small d-inline-block text-truncate" style="max-width: 180px;" title="<?php echo htmlspecialchars($j['catatan'] ?? ''); ?>">
                                    <?php echo !empty($j['catatan']) ? htmlspecialchars($j['catatan']) : '-'; ?>
                                </span>
                            </td>
                            <td class="no-print">
                                <div class="d-flex gap-2">
                                    <a href="print_detail.php?id=<?php echo $j['id']; ?>" class="btn btn-xs btn-outline-info" title="Lihat Jurnal"><i class="fa-solid fa-eye"></i> Lihat</a>
                                    <a href="print_detail.php?id=<?php echo $j['id']; ?>" target="_blank" class="btn btn-xs btn-outline-custom text-gold" title="Cetak Jurnal"><i class="fa-solid fa-print"></i> Cetak</a>
                                    
                                    <?php if (has_role('Guru') && ($j['status'] === 'Menunggu Verifikasi' || $j['status'] === 'Revisi')): ?>
                                        <a href="edit.php?id=<?php echo $j['id']; ?>" class="btn btn-xs btn-outline-warning" title="Edit Jurnal"><i class="fa-solid fa-pen"></i> Edit</a>
                                    <?php endif; ?>

                                    <?php if (has_role('Kepala Sekolah') && $j['status'] === 'Menunggu Verifikasi'): ?>
                                        <a href="verifikasi.php?id=<?php echo $j['id']; ?>" class="btn btn-xs btn-gold" title="Verifikasi Jurnal"><i class="fa-solid fa-signature"></i> Verifikasi</a>
                                    <?php elseif (has_role(['Super Admin', 'Admin', 'Kepala Sekolah'])): ?>
                                        <a href="verifikasi.php?id=<?php echo $j['id']; ?>" class="btn btn-xs btn-outline-info" title="Detail Verifikasi"><i class="fa-solid fa-circle-info"></i> Detail</a>
                                    <?php endif; ?>

                                    <?php if (has_role(['Super Admin', 'Admin', 'Kepala Sekolah'])): ?>
                                        <button onclick="confirmDelete('delete.php?id=<?php echo $j['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i> Hapus</button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="<?php echo has_role('Guru') ? 7 : 8; ?>" class="text-center text-secondary py-4">Belum ada jurnal mengajar terinput.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function confirmDelete(url) {
    Swal.fire({
        title: 'Apakah Anda yakin?',
        text: "Data jurnal dan detail jam mengajar akan dihapus permanen!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = url;
        }
    });
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
