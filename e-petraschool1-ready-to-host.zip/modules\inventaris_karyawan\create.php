<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris_karyawan\create.php

$page_title = 'Tugaskan Aset Karyawan';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$karyawan_id = isset($_GET['karyawan_id']) ? intval($_GET['karyawan_id']) : 0;
if ($karyawan_id <= 0 && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../karyawan/index.php");
    exit;
}

$error = '';

// Fetch karyawan details
try {
    $k_stmt = $pdo->prepare("SELECT * FROM karyawan WHERE id = ?");
    $k_stmt->execute([$karyawan_id]);
    $karyawan = $k_stmt->fetch();
    
    if (!$karyawan && $_SERVER['REQUEST_METHOD'] !== 'POST') {
        die("<div class='alert alert-danger m-4'>Data karyawan tidak ditemukan.</div>");
    }
} catch (Exception $e) {
    die("<div class='alert alert-danger m-4'>Database Error: " . $e->getMessage() . "</div>");
}

// Handle POST Request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();
    
    $karyawan_id = intval($_POST['karyawan_id'] ?? 0);
    $inventaris_id = intval($_POST['inventaris_id'] ?? 0);
    $tanggal_mulai = $_POST['tanggal_mulai'] ?? date('Y-m-d');
    $keterangan = trim($_POST['keterangan'] ?? '');
    $status = $_POST['status'] ?? 'Aktif';
    $tanggal_selesai = !empty($_POST['tanggal_selesai']) ? $_POST['tanggal_selesai'] : null;

    if ($status === 'Selesai' && empty($tanggal_selesai)) {
        $tanggal_selesai = date('Y-m-d');
    }
    
    if ($karyawan_id <= 0 || $inventaris_id <= 0 || empty($tanggal_mulai)) {
        $error = 'Pilih karyawan, barang aset, dan tanggal mulai!';
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO inventaris_karyawan (karyawan_id, inventaris_id, tanggal_mulai, tanggal_selesai, keterangan, status)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([$karyawan_id, $inventaris_id, $tanggal_mulai, $tanggal_selesai, $keterangan, $status]);
            
            // Get asset details for log
            $ast_stmt = $pdo->prepare("SELECT nama_barang, kode_barang FROM inventaris WHERE id = ?");
            $ast_stmt->execute([$inventaris_id]);
            $asset = $ast_stmt->fetch();
            
            // Get employee name for log
            $emp_stmt = $pdo->prepare("SELECT nama, nik FROM karyawan WHERE id = ?");
            $emp_stmt->execute([$karyawan_id]);
            $emp = $emp_stmt->fetch();
            
            $log_msg = "Menugaskan aset " . ($asset ? $asset['nama_barang'] . " (" . $asset['kode_barang'] . ")" : "") . " untuk karyawan: " . ($emp ? $emp['nama'] . " (NIP: " . $emp['nik'] . ")" : "") . ".";
            write_audit_log($log_msg);
            
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire('Berhasil', 'Aset berhasil ditugaskan ke karyawan!', 'success').then(() => {
                        window.location.href = 'index.php?karyawan_id=$karyawan_id';
                    });
                });
            </script>";
            exit;
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Fetch active assets for assignment dropdown
try {
    $assets = $pdo->query("
        SELECT id, kode_barang, nama_barang, merk, kondisi 
        FROM inventaris 
        WHERE status_aktif = 'Aktif' 
        ORDER BY nama_barang ASC
    ")->fetchAll();
} catch (Exception $e) {
    $assets = [];
    $error = 'Gagal memuat daftar barang: ' . $e->getMessage();
}
?>

<div class="glass-card" style="max-width: 650px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-plus-circle me-2"></i> Tugaskan Aset ke Karyawan</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="create.php">
        <?php csrf_input(); ?>
        <input type="hidden" name="karyawan_id" value="<?php echo $karyawan_id; ?>">

        <div class="row g-3">
            <div class="col-12">
                <label class="form-label form-label-custom">Nama Karyawan</label>
                <input type="text" class="form-control form-control-custom" style="background-color: rgba(255,255,255,0.03);" readonly value="<?php echo htmlspecialchars($karyawan['nama']) . ' (NIP: ' . htmlspecialchars($karyawan['nik']) . ')'; ?>">
            </div>

            <div class="col-12">
                <label for="inventaris_id" class="form-label form-label-custom">Pilih Barang Aset / Inventaris <span class="text-danger">*</span></label>
                <select name="inventaris_id" id="inventaris_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="" disabled selected>— Pilih Barang Aset —</option>
                    <?php foreach ($assets as $ast): ?>
                        <option value="<?php echo $ast['id']; ?>">
                            <?php echo htmlspecialchars($ast['nama_barang']) . ' (' . htmlspecialchars($ast['kode_barang']) . ') — Kondisi: ' . htmlspecialchars($ast['kondisi']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-12 col-md-6">
                <label for="tanggal_mulai" class="form-label form-label-custom">Tanggal Mulai Ditugaskan <span class="text-danger">*</span></label>
                <input type="date" name="tanggal_mulai" id="tanggal_mulai" class="form-control form-control-custom" value="<?php echo date('Y-m-d'); ?>" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="status" class="form-label form-label-custom">Status</label>
                <select name="status" id="status" class="form-select form-control-custom bg-dark-select text-white" onchange="toggleEndDateField()">
                    <option value="Aktif" selected>Aktif</option>
                    <option value="Selesai">Selesai (Diakhiri)</option>
                </select>
            </div>

            <div class="col-12" id="tanggal_selesai_container" style="display: none;">
                <label for="tanggal_selesai" class="form-label form-label-custom">Tanggal Selesai Ditugaskan</label>
                <input type="date" name="tanggal_selesai" id="tanggal_selesai" class="form-control form-control-custom" value="<?php echo date('Y-m-d'); ?>">
            </div>

            <div class="col-12">
                <label for="keterangan" class="form-label form-label-custom">Keterangan / Catatan Penugasan</label>
                <textarea name="keterangan" id="keterangan" class="form-control form-control-custom" rows="3" placeholder="Contoh: Digunakan untuk menunjang operasional Tata Usaha harian."></textarea>
            </div>

            <div class="col-12 d-flex justify-content-end gap-2 mt-4">
                <a href="index.php?karyawan_id=<?php echo $karyawan_id; ?>" class="btn btn-outline-custom">Batal</a>
                <button type="submit" class="btn btn-gold">Simpan Penugasan <i class="fa-solid fa-check ms-1"></i></button>
            </div>
        </div>
    </form>
</div>

<script>
function toggleEndDateField() {
    const statusSelect = document.getElementById('status');
    const endDateContainer = document.getElementById('tanggal_selesai_container');
    const endDateInput = document.getElementById('tanggal_selesai');
    
    if (statusSelect.value === 'Selesai') {
        endDateContainer.style.display = 'block';
        endDateInput.setAttribute('required', 'required');
    } else {
        endDateContainer.style.display = 'none';
        endDateInput.removeAttribute('required');
    }
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
