<?php
// c:\xampp\htdocs\e-petraschool1\modules\siswa\print.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

try {
    $stmt = $pdo->prepare("SELECT s.*, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON s.kelas_id = k.id WHERE s.id = ? LIMIT 1");
    $stmt->execute([$id]);
    $student = $stmt->fetch();

    if (!$student) {
        die('Data siswa tidak ditemukan!');
    }

    // Set student code if empty
    $student_code = !empty($student['student_code']) ? $student['student_code'] : 'STD-' . $student['nis'];

    // Format tanggal lahir
    $tgl_lahir = '';
    if (!empty($student['tanggal_lahir'])) {
        $dt = new DateTime($student['tanggal_lahir']);
        $tgl_lahir = $dt->format('d/m/Y');
    }

    // Log card printing
    write_audit_log("Mencetak Kartu Pelajar untuk siswa: " . $student['nama_lengkap'] . " (NIS: " . $student['nis'] . ").");

} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

// Compute dynamic base_url
$project_dir = str_replace('\\', '/', dirname(dirname(__DIR__)));
$web_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
$base_url = str_replace($web_root, '', $project_dir);
if (empty($base_url)) {
    $base_url = '/';
} else {
    if (substr($base_url, 0, 1) !== '/') {
        $base_url = '/' . $base_url;
    }
    if (substr($base_url, -1) !== '/') {
        $base_url .= '/';
    }
}
$base_url = str_replace('//', '/', $base_url);

// Embed logo as base64
$logo_file = dirname(dirname(__DIR__)) . '/assets/images/logo.png';
if (file_exists($logo_file)) {
    $logo_data = base64_encode(file_get_contents($logo_file));
    $logo_src  = 'data:image/png;base64,' . $logo_data;
} else {
    $logo_src  = $base_url . 'assets/images/logo.png';
}

// Embed tut wuri as base64
$tutwuri_file = dirname(dirname(__DIR__)) . '/assets/images/tut_wuri.png';
if (file_exists($tutwuri_file)) {
    $tutwuri_data = base64_encode(file_get_contents($tutwuri_file));
    $tutwuri_src  = 'data:image/png;base64,' . $tutwuri_data;
} else {
    $tutwuri_src  = $base_url . 'assets/images/tut_wuri.png';
}

// Student photo
$foto_path = '';
if (!empty($student['foto'])) {
    $foto_file = dirname(dirname(__DIR__)) . '/assets/uploads/siswa/' . $student['foto'];
    if (file_exists($foto_file)) {
        $foto_ext = strtolower(pathinfo($foto_file, PATHINFO_EXTENSION));
        $mime = ($foto_ext === 'png') ? 'image/png' : (($foto_ext === 'gif') ? 'image/gif' : 'image/jpeg');
        $foto_data = base64_encode(file_get_contents($foto_file));
        $foto_path = 'data:' . $mime . ';base64,' . $foto_data;
    }
}
if (empty($foto_path)) {
    $foto_path = 'https://ui-avatars.com/api/?name=' . urlencode($student['nama_lengkap']) . '&size=200&background=1a3a6e&color=ffffff&bold=true&rounded=true';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kartu Pelajar - <?php echo htmlspecialchars($student['nama_lengkap']); ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background: #e8edf5;
            font-family: 'Outfit', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 30px 20px;
        }

        /* ── ACTION BAR ── */
        .action-bar {
            display: flex;
            gap: 12px;
            margin-bottom: 30px;
        }

        .btn-act {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 22px;
            border-radius: 10px;
            font-family: 'Outfit', sans-serif;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.2s ease;
            border: none;
        }
        .btn-act-print {
            background: linear-gradient(135deg, #1a7abf 0%, #155ea0 100%);
            color: #fff;
            box-shadow: 0 4px 14px rgba(26,122,191,0.35);
        }
        .btn-act-print:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(26,122,191,0.45); }
        .btn-act-back {
            background: #fff;
            color: #334155;
            border: 1.5px solid #e2e8f0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        }
        .btn-act-back:hover { background: #f8fafc; transform: translateY(-2px); }

        /* ── CARD WRAPPER ── */
        .card-wrapper {
            position: relative;
        }

        /* ── ID CARD ── */
        .id-card {
            width: 640px;
            height: 400px;
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 20px 60px rgba(0,0,0,0.22);
            position: relative;
            background: #ffffff;
            display: flex;
            flex-direction: column;
        }

        /* ── CARD TOP SECTION (header blue/teal area) ── */
        .card-top {
            background: linear-gradient(135deg, #0d6ebd 0%, #0a4d8c 40%, #1a8c75 100%);
            height: 195px;
            position: relative;
            overflow: hidden;
            display: flex;
            align-items: flex-start;
            flex-shrink: 0;
        }

        /* Geometric polygon background pattern */
        .card-top::before {
            content: '';
            position: absolute;
            inset: 0;
            background-image:
                /* triangles/polygons using clip-path overlay via radial gradients & shapes */
                linear-gradient(135deg, rgba(255,255,255,0.06) 25%, transparent 25%),
                linear-gradient(225deg, rgba(255,255,255,0.06) 25%, transparent 25%),
                linear-gradient(45deg,  rgba(255,255,255,0.06) 25%, transparent 25%),
                linear-gradient(315deg, rgba(255,255,255,0.06) 25%, transparent 25%);
            background-size: 40px 40px;
            background-position: 0 0, 20px 0, 20px -20px, 0 20px;
        }

        /* Extra polygon overlays */
        .poly-shape {
            position: absolute;
            opacity: 0.18;
        }
        .poly-1 {
            width: 180px; height: 180px;
            background: #00c8a0;
            clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
            top: -60px; right: 60px;
        }
        .poly-2 {
            width: 120px; height: 120px;
            background: #1a9de0;
            clip-path: polygon(50% 0%, 100% 38%, 82% 100%, 18% 100%, 0% 38%);
            top: 30px; right: 200px;
        }
        .poly-3 {
            width: 200px; height: 200px;
            background: #0a3d7a;
            clip-path: polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%);
            bottom: -80px; right: -30px;
        }
        .poly-4 {
            width: 90px; height: 90px;
            background: #00e0b0;
            clip-path: polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%);
            top: 10px; right: 350px;
            opacity: 0.12;
        }
        .poly-5 {
            width: 140px; height: 140px;
            background: #1565C0;
            clip-path: polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%);
            top: -50px; left: 200px;
            opacity: 0.15;
        }

        /* School logo & name top-right */
        .school-brand {
            position: absolute;
            top: 18px;
            right: 22px;
            display: flex;
            align-items: center;
            gap: 10px;
            z-index: 10;
        }
        .school-brand img {
            width: 38px;
            height: 38px;
            object-fit: contain;
            filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
        }
        .school-brand-text {
            text-align: left;
        }
        .school-brand-text .school-name {
            font-size: 12px;
            font-weight: 700;
            color: #ffffff;
            line-height: 1.2;
            letter-spacing: 0.3px;
            text-shadow: 0 1px 3px rgba(0,0,0,0.3);
        }
        .school-brand-text .school-city {
            font-size: 9.5px;
            color: rgba(255,255,255,0.8);
            letter-spacing: 1px;
            font-weight: 400;
        }

        /* Student ID Card title */
        .card-title-area {
            position: absolute;
            bottom: 22px;
            right: 22px;
            text-align: right;
            z-index: 10;
        }
        .card-title-text {
            font-size: 28px;
            font-weight: 800;
            color: #ffffff;
            letter-spacing: 0.5px;
            line-height: 1.1;
            text-shadow: 0 2px 8px rgba(0,0,0,0.3);
        }
        .card-title-sub {
            font-size: 11px;
            color: rgba(255,255,255,0.75);
            letter-spacing: 2px;
            font-weight: 500;
            text-transform: uppercase;
        }

        /* ── STUDENT PHOTO (circle, spanning top + bottom) ── */
        .photo-container {
            position: absolute;
            left: 40px;
            top: 30px;
            z-index: 20;
            width: 145px;
            height: 145px;
        }
        .photo-ring {
            width: 145px;
            height: 145px;
            border-radius: 50%;
            background: linear-gradient(135deg, #ffffff 0%, #e8f0fe 100%);
            padding: 5px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.25);
        }
        .photo-img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            display: block;
        }

        /* ── CARD BOTTOM (white info area) ── */
        .card-bottom {
            flex: 1;
            background: #ffffff;
            display: flex;
            align-items: center;
            padding: 0 22px 0 22px;
            gap: 18px;
        }

        /* Left side: photo overflow + barcode */
        .card-bottom-left {
            display: flex;
            flex-direction: column;
            align-items: center;
            min-width: 145px;
            padding-top: 10px;
        }

        .barcode-area {
            margin-top: 6px;
            background: #fff;
            padding: 4px 2px 2px;
            border-radius: 4px;
        }
        .barcode-area svg {
            display: block;
        }

        /* Right side: student info */
        .card-bottom-right {
            flex: 1;
            padding: 10px 0;
        }

        .info-table {
            width: 100%;
            border-collapse: collapse;
        }
        .info-table tr {
            height: 30px;
        }
        .info-table td {
            vertical-align: middle;
            font-size: 13.5px;
            color: #1e293b;
            padding: 1px 0;
        }
        .info-label {
            width: 88px;
            font-weight: 500;
            color: #475569;
            white-space: nowrap;
        }
        .info-colon {
            width: 16px;
            color: #64748b;
            font-weight: 500;
        }
        .info-value {
            font-weight: 600;
            color: #0f172a;
        }

        /* ── CARD FOOTER STRIPE ── */
        .card-footer-stripe {
            height: 12px;
            background: linear-gradient(90deg, #1a8c75 0%, #0d6ebd 100%);
            flex-shrink: 0;
        }

        /* ── PRINT MEDIA ── */
        @media print {
            body {
                background: #fff !important;
                padding: 0;
                display: block;
            }
            .action-bar { display: none !important; }
            .id-card {
                box-shadow: none !important;
                width: 640px !important;
                height: 400px !important;
                margin: auto;
                position: fixed;
                left: 50%;
                top: 50%;
                transform: translate(-50%, -50%);
            }
        }
    </style>
</head>
<body>

    <div class="action-bar no-print">
        <a href="index.php" class="btn-act btn-act-back">
            <i class="fa-solid fa-chevron-left"></i> Kembali
        </a>
        <button onclick="window.print()" class="btn-act btn-act-print">
            <i class="fa-solid fa-print"></i> Cetak Kartu
        </button>
    </div>

    <!-- ═══════════════ ID CARD ═══════════════ -->
    <div class="card-wrapper">
        <div id="id-card-layout" class="id-card">

            <!-- TOP: header gradient + polygons -->
            <div class="card-top">
                <!-- Decorative polygon shapes -->
                <div class="poly-shape poly-1"></div>
                <div class="poly-shape poly-2"></div>
                <div class="poly-shape poly-3"></div>
                <div class="poly-shape poly-4"></div>
                <div class="poly-shape poly-5"></div>

                <!-- School brand top-right -->
                <div class="school-brand">
                    <img src="<?php echo $logo_src; ?>" alt="Logo SD Petra 1">
                    <div class="school-brand-text">
                        <div class="school-name">SD Kristen Petra 1</div>
                        <div class="school-city">SURABAYA</div>
                    </div>
                </div>

                <!-- Card title bottom-right -->
                <div class="card-title-area">
                    <div class="card-title-text">Kartu Pelajar</div>
                    <div class="card-title-sub">Student ID Card</div>
                </div>

                <!-- Student photo (circle) -->
                <div class="photo-container">
                    <div class="photo-ring">
                        <img src="<?php echo $foto_path; ?>" class="photo-img" alt="Foto Siswa">
                    </div>
                </div>
            </div>

            <!-- BOTTOM: white info section -->
            <div class="card-bottom">
                <!-- Left: photo offset space + barcode -->
                <div class="card-bottom-left">
                    <div style="height: 55px;"></div><!-- push down for photo overflow -->
                    <div class="barcode-area">
                        <svg id="barcode-svg"></svg>
                    </div>
                </div>

                <!-- Divider -->
                <div style="width:1px; height:120px; background:linear-gradient(to bottom, transparent, #e2e8f0, transparent);"></div>

                <!-- Right: student info -->
                <div class="card-bottom-right">
                    <table class="info-table">
                        <tr>
                            <td class="info-label">Nama</td>
                            <td class="info-colon">:</td>
                            <td class="info-value" style="font-size:14px;"><?php echo htmlspecialchars($student['nama_lengkap']); ?></td>
                        </tr>
                        <tr>
                            <td class="info-label">NIS / NISN</td>
                            <td class="info-colon">:</td>
                            <td class="info-value" style="font-family: monospace; letter-spacing:0.5px; font-size:13px;">
                                <?php echo htmlspecialchars($student['nis']); ?> / <?php echo htmlspecialchars($student['nisn']); ?>
                            </td>
                        </tr>
                        <tr>
                            <td class="info-label">Kelas</td>
                            <td class="info-colon">:</td>
                            <td class="info-value"><?php echo htmlspecialchars($student['nama_kelas'] ?? 'Tanpa Kelas'); ?></td>
                        </tr>
                        <?php if (!empty($student['tanggal_lahir'])): ?>
                        <tr>
                            <td class="info-label">T.T.L</td>
                            <td class="info-colon">:</td>
                            <td class="info-value" style="font-size:13px;">
                                <?php echo htmlspecialchars($student['tempat_lahir'] ?? ''); ?>
                                <?php if (!empty($student['tempat_lahir'])) echo ', '; ?>
                                <?php echo $tgl_lahir; ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php if (!empty($student['alamat'])): ?>
                        <tr>
                            <td class="info-label">Alamat</td>
                            <td class="info-colon">:</td>
                            <td class="info-value" style="font-size:12px; max-width:230px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                <?php echo htmlspecialchars($student['alamat']); ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </table>
                </div>
            </div>

            <!-- FOOTER STRIPE -->
            <div class="card-footer-stripe"></div>

        </div>
    </div>

    <!-- JsBarcode library -->
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script>
    <!-- QRious QR Code library (kept for optional QR use) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Generate barcode
            const barcodeValue = '<?php echo addslashes($student['nis']); ?>';
            try {
                JsBarcode("#barcode-svg", barcodeValue, {
                    format: "CODE128",
                    width: 1.6,
                    height: 38,
                    displayValue: true,
                    fontSize: 9,
                    font: "Outfit",
                    textAlign: "center",
                    textPosition: "bottom",
                    textMargin: 2,
                    background: "#ffffff",
                    lineColor: "#000000",
                    margin: 2
                });
            } catch(e) {
                console.warn('Barcode error:', e);
            }

            // Auto-print (skip if preview mode)
            <?php if (!isset($_GET['preview'])): ?>
                setTimeout(() => {
                    window.print();
                }, 600);
            <?php endif; ?>
        });
    </script>
</body>
</html>
