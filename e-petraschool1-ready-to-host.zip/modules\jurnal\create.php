<?php
// c:\xampp\htdocs\e-petraschool1\modules\jurnal\create.php

$page_title = 'Input Jurnal Mengajar';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role('Guru');

$error = '';
$guru_id = $_SESSION['guru_id'];
$nama_user = $_SESSION['nama'];

// Load Teacher info
try {
    $teacher_stmt = $pdo->prepare("SELECT * FROM guru WHERE id = ?");
    $teacher_stmt->execute([$guru_id]);
    $teacher = $teacher_stmt->fetch();
    
    if (!$teacher) {
        die('<div class="alert alert-danger">Profil Guru Anda tidak ditemukan! Silakan hubungi Administrator.</div>');
    }

    // Load Active Semester
    $sem_stmt = $pdo->query("SELECT * FROM semester WHERE status = 'Aktif' LIMIT 1");
    $active_sem = $sem_stmt->fetch();

    // Load Active Year
    $yr_stmt = $pdo->query("SELECT * FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1");
    $active_yr = $yr_stmt->fetch();

    if (!$active_sem || !$active_yr) {
        $error = 'Tahun Ajaran atau Semester Aktif belum diatur di sistem! Silakan hubungi Administrator.';
    }

    // Load All Semesters
    $semesters_list = $pdo->query("SELECT * FROM semester ORDER BY semester ASC")->fetchAll();

    // Load All Years
    $years_list = $pdo->query("SELECT * FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();

    // Load Classes
    $classes = $pdo->query("SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas ASC")->fetchAll();

    // Load Active Subjects
    $subjects = $pdo->query("SELECT id, nama_mapel, kode_mapel FROM mata_pelajaran WHERE status = 'Aktif' ORDER BY nama_mapel ASC")->fetchAll();

} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($error)) {
    check_csrf_request();

    $jabatan = trim($_POST['jabatan'] ?? '');
    $hari = trim($_POST['hari'] ?? '');
    $tanggal = $_POST['tanggal'] ?? '';
    $signature_data = $_POST['signature_data'] ?? ''; // base64 string
    
    // File upload fallback
    if (isset($_FILES['signature_file']) && $_FILES['signature_file']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['signature_file']['tmp_name'];
        $file_name = $_FILES['signature_file']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed_exts = ['jpg', 'jpeg', 'png'];
        if (in_array($file_ext, $allowed_exts)) {
            $data = file_get_contents($file_tmp);
            $signature_data = 'data:image/' . $file_ext . ';base64,' . base64_encode($data);
        }
    }

    if (empty($jabatan) || empty($hari) || empty($tanggal)) {
        $error = 'Semua identitas jurnal wajib diisi!';
    } else {
        try {
            $pdo->beginTransaction();

            $semester_id = isset($_POST['semester_id']) ? intval($_POST['semester_id']) : ($active_sem['id'] ?? 0);
            $tahun_ajaran_id = isset($_POST['tahun_ajaran_id']) ? intval($_POST['tahun_ajaran_id']) : ($active_yr['id'] ?? 0);

            // Insert into jurnal_mengajar
            $stmt = $pdo->prepare("INSERT INTO jurnal_mengajar (guru_id, semester_id, tahun_ajaran_id, jabatan, hari, tanggal, tanda_tangan, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'Menunggu Verifikasi')");
            $stmt->execute([
                $guru_id,
                $semester_id,
                $tahun_ajaran_id,
                $jabatan,
                $hari,
                $tanggal,
                $signature_data
            ]);
            $jurnal_id = $pdo->lastInsertId();

            // Insert detail jam 0-9
            $detail_stmt = $pdo->prepare("INSERT INTO jurnal_mengajar_detail (jurnal_id, jam_ke, mapel_id, kelas_id, materi, kegiatan) VALUES (?, ?, ?, ?, ?, ?)");
            
            $has_activities = false;
            for ($jam = 0; $jam <= 9; $jam++) {
                $mapel_id = $_POST['mapel_' . $jam] !== '' ? intval($_POST['mapel_' . $jam]) : null;
                $kelas_id = $_POST['kelas_' . $jam] !== '' ? intval($_POST['kelas_' . $jam]) : null;
                $materi = trim($_POST['materi_' . $jam] ?? '');
                $kegiatan = trim($_POST['kegiatan_' . $jam] ?? '');

                // Only save if at least one field is filled
                if ($mapel_id !== null || $kelas_id !== null || !empty($materi) || !empty($kegiatan)) {
                    $detail_stmt->execute([
                        $jurnal_id,
                        $jam,
                        $mapel_id,
                        $kelas_id,
                        $materi,
                        $kegiatan
                    ]);
                    $has_activities = true;
                }
            }

            // Create notification for Kepsek & Admin
            $kepsek_ids = $pdo->query("SELECT id FROM users WHERE role_id IN (1, 2, 4)")->fetchAll(PDO::FETCH_COLUMN);
            $notif_stmt = $pdo->prepare("INSERT INTO notifikasi (user_id, pesan) VALUES (?, ?)");
            foreach ($kepsek_ids as $k_id) {
                $notif_stmt->execute([$k_id, "Guru <strong>" . htmlspecialchars($teacher['nama_guru']) . "</strong> telah menginput jurnal mengajar baru untuk tanggal " . date('d/m/Y', strtotime($tanggal)) . "."]);
            }

            $pdo->commit();

            write_audit_log("Menginput jurnal mengajar tanggal $tanggal.");

            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire('Berhasil', 'Jurnal mengajar berhasil dikirim!', 'success').then(() => {
                        window.location.href = 'index.php';
                    });
                });
            </script>";

        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = 'Database Error: ' . $e->getMessage();
        }
    }
}

// Default values
$today = date('Y-m-d');
$current_day = '';
$days_map = [
    'Monday' => 'Senin',
    'Tuesday' => 'Selasa',
    'Wednesday' => 'Rabu',
    'Thursday' => 'Kamis',
    'Friday' => 'Jumat',
    'Saturday' => 'Sabtu',
    'Sunday' => 'Minggu'
];
$english_day = date('l');
$current_day = $days_map[$english_day] ?? '';
?>

<div class="glass-card" style="max-width: 1000px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-file-signature me-2"></i> Form Input Jurnal Mengajar Harian</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="create.php" enctype="multipart/form-data" id="jurnal-form">
        <?php csrf_input(); ?>

        <!-- Identity Section -->
        <div class="row g-3 mb-4">
            <div class="col-12 col-md-4">
                <label class="form-label form-label-custom">Nama Guru</label>
                <input type="text" class="form-control form-control-custom text-white" value="<?php echo htmlspecialchars($teacher['nama_guru']); ?>" readonly style="background: rgba(255,255,255,0.05) !important;">
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label form-label-custom">NIP Guru</label>
                <input type="text" class="form-control form-control-custom text-white" value="<?php echo htmlspecialchars($teacher['nip']); ?>" readonly style="background: rgba(255,255,255,0.05) !important;">
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label form-label-custom">Tahun Ajaran / Semester <span class="text-danger">*</span></label>
                <div class="d-flex gap-2">
                    <input type="hidden" name="tahun_ajaran_id" id="tahun_ajaran_id" value="<?php echo $active_yr['id'] ?? ''; ?>">
                    <input type="hidden" name="semester_id" id="semester_id" value="<?php echo $active_sem['id'] ?? ''; ?>">
                    <select name="tahun_ajaran_id_display" id="tahun_ajaran_id_display" class="form-select form-control-custom bg-dark-select text-white" disabled>
                        <?php foreach ($years_list as $yr): ?>
                            <option value="<?php echo $yr['id']; ?>" <?php echo ($active_yr['id'] ?? 0) == $yr['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($yr['tahun_ajaran']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <select name="semester_id_display" id="semester_id_display" class="form-select form-control-custom bg-dark-select text-white" disabled>
                        <?php foreach ($semesters_list as $sem): ?>
                            <option value="<?php echo $sem['id']; ?>" <?php echo ($active_sem['id'] ?? 0) == $sem['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($sem['semester']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="col-12 col-sm-4">
                <label for="jabatan" class="form-label form-label-custom">Jabatan Mengajar <span class="text-danger">*</span></label>
                <select name="jabatan" id="jabatan" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="Guru Kelas" <?php echo strpos($teacher['jabatan'], 'Kelas') !== false ? 'selected' : ''; ?>>Guru Kelas</option>
                    <option value="Guru Mata Pelajaran" <?php echo strpos($teacher['jabatan'], 'Mapel') !== false ? 'selected' : ''; ?>>Guru Mata Pelajaran</option>
                    <option value="Wali Kelas" <?php echo strpos($teacher['jabatan'], 'Wali') !== false ? 'selected' : ''; ?>>Wali Kelas</option>
                    <option value="Kepala Sekolah">Kepala Sekolah</option>
                </select>
            </div>

            <div class="col-12 col-sm-4">
                <label for="hari" class="form-label form-label-custom">Hari <span class="text-danger">*</span></label>
                <select name="hari" id="hari" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="Senin" <?php echo $current_day === 'Senin' ? 'selected' : ''; ?>>Senin</option>
                    <option value="Selasa" <?php echo $current_day === 'Selasa' ? 'selected' : ''; ?>>Selasa</option>
                    <option value="Rabu" <?php echo $current_day === 'Rabu' ? 'selected' : ''; ?>>Rabu</option>
                    <option value="Kamis" <?php echo $current_day === 'Kamis' ? 'selected' : ''; ?>>Kamis</option>
                    <option value="Jumat" <?php echo $current_day === 'Jumat' ? 'selected' : ''; ?>>Jumat</option>
                </select>
            </div>

            <div class="col-12 col-sm-4">
                <label for="tanggal" class="form-label form-label-custom">Tanggal <span class="text-danger">*</span></label>
                <input type="date" name="tanggal" id="tanggal" class="form-control form-control-custom text-white" value="<?php echo $today; ?>" required>
            </div>
        </div>

        <!-- Hourly Schedule Table -->
        <h6 class="text-gold border-bottom border-secondary border-opacity-25 pb-2 mb-3"><i class="fa-solid fa-list-check me-2"></i> Rincian KBM Harian (Jam Ke-1 s/d Jam Ke-9)</h6>
        <p class="text-secondary small">Isi baris jam yang Anda gunakan untuk mengajar. Baris yang kosong tidak akan tersimpan.</p>

        <div class="table-responsive mb-4">
            <table class="table table-custom table-bordered" style="border-color: var(--border-color);">
                <thead>
                    <tr>
                        <th style="width: 80px; text-align: center;">Jam Ke</th>
                        <th style="width: 230px;">Mata Pelajaran</th>
                        <th style="width: 150px;">Kelas</th>
                        <th>Materi Pembelajaran</th>
                        <th>Kegiatan Pembelajaran</th>
                        <th style="width: 80px; text-align: center;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php for ($jam = 0; $jam <= 9; $jam++): ?>
                        <tr id="row-<?php echo $jam; ?>">
                            <td class="text-center fw-bold text-white pt-3"># <?php echo $jam; ?></td>
                            <td>
                                <select name="mapel_<?php echo $jam; ?>" id="mapel_<?php echo $jam; ?>" class="form-select form-control-custom bg-dark-select text-white py-1.5">
                                    <option value="">Pilih Mapel...</option>
                                    <?php foreach ($subjects as $sub): ?>
                                        <option value="<?php echo $sub['id']; ?>"><?php echo htmlspecialchars($sub['nama_mapel']) . ' (' . htmlspecialchars($sub['kode_mapel']) . ')'; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select name="kelas_<?php echo $jam; ?>" id="kelas_<?php echo $jam; ?>" class="form-select form-control-custom bg-dark-select text-white py-1.5">
                                    <option value="">Pilih Kelas...</option>
                                    <?php foreach ($classes as $cl): ?>
                                        <option value="<?php echo $cl['id']; ?>"><?php echo htmlspecialchars($cl['nama_kelas']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="materi_<?php echo $jam; ?>" id="materi_<?php echo $jam; ?>" class="form-control form-control-custom py-1.5" placeholder="Materi pokok bahasan">
                            </td>
                            <td>
                                <input type="text" name="kegiatan_<?php echo $jam; ?>" id="kegiatan_<?php echo $jam; ?>" class="form-control form-control-custom py-1.5" value="" placeholder="Kegiatan KBM">
                            </td>
                            <td class="text-center pt-2">
                                <button type="button" class="btn btn-xs btn-outline-danger" onclick="clearRow(<?php echo $jam; ?>)" title="Kosongkan"><i class="fa-solid fa-eraser"></i></button>
                            </td>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>

        <!-- Signature Section -->
        <h6 class="text-gold border-bottom border-secondary border-opacity-25 pb-2 mb-3"><i class="fa-solid fa-signature me-2"></i> Tanda Tangan Guru</h6>
        <div class="row g-4 mb-4">
            <div class="col-12 col-md-6">
                <label class="form-label form-label-custom">Tanda Tangan Digital (Gambar pada kanvas di bawah)</label>
                <div class="glass-card mb-2 p-0 position-relative" style="background: rgba(0,0,0,0.4); border: 2px dashed var(--border-color); overflow: hidden;">
                    <canvas id="sig-canvas" width="450" height="200" style="cursor: crosshair; touch-action: none; width: 100%; display: block;"></canvas>
                </div>
                <button type="button" class="btn btn-xs btn-outline-warning" id="btn-clear-sig"><i class="fa-solid fa-rotate-left me-1"></i> Bersihkan Kanvas</button>
                <input type="hidden" name="signature_data" id="signature_data">
            </div>
            
            <div class="col-12 col-md-6">
                <label class="form-label form-label-custom">Alternatif: Unggah Tanda Tangan (Format Gambar)</label>
                <div class="p-4 rounded border border-secondary border-opacity-10 bg-dark bg-opacity-25 text-center d-flex flex-column align-items-center justify-content-center h-100" style="min-height: 200px;">
                    <i class="fa-solid fa-file-image text-secondary mb-3" style="font-size: 32px;"></i>
                    <input type="file" name="signature_file" id="signature_file" class="form-control form-control-custom w-75" accept="image/*">
                    <span class="text-secondary small mt-2">Pilih file scan/foto tanda tangan Anda jika tidak ingin menggambar langsung.</span>
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-end gap-2 border-top border-secondary border-opacity-10 pt-4 mt-4">
            <a href="index.php" class="btn btn-outline-custom px-4">Batal</a>
            <button type="submit" class="btn btn-gold px-4" id="btn-submit-jurnal" disabled title="Isi minimal satu baris jam mengajar terlebih dahulu">Kirim Jurnal Mengajar <i class="fa-solid fa-paper-plane ms-1"></i></button>
        </div>
    </form>
</div>

<!-- Signature Canvas Drawing Script -->
<script>
// ── Validasi: cek apakah minimal 1 baris jam sudah terisi ──
function checkJurnalFilled() {
    const submitBtn = document.getElementById('btn-submit-jurnal');
    let hasFilled = false;

    for (let jam = 0; jam <= 9; jam++) {
        const mapel   = document.getElementById('mapel_'   + jam)?.value?.trim();
        const kelas   = document.getElementById('kelas_'   + jam)?.value?.trim();
        const materi  = document.getElementById('materi_'  + jam)?.value?.trim();
        const kegiatan = document.getElementById('kegiatan_' + jam)?.value?.trim();

        // Semua 4 kolom harus terisi pada baris yang sama
        if (mapel && kelas && materi && kegiatan) {
            hasFilled = true;
            break;
        }
    }

    if (hasFilled) {
        submitBtn.disabled = false;
        submitBtn.title = '';
        submitBtn.style.opacity = '1';
        submitBtn.style.cursor = 'pointer';
    } else {
        submitBtn.disabled = true;
        submitBtn.title = 'Minimal satu baris harus lengkap: Mata Pelajaran, Kelas, Materi, dan Kegiatan Pembelajaran wajib diisi';
        submitBtn.style.opacity = '0.5';
        submitBtn.style.cursor = 'not-allowed';
    }
}

function clearRow(jam) {
    document.getElementById('mapel_' + jam).value = '';
    document.getElementById('kelas_' + jam).value = '';
    document.getElementById('materi_' + jam).value = '';
    document.getElementById('kegiatan_' + jam).value = '';
    checkJurnalFilled(); // update tombol setelah dikosongkan
}

document.addEventListener('DOMContentLoaded', function() {
    // Pasang listener pada semua input baris jurnal
    for (let jam = 0; jam <= 9; jam++) {
        ['mapel_', 'kelas_', 'materi_', 'kegiatan_'].forEach(function(prefix) {
            const el = document.getElementById(prefix + jam);
            if (el) el.addEventListener('change', checkJurnalFilled);
            if (el) el.addEventListener('input',  checkJurnalFilled);
        });
    }
    checkJurnalFilled(); // jalankan sekali saat halaman dimuat

    // Auto-update Tahun Ajaran / Semester / Hari berdasarkan Tanggal
    const tanggalInput = document.getElementById('tanggal');
    if (tanggalInput) {
        tanggalInput.addEventListener('change', updateAcademicYearAndSemester);
        // Run once on load to sync the default date
        updateAcademicYearAndSemester();
    }

    function updateAcademicYearAndSemester() {
        const tanggalVal = tanggalInput.value;
        if (!tanggalVal) return;
        
        const parts = tanggalVal.split('-');
        if (parts.length !== 3) return;
        
        const year = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10);
        const day = parseInt(parts[2], 10);
        
        let targetSemester = '';
        let targetTahunAjaran = '';
        
        // July - December = Ganjil, January - June = Genap
        if (month >= 7 && month <= 12) {
            targetSemester = 'Ganjil';
            targetTahunAjaran = year + '/' + (year + 1);
        } else if (month >= 1 && month <= 6) {
            targetSemester = 'Genap';
            targetTahunAjaran = (year - 1) + '/' + year;
        }
        
        // Select Tahun Ajaran
        const taSelect = document.getElementById('tahun_ajaran_id_display');
        const taHidden = document.getElementById('tahun_ajaran_id');
        if (taSelect) {
            for (let i = 0; i < taSelect.options.length; i++) {
                if (taSelect.options[i].text.trim() === targetTahunAjaran) {
                    taSelect.selectedIndex = i;
                    if (taHidden) {
                        taHidden.value = taSelect.options[i].value;
                    }
                    break;
                }
            }
        }
        
        // Select Semester
        const semSelect = document.getElementById('semester_id_display');
        const semHidden = document.getElementById('semester_id');
        if (semSelect) {
            for (let i = 0; i < semSelect.options.length; i++) {
                if (semSelect.options[i].text.trim().toLowerCase() === targetSemester.toLowerCase()) {
                    semSelect.selectedIndex = i;
                    if (semHidden) {
                        semHidden.value = semSelect.options[i].value;
                    }
                    break;
                }
            }
        }
        
        // Select Hari
        const hariSelect = document.getElementById('hari');
        if (hariSelect) {
            const dateObj = new Date(year, month - 1, day);
            const dayOfWeek = dateObj.getDay(); // 0 = Sunday, 1 = Monday, ...
            const indonesianDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
            const targetDay = indonesianDays[dayOfWeek];
            
            for (let i = 0; i < hariSelect.options.length; i++) {
                if (hariSelect.options[i].value === targetDay) {
                    hariSelect.selectedIndex = i;
                    break;
                }
            }
        }
    }

    const canvas = document.getElementById('sig-canvas');
    const ctx = canvas.getContext('2d');
    const clearBtn = document.getElementById('btn-clear-sig');
    const signatureInput = document.getElementById('signature_data');
    const form = document.getElementById('jurnal-form');
    
    ctx.strokeStyle = "#000000"; // Black color brush
    ctx.lineWidth = 3;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';

    let drawing = false;
    let lastX = 0;
    let lastY = 0;

    // Get Mouse/Touch Position relative to Canvas
    function getPos(e) {
        const rect = canvas.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        
        // Scale appropriately due to CSS scaling
        return {
            x: (clientX - rect.left) * (canvas.width / rect.width),
            y: (clientY - rect.top) * (canvas.height / rect.height)
        };
    }

    function startDrawing(e) {
        drawing = true;
        const pos = getPos(e);
        lastX = pos.x;
        lastY = pos.y;
    }

    function draw(e) {
        if (!drawing) return;
        e.preventDefault();
        const pos = getPos(e);

        ctx.beginPath();
        ctx.moveTo(lastX, lastY);
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();

        lastX = pos.x;
        lastY = pos.y;
    }

    function stopDrawing() {
        drawing = false;
    }

    // Mouse Events
    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseout', stopDrawing);

    // Touch Events for Mobile
    canvas.addEventListener('touchstart', startDrawing);
    canvas.addEventListener('touchmove', draw);
    canvas.addEventListener('touchend', stopDrawing);

    // Clear Canvas
    clearBtn.addEventListener('click', function() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        signatureInput.value = '';
    });

    // On Form Submit, extract canvas image data
    form.addEventListener('submit', function(e) {
        // Check if canvas has drawing (we check if canvas is blank by comparing pixels)
        const isBlank = isCanvasBlank(canvas);
        if (!isBlank) {
            const dataUrl = canvas.toDataURL('image/png');
            signatureInput.value = dataUrl;
        }
    });

    function isCanvasBlank(c) {
        const blank = document.createElement('canvas');
        blank.width = c.width;
        blank.height = c.height;
        return c.toDataURL() === blank.toDataURL();
    }
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
