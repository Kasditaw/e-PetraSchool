<?php
// c:\xampp\htdocs\e-petraschool1\modules\pengaturan\akun.php

$page_title = 'Kelola Akun NIP';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';
$success = '';

// -----------------------------------------------------
// PROCESS FORM SUBMISSIONS
// -----------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    check_csrf_request();
    
    $action = $_POST['action'];
    
    if ($action === 'create') {
        $personnel_id = intval($_POST['personnel_id'] ?? 0);
        $tipe = trim($_POST['tipe'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $role_id = intval($_POST['role_id'] ?? 0);
        $status_aktif = trim($_POST['status_aktif'] ?? 'Aktif');
        
        if ($personnel_id <= 0 || empty($tipe) || empty($username) || empty($password) || $role_id <= 0) {
            $error = 'Semua field wajib diisi untuk membuat akun baru!';
        } else {
            try {
                // Check duplicate username
                $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ?");
                $check_stmt->execute([$username]);
                if ($check_stmt->fetchColumn() > 0) {
                    $error = "Username '$username' sudah terdaftar di sistem. Gunakan username lain!";
                } else {
                    // Fetch personnel details to get full name
                    if ($tipe === 'Guru') {
                        $p_stmt = $pdo->prepare("SELECT nama_guru as nama FROM guru WHERE id = ?");
                    } else {
                        $p_stmt = $pdo->prepare("SELECT nama FROM karyawan WHERE id = ?");
                    }
                    $p_stmt->execute([$personnel_id]);
                    $nama = $p_stmt->fetchColumn() ?: 'Staff';
                    
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $guru_id = ($tipe === 'Guru') ? $personnel_id : null;
                    $karyawan_id = ($tipe === 'Karyawan') ? $personnel_id : null;
                    
                    $stmt = $pdo->prepare("INSERT INTO users (username, password, nama, role_id, guru_id, karyawan_id, status_aktif) 
                                           VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$username, $hashed_password, $nama, $role_id, $guru_id, $karyawan_id, $status_aktif]);
                    
                    write_audit_log("Membuat akun baru: username '$username', tipe '$tipe' untuk $nama.");
                    
                    $success = "Akun untuk $nama berhasil dibuat!";
                }
            } catch (Exception $e) {
                $error = 'Gagal menyimpan akun: ' . $e->getMessage();
            }
        }
    }
    
    else if ($action === 'edit') {
        $user_id = intval($_POST['user_id'] ?? 0);
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $role_id = intval($_POST['role_id'] ?? 0);
        $status_aktif = trim($_POST['status_aktif'] ?? 'Aktif');
        
        if ($user_id <= 0 || empty($username) || $role_id <= 0) {
            $error = 'Username dan Hak Akses wajib diisi!';
        } else {
            try {
                // Check duplicate username for other users
                $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE username = ? AND id != ?");
                $check_stmt->execute([$username, $user_id]);
                if ($check_stmt->fetchColumn() > 0) {
                    $error = "Username '$username' sudah digunakan oleh akun lain!";
                } else {
                    // Fetch user details to log
                    $u_stmt = $pdo->prepare("SELECT nama FROM users WHERE id = ?");
                    $u_stmt->execute([$user_id]);
                    $nama = $u_stmt->fetchColumn() ?: 'User';
                    
                    if (!empty($password)) {
                        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                        $stmt = $pdo->prepare("UPDATE users 
                                               SET username = ?, password = ?, role_id = ?, status_aktif = ? 
                                               WHERE id = ?");
                        $stmt->execute([$username, $hashed_password, $role_id, $status_aktif, $user_id]);
                        write_audit_log("Memperbarui akun dan password untuk: $nama (username '$username').");
                    } else {
                        $stmt = $pdo->prepare("UPDATE users 
                                               SET username = ?, role_id = ?, status_aktif = ? 
                                               WHERE id = ?");
                        $stmt->execute([$username, $role_id, $status_aktif, $user_id]);
                        write_audit_log("Memperbarui pengaturan akun untuk: $nama (username '$username').");
                    }
                    
                    $success = "Akun untuk $nama berhasil diperbarui!";
                }
            } catch (Exception $e) {
                $error = 'Gagal memperbarui akun: ' . $e->getMessage();
            }
        }
    }
    
    else if ($action === 'delete') {
        $user_id = intval($_POST['user_id'] ?? 0);
        
        if ($user_id <= 0) {
            $error = 'ID Akun tidak valid!';
        } else {
            try {
                // Fetch user details to log
                $u_stmt = $pdo->prepare("SELECT username, nama FROM users WHERE id = ?");
                $u_stmt->execute([$user_id]);
                $user = $u_stmt->fetch();
                
                if ($user) {
                    // Prevent deleting self
                    if ($user_id === intval($_SESSION['user_id'])) {
                        $error = 'Anda tidak dapat menghapus akun Anda sendiri yang sedang digunakan!';
                    } else {
                        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
                        $stmt->execute([$user_id]);
                        write_audit_log("Menghapus login akun: username '" . $user['username'] . "' milik " . $user['nama'] . ".");
                        $success = "Akun login untuk " . $user['nama'] . " berhasil dihapus.";
                    }
                } else {
                    $error = 'Akun tidak ditemukan!';
                }
            } catch (Exception $e) {
                $error = 'Gagal menghapus akun: ' . $e->getMessage();
            }
        }
    }

    else if ($action === 'reset_password') {
        $user_id      = intval($_POST['user_id'] ?? 0);
        $new_password = trim($_POST['new_password'] ?? '');

        if ($user_id <= 0 || empty($new_password)) {
            $error = 'ID akun dan password baru wajib diisi!';
        } elseif (strlen($new_password) < 6) {
            $error = 'Password minimal 6 karakter!';
        } else {
            try {
                $u_stmt = $pdo->prepare("SELECT nama, username FROM users WHERE id = ?");
                $u_stmt->execute([$user_id]);
                $u = $u_stmt->fetch();
                if ($u) {
                    $hash = password_hash($new_password, PASSWORD_DEFAULT);
                    $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([$hash, $user_id]);
                    write_audit_log("Reset password akun: username '{$u['username']}' ({$u['nama']}) oleh Admin.");
                    $success = "Password untuk akun <strong>{$u['nama']}</strong> berhasil direset!";
                } else {
                    $error = 'Akun tidak ditemukan!';
                }
            } catch (Exception $e) {
                $error = 'Gagal reset: ' . $e->getMessage();
            }
        }
    }
}


// -----------------------------------------------------
// RETRIEVE DATA
// -----------------------------------------------------
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$filter_tipe = isset($_GET['tipe']) ? trim($_GET['tipe']) : '';
$filter_status = isset($_GET['status_akun']) ? trim($_GET['status_akun']) : '';

try {
    // 1. Fetch available Roles — exclude 'Super Admin' from dropdown choices
    $roles_stmt = $pdo->query("SELECT id, nama_role FROM roles WHERE nama_role != 'Super Admin' ORDER BY id");
    $roles = $roles_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 2. Fetch union personnel list
    $query = "
        SELECT g.id as personnel_id, g.nip as code, g.nama_guru as nama, 'Guru' as tipe, g.jabatan,
               u.id as user_id, u.username, u.role_id, u.status_aktif, r.nama_role
        FROM guru g
        LEFT JOIN users u ON g.id = u.guru_id
        LEFT JOIN roles r ON u.role_id = r.id
        UNION ALL
        SELECT k.id as personnel_id, k.nik as code, k.nama, 'Karyawan' as tipe, k.jabatan,
               u.id as user_id, u.username, u.role_id, u.status_aktif, r.nama_role
        FROM karyawan k
        LEFT JOIN users u ON k.id = u.karyawan_id
        LEFT JOIN roles r ON u.role_id = r.id
        ORDER BY nama ASC
    ";
    $stmt = $pdo->query($query);
    $all_personnel = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Apply filters in PHP
    $filtered_personnel = [];
    foreach ($all_personnel as $p) {
        // ── Sembunyikan akun superadmin / akun yang tidak terhubung NIP ────────
        // Baris yang tidak punya user_id (belum ada akun) tetap tampil.
        // Baris yang PUNYA user_id — pastikan user tersebut terhubung ke
        // personnel di tabel ini (guru_id atau karyawan_id), bukan akun standalone.
        // Catatan: query UNION sudah menjamin semua baris berasal dari guru/karyawan,
        // sehingga superadmin (tidak terhubung guru/karyawan) tidak akan muncul.

        if ($search !== '') {
            if (stripos($p['nama'], $search) === false && 
                stripos($p['code'], $search) === false && 
                stripos($p['username'] ?? '', $search) === false) {
                continue;
            }
        }
        if ($filter_tipe !== '') {
            if ($p['tipe'] !== $filter_tipe) {
                continue;
            }
        }
        if ($filter_status !== '') {
            if ($filter_status === 'linked' && $p['user_id'] === null) {
                continue;
            }
            if ($filter_status === 'unlinked' && $p['user_id'] !== null) {
                continue;
            }
        }
        $filtered_personnel[] = $p;
    }
} catch (Exception $e) {
    $error = 'Database Error: ' . $e->getMessage();
    $roles = [];
    $filtered_personnel = [];
}
?>

<style>
    .glass-card {
        background: var(--bg-card);
        border: 1px solid var(--border-color);
        border-radius: 12px;
        padding: 1.5rem;
        box-shadow: var(--glass-shadow);
        color: var(--text-primary);
    }
    .badge-status {
        font-size: 10px;
        font-weight: 700;
        padding: 4px 10px;
        border-radius: 12px;
        text-transform: uppercase;
        display: inline-block;
    }
    .badge-status-aktif {
        background: rgba(16, 185, 129, 0.08);
        border: 1px solid #10b981;
        color: #10b981;
    }
    .badge-status-tidak {
        background: rgba(239, 68, 68, 0.08);
        border: 1px solid #ef4444;
        color: #ef4444;
    }
    .badge-status-belum {
        background: rgba(100, 116, 139, 0.08);
        border: 1px solid #64748b;
        color: #64748b;
    }
    .badge-tipe {
        font-size: 9px;
        font-weight: 700;
        padding: 2px 8px;
        border-radius: 4px;
        text-transform: uppercase;
        display: inline-block;
    }
    .badge-tipe-guru {
        background: rgba(59, 130, 246, 0.1);
        border: 1px solid rgba(59, 130, 246, 0.3);
        color: #3b82f6;
    }
    .badge-tipe-karyawan {
        background: rgba(245, 158, 11, 0.1);
        border: 1px solid rgba(245, 158, 11, 0.3);
        color: #f59e0b;
    }
    .table-custom thead th {
        background-color: var(--bg-sidebar);
        color: var(--color-gold);
        font-weight: 600;
        text-transform: uppercase;
        font-size: 10px;
        letter-spacing: 0.05em;
        padding: 12px 10px;
        border-bottom: 2px solid var(--border-color);
    }
    .table-custom tbody td {
        padding: 12px 10px;
        border-bottom: 1px solid var(--border-color);
        vertical-align: middle;
        color: var(--text-primary);
    }
    .table-custom tbody tr:hover td {
        background-color: rgba(255, 255, 255, 0.02);
    }
    .light-theme .table-custom tbody tr:hover td {
        background-color: #f8fafc;
    }
    .search-input-container {
        position: relative;
    }
    .search-input-container i {
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--text-secondary);
        pointer-events: none;
    }
    .search-input-container input {
        padding-left: 36px !important;
        background-color: var(--bg-main) !important;
        border: 1px solid var(--border-color) !important;
        color: var(--text-primary) !important;
    }
    .filter-select {
        background-color: var(--bg-main) !important;
        border: 1px solid var(--border-color) !important;
        color: var(--text-primary) !important;
    }
    /* ── Fix: pastikan option di dropdown selalu terbaca di semua tema ── */
    /* Default (light theme) */
    select.form-select option,
    select.filter-select option {
        background-color: #ffffff !important;
        color: #1e293b !important;
    }
    /* Dark theme: class yang dipakai app adalah body.dark-theme */
    body.dark-theme select.form-select option,
    body.dark-theme select.filter-select option {
        background-color: #0c1328 !important;
        color: #eef2ff !important;
    }

    /* ── Custom Role Picker ─────────────────────────────────────────────── */
    .role-picker {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-top: 4px;
    }
    .role-picker input[type="radio"] {
        display: none;
    }
    .role-picker label {
        display: flex;
        align-items: center;
        gap: 7px;
        padding: 8px 14px;
        border-radius: 8px;
        border: 1.5px solid var(--border-color, #cbd5e1);
        background: #f8fafc;
        color: #334155;
        font-size: 13px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.18s ease;
        user-select: none;
        white-space: nowrap;
    }
    .role-picker label:hover {
        border-color: #6257DE;
        background: #f0edff;
        color: #6257DE;
    }
    .role-picker input[type="radio"]:checked + label {
        background: #6257DE;
        border-color: #6257DE;
        color: #ffffff;
        box-shadow: 0 2px 8px rgba(98, 87, 222, 0.35);
    }
    /* Dark theme role picker */
    body.dark-theme .role-picker label {
        background: rgba(255,255,255,0.05);
        border-color: rgba(255,255,255,0.12);
        color: #cbd5e1;
    }
    body.dark-theme .role-picker label:hover {
        background: rgba(98, 87, 222, 0.15);
        border-color: #6257DE;
        color: #a8a0f8;
    }
    body.dark-theme .role-picker input[type="radio"]:checked + label {
        background: #6257DE;
        border-color: #6257DE;
        color: #ffffff;
    }
    .role-picker-required-msg {
        font-size: 11px;
        color: #ef4444;
        margin-top: 4px;
        display: none;
    }
</style>

<div class="container-fluid px-4 py-2">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4 pb-3 border-b" style="border-color: var(--border-color) !important;">
        <div class="d-flex align-items-center gap-3">
            <div class="d-flex align-items-center justify-content-center shadow-md shadow-indigo-600/20" style="width: 40px; height: 40px; background-color: var(--color-gold) !important; border-radius: 8px;">
                <i class="fa-solid fa-user-lock text-white text-xl"></i>
            </div>
            <div>
                <h5 class="font-bold text-lg mb-0 font-sans tracking-wide" style="color: var(--text-primary) !important;">Pengaturan Akun & Akses Pegawai</h5>
                <p class="text-xs mb-0" style="color: var(--text-secondary) !important;">Kelola akun login (username & password) untuk NIP/NIK guru dan karyawan</p>
            </div>
        </div>
    </div>

    <!-- Alert Notifications -->
    <?php if ($error !== ''): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({ icon: 'error', title: 'Gagal', text: <?php echo json_encode($error); ?>, confirmButtonColor: '#ef4444' });
            });
        </script>
    <?php endif; ?>

    <?php if ($success !== ''): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({ icon: 'success', title: 'Berhasil', text: <?php echo json_encode($success); ?>, confirmButtonColor: '#10b981' });
            });
        </script>
    <?php endif; ?>

    <div class="glass-card">
        <!-- Search and Filters -->
        <form method="GET" action="akun.php" class="row g-3 mb-4 align-items-end">
            <div class="col-12 col-md-4">
                <label class="form-label text-uppercase font-bold" style="color: var(--text-secondary); font-size: 10px; letter-spacing: 0.5px;">Pencarian</label>
                <div class="search-input-container">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input type="text" name="search" class="form-control rounded-lg" placeholder="Cari nama, NIP, NIK, username..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
            </div>
            
            <div class="col-12 col-sm-6 col-md-3">
                <label class="form-label text-uppercase font-bold" style="color: var(--text-secondary); font-size: 10px; letter-spacing: 0.5px;">Filter Tipe</label>
                <select name="tipe" class="form-select filter-select rounded-lg">
                    <option value="">Semua Tipe</option>
                    <option value="Guru" <?php echo $filter_tipe === 'Guru' ? 'selected' : ''; ?>>Guru (Pendidik)</option>
                    <option value="Karyawan" <?php echo $filter_tipe === 'Karyawan' ? 'selected' : ''; ?>>Karyawan (Staff)</option>
                </select>
            </div>

            <div class="col-12 col-sm-6 col-md-3">
                <label class="form-label text-uppercase font-bold" style="color: var(--text-secondary); font-size: 10px; letter-spacing: 0.5px;">Status Akun</label>
                <select name="status_akun" class="form-select filter-select rounded-lg">
                    <option value="">Semua Status</option>
                    <option value="linked" <?php echo $filter_status === 'linked' ? 'selected' : ''; ?>>Sudah Memiliki Akun</option>
                    <option value="unlinked" <?php echo $filter_status === 'unlinked' ? 'selected' : ''; ?>>Belum Memiliki Akun</option>
                </select>
            </div>

            <div class="col-auto">
                <button type="submit" class="btn btn-indigo px-4 font-semibold text-xs py-2 rounded-lg">Filter</button>
            </div>
            
            <?php if ($search !== '' || $filter_tipe !== '' || $filter_status !== ''): ?>
                <div class="col-auto">
                    <a href="akun.php" class="btn btn-outline-secondary px-4 font-semibold text-xs py-2 rounded-lg" style="color: var(--text-secondary); border-color: var(--border-color);">Reset</a>
                </div>
            <?php endif; ?>
        </form>

        <!-- Personnel Table -->
        <div class="table-responsive">
            <table class="table table-custom w-full text-left">
                <thead>
                    <tr>
                        <th style="width: 5%;">NO</th>
                        <th style="width: 15%;">NIP / NIK</th>
                        <th style="width: 25%;">NAMA LENGKAP</th>
                        <th style="width: 12%;">TIPE</th>
                        <th style="width: 13%;">USERNAME</th>
                        <th style="width: 12%;">HAK AKSES</th>
                        <th style="width: 10%;">STATUS</th>
                        <th style="width: 8%; text-align: right;">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($filtered_personnel) > 0): ?>
                        <?php foreach ($filtered_personnel as $index => $p): ?>
                            <tr>
                                <td class="font-mono text-secondary text-xs"><?php echo $index + 1; ?></td>
                                <td class="font-mono text-xs"><?php echo htmlspecialchars($p['code']); ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($p['nama']); ?></strong>
                                    <?php if (!empty($p['jabatan'])): ?>
                                        <div class="text-secondary" style="font-size: 10px;"><?php echo htmlspecialchars($p['jabatan']); ?></div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($p['tipe'] === 'Guru'): ?>
                                        <span class="badge-tipe badge-tipe-guru">Guru</span>
                                    <?php else: ?>
                                        <span class="badge-tipe badge-tipe-karyawan">Karyawan</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($p['user_id'] !== null): ?>
                                        <code class="text-info"><?php echo htmlspecialchars($p['username']); ?></code>
                                    <?php else: ?>
                                        <span class="text-secondary small italic">Belum Ada</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($p['user_id'] !== null): ?>
                                        <span class="font-semibold text-xs text-gold"><?php echo htmlspecialchars($p['nama_role'] ?? '—'); ?></span>
                                    <?php else: ?>
                                        <span class="text-secondary small">—</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($p['user_id'] === null): ?>
                                        <span class="badge-status badge-status-belum">Belum Aktif</span>
                                    <?php elseif ($p['status_aktif'] === 'Aktif'): ?>
                                        <span class="badge-status badge-status-aktif">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge-status badge-status-tidak">Nonaktif</span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: right;">
                                    <?php if ($p['user_id'] === null): ?>
                                        <button type="button" 
                                                class="btn btn-gold btn-create-trigger px-2.5 py-1 text-3xs font-bold rounded-lg shadow-sm"
                                                data-personnel-id="<?php echo $p['personnel_id']; ?>"
                                                data-tipe="<?php echo $p['tipe']; ?>"
                                                data-code="<?php echo htmlspecialchars($p['code']); ?>"
                                                data-name="<?php echo htmlspecialchars($p['nama']); ?>"
                                                data-bs-toggle="modal" 
                                                data-bs-target="#createAccountModal">
                                            <i class="fa-solid fa-plus-circle me-1"></i> Buat Akun
                                        </button>
                                    <?php else: ?>
                                        <div class="d-flex justify-content-end gap-1.5">
                                            <button type="button" 
                                                    class="btn btn-outline-info btn-edit-trigger px-2 py-1 text-3xs font-bold rounded-lg shadow-sm"
                                                    data-user-id="<?php echo $p['user_id']; ?>"
                                                    data-name="<?php echo htmlspecialchars($p['nama']); ?>"
                                                    data-username="<?php echo htmlspecialchars($p['username']); ?>"
                                                    data-role-id="<?php echo $p['role_id']; ?>"
                                                    data-status="<?php echo $p['status_aktif']; ?>"
                                                    data-bs-toggle="modal" 
                                                    data-bs-target="#editAccountModal"
                                                    style="border-color: rgba(59, 130, 246, 0.4); color: #3b82f6;">
                                                <i class="fa-solid fa-user-pen"></i>
                                            </button>
                                            <button type="button" 
                                                    class="btn btn-outline-danger btn-delete-trigger px-2 py-1 text-3xs font-bold rounded-lg shadow-sm"
                                                    data-user-id="<?php echo $p['user_id']; ?>"
                                                    data-name="<?php echo htmlspecialchars($p['nama']); ?>"
                                                    style="border-color: rgba(239, 68, 68, 0.4); color: #ef4444;">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center text-secondary py-8">
                                <i class="fa-solid fa-folder-open d-block text-lg mb-2 text-indigo-600 opacity-60"></i>
                                Tidak ada data pegawai ditemukan.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- =====================================================
     MODAL CREATE ACCOUNT
     ===================================================== -->
<div class="modal fade" id="createAccountModal" tabindex="-1" aria-labelledby="createAccountModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <form method="POST" action="akun.php" class="modal-content modal-content-custom">
            <?php csrf_input(); ?>
            <input type="hidden" name="action" value="create">
            <input type="hidden" name="personnel_id" id="create_personnel_id">
            <input type="hidden" name="tipe" id="create_tipe">
            
            <div class="modal-header">
                <h6 class="modal-title font-bold text-gold" id="createAccountModalLabel"><i class="fa-solid fa-plus-circle me-1"></i> Buat Akun Akses NIP</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <div class="modal-body text-start">
                <div class="mb-3">
                    <label class="form-label text-secondary small">Nama Pegawai</label>
                    <input type="text" id="create_name" class="form-control" readonly disabled style="background-color: var(--bg-main) !important; border: 1px solid var(--border-color);">
                </div>

                <div class="mb-3">
                    <label for="create_username" class="form-label small">Username (NIP/NIK) <span class="text-danger">*</span></label>
                    <input type="text" name="username" id="create_username" class="form-control" required style="background-color: var(--bg-main) !important; border: 1px solid var(--border-color); color: var(--text-primary) !important;">
                </div>

                <div class="mb-3">
                    <label for="create_password" class="form-label small">Password <span class="text-danger">*</span></label>
                    <input type="password" name="password" id="create_password" class="form-control" required style="background-color: var(--bg-main) !important; border: 1px solid var(--border-color); color: var(--text-primary) !important;">
                </div>

                <div class="mb-3">
                    <label class="form-label small">Hak Akses (Role) <span class="text-danger">*</span></label>
                    <input type="hidden" name="role_id" id="create_role_id" required>
                    <div class="role-picker" id="create_role_picker">
                        <?php foreach ($roles as $role): ?>
                        <input type="radio" name="_role_create" id="create_role_<?php echo $role['id']; ?>" value="<?php echo $role['id']; ?>">
                        <label for="create_role_<?php echo $role['id']; ?>">
                            <?php
                            $icon = 'fa-user';
                            if ($role['nama_role'] === 'Guru') $icon = 'fa-chalkboard-user';
                            elseif ($role['nama_role'] === 'Admin') $icon = 'fa-user-shield';
                            elseif ($role['nama_role'] === 'Kepala Sekolah') $icon = 'fa-user-tie';
                            elseif ($role['nama_role'] === 'TU') $icon = 'fa-briefcase';
                            ?>
                            <i class="fa-solid <?php echo $icon; ?>"></i>
                            <?php echo htmlspecialchars($role['nama_role']); ?>
                        </label>
                        <?php endforeach; ?>
                    </div>
                    <div class="role-picker-required-msg" id="create_role_msg">Pilih salah satu hak akses.</div>
                </div>

                <div class="mb-3">
                    <label for="create_status_aktif" class="form-label small">Status Akun <span class="text-danger">*</span></label>
                    <select name="status_aktif" id="create_status_aktif" class="form-select" required style="background-color: var(--bg-main) !important; border: 1px solid var(--border-color); color: var(--text-primary) !important;">
                        <option value="Aktif">Aktif</option>
                        <option value="Tidak Aktif">Tidak Aktif (Nonaktif)</option>
                    </select>
                </div>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary text-xs px-3.5 py-2 rounded-lg" data-bs-dismiss="modal" style="border-color: var(--border-color);">Batal</button>
                <button type="submit" class="btn btn-gold text-xs px-3.5 py-2 rounded-lg">Buat Akun Pegawai <i class="fa-solid fa-save ms-1"></i></button>
            </div>
        </form>
    </div>
</div>

<!-- =====================================================
     MODAL EDIT ACCOUNT
     ===================================================== -->
<div class="modal fade" id="editAccountModal" tabindex="-1" aria-labelledby="editAccountModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <form method="POST" action="akun.php" class="modal-content modal-content-custom">
            <?php csrf_input(); ?>
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="user_id" id="edit_user_id">
            
            <div class="modal-header">
                <h6 class="modal-title font-bold text-gold" id="editAccountModalLabel"><i class="fa-solid fa-user-pen me-1"></i> Perbarui Pengaturan Akun</h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <div class="modal-body text-start">
                <div class="mb-3">
                    <label class="form-label text-secondary small">Nama Pegawai</label>
                    <input type="text" id="edit_name" class="form-control" readonly disabled style="background-color: var(--bg-main) !important; border: 1px solid var(--border-color);">
                </div>

                <div class="mb-3">
                    <label for="edit_username" class="form-label small">Username (NIP/NIK) <span class="text-danger">*</span></label>
                    <input type="text" name="username" id="edit_username" class="form-control" required style="background-color: var(--bg-main) !important; border: 1px solid var(--border-color); color: var(--text-primary) !important;">
                </div>

                <div class="mb-3">
                    <label for="edit_password" class="form-label small">Password Baru <span class="text-secondary">(Isi hanya jika ingin mereset password)</span></label>
                    <input type="password" name="password" id="edit_password" class="form-control" placeholder="Kosongkan jika tidak ada perubahan" style="background-color: var(--bg-main) !important; border: 1px solid var(--border-color); color: var(--text-primary) !important;">
                </div>

                <div class="mb-3">
                    <label class="form-label small">Hak Akses (Role) <span class="text-danger">*</span></label>
                    <input type="hidden" name="role_id" id="edit_role_id" required>
                    <div class="role-picker" id="edit_role_picker">
                        <?php foreach ($roles as $role): ?>
                        <input type="radio" name="_role_edit" id="edit_role_<?php echo $role['id']; ?>" value="<?php echo $role['id']; ?>">
                        <label for="edit_role_<?php echo $role['id']; ?>">
                            <?php
                            $icon = 'fa-user';
                            if ($role['nama_role'] === 'Guru') $icon = 'fa-chalkboard-user';
                            elseif ($role['nama_role'] === 'Admin') $icon = 'fa-user-shield';
                            elseif ($role['nama_role'] === 'Kepala Sekolah') $icon = 'fa-user-tie';
                            elseif ($role['nama_role'] === 'TU') $icon = 'fa-briefcase';
                            ?>
                            <i class="fa-solid <?php echo $icon; ?>"></i>
                            <?php echo htmlspecialchars($role['nama_role']); ?>
                        </label>
                        <?php endforeach; ?>
                    </div>
                    <div id="edit_role_superadmin_notice" class="mt-1" style="font-size: 11px; color: #f59e0b; display:none;">
                        <i class="fa-solid fa-triangle-exclamation me-1"></i> Akun ini memiliki role Super Admin. Pilih role baru di atas.
                    </div>
                    <div class="role-picker-required-msg" id="edit_role_msg">Pilih salah satu hak akses.</div>
                </div>

                <div class="mb-3">
                    <label for="edit_status_aktif" class="form-label small">Status Akun <span class="text-danger">*</span></label>
                    <select name="status_aktif" id="edit_status_aktif" class="form-select" required style="background-color: var(--bg-main) !important; border: 1px solid var(--border-color); color: var(--text-primary) !important;">
                        <option value="Aktif">Aktif</option>
                        <option value="Tidak Aktif">Tidak Aktif (Nonaktif)</option>
                    </select>
                </div>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary text-xs px-3.5 py-2 rounded-lg" data-bs-dismiss="modal" style="border-color: var(--border-color);">Batal</button>
                <button type="submit" class="btn btn-gold text-xs px-3.5 py-2 rounded-lg">Simpan Perubahan <i class="fa-solid fa-save ms-1"></i></button>
            </div>
        </form>
    </div>
</div>

<!-- =====================================================
     POST ACTION DELETE HELPER
     ===================================================== -->
<form id="deleteAccountForm" method="POST" action="akun.php" style="display:none;">
    <?php csrf_input(); ?>
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="user_id" id="delete_user_id">
</form>

<script>
document.addEventListener('DOMContentLoaded', function() {

    // ── Helper: wire role-picker radio buttons to a hidden input ──────────────
    function wireRolePicker(pickerEl, hiddenInputId) {
        if (!pickerEl) return;
        const hiddenInput = document.getElementById(hiddenInputId);
        pickerEl.querySelectorAll('input[type="radio"]').forEach(radio => {
            radio.addEventListener('change', function() {
                hiddenInput.value = this.value;
            });
        });
    }

    // ── Helper: pre-select a role in a picker by role ID ─────────────────────
    function setRolePicker(pickerEl, hiddenInputId, roleId) {
        if (!pickerEl) return;
        const hiddenInput = document.getElementById(hiddenInputId);
        // Uncheck all first
        pickerEl.querySelectorAll('input[type="radio"]').forEach(r => r.checked = false);
        hiddenInput.value = '';
        // Try to find the matching radio
        const target = pickerEl.querySelector('input[type="radio"][value="' + roleId + '"]');
        if (target) {
            target.checked = true;
            hiddenInput.value = roleId;
            return true;
        }
        return false; // role not found in picker (e.g., Super Admin excluded)
    }

    // ── Wire both pickers ────────────────────────────────────────────────────
    wireRolePicker(document.getElementById('create_role_picker'), 'create_role_id');
    wireRolePicker(document.getElementById('edit_role_picker'),   'edit_role_id');

    // ── Populate Create Modal ─────────────────────────────────────────────────
    const createTriggers = document.querySelectorAll('.btn-create-trigger');
    createTriggers.forEach(btn => {
        btn.addEventListener('click', function() {
            document.getElementById('create_personnel_id').value = this.getAttribute('data-personnel-id');
            document.getElementById('create_tipe').value          = this.getAttribute('data-tipe');
            document.getElementById('create_name').value          = this.getAttribute('data-name');
            document.getElementById('create_username').value      = this.getAttribute('data-code');
            document.getElementById('create_password').value      = '';
            document.getElementById('create_role_msg').style.display = 'none';

            const picker = document.getElementById('create_role_picker');
            if (this.getAttribute('data-tipe') === 'Guru') {
                // Auto-select Guru role (look for role with text "Guru")
                let selected = false;
                picker.querySelectorAll('input[type="radio"]').forEach(r => {
                    if (r.nextElementSibling && r.nextElementSibling.textContent.trim() === 'Guru') {
                        r.checked = true;
                        document.getElementById('create_role_id').value = r.value;
                        selected = true;
                    } else {
                        r.checked = false;
                    }
                });
            } else {
                // Reset picker for Karyawan — let admin choose
                picker.querySelectorAll('input[type="radio"]').forEach(r => r.checked = false);
                document.getElementById('create_role_id').value = '';
            }
        });
    });

    // ── Populate Edit Modal ───────────────────────────────────────────────────
    const editTriggers = document.querySelectorAll('.btn-edit-trigger');
    editTriggers.forEach(btn => {
        btn.addEventListener('click', function() {
            document.getElementById('edit_user_id').value    = this.getAttribute('data-user-id');
            document.getElementById('edit_name').value       = this.getAttribute('data-name');
            document.getElementById('edit_username').value   = this.getAttribute('data-username');
            document.getElementById('edit_password').value   = '';
            document.getElementById('edit_status_aktif').value = this.getAttribute('data-status');
            document.getElementById('edit_role_msg').style.display = 'none';

            const roleId = this.getAttribute('data-role-id');
            const notice = document.getElementById('edit_role_superadmin_notice');
            const picker = document.getElementById('edit_role_picker');

            const found = setRolePicker(picker, 'edit_role_id', roleId);
            if (!found) {
                // Role not in picker (Super Admin) — show warning
                notice.style.display = 'block';
            } else {
                notice.style.display = 'none';
            }
        });
    });

    // ── Form submit validation: ensure role is selected ───────────────────────
    document.querySelector('form.modal-content[action="akun.php"]:has(#create_role_id)')?.addEventListener('submit', function(e) {
        if (!document.getElementById('create_role_id').value) {
            e.preventDefault();
            document.getElementById('create_role_msg').style.display = 'block';
        }
    });

    // ── Confirm Delete Account ────────────────────────────────────────────────
    const deleteTriggers = document.querySelectorAll('.btn-delete-trigger');
    deleteTriggers.forEach(btn => {
        btn.addEventListener('click', function() {
            const userId = this.getAttribute('data-user-id');
            const name   = this.getAttribute('data-name');
            
            Swal.fire({
                title: 'Apakah Anda yakin?',
                text: "Menghapus akun login milik " + name + " tidak akan menghapus data induk pegawai, namun mereka tidak akan bisa login kembali.",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#64748b',
                confirmButtonText: 'Ya, Hapus Akun!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('delete_user_id').value = userId;
                    document.getElementById('deleteAccountForm').submit();
                }
            });
        });
    });
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
