<?php
// c:\xampp\htdocs\e-petraschool1\modules\kelas\detail.php

$page_title = 'Detail Kelas';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$class_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';

try {
    // Load class details
    $class_stmt = $pdo->prepare("SELECT k.*, g.nama_guru, g.nip FROM kelas k LEFT JOIN guru g ON k.wali_kelas_id = g.id WHERE k.id = ?");
    $class_stmt->execute([$class_id]);
    $class = $class_stmt->fetch();

    if (!$class) {
        die('<div class="alert alert-danger">Kelas tidak ditemukan!</div>');
    }

    // Check authorization: Wali Kelas can only see their own class, Admin/Kepsek/Super Admin can see all
    if (has_role('Guru')) {
        $my_guru_id = $_SESSION['guru_id'] ?? 0;
        if ($class['wali_kelas_id'] != $my_guru_id) {
            write_audit_log("Mencoba mengakses detail kelas orang lain (ID Kelas: $class_id).");
            echo "<div class='glass-card text-center py-5'>
                <i class='fa-solid fa-circle-exclamation text-danger mb-3' style='font-size: 48px;'></i>
                <h5 class='text-white fw-bold'>Akses Ditolak</h5>
                <p class='text-secondary small'>Anda hanya diizinkan melihat data kelas Anda sendiri.</p>
                <a href='index.php' class='btn btn-gold btn-sm mt-3'>Kembali</a>
            </div>";
            require_once dirname(dirname(__DIR__)) . '/includes/footer.php';
            exit;
        }
    }

    // Fetch all academic years for filter dropdown
    $years = $pdo->query("SELECT * FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();
    
    // Get currently active year as default
    $active_year = $pdo->query("SELECT id, tahun_ajaran FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1")->fetch();
    $filter_year_id = isset($_GET['tahun_ajaran_id']) ? intval($_GET['tahun_ajaran_id']) : ($active_year['id'] ?? 0);

    // ── PROCESS MAPEL GURU POST ACTIONS ──
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && has_role(['Super Admin', 'Admin'])) {
        check_csrf_request();
        
        $action = $_POST['action'];
        if ($action === 'add_mapel_guru') {
            $mapel_id = intval($_POST['mapel_id'] ?? 0);
            $guru_id = intval($_POST['guru_id'] ?? 0);
            
            if ($mapel_id > 0 && $guru_id > 0) {
                $stmt = $pdo->prepare("INSERT INTO kelas_mapel_guru (kelas_id, mapel_id, guru_id) VALUES (?, ?, ?) 
                                       ON DUPLICATE KEY UPDATE guru_id = VALUES(guru_id)");
                $stmt->execute([$class_id, $mapel_id, $guru_id]);
                
                $m_name = $pdo->query("SELECT nama_mapel FROM mata_pelajaran WHERE id = $mapel_id")->fetchColumn();
                $g_name = $pdo->query("SELECT nama_guru FROM guru WHERE id = $guru_id")->fetchColumn();
                write_audit_log("Menugaskan guru $g_name untuk mapel $m_name di kelas {$class['nama_kelas']}.");
                
                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Guru mata pelajaran berhasil ditugaskan!', 'success').then(() => {
                            window.location.href = 'detail.php?id=$class_id&tahun_ajaran_id=$filter_year_id';
                        });
                    });
                </script>";
                exit;
            } else {
                $error = 'Mata pelajaran dan guru wajib dipilih!';
            }
        }
    }

    // ── PROCESS MAPEL GURU DELETE ACTION ──
    if (isset($_GET['action']) && $_GET['action'] === 'delete_mapel_guru' && has_role(['Super Admin', 'Admin'])) {
        $mapping_id = intval($_GET['mapping_id'] ?? 0);
        if ($mapping_id > 0) {
            $info_stmt = $pdo->prepare("
                SELECT m.nama_mapel, g.nama_guru 
                FROM kelas_mapel_guru kmg
                JOIN mata_pelajaran m ON kmg.mapel_id = m.id
                JOIN guru g ON kmg.guru_id = g.id
                WHERE kmg.id = ? AND kmg.kelas_id = ?
            ");
            $info_stmt->execute([$mapping_id, $class_id]);
            $info = $info_stmt->fetch();
            
            if ($info) {
                $stmt = $pdo->prepare("DELETE FROM kelas_mapel_guru WHERE id = ? AND kelas_id = ?");
                $stmt->execute([$mapping_id, $class_id]);
                
                write_audit_log("Menghapus penugasan guru {$info['nama_guru']} untuk mapel {$info['nama_mapel']} di kelas {$class['nama_kelas']}.");
                
                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Penugasan guru mata pelajaran berhasil dihapus!', 'success').then(() => {
                            window.location.href = 'detail.php?id=$class_id&tahun_ajaran_id=$filter_year_id';
                        });
                    });
                </script>";
                exit;
            }
        }
    }

    // Load students in this class for the selected academic year
    $student_stmt = $pdo->prepare("
        SELECT s.*, r.tanggal_masuk, r.status as status_placement 
        FROM riwayat_kelas r
        JOIN siswa s ON r.siswa_id = s.id
        WHERE r.kelas_id = ? AND r.tahun_ajaran_id = ?
        ORDER BY s.nama_lengkap ASC
    ");
    $student_stmt->execute([$class_id, $filter_year_id]);
    $students = $student_stmt->fetchAll();

    // Fetch class-subject-teacher mappings
    $mapped_stmt = $pdo->prepare("
        SELECT kmg.*, m.nama_mapel, m.kode_mapel, g.nama_guru, g.nip 
        FROM kelas_mapel_guru kmg
        JOIN mata_pelajaran m ON kmg.mapel_id = m.id
        JOIN guru g ON kmg.guru_id = g.id
        WHERE kmg.kelas_id = ?
        ORDER BY m.nama_mapel ASC
    ");
    $mapped_stmt->execute([$class_id]);
    $mappings = $mapped_stmt->fetchAll();

    // Fetch all active subjects and teachers for modal assignment
    $all_subjects = $pdo->query("SELECT id, kode_mapel, nama_mapel FROM mata_pelajaran WHERE status = 'Aktif' ORDER BY nama_mapel ASC")->fetchAll();
    $all_teachers = $pdo->query("SELECT id, nama_guru, nip FROM guru ORDER BY nama_guru ASC")->fetchAll();

    // Log detail viewing
    write_audit_log("Melihat detail data kelas: {$class['nama_kelas']} (Tahun Ajaran ID: $filter_year_id).");

} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}
?>

<div class="glass-card mb-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-school me-2"></i> Kelas <?php echo htmlspecialchars($class['nama_kelas']); ?></h5>
            <p class="text-secondary small mb-0">Informasi detail mengenai rombel, wali kelas, kapasitas, dan histori penempatan siswa.</p>
        </div>
        <div class="d-flex gap-2 no-print">
            <a href="index.php" class="btn btn-outline-custom"><i class="fa-solid fa-arrow-left"></i> Kembali</a>
            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                <a href="../penempatan/index.php?kelas_id=<?php echo $class_id; ?>&tahun_ajaran_id=<?php echo $filter_year_id; ?>" class="btn btn-gold"><i class="fa-solid fa-user-tag"></i> Atur Penempatan</a>
            <?php endif; ?>
            <a href="../laporan/print.php?type=siswa&kelas_id=<?php echo $class_id; ?>&tahun_ajaran_id=<?php echo $filter_year_id; ?>" target="_blank" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-print"></i> Cetak Daftar</a>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Class Info Metadata Card -->
    <div class="col-lg-4">
        <div class="glass-card h-100">
            <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-circle-info me-2"></i> Identitas Rombel</h5>
            
            <table class="table table-sm text-secondary" style="font-size: 13px;">
                <tr>
                    <td class="fw-bold text-white" style="width: 40%;">Kode Rombel</td>
                    <td>: <span class="badge badge-secondary"><?php echo htmlspecialchars($class['kode_kelas']); ?></span></td>
                </tr>
                <tr>
                    <td class="fw-bold text-white">Nama Kelas</td>
                    <td>: <span class="text-white fw-bold"><?php echo htmlspecialchars($class['nama_kelas']); ?></span></td>
                </tr>
                <tr>
                    <td class="fw-bold text-white">Tingkat</td>
                    <td>: Kelas <?php echo htmlspecialchars($class['tingkat']); ?></td>
                </tr>
                <tr>
                    <td class="fw-bold text-white">Wali Kelas</td>
                    <td>: <?php echo $class['nama_guru'] ? htmlspecialchars($class['nama_guru']) . ' (NIP: ' . htmlspecialchars($class['nip']) . ')' : '<span class="text-danger">Belum Ditentukan</span>'; ?></td>
                </tr>
                <tr>
                    <td class="fw-bold text-white">Lokasi Ruangan</td>
                    <td>: <i class="fa-solid fa-location-dot text-gold me-1"></i> <?php echo htmlspecialchars($class['lokasi_ruangan']); ?></td>
                </tr>
                <tr>
                    <td class="fw-bold text-white">Kapasitas Maksimal</td>
                    <td>: <?php echo intval($class['kapasitas']); ?> Kursi</td>
                </tr>
                <tr>
                    <td class="fw-bold text-white">Jumlah Siswa Terdaftar</td>
                    <td>: <span class="text-white fw-bold"><?php echo count($students); ?> Siswa</span></td>
                </tr>
                <tr>
                    <td class="fw-bold text-white">Status Rombel</td>
                    <td>: 
                        <span class="badge <?php echo $class['status'] === 'Aktif' ? 'badge-success' : 'badge-danger'; ?>">
                            <?php echo htmlspecialchars($class['status']); ?>
                        </span>
                    </td>
                </tr>
            </table>
        </div>

        <!-- Subject Teacher Mapping Card -->
        <div class="glass-card mt-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="text-gold fw-bold mb-0"><i class="fa-solid fa-book-open me-2"></i> Guru Mapel</h5>
                <?php if (has_role(['Super Admin', 'Admin'])): ?>
                    <button class="btn btn-xs btn-gold" onclick="openAddMapelGuruModal()"><i class="fa-solid fa-plus-circle me-1"></i> Atur Guru</button>
                <?php endif; ?>
            </div>
            
            <div class="table-responsive">
                <table class="table table-sm text-secondary align-middle" style="font-size: 12.5px;">
                    <thead>
                        <tr class="text-white fw-bold">
                            <th>Mata Pelajaran</th>
                            <th>Guru Pengajar</th>
                            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                <th class="text-center no-print">Aksi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($mappings) > 0): ?>
                            <?php foreach ($mappings as $m): ?>
                                <tr>
                                    <td>
                                        <strong class="text-white"><?php echo htmlspecialchars($m['nama_mapel']); ?></strong>
                                        <span class="text-secondary d-block font-monospace" style="font-size: 10px;"><?php echo htmlspecialchars($m['kode_mapel']); ?></span>
                                    </td>
                                    <td>
                                        <span class="text-white d-block fw-semibold"><?php echo htmlspecialchars($m['nama_guru']); ?></span>
                                        <span class="text-secondary d-block font-monospace" style="font-size: 10px;">NIP: <?php echo htmlspecialchars($m['nip']); ?></span>
                                    </td>
                                    <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                        <td class="text-center no-print">
                                            <button onclick="confirmDeleteMapping(<?php echo $m['id']; ?>)" class="btn btn-link text-danger p-0" title="Hapus Penugasan">
                                                <i class="fa-solid fa-trash-can"></i>
                                            </button>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="<?php echo has_role(['Super Admin', 'Admin']) ? 3 : 2; ?>" class="text-center text-secondary py-3 small">
                                    <i class="fa-solid fa-info-circle me-1"></i> Belum ada guru mata pelajaran diatur.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Student List Section -->
    <div class="col-lg-8">
        <div class="glass-card h-100">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4 no-print">
                <h5 class="text-gold fw-bold mb-0"><i class="fa-solid fa-graduation-cap me-2"></i> Daftar Anggota Rombel</h5>
                
                <!-- Filter Year Form -->
                <form method="GET" action="detail.php" class="d-flex align-items-center gap-2">
                    <input type="hidden" name="id" value="<?php echo $class_id; ?>">
                    <select name="tahun_ajaran_id" class="form-select form-control-custom bg-dark-select text-white input-sm" onchange="this.form.submit()">
                        <?php foreach ($years as $yr): ?>
                            <option value="<?php echo $yr['id']; ?>" <?php echo $filter_year_id == $yr['id'] ? 'selected' : ''; ?>>
                                Tahun Ajaran <?php echo htmlspecialchars($yr['tahun_ajaran']); ?> <?php echo $yr['status'] === 'Aktif' ? '(Aktif)' : ''; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </form>
            </div>

            <div class="table-responsive">
                <table class="table table-custom">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>NIS / NISN</th>
                            <th>Nama Siswa</th>
                            <th>Gender</th>
                            <th>Tgl Masuk Rombel</th>
                            <th>Status Penempatan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($students) > 0): ?>
                            <?php $no = 1; foreach ($students as $std): ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td>
                                        <strong class="text-white font-monospace d-block"><?php echo htmlspecialchars($std['nis']); ?></strong>
                                        <span class="text-secondary small font-monospace"><?php echo htmlspecialchars($std['nisn']); ?></span>
                                    </td>
                                    <td class="fw-semibold text-white">
                                        <a href="../siswa/history.php?id=<?php echo $std['id']; ?>" class="text-white link-gold-hover" style="text-decoration:none;">
                                            <?php echo htmlspecialchars($std['nama_lengkap']); ?>
                                        </a>
                                    </td>
                                    <td><?php echo $std['gender'] === 'L' ? 'Laki-laki' : 'Perempuan'; ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($std['tanggal_masuk'])); ?></td>
                                    <td>
                                        <?php
                                            $badge_class = 'badge-secondary';
                                            if ($std['status_placement'] === 'Aktif') $badge_class = 'badge-success';
                                            elseif ($std['status_placement'] === 'Pindahan') $badge_class = 'badge-warning';
                                            elseif ($std['status_placement'] === 'Lulus') $badge_class = 'badge-info';
                                            elseif ($std['status_placement'] === 'Keluar') $badge_class = 'badge-danger';
                                        ?>
                                        <span class="badge <?php echo $badge_class; ?>"><?php echo htmlspecialchars($std['status_placement']); ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-secondary py-4">Tidak ada data siswa terdaftar pada tahun ajaran ini.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Assign Mapel Guru -->
<?php if (has_role(['Super Admin', 'Admin'])): ?>
<div class="modal fade" id="addMapelGuruModal" tabindex="-1" aria-labelledby="addMapelGuruModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content bg-dark-select text-white border-gold-subtle" style="background-color: #0f172a; border: 1px solid rgba(212, 175, 55, 0.2);">
            <div class="modal-header border-bottom-gold" style="border-bottom: 1px solid rgba(212, 175, 55, 0.2);">
                <h5 class="modal-title text-gold" id="addMapelGuruModalLabel"><i class="fa-solid fa-book-open-reader me-2"></i> Atur Guru Mata Pelajaran</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="detail.php?id=<?php echo $class_id; ?>&tahun_ajaran_id=<?php echo $filter_year_id; ?>">
                <?php csrf_input(); ?>
                <input type="hidden" name="action" value="add_mapel_guru">
                
                <div class="modal-body">
                    <p class="small text-secondary mb-3">Pilih mata pelajaran dan tentukan guru pengajar untuk kelas <strong><?php echo htmlspecialchars($class['nama_kelas']); ?></strong>.</p>
                    
                    <div class="mb-3">
                        <label for="mapel_id" class="form-label form-label-custom">Mata Pelajaran <span class="text-danger">*</span></label>
                        <select name="mapel_id" id="mapel_id" class="form-select form-control-custom bg-dark-select text-white" required>
                            <option value="">Pilih Mata Pelajaran...</option>
                            <?php foreach ($all_subjects as $sub): ?>
                                <option value="<?php echo $sub['id']; ?>"><?php echo htmlspecialchars($sub['nama_mapel']) . ' (' . htmlspecialchars($sub['kode_mapel']) . ')'; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="guru_id" class="form-label form-label-custom">Guru Pengajar <span class="text-danger">*</span></label>
                        <select name="guru_id" id="guru_id" class="form-select form-control-custom bg-dark-select text-white" required>
                            <option value="">Pilih Guru Pengajar...</option>
                            <?php foreach ($all_teachers as $tc): ?>
                                <option value="<?php echo $tc['id']; ?>"><?php echo htmlspecialchars($tc['nama_guru']) . ' (' . htmlspecialchars($tc['nip']) . ')'; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-top-gold" style="border-top: 1px solid rgba(212, 175, 55, 0.2);">
                    <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-gold">Simpan Penugasan <i class="fa-solid fa-check ms-1"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openAddMapelGuruModal() {
    var modalEl = document.getElementById('addMapelGuruModal');
    var existingModal = bootstrap.Modal.getInstance(modalEl);
    if (existingModal) {
        existingModal.dispose();
    }
    var myModal = new bootstrap.Modal(modalEl);
    myModal.show();
}

function confirmDeleteMapping(mappingId) {
    Swal.fire({
        title: 'Apakah Anda yakin?',
        text: "Penugasan guru mata pelajaran ini akan dihapus!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#3b82f6',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'detail.php?id=<?php echo $class_id; ?>&tahun_ajaran_id=<?php echo $filter_year_id; ?>&action=delete_mapel_guru&mapping_id=' + mappingId;
        }
    });
}
</script>
<?php endif; ?>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
