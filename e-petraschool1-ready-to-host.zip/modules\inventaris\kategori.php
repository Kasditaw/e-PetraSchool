<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris\kategori.php

$page_title = 'Kategori Inventaris';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_inventaris_access();

$error = '';
$success = '';

// Handle CRUD operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_role(['Super Admin', 'Admin']);
    check_csrf_request();
    
    $action = $_POST['action'] ?? '';
    
    // Add Category
    if ($action === 'add') {
        $nama_kategori = trim($_POST['nama_kategori'] ?? '');
        $kode_kategori = strtoupper(trim($_POST['kode_kategori'] ?? ''));
        $deskripsi = trim($_POST['deskripsi'] ?? '');
        
        if (empty($nama_kategori) || empty($kode_kategori)) {
            $error = 'Nama Kategori dan Kode Kategori wajib diisi!';
        } else {
            try {
                // Check duplicate kode
                $chk = $pdo->prepare("SELECT COUNT(*) FROM kategori_barang WHERE kode_kategori = ? OR nama_kategori = ?");
                $chk->execute([$kode_kategori, $nama_kategori]);
                if ($chk->fetchColumn() > 0) {
                    $error = 'Nama Kategori atau Kode Kategori sudah terdaftar!';
                } else {
                    $stmt = $pdo->prepare("INSERT INTO kategori_barang (nama_kategori, kode_kategori, deskripsi) VALUES (?, ?, ?)");
                    $stmt->execute([$nama_kategori, $kode_kategori, $deskripsi]);
                    
                    write_audit_log("Menambahkan kategori inventaris baru: $nama_kategori ($kode_kategori).");
                    
                    $success = 'Kategori berhasil ditambahkan!';
                }
            } catch (Exception $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
    
    // Edit Category
    if ($action === 'edit') {
        $id = intval($_POST['id'] ?? 0);
        $nama_kategori = trim($_POST['nama_kategori'] ?? '');
        $kode_kategori = strtoupper(trim($_POST['kode_kategori'] ?? ''));
        $deskripsi = trim($_POST['deskripsi'] ?? '');
        
        if ($id <= 0 || empty($nama_kategori) || empty($kode_kategori)) {
            $error = 'ID, Nama Kategori, dan Kode Kategori wajib diisi!';
        } else {
            try {
                // Check duplicate kode
                $chk = $pdo->prepare("SELECT COUNT(*) FROM kategori_barang WHERE (kode_kategori = ? OR nama_kategori = ?) AND id != ?");
                $chk->execute([$kode_kategori, $nama_kategori, $id]);
                if ($chk->fetchColumn() > 0) {
                    $error = 'Nama Kategori atau Kode Kategori sudah digunakan pada kategori lain!';
                } else {
                    $stmt = $pdo->prepare("UPDATE kategori_barang SET nama_kategori = ?, kode_kategori = ?, deskripsi = ? WHERE id = ?");
                    $stmt->execute([$nama_kategori, $kode_kategori, $deskripsi, $id]);
                    
                    write_audit_log("Mengubah kategori inventaris ID $id menjadi: $nama_kategori ($kode_kategori).");
                    
                    $success = 'Kategori berhasil diperbarui!';
                }
            } catch (Exception $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

// Handle Delete Category via GET (consistent with other delete screens)
if (isset($_GET['delete_id'])) {
    require_role(['Super Admin', 'Admin']);
    $delete_id = intval($_GET['delete_id']);
    try {
        // Check if category is used by assets
        $chk = $pdo->prepare("SELECT COUNT(*) FROM inventaris WHERE kategori_id = ? AND status_aktif = 'Aktif'");
        $chk->execute([$delete_id]);
        if ($chk->fetchColumn() > 0) {
            $error = 'Kategori tidak dapat dihapus karena masih digunakan oleh data aset inventaris!';
        } else {
            // Fetch name for audit log
            $name_stmt = $pdo->prepare("SELECT nama_kategori FROM kategori_barang WHERE id = ?");
            $name_stmt->execute([$delete_id]);
            $name = $name_stmt->fetchColumn();

            $stmt = $pdo->prepare("DELETE FROM kategori_barang WHERE id = ?");
            $stmt->execute([$delete_id]);
            
            write_audit_log("Menghapus kategori inventaris: $name (ID: $delete_id).");
            
            $success = 'Kategori berhasil dihapus!';
        }
    } catch (Exception $e) {
        $error = 'Gagal menghapus kategori: ' . $e->getMessage();
    }
}

// Load all categories with asset counts
try {
    $categories = $pdo->query("
        SELECT k.*, COALESCE(SUM(i.jumlah), 0) as total_aset 
        FROM kategori_barang k 
        LEFT JOIN inventaris i ON k.id = i.kategori_id AND i.status_aktif = 'Aktif'
        GROUP BY k.id 
        ORDER BY k.nama_kategori ASC
    ")->fetchAll();
} catch (Exception $e) {
    $error = 'Gagal memuat kategori: ' . $e->getMessage();
    $categories = [];
}
?>

<div class="glass-card mb-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-tags me-2"></i> Kategori Inventaris</h5>
            <p class="text-secondary small mb-0">Kelola kategori pengelompokkan barang inventaris dan sarana prasarana sekolah.</p>
        </div>
        <div>
            <?php if (has_role(['Super Admin', 'Admin'])): ?>
            <button class="btn btn-gold" data-bs-toggle="modal" data-bs-target="#addCategoryModal"><i class="fa-solid fa-plus me-1"></i> Tambah Kategori</button>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
    </div>
<?php endif; ?>

<?php if ($success !== ''): ?>
    <div class="alert alert-success border-0 text-white bg-success bg-opacity-25 small mb-4 py-2" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i> <?php echo htmlspecialchars($success); ?>
    </div>
<?php endif; ?>

<!-- Categories Table -->
<div class="glass-card">
    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th style="width: 80px;">No</th>
                    <th style="width: 120px;">Kode Kategori</th>
                    <th>Nama Kategori</th>
                    <th>Deskripsi</th>
                    <th style="text-align: center; width: 140px;">Jumlah Aset</th>
                    <?php if (has_role(['Super Admin', 'Admin'])): ?>
                    <th style="text-align: right; width: 180px;" class="no-print">Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (count($categories) > 0): ?>
                    <?php $no = 1; foreach ($categories as $cat): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><span class="badge badge-secondary font-monospace"><?php echo htmlspecialchars($cat['kode_kategori'] ?: '-'); ?></span></td>
                            <td><strong class="text-white"><?php echo htmlspecialchars($cat['nama_kategori']); ?></strong></td>
                            <td><span class="text-secondary small"><?php echo htmlspecialchars($cat['deskripsi'] ?: '-'); ?></span></td>
                            <td style="text-align: center;"><span class="badge bg-dark border text-white"><?php echo intval($cat['total_aset']); ?> unit</span></td>
                            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                            <td style="text-align: right;" class="no-print">
                                <div class="d-flex gap-2 justify-content-end">
                                    <button class="btn btn-xs btn-outline-warning" 
                                             onclick="openEditModal(<?php echo $cat['id']; ?>, '<?php echo htmlspecialchars($cat['nama_kategori'], ENT_QUOTES); ?>', '<?php echo htmlspecialchars($cat['kode_kategori'] ?? '', ENT_QUOTES); ?>', '<?php echo htmlspecialchars($cat['deskripsi'] ?? '', ENT_QUOTES); ?>')">
                                        <i class="fa-solid fa-pen"></i> Edit
                                    </button>
                                    <button class="btn btn-xs btn-outline-danger" 
                                             onclick="confirmDeleteCategory(<?php echo $cat['id']; ?>, '<?php echo htmlspecialchars($cat['nama_kategori'], ENT_QUOTES); ?>')">
                                        <i class="fa-solid fa-trash"></i> Hapus
                                    </button>
                                </div>
                            </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center text-secondary py-4">Kategori inventaris kosong.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Tambah Kategori -->
<div class="modal fade" id="addCategoryModal" tabindex="-1" aria-labelledby="addCategoryModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark-select text-white border-gold-subtle" style="background-color: #0f172a; border: 1px solid rgba(212, 175, 55, 0.2); border-radius: 12px;">
            <div class="modal-header border-bottom-gold" style="border-bottom: 1px solid rgba(212, 175, 55, 0.2);">
                <h5 class="modal-title text-gold" id="addCategoryModalLabel"><i class="fa-solid fa-plus-circle me-2"></i> Tambah Kategori Aset</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="kategori.php">
                <?php csrf_input(); ?>
                <input type="hidden" name="action" value="add">
                
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="add_kode_kategori" class="form-label form-label-custom">Kode Kategori <span class="text-danger">*</span></label>
                        <input type="text" name="kode_kategori" id="add_kode_kategori" class="form-control form-control-custom" placeholder="Contoh: ELK, FUR, BUK" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="add_nama_kategori" class="form-label form-label-custom">Nama Kategori <span class="text-danger">*</span></label>
                        <input type="text" name="nama_kategori" id="add_nama_kategori" class="form-control form-control-custom" placeholder="Nama Kategori Baru" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="add_deskripsi" class="form-label form-label-custom">Deskripsi / Keterangan</label>
                        <textarea name="deskripsi" id="add_deskripsi" class="form-control form-control-custom" rows="3" placeholder="Penjelasan mengenai barang yang termasuk kategori ini"></textarea>
                    </div>
                </div>
                <div class="modal-footer border-top-gold" style="border-top: 1px solid rgba(212, 175, 55, 0.2);">
                    <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-gold">Simpan Kategori <i class="fa-solid fa-check ms-1"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit Kategori -->
<div class="modal fade" id="editCategoryModal" tabindex="-1" aria-labelledby="editCategoryModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark-select text-white border-gold-subtle" style="background-color: #0f172a; border: 1px solid rgba(212, 175, 55, 0.2); border-radius: 12px;">
            <div class="modal-header border-bottom-gold" style="border-bottom: 1px solid rgba(212, 175, 55, 0.2);">
                <h5 class="modal-title text-gold" id="editCategoryModalLabel"><i class="fa-solid fa-pen-to-square me-2"></i> Edit Kategori Aset</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="kategori.php">
                <?php csrf_input(); ?>
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="edit_id">
                
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="edit_kode_kategori" class="form-label form-label-custom">Kode Kategori <span class="text-danger">*</span></label>
                        <input type="text" name="kode_kategori" id="edit_kode_kategori" class="form-control form-control-custom" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_nama_kategori" class="form-label form-label-custom">Nama Kategori <span class="text-danger">*</span></label>
                        <input type="text" name="nama_kategori" id="edit_nama_kategori" class="form-control form-control-custom" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_deskripsi" class="form-label form-label-custom">Deskripsi / Keterangan</label>
                        <textarea name="deskripsi" id="edit_deskripsi" class="form-control form-control-custom" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer border-top-gold" style="border-top: 1px solid rgba(212, 175, 55, 0.2);">
                    <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-gold">Simpan Perubahan <i class="fa-solid fa-check ms-1"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openEditModal(id, nama, kode, deskripsi) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_nama_kategori').value = nama;
    document.getElementById('edit_kode_kategori').value = kode;
    document.getElementById('edit_deskripsi').value = deskripsi;
    
    const editModal = new bootstrap.Modal(document.getElementById('editCategoryModal'));
    editModal.show();
}

function confirmDeleteCategory(id, name) {
    Swal.fire({
        title: 'Hapus Kategori?',
        text: `Apakah Anda yakin ingin menghapus kategori "${name}"? Tindakan ini tidak dapat dibatalkan.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = `kategori.php?delete_id=${id}`;
        }
    });
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
