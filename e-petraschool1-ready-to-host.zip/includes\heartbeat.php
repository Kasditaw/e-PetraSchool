<?php
// c:\xampp\htdocs\e-petraschool1\includes\heartbeat.php
// AJAX endpoint — keep session alive

require_once dirname(__DIR__) . '/config/auth.php';

header('Content-Type: application/json');

if (is_logged_in()) {
    echo json_encode(['status' => 'success', 'message' => 'Session extended successfully.']);
} else {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized. Session has expired.']);
}
exit;
