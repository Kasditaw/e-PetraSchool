<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\inventaris\print_qr.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_inventaris_access();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

try {
    $stmt = $pdo->prepare("SELECT i.*, k.nama_kategori, r.nama_ruangan FROM inventaris i JOIN kategori_barang k ON i.kategori_id = k.id LEFT JOIN ruangan r ON i.ruangan_id = r.id WHERE i.id = ? LIMIT 1");
    $stmt->execute([$id]);
    $asset = $stmt->fetch();

    if (!$asset) {
        die('Data aset tidak ditemukan!');
    }

    // Log label printing
    write_audit_log("Mencetak label QR Code Aset: " . $asset['nama_barang'] . " (Kode: " . $asset['kode_barang'] . ").");

} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

// Compute base_url
$project_dir = str_replace('\\', '/', dirname(dirname(__DIR__)));
$web_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
$base_url = str_replace($web_root, '', $project_dir);
if (empty($base_url)) {
    $base_url = '/';
} else {
    if (substr($base_url, 0, 1) !== '/') {
        $base_url = '/' . $base_url;
    }
    if (substr($base_url, -1) !== '/') {
        $base_url .= '/';
    }
}
$base_url = str_replace('//', '/', $base_url);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Label Aset - <?php echo htmlspecialchars($asset['kode_barang']); ?></title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&display=swap" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <!-- Custom CSS -->
    <style>
        * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
        body {
            background-color: #f8fafc !important;
            color: #0f172a !important;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
            padding: 0;
            font-family: 'Outfit', sans-serif;
        }
        .barcode-card-print {
            width: 320px;
            background: #ffffff;
            border: 2px dashed #475569;
            color: #0f172a;
            padding: 20px;
            font-family: 'Outfit', sans-serif;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
            border-radius: 12px;
        }
        .print-btn-bar {
            position: fixed;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
            z-index: 1000;
        }
        .btn-print-action {
            background: #D4AF37;
            color: #000;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-family: 'Outfit', sans-serif;
            box-shadow: 0 4px 12px rgba(212, 175, 55, 0.3);
            transition: all 0.2s ease;
        }
        .btn-print-action:hover {
            background: #f3cd48;
            transform: translateY(-1px);
        }
        .btn-print-back {
            background: #ffffff;
            color: #334155;
            border: 1px solid #e2e8f0;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-family: 'Outfit', sans-serif;
            transition: all 0.2s ease;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        }
        .btn-print-back:hover {
            background: #f8fafc;
            border-color: #cbd5e1;
            transform: translateY(-1px);
        }
        @media print {
            body {
                background: #ffffff !important;
            }
            .print-btn-bar {
                display: none !important;
            }
            .barcode-card-print {
                box-shadow: none !important;
                position: fixed !important;
                left: 50% !important;
                top: 50% !important;
                transform: translate(-50%, -50%) scale(1.5) !important;
                border: 2px dashed #000 !important;
            }
        }
    </style>
</head>
<body>

    <div class="print-btn-bar no-print">
        <a href="index.php" class="btn-print-back"><i class="fa-solid fa-chevron-left"></i> Kembali</a>
        <button onclick="window.print()" class="btn-print-action"><i class="fa-solid fa-print"></i> Cetak Label</button>
    </div>

    <!-- Label Card Structure -->
    <div id="barcode-card-layout" class="barcode-card-print rounded-3">
        <div class="text-center border-bottom border-dark pb-1 mb-2">
            <span class="fw-bold d-block" style="font-size: 11px; color: #000; letter-spacing: 0.5px;">PROPERTI SD KRISTEN PETRA 1</span>
            <span class="font-monospace text-uppercase" style="font-size: 8px; color: #555; letter-spacing: 0.5px;">LABEL INVENTARIS ASET</span>
        </div>
        <div class="d-flex align-items-center gap-3">
            <!-- QR Canvas container -->
            <div style="background: #fff; padding: 2px; border: 1px solid #ddd;">
                <canvas id="qrCanvas"></canvas>
            </div>
            
            <div class="text-start flex-grow-1" style="font-size: 11px; color: #000; line-height: 1.35;">
                <div class="mb-0.5"><strong class="text-uppercase" style="font-size: 12px; color: #000;"><?php echo htmlspecialchars($asset['nama_barang']); ?></strong></div>
                <div class="mb-1"><span class="font-monospace text-danger fw-bold" style="font-size: 10px;"><?php echo htmlspecialchars($asset['kode_barang']); ?></span></div>
                <div class="mb-0.5" style="font-size: 9px;"><span class="text-secondary">Kondisi: </span><span class="badge bg-dark text-white font-monospace" style="font-size: 8px; padding: 2px 6px;"><?php echo htmlspecialchars($asset['kondisi']); ?></span></div>
                <div style="font-size: 9px;"><span class="text-secondary">Lokasi: </span><span class="fw-semibold"><?php echo htmlspecialchars($asset['nama_ruangan'] ?? 'Belum Alokasi'); ?></span></div>
            </div>
        </div>
    </div>

    <!-- QRious QR Code CDN -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            new QRious({
                element: document.getElementById('qrCanvas'),
                value: '<?php echo htmlspecialchars($asset['kode_barang']); ?>',
                size: 65,
                background: '#ffffff',
                foreground: '#000000',
                level: 'H'
            });

            // Auto print on load
            <?php if (!isset($_GET['preview'])): ?>
                setTimeout(() => {
                    window.print();
                }, 500);
            <?php endif; ?>
        });
    </script>
</body>
</html>
