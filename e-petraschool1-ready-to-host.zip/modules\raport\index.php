<?php
// c:\xampp\htdocs\e-petraschool1\modules\raport\index.php

$page_title = 'Raport Siswa';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin', 'Kepala Sekolah', 'Guru']);

// Dapatkan semester dan tahun ajaran aktif dari sistem
try {
    $active_sem_stmt = $pdo->query("SELECT semester FROM semester WHERE status = 'Aktif' LIMIT 1");
    $active_sem_db = $active_sem_stmt->fetchColumn();
    $active_sem = ($active_sem_db === 'Ganjil' || $active_sem_db === '1') ? '1' : '2';

    $active_ta_stmt = $pdo->query("SELECT tahun_ajaran FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1");
    $active_ta = $active_ta_stmt->fetchColumn() ?: '2025/2026';
} catch (Exception $e) {
    $active_sem = '1';
    $active_ta = '2025/2026';
}

$selected_sem = isset($_GET['semester']) ? $_GET['semester'] : $active_sem;
$selected_ta = $active_ta;

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$filter_kelas = isset($_GET['kelas_id']) ? $_GET['kelas_id'] : '';

try {
    // Ambil daftar kelas untuk dropdown filter
    $classes_stmt = $pdo->query("SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas ASC");
    $classes = $classes_stmt->fetchAll();

    // Query daftar siswa beserta status rapor
    $query = "SELECT s.id, s.nis, s.nisn, s.nama_lengkap, k.nama_kelas, k.id as kelas_id,
                     r.id as raport_id, r.status_draft 
              FROM siswa s 
              LEFT JOIN kelas k ON s.kelas_id = k.id 
              LEFT JOIN raport_siswa r ON s.id = r.siswa_id AND r.semester = :sem AND r.tahun_ajaran = :ta
              WHERE s.status_siswa = 'Aktif'";
              
    $params = [
        'sem' => $selected_sem,
        'ta' => $selected_ta
    ];

    if ($search !== '') {
        $query .= " AND (s.nama_lengkap LIKE :search OR s.nis LIKE :search OR s.nisn LIKE :search)";
        $params['search'] = "%$search%";
    }

    if ($filter_kelas !== '') {
        $query .= " AND s.kelas_id = :kelas_id";
        $params['kelas_id'] = intval($filter_kelas);
    }

    $query .= " ORDER BY k.nama_kelas ASC, s.nama_lengkap ASC";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $siswa_list = $stmt->fetchAll();

} catch (Exception $e) {
    echo '<div class="alert alert-danger">Gagal memuat data rapor: ' . $e->getMessage() . '</div>';
    $siswa_list = [];
}
?>

<!-- Custom CSS for modern list style -->
<style>
    .raport-list-card {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 1rem;
        padding: 1.5rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.02);
    }
    .badge-status {
        font-size: 10px;
        font-weight: 700;
        padding: 4px 10px;
        border-radius: 12px;
        text-transform: uppercase;
        display: inline-block;
    }
    .badge-status-completed {
        background: rgba(16, 185, 129, 0.08);
        border: 1px solid #10b981;
        color: #10b981;
    }
    .badge-status-draft {
        background: rgba(245, 158, 11, 0.08);
        border: 1px solid #f59e0b;
        color: #d97706;
    }
    .badge-status-empty {
        background: rgba(100, 116, 139, 0.08);
        border: 1px solid #64748b;
        color: #64748b;
    }
    .search-input-container-light {
        position: relative;
    }
    .search-input-container-light i {
        position: absolute;
        left: 10px;
        top: 10px;
        color: #94a3b8;
    }
    .search-input-container-light input {
        padding-left: 32px;
        background-color: #ffffff !important;
        border: 1px solid #cbd5e1 !important;
        color: #0f172a !important;
    }
    .table-custom-light thead th {
        background-color: #f8fafc;
        color: #475569;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 10px;
        letter-spacing: 0.05em;
        padding: 12px 10px;
        border-bottom: 2px solid #e2e8f0;
    }
    .table-custom-light tbody td {
        padding: 12px 10px;
        border-bottom: 1px solid #f1f5f9;
        vertical-align: middle;
        color: #334155;
    }
    .table-custom-light tbody tr:hover td {
        background-color: #f8fafc;
    }
</style>

<div class="container-fluid px-4 py-2">
    
    <!-- Redesigned Premium Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-4">
        <div class="d-flex align-items-center gap-3">
            <div class="w-10 h-10 bg-indigo-600 rounded-lg d-flex align-items-center justify-center shadow-md shadow-indigo-600/20" style="width: 40px; height: 40px;">
                <i class="fa-solid fa-file-invoice text-white text-xl"></i>
            </div>
            <div>
                <h5 class="text-slate-800 font-bold text-lg mb-0 font-sans tracking-wide">Pengisian Rapor Siswa</h5>
                <p class="text-slate-500 text-xs mb-0">Kelola & input nilai capaian kurikulum merdeka, ekskul, absensi per siswa</p>
            </div>
        </div>
        <div class="d-flex align-items-center gap-2 flex-wrap">
            <a href="import.php?semester=<?php echo htmlspecialchars($selected_sem); ?>" class="btn btn-indigo d-inline-flex align-items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg shadow-sm">
                <i class="fa-solid fa-cloud-arrow-up"></i> Upload Nilai Rapor
            </a>
            
            <?php if (!empty($filter_kelas)): ?>
                <a href="import.php?action=download_template&kelas_id=<?php echo htmlspecialchars($filter_kelas); ?>&semester=<?php echo htmlspecialchars($selected_sem); ?>" class="btn btn-success d-inline-flex align-items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg shadow-sm">
                    <i class="fa-solid fa-file-excel"></i> Download Template Excel
                </a>
                <a href="rekap.php?kelas_id=<?php echo htmlspecialchars($filter_kelas); ?>&semester=<?php echo htmlspecialchars($selected_sem); ?>" class="btn btn-warning text-white d-inline-flex align-items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg shadow-sm">
                    <i class="fa-solid fa-eye"></i> Lihat Rekap Nilai
                </a>
                <a href="rekap.php?kelas_id=<?php echo htmlspecialchars($filter_kelas); ?>&semester=<?php echo htmlspecialchars($selected_sem); ?>&export=excel" class="btn btn-primary d-inline-flex align-items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg shadow-sm">
                    <i class="fa-solid fa-download"></i> Download Rekap Excel
                </a>
            <?php else: ?>
                <button type="button" onclick="Swal.fire({ icon: 'warning', title: 'Pilih Kelas', text: 'Silakan pilih Filter Kelas terlebih dahulu untuk mengunduh template!', confirmButtonColor: '#3b82f6' })" class="btn btn-success d-inline-flex align-items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg shadow-sm">
                    <i class="fa-solid fa-file-excel"></i> Download Template Excel
                </button>
                <button type="button" onclick="Swal.fire({ icon: 'warning', title: 'Pilih Kelas', text: 'Silakan pilih Filter Kelas terlebih dahulu untuk melihat rekap nilai!', confirmButtonColor: '#3b82f6' })" class="btn btn-warning text-white d-inline-flex align-items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg shadow-sm">
                    <i class="fa-solid fa-eye"></i> Lihat Rekap Nilai
                </button>
                <button type="button" onclick="Swal.fire({ icon: 'warning', title: 'Pilih Kelas', text: 'Silakan pilih Filter Kelas terlebih dahulu untuk mendownload rekap nilai!', confirmButtonColor: '#3b82f6' })" class="btn btn-primary d-inline-flex align-items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg shadow-sm">
                    <i class="fa-solid fa-download"></i> Download Rekap Excel
                </button>
            <?php endif; ?>

            <span class="d-inline-flex align-items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-600 border border-indigo-200" style="font-size: 11px;">
                <i class="fa-solid fa-calendar-day"></i> Periode Aktif: Semester <?php echo $active_sem; ?> (<?php echo htmlspecialchars($active_ta); ?>)
            </span>
        </div>
    </div>

    <!-- Main Card Content -->
    <div class="raport-list-card">
        
        <!-- Filter & Search Form -->
        <form method="GET" action="index.php" class="row g-3 mb-4 align-items-end">
            <div class="col-12 col-md-3">
                <label class="form-label text-slate-600 text-2xs font-semibold uppercase tracking-wider block mb-1">Pencarian</label>
                <div class="search-input-container-light">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <input type="text" name="search" class="form-control rounded-lg" placeholder="Cari nama siswa, NIS..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
            </div>
            
            <div class="col-12 col-sm-6 col-md-3">
                <label class="form-label text-slate-600 text-2xs font-semibold uppercase tracking-wider block mb-1">Filter Kelas</label>
                <select name="kelas_id" class="form-select border-slate-300 text-slate-800">
                    <option value="">Semua Kelas</option>
                    <?php foreach ($classes as $cl): ?>
                        <option value="<?php echo $cl['id']; ?>" <?php echo $filter_kelas == $cl['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($cl['nama_kelas']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-12 col-sm-6 col-md-3">
                <label class="form-label text-slate-600 text-2xs font-semibold uppercase tracking-wider block mb-1">Pilih Semester</label>
                <select name="semester" class="form-select border-slate-300 text-slate-800">
                    <option value="1" <?php echo $selected_sem === '1' ? 'selected' : ''; ?>>Semester 1</option>
                    <option value="2" <?php echo $selected_sem === '2' ? 'selected' : ''; ?>>Semester 2</option>
                </select>
            </div>

            <div class="col-auto">
                <button type="submit" class="btn btn-indigo px-4 font-semibold text-xs py-2 rounded-lg">Filter</button>
            </div>
            
            <?php if ($search !== '' || $filter_kelas !== '' || isset($_GET['semester'])): ?>
                <div class="col-auto">
                    <a href="index.php" class="btn btn-outline-secondary px-4 font-semibold text-xs py-2 rounded-lg">Reset</a>
                </div>
            <?php endif; ?>
        </form>

        <!-- Students Table -->
        <div class="table-responsive">
            <table class="table table-custom-light w-full text-left" id="raport-students-table">
                <thead>
                    <tr>
                        <th style="width: 5%;">NO</th>
                        <th style="width: 15%;">NIS / NISN</th>
                        <th style="width: 30%;">NAMA LENGKAP</th>
                        <th style="width: 15%;">KELAS</th>
                        <th style="width: 15%; text-align: center;">STATUS RAPOR</th>
                        <th style="width: 20%; text-align: right;" class="no-print">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($siswa_list) > 0): ?>
                        <?php foreach ($siswa_list as $index => $siswa): ?>
                            <tr>
                                <td class="font-mono text-slate-400 text-xs"><?php echo $index + 1; ?></td>
                                <td class="font-mono text-xs text-slate-500">
                                    NIS: <?php echo htmlspecialchars($siswa['nis']); ?><br>
                                    NISN: <?php echo htmlspecialchars($siswa['nisn']); ?>
                                </td>
                                <td>
                                    <strong class="text-slate-800"><?php echo htmlspecialchars($siswa['nama_lengkap']); ?></strong>
                                </td>
                                <td>
                                    <span class="text-slate-700 font-semibold"><?php echo htmlspecialchars($siswa['nama_kelas'] ?? 'Belum Diatur'); ?></span>
                                </td>
                                <td style="text-align: center;">
                                    <?php if ($siswa['raport_id'] === null): ?>
                                        <span class="badge-status badge-status-empty">Belum Diisi</span>
                                    <?php elseif ($siswa['status_draft'] == 1): ?>
                                        <span class="badge-status badge-status-draft">Draft</span>
                                    <?php else: ?>
                                        <span class="badge-status badge-status-completed">Selesai</span>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: right;" class="no-print">
                                    <a href="input.php?siswa_id=<?php echo $siswa['id']; ?>&semester=<?php echo $selected_sem; ?>" class="btn btn-indigo px-3 py-1.5 font-bold text-3xs rounded-lg shadow-sm">
                                        <i class="fa-solid fa-pen-to-square me-1"></i> Input Rapor
                                    </a>
                                    <?php if ($siswa['raport_id'] !== null): ?>
                                        <a href="print.php?siswa_id=<?php echo $siswa['id']; ?>&semester=<?php echo $selected_sem; ?>" target="_blank" class="btn btn-success px-3 py-1.5 font-bold text-3xs rounded-lg shadow-sm ms-1">
                                            <i class="fa-solid fa-print me-1"></i> Cetak Rapor
                                        </a>
                                        <a href="print_osl.php?siswa_id=<?php echo $siswa['id']; ?>&semester=<?php echo $selected_sem; ?>" target="_blank" class="btn btn-primary px-3 py-1.5 font-bold text-3xs rounded-lg shadow-sm ms-1">
                                            <i class="fa-solid fa-star me-1"></i> Cetak Rapor OSL
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center text-slate-500 py-8">
                                <i class="fa-solid fa-folder-open d-block text-lg mb-2 text-indigo-600 opacity-60"></i>
                                Tidak ada data siswa aktif ditemukan.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
