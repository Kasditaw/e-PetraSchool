<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\config\captcha.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Generate a new math captcha and save in session
 * @return string The captcha question string
 */
function generate_captcha() {
    $num1 = rand(1, 10);
    $num2 = rand(1, 9);
    $operators = ['+', '-'];
    $operator = $operators[rand(0, 1)];

    if ($operator === '+') {
        $answer = $num1 + $num2;
    } else {
        // Ensure no negative answers for simplicity
        if ($num1 < $num2) {
            $temp = $num1;
            $num1 = $num2;
            $num2 = $temp;
        }
        $answer = $num1 - $num2;
    }

    $_SESSION['captcha_answer'] = $answer;
    $_SESSION['captcha_question'] = "$num1 $operator $num2";

    return $_SESSION['captcha_question'];
}

/**
 * Get current captcha question
 */
function get_captcha_question() {
    if (empty($_SESSION['captcha_question'])) {
        return generate_captcha();
    }
    return $_SESSION['captcha_question'];
}

/**
 * Validate captcha answer
 */
function validate_captcha($user_answer) {
    if (!isset($_SESSION['captcha_answer'])) {
        return false;
    }
    return intval($user_answer) === intval($_SESSION['captcha_answer']);
}
?>
