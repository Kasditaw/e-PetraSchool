<?php
// c:\xampp\htdocs\e-petraschool1\modules\penempatan\kenaikan.php

$page_title = 'Kenaikan Kelas Massal';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';
$success = '';

try {
    // Fetch all academic years
    $years = $pdo->query("SELECT * FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();
    
    // Default active year
    $active_year = $pdo->query("SELECT id, status FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1")->fetch();
    $active_year_id = $active_year['id'] ?? 0;
    
    // Fetch all classes
    $classes = $pdo->query("SELECT id, nama_kelas FROM kelas WHERE status = 'Aktif' ORDER BY nama_kelas ASC")->fetchAll();

    // Filters / Inputs
    $origin_year_id = isset($_GET['origin_year_id']) ? intval($_GET['origin_year_id']) : ($years[1]['id'] ?? 0);
    $origin_class_id = isset($_GET['origin_class_id']) ? intval($_GET['origin_class_id']) : ($classes[0]['id'] ?? 0);
    
    $dest_year_id = isset($_GET['dest_year_id']) ? intval($_GET['dest_year_id']) : $active_year_id;
    $dest_class_id = isset($_GET['dest_class_id']) ? intval($_GET['dest_class_id']) : ($classes[1]['id'] ?? 0);

    // Handle Promotion processing
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'promote_students') {
        check_csrf_request();
        
        $post_origin_class = intval($_POST['origin_class_id'] ?? 0);
        $post_origin_year = intval($_POST['origin_year_id'] ?? 0);
        $post_dest_class = intval($_POST['dest_class_id'] ?? 0);
        $post_dest_year = intval($_POST['dest_year_id'] ?? 0);
        $selected_siswa = $_POST['siswa_ids'] ?? [];

        if ($post_origin_class > 0 && $post_origin_year > 0 && $post_dest_class > 0 && $post_dest_year > 0 && !empty($selected_siswa)) {
            if ($post_origin_year === $post_dest_year) {
                $error = 'Tahun ajaran asal dan tujuan tidak boleh sama!';
            } else {
                $pdo->beginTransaction();
                
                $promote_stmt = $pdo->prepare("
                    INSERT INTO riwayat_kelas (siswa_id, kelas_id, tahun_ajaran_id, tanggal_masuk, status) 
                    VALUES (?, ?, ?, ?, 'Aktif')
                    ON DUPLICATE KEY UPDATE kelas_id = VALUES(kelas_id), tanggal_masuk = VALUES(tanggal_masuk)
                ");
                $sync_stmt = $pdo->prepare("UPDATE siswa SET kelas_id = ? WHERE id = ?");
                
                $today = date('Y-m-d');
                $count = 0;
                
                foreach ($selected_siswa as $siswa_id) {
                    $promote_stmt->execute([intval($siswa_id), $post_dest_class, $post_dest_year, $today]);
                    $count++;
                    
                    // If destination year is the currently active one, sync the siswa table current kelas_id
                    if ($post_dest_year === $active_year_id) {
                        $sync_stmt->execute([$post_dest_class, intval($siswa_id)]);
                    }
                }
                
                $pdo->commit();
                
                // Get class names for logs
                $o_class_name = $pdo->query("SELECT nama_kelas FROM kelas WHERE id = $post_origin_class")->fetchColumn();
                $d_class_name = $pdo->query("SELECT nama_kelas FROM kelas WHERE id = $post_dest_class")->fetchColumn();
                write_audit_log("Memproses kenaikan kelas massal untuk $count siswa dari $o_class_name ke $d_class_name.");

                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', '$count siswa berhasil dipromosikan ke kelas baru!', 'success').then(() => {
                            window.location.href = 'kenaikan.php?origin_class_id=$post_origin_class&origin_year_id=$post_origin_year&dest_class_id=$post_dest_class&dest_year_id=$post_dest_year';
                        });
                    });
                </script>";
                exit;
            }
        } else {
            $error = 'Harap pilih asal, tujuan kelas, dan minimal satu siswa!';
        }
    }

    // Load source students
    $students = [];
    if ($origin_class_id > 0 && $origin_year_id > 0) {
        $student_stmt = $pdo->prepare("
            SELECT s.id, s.nis, s.nisn, s.nama_lengkap, s.gender 
            FROM riwayat_kelas r
            JOIN siswa s ON r.siswa_id = s.id
            WHERE r.kelas_id = ? AND r.tahun_ajaran_id = ? AND s.status_siswa = 'Aktif'
            ORDER BY s.nama_lengkap ASC
        ");
        $student_stmt->execute([$origin_class_id, $origin_year_id]);
        $students = $student_stmt->fetchAll();
    }

} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}
?>

<div class="glass-card mb-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-angles-up me-2"></i> Kenaikan Kelas Massal</h5>
            <p class="text-secondary small mb-0">Promosikan rombongan belajar siswa secara massal dari tahun ajaran asal ke tahun ajaran tujuan.</p>
        </div>
        <div class="d-flex gap-2">
            <a href="index.php" class="btn btn-outline-custom"><i class="fa-solid fa-arrow-left"></i> Penempatan Kelas</a>
        </div>
    </div>
</div>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
    </div>
<?php endif; ?>

<form method="POST" action="kenaikan.php">
    <?php csrf_input(); ?>
    <input type="hidden" name="action" value="promote_students">
    
    <div class="row g-4 mb-4">
        <!-- Source Configuration (Left) -->
        <div class="col-md-6">
            <div class="glass-card h-100" style="background: rgba(18, 28, 54, 0.2);">
                <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-arrow-right-from-bracket me-1"></i> Rombel Asal</h6>
                
                <div class="mb-3">
                    <label class="form-label form-label-custom">Tahun Ajaran Asal</label>
                    <select name="origin_year_id" id="origin_year_id" class="form-select form-control-custom bg-dark-select text-white" onchange="updateFilters()">
                        <?php foreach ($years as $yr): ?>
                            <option value="<?php echo $yr['id']; ?>" <?php echo $origin_year_id == $yr['id'] ? 'selected' : ''; ?>>
                                Tahun Ajaran <?php echo htmlspecialchars($yr['tahun_ajaran']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-0">
                    <label class="form-label form-label-custom">Kelas Asal</label>
                    <select name="origin_class_id" id="origin_class_id" class="form-select form-control-custom bg-dark-select text-white" onchange="updateFilters()">
                        <?php foreach ($classes as $cl): ?>
                            <option value="<?php echo $cl['id']; ?>" <?php echo $origin_class_id == $cl['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cl['nama_kelas']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </div>

        <!-- Destination Configuration (Right) -->
        <div class="col-md-6">
            <div class="glass-card h-100" style="background: rgba(18, 28, 54, 0.2);">
                <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-arrow-right-to-bracket me-1"></i> Rombel Tujuan</h6>
                
                <div class="mb-3">
                    <label class="form-label form-label-custom">Tahun Ajaran Tujuan</label>
                    <select name="dest_year_id" class="form-select form-control-custom bg-dark-select text-white">
                        <?php foreach ($years as $yr): ?>
                            <option value="<?php echo $yr['id']; ?>" <?php echo $dest_year_id == $yr['id'] ? 'selected' : ''; ?>>
                                Tahun Ajaran <?php echo htmlspecialchars($yr['tahun_ajaran']); ?> <?php echo $yr['status'] === 'Aktif' ? '(Aktif)' : ''; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-0">
                    <label class="form-label form-label-custom">Kelas Tujuan</label>
                    <select name="dest_class_id" class="form-select form-control-custom bg-dark-select text-white">
                        <?php foreach ($classes as $cl): ?>
                            <option value="<?php echo $cl['id']; ?>" <?php echo $dest_class_id == $cl['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cl['nama_kelas']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <!-- Student Selection List -->
    <div class="glass-card mb-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="text-gold fw-bold mb-0"><i class="fa-solid fa-list me-2"></i> Pilih Siswa untuk Kenaikan Kelas (Total: <?php echo count($students); ?>)</h6>
            <div class="no-print">
                <input type="checkbox" id="select-all" class="form-check-input me-1"> <label for="select-all" class="small text-secondary cursor-pointer">Pilih Semua</label>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-custom">
                <thead>
                    <tr>
                        <th style="width: 50px;">Pilih</th>
                        <th>NIS / NISN</th>
                        <th>Nama Siswa</th>
                        <th>L/P</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($students) > 0): ?>
                        <?php foreach ($students as $std): ?>
                            <tr>
                                <td>
                                    <input type="checkbox" name="siswa_ids[]" value="<?php echo $std['id']; ?>" class="form-check-input siswa-chk" checked>
                                </td>
                                <td>
                                    <strong class="text-white font-monospace"><?php echo htmlspecialchars($std['nis']); ?></strong>
                                    <span class="text-secondary small font-monospace d-block"><?php echo htmlspecialchars($std['nisn']); ?></span>
                                </td>
                                <td class="fw-semibold text-white"><?php echo htmlspecialchars($std['nama_lengkap']); ?></td>
                                <td><?php echo htmlspecialchars($std['gender']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="4" class="text-center text-secondary py-4">Tidak ada data siswa terdaftar di rombel kelas asal pada tahun ajaran tersebut.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if (count($students) > 0): ?>
            <div class="mt-4 text-end">
                <button type="submit" class="btn btn-gold w-100 py-2 fw-bold" onclick="return confirm('Apakah Anda yakin ingin memproses kenaikan kelas untuk siswa yang dipilih?')">
                    Proses Kenaikan Kelas <i class="fa-solid fa-circle-chevron-right ms-1"></i>
                </button>
            </div>
        <?php endif; ?>
    </div>
</form>

<script>
function updateFilters() {
    const originYear = document.getElementById('origin_year_id').value;
    const originClass = document.getElementById('origin_class_id').value;
    window.location.href = `kenaikan.php?origin_year_id=${originYear}&origin_class_id=${originClass}`;
}

document.getElementById('select-all')?.addEventListener('change', function(e) {
    const chks = document.querySelectorAll('.siswa-chk');
    chks.forEach(chk => {
        chk.checked = e.target.checked;
    });
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
