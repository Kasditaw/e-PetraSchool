<?php
// c:\xampp\htdocs\e-petraschool1\modules\raport\print_osl.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_role(['Super Admin', 'Admin', 'Kepala Sekolah', 'Guru']);

$siswa_id = isset($_GET['siswa_id']) ? intval($_GET['siswa_id']) : 0;

// Get semester and academic year
try {
    $active_sem_stmt = $pdo->query("SELECT semester FROM semester WHERE status = 'Aktif' LIMIT 1");
    $active_sem_db = $active_sem_stmt->fetchColumn();
    $active_sem = ($active_sem_db === 'Ganjil' || $active_sem_db === '1') ? '1' : '2';

    $active_ta_stmt = $pdo->query("SELECT tahun_ajaran FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1");
    $active_ta = $active_ta_stmt->fetchColumn() ?: '2025/2026';
} catch (Exception $e) {
    $active_sem = '1';
    $active_ta = '2025/2026';
}

$selected_sem = isset($_GET['semester']) ? $_GET['semester'] : $active_sem;
$selected_ta = isset($_GET['tahun_ajaran']) ? $_GET['tahun_ajaran'] : $active_ta;

try {
    // Fetch student details with kelas
    $siswa_stmt = $pdo->prepare("SELECT s.*, k.nama_kelas, k.tingkat, k.wali_kelas_id, g.nama_guru as nama_wali 
                                 FROM siswa s 
                                 LEFT JOIN kelas k ON s.kelas_id = k.id 
                                 LEFT JOIN guru g ON k.wali_kelas_id = g.id 
                                 WHERE s.id = ? LIMIT 1");
    $siswa_stmt->execute([$siswa_id]);
    $siswa = $siswa_stmt->fetch();
    
    if (!$siswa) {
        die("Siswa tidak ditemukan.");
    }
    
    // Fetch existing report card data
    $raport_stmt = $pdo->prepare("SELECT * FROM raport_siswa WHERE siswa_id = ? AND semester = ? AND tahun_ajaran = ? LIMIT 1");
    $raport_stmt->execute([$siswa_id, $selected_sem, $selected_ta]);
    $raport = $raport_stmt->fetch();
    
    if (!$raport) {
        die("Data rapor untuk siswa ini di semester terpilih belum diisi.");
    }

    // Fetch principal details
    $kepsek_stmt = $pdo->query("SELECT nama_guru FROM guru WHERE jabatan = 'Kepala Sekolah' LIMIT 1");
    $nama_kepsek = $kepsek_stmt->fetchColumn() ?: 'Lilia, S.Pd., M.Psi.';
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

$saved_slo = json_decode($raport['slo'] ?? '[]', true) ?: [];

// Load logo base64
$logo_file = dirname(dirname(__DIR__)) . '/assets/images/logo.png';
if (file_exists($logo_file)) {
    $logo_data = base64_encode(file_get_contents($logo_file));
    $logo_src  = 'data:image/png;base64,' . $logo_data;
} else {
    $logo_src  = 'https://img.icons8.com/color/96/school.png';
}

$tut_wuri_file = dirname(dirname(__DIR__)) . '/assets/images/tut_wuri.png';
if (file_exists($tut_wuri_file)) {
    $tut_wuri_data = base64_encode(file_get_contents($tut_wuri_file));
    $tut_wuri_src  = 'data:image/png;base64,' . $tut_wuri_data;
} else {
    $tut_wuri_src  = 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Logo-Tut-Wuri-Handayani-PNG-Warna.png/120px-Logo-Tut-Wuri-Handayani-PNG-Warna.png';
}

$romanize = function($nama) {
    $nama_roman = preg_replace_callback('/(\d+)/', function($matches) {
        $map = [1 => 'I', 2 => 'II', 3 => 'III', 4 => 'IV', 5 => 'V', 6 => 'VI'];
        return $map[$matches[1]] ?? $matches[1];
    }, $nama);
    return preg_replace('/([I|V|X]+)([A-HJ-UW-Z])/', '$1 $2', $nama_roman);
};

// Helper conversion: "Kelas I A" -> "1-A"
$class_arabic = '';
if (!empty($siswa['nama_kelas'])) {
    $class_name = $siswa['nama_kelas'];
    $class_name = str_ireplace('Kelas ', '', $class_name);
    $roman_to_arabic = [
        'VIII' => '8', 'VII' => '7', 'III' => '3', 'II' => '2', 'VI' => '6', 'IV' => '4', 'V' => '5', 'I' => '1', 'IX' => '9', 'X' => '10'
    ];
    foreach ($roman_to_arabic as $roman => $arab) {
        $class_name = preg_replace('/\b' . $roman . '\b/', $arab, $class_name);
    }
    $class_name = preg_replace('/(\d+)\s*([A-Za-z])/', '$1-$2', $class_name);
    $class_arabic = $class_name;
} else {
    $class_arabic = '-';
}

// Calculate Indonesian date
$indo_months = [
    'January' => 'Januari',
    'February' => 'Februari',
    'March' => 'Maret',
    'April' => 'April',
    'May' => 'Mei',
    'June' => 'Juni',
    'July' => 'Juli',
    'August' => 'Agustus',
    'September' => 'September',
    'October' => 'Oktober',
    'November' => 'November',
    'December' => 'Desember'
];
$date_en = date('d F Y');
$date_id = strtr($date_en, $indo_months);

$slo_aspects = [
    'spiritual' => 'Relationship with God',
    'physical' => 'Physical Growth',
    'emotional' => 'Emotional Intelligence',
    'talent' => 'Talent Development',
    'academic' => 'Academic Excellence'
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rapor OSL (SLO) <?php echo htmlspecialchars($siswa['nama_lengkap']); ?> - Semester <?php echo $selected_sem; ?></title>
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        * {
            box-sizing: border-box;
        }
        body {
            background-color: #9e9e9e;
            background-image: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI1IiBoZWlnaHQ9IjUiPgo8cmVjdCB3aWR0aD0iNSIgaGVpZ2h0PSI1IiBmaWxsPSIjOWU5ZTllIj48L3JlY3Q+CjxwYXRoIGQ9Ik0wIDVMNSAwWk02IDRMNCA2Wk0tMSAxTDEgLTFaIiBzdHJva2U9IiM4ODgiIHN0cm9rZS13aWR0aD0iMSI+PC9wYXRoPgo8L3N2Zz4=");
            color: #000000;
            font-family: 'Times New Roman', Times, serif;
            margin: 0;
            padding: 20px;
        }
        .print-container {
            width: 215mm;
            height: 330mm;
            min-height: 330mm;
            padding: 15mm 20mm;
            margin: 13px auto;
            background: #ffffff;
            box-shadow: 1px 1px 3px 1px #333;
            border-radius: 0;
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .outer-border {
            border: 4px double #1e3a8a;
            padding: 8mm;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        /* Kop Surat */
        .report-kop-surat {
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 3px double #000;
            padding-bottom: 12px;
            margin-bottom: 15px;
        }
        .kop-logo-left, .kop-logo-right {
            width: 65px;
            height: 65px;
            flex: 0 0 65px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .kop-logo-left img, .kop-logo-right img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }
        .kop-title {
            text-align: center;
            flex: 1 1 auto;
            min-width: 0;
            padding: 0 15px;
        }
        .kop-title h4 {
            font-size: 15px;
            font-weight: 800;
            margin: 2px 0;
            text-transform: uppercase;
            color: #000;
        }
        .kop-title p {
            font-size: 10px;
            margin: 0;
            color: #000;
        }
        .report-title {
            text-align: center;
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 15px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #000;
            line-height: 1.3;
        }
        .report-table-print {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
            font-size: 10pt;
        }
        .report-table-print th, .report-table-print td {
            border: 1px solid #000;
            padding: 6px 8px;
            text-align: left;
            color: #000;
            vertical-align: middle;
        }
        .report-table-print th {
            background-color: #f1f5f9 !important;
            font-weight: bold;
            color: #000;
            text-transform: uppercase;
            font-size: 9pt;
            text-align: center;
        }
        .btn-print-panel {
            position: fixed;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
            z-index: 1000;
        }
        .btn-action-print {
            background: #6366f1;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-family: Arial, sans-serif;
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
        }
        .btn-action-print:hover {
            background: #4f46e5;
            transform: translateY(-1px);
        }
        .btn-action-back {
            background: #ffffff;
            color: #334155;
            border: 1px solid #e2e8f0;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-family: Arial, sans-serif;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        }
        .btn-action-back:hover {
            background: #f8fafc;
            border-color: #cbd5e1;
            transform: translateY(-1px);
        }
        .legend-table {
            border-collapse: collapse;
            font-size: 8pt;
            margin-top: 5px;
        }
        .legend-table td {
            border: 1px solid #94a3b8;
            padding: 3px 8px;
            color: #475569;
        }
        @media print {
            @page {
                size: 215mm 330mm;
                margin: 0;
            }
            html {
                margin: 0;
            }
            body {
                background-color: transparent !important;
                padding: 0 !important;
                margin: 0 !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }
            .print-container {
                width: 215mm !important;
                height: 330mm !important;
                min-height: 330mm !important;
                border: none !important;
                box-shadow: none !important;
                padding: 15mm 20mm !important;
                margin: 0 !important;
                background-color: #ffffff !important;
                page-break-after: always;
                page-break-inside: avoid;
            }
            .btn-print-panel {
                display: none !important;
            }
        }
    </style>
</head>
<body>

    <div class="btn-print-panel no-print">
        <a href="index.php?semester=<?php echo $selected_sem; ?>" class="btn-action-back"><i class="fa-solid fa-chevron-left"></i> Kembali</a>
        <button onclick="window.print()" class="btn-action-print"><i class="fa-solid fa-print"></i> Cetak PDF</button>
    </div>

    <div class="print-container">
        <div class="outer-border">
            <div>
                <!-- Kop Surat -->
                <div class="report-kop-surat">
                    <div class="kop-logo-left">
                        <img src="<?php echo $tut_wuri_src; ?>" alt="Logo Kemdikbud">
                    </div>
                    <div class="kop-title">
                        <div style="font-size: 11px; font-weight: bold; margin: 0; text-transform: uppercase; color: #000;">Kementerian Pendidikan Dasar dan Menengah</div>
                        <div style="font-size: 11px; font-weight: bold; margin: 1px 0; text-transform: uppercase; color: #000;">Dinas Pendidikan Kota Surabaya</div>
                        <h4>SD KRISTEN PETRA 1 SURABAYA</h4>
                        <p>Jalan WR. Supratman 46, Surabaya 60264 | Email: sd1@pppkpetra.sch.id</p>
                    </div>
                    <div class="kop-logo-right">
                        <img src="<?php echo $logo_src; ?>" alt="Logo Petra">
                    </div>
                </div>

                <div class="report-title">
                    LAPORAN STUDENT LEARNING OUTCOMES (SLO)<br>
                    SD KRISTEN PETRA 1 SURABAYA
                </div>

                <!-- Student Info -->
                <div style="margin-bottom: 15px;">
                    <table style="width: 100%; font-size: 10pt; border-collapse: collapse; font-family: 'Times New Roman', Times, serif;">
                        <tr>
                            <td style="width: 15%; font-weight: bold; padding: 3px 0;">Nama Siswa</td>
                            <td style="width: 2%; padding: 3px 0;">:</td>
                            <td style="width: 43%; padding: 3px 0; font-weight: bold; text-transform: uppercase;"><?php echo htmlspecialchars($siswa['nama_lengkap']); ?></td>
                            <td style="width: 15%; font-weight: bold; padding: 3px 0;">Kelas</td>
                            <td style="width: 2%; padding: 3px 0;">:</td>
                            <td style="width: 23%; padding: 3px 0;"><?php echo htmlspecialchars($siswa['nama_kelas'] ? $romanize($siswa['nama_kelas']) : '-'); ?></td>
                        </tr>
                        <tr>
                            <td style="font-weight: bold; padding: 3px 0;">NIS / NISN</td>
                            <td>:</td>
                            <td><?php echo htmlspecialchars($siswa['nis'] . ' / ' . $siswa['nisn']); ?></td>
                            <td style="font-weight: bold; padding: 3px 0;">Semester</td>
                            <td>:</td>
                            <td><?php echo htmlspecialchars($selected_sem); ?></td>
                        </tr>
                        <tr>
                            <td style="font-weight: bold; padding: 3px 0;">No. Absen</td>
                            <td>:</td>
                            <td><?php echo htmlspecialchars($raport['no_absen'] ?: '-'); ?></td>
                            <td style="font-weight: bold; padding: 3px 0;">Tahun Ajaran</td>
                            <td>:</td>
                            <td><?php echo htmlspecialchars($selected_ta); ?></td>
                        </tr>
                    </table>
                </div>

                <!-- SLO Table -->
                <table class="report-table-print">
                    <thead>
                        <tr>
                            <th style="width: 5%; text-align: center;">No</th>
                            <th style="width: 30%; text-align: left;">Aspek Pengembangan (P.E.T.R.A.)</th>
                            <th style="width: 12%; text-align: center;">Predikat</th>
                            <th style="width: 53%; text-align: left;">Deskripsi Capaian</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no_slo = 1;
                        foreach ($slo_aspects as $key => $label) {
                            $aspect_data = $saved_slo[$key] ?? ['predikat' => '—', 'deskripsi' => ''];
                            $predikat = ($aspect_data['predikat'] !== '') ? htmlspecialchars($aspect_data['predikat']) : '—';
                            $deskripsi = ($aspect_data['deskripsi'] !== '') ? htmlspecialchars($aspect_data['deskripsi']) : '—';
                            
                            echo "<tr>
                                <td style='text-align: center;'>$no_slo</td>
                                <td><strong>$label</strong></td>
                                <td style='font-size: 11pt; text-align: center;'><strong>$predikat</strong></td>
                                <td style='line-height: 1.35; text-align: justify;'>$deskripsi</td>
                            </tr>";
                            $no_slo++;
                        }
                        ?>
                    </tbody>
                </table>

                <!-- Predikat Legend -->
                <div style="margin-top: 5px;">
                    <div style="font-size: 8pt; font-weight: bold; color: #475569; margin-bottom: 2px;">Keterangan Kualifikasi Predikat:</div>
                    <table class="legend-table">
                        <tr>
                            <td><strong>A</strong> (Sangat Baik / Excellent)</td>
                            <td><strong>B</strong> (Baik / Good)</td>
                            <td><strong>C</strong> (Cukup / Satisfactory)</td>
                            <td><strong>D</strong> (Perlu Bimbingan / Needs Improvement)</td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- Signatures -->
            <div>
                <table style="width: 100%; font-size: 10pt; text-align: center; border-collapse: collapse; border: none; margin-top: 15px;">
                    <tr style="border: none;">
                        <td style="width: 33%; border: none; padding: 5px 0; vertical-align: top;">
                            Orang tua/Wali Peserta Didik<br><br><br><br><br>
                            ( ___________________ )
                        </td>
                        <td style="width: 33%; border: none; padding: 5px 0; vertical-align: top;">
                            Mengetahui<br>
                            Kepala Sekolah<br><br><br><br><br>
                            <strong><u><?php echo htmlspecialchars($nama_kepsek); ?></u></strong>
                        </td>
                        <td style="width: 34%; border: none; padding: 5px 0; vertical-align: top;">
                            Surabaya, <?php echo $date_id; ?><br>
                            Guru Kelas <?php echo htmlspecialchars($class_arabic); ?><br><br><br><br><br>
                            <strong><u><?php echo htmlspecialchars($siswa['nama_wali'] ?: '___________________'); ?></u></strong>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

</body>
</html>
