<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\audit_log\index.php

$page_title = 'Audit Log Aktivitas';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

// Restrict access: only Super Admin and Kepala Sekolah
require_role(['Super Admin', 'Kepala Sekolah']);

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

try {
    $query = "SELECT * FROM audit_log WHERE 1=1";
    $count_query = "SELECT COUNT(*) FROM audit_log WHERE 1=1";
    $params = [];

    if ($search !== '') {
        $filter_sql = " AND (username LIKE :search OR aktivitas LIKE :search OR ip_address LIKE :search)";
        $query .= $filter_sql;
        $count_query .= $filter_sql;
        $params['search'] = "%$search%";
    }

    // Count query
    $stmt_count = $pdo->prepare($count_query);
    $stmt_count->execute($params);
    $total_items = intval($stmt_count->fetchColumn());

    // Pagination variables
    $limit = 10;
    $total_pages = max(1, ceil($total_items / $limit));
    $page = isset($_GET['page']) ? max(1, min($total_pages, intval($_GET['page']))) : 1;
    $offset = ($page - 1) * $limit;

    $query .= " ORDER BY tanggal DESC, id DESC LIMIT $limit OFFSET $offset";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $logs = $stmt->fetchAll();

} catch (Exception $e) {
    error_log("Database error in audit log index: " . $e->getMessage());
    echo '<div class="alert alert-danger">Gagal memuat log audit. Silakan hubungi administrator.</div>';
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-clipboard-list me-2"></i> Log Audit Keamanan & Aktivitas Sistem</h5>
            <p class="text-secondary small mb-0">Catatan riwayat operasi masuk log (login), manipulasi data (insert/update/delete), dan pencetakan dokumen.</p>
        </div>
        
        <div class="d-flex gap-2">
            <a href="../laporan/export.php?type=audit_log" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-excel me-1"></i> Ekspor Excel</a>
            <a href="../laporan/print.php?type=audit_log" target="_blank" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-pdf me-1"></i> Cetak PDF</a>
        </div>
    </div>

    <!-- Search Form -->
    <form method="GET" action="index.php" class="row g-2 mb-4 no-print">
        <div class="col-12 col-md-4">
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari user, aktivitas, IP..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">Cari</button>
        </div>
        <?php if ($search !== ''): ?>
            <div class="col-auto">
                <a href="index.php" class="btn btn-outline-danger">Reset</a>
            </div>
        <?php endif; ?>
    </form>

    <!-- Desktop View: Table -->
    <div class="table-responsive d-none d-md-block">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th style="width: 5%;">No</th>
                    <th style="width: 15%;">Waktu Kejadian</th>
                    <th style="width: 15%;">Pengguna (Username)</th>
                    <th>Aktivitas Tindakan</th>
                    <th style="width: 15%;">IP Address</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($logs) > 0): ?>
                    <?php $no = $offset + 1; foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><span class="text-secondary small font-monospace"><?php echo date('d M Y H:i:s', strtotime($log['tanggal'])); ?></span></td>
                            <td>
                                <strong class="text-white"><i class="fa-solid fa-circle-user me-1 text-gold"></i> <?php echo htmlspecialchars($log['username']); ?></strong>
                            </td>
                            <td class="text-white"><?php echo htmlspecialchars($log['aktivitas']); ?></td>
                            <td><span class="badge badge-secondary font-monospace"><?php echo htmlspecialchars($log['ip_address']); ?></span></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center text-secondary py-4">Belum ada catatan aktivitas masuk log.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Mobile View: Card List -->
    <div class="d-block d-md-none">
        <?php if (count($logs) > 0): ?>
            <?php foreach ($logs as $log): ?>
                <div class="glass-card mb-3 p-3" style="background: rgba(255, 255, 255, 0.02); border: 1px solid var(--border-color, rgba(255, 255, 255, 0.08)); border-radius: 8px;">
                    <div class="d-flex justify-content-between align-items-center mb-2 flex-wrap gap-1">
                        <span class="text-secondary small font-monospace"><i class="fa-solid fa-clock me-1 text-gold"></i> <?php echo date('d M Y H:i:s', strtotime($log['tanggal'])); ?></span>
                        <span class="badge badge-secondary font-monospace" style="font-size: 10px;"><?php echo htmlspecialchars($log['ip_address']); ?></span>
                    </div>
                    <div class="mb-2">
                        <strong class="text-white"><i class="fa-solid fa-circle-user me-1 text-gold"></i> <?php echo htmlspecialchars($log['username']); ?></strong>
                    </div>
                    <div class="text-white small" style="line-height: 1.4;"><?php echo htmlspecialchars($log['aktivitas']); ?></div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="text-center text-secondary py-4">Belum ada catatan aktivitas masuk log.</div>
        <?php endif; ?>
    </div>

    <!-- Pagination Navigation -->
    <?php if ($total_pages > 1): ?>
        <nav aria-label="Page navigation" class="mt-4 no-print">
            <ul class="pagination justify-content-center">
                <!-- Previous Button -->
                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $page - 1; ?><?php echo $search !== '' ? '&search='.urlencode($search) : ''; ?>" aria-label="Previous" style="background: rgba(18, 28, 54, 0.6); color: #fff; border-color: rgba(255,255,255,0.08);">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                
                <!-- Page Numbers -->
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <li class="page-item <?php echo $page == $i ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?><?php echo $search !== '' ? '&search='.urlencode($search) : ''; ?>" style="<?php echo $page == $i ? 'background: linear-gradient(135deg, #D4AF37 0%, #F3CD48 100%); color: #000; font-weight: bold; border-color: #D4AF37;' : 'background: rgba(18, 28, 54, 0.6); color: #fff; border-color: rgba(255,255,255,0.08);'; ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
                
                <!-- Next Button -->
                <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $page + 1; ?><?php echo $search !== '' ? '&search='.urlencode($search) : ''; ?>" aria-label="Next" style="background: rgba(18, 28, 54, 0.6); color: #fff; border-color: rgba(255,255,255,0.08);">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    <?php endif; ?>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
