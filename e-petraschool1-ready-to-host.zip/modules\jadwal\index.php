<?php
// c:\xampp\htdocs\e-petraschool1\modules\jadwal\index.php

$page_title = 'Jadwal Pelajaran';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$role = $_SESSION['role'] ?? '';
$guru_id_session = $_SESSION['guru_id'] ?? null;

$filter_kelas     = isset($_GET['kelas_id'])        ? intval($_GET['kelas_id'])        : 0;
$filter_ta        = isset($_GET['tahun_ajaran_id'])  ? intval($_GET['tahun_ajaran_id']) : 0;
$filter_semester  = isset($_GET['semester_id'])      ? intval($_GET['semester_id'])     : 0;

try {
    $kelas_list  = $pdo->query("SELECT id, nama_kelas FROM kelas WHERE status = 'Aktif' ORDER BY nama_kelas ASC")->fetchAll();
    $ta_list     = $pdo->query("SELECT id, tahun_ajaran, status FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();
    $sem_list    = $pdo->query("SELECT id, semester, status FROM semester ORDER BY semester ASC")->fetchAll();

    // Default ke aktif
    if (!$filter_ta) {
        foreach ($ta_list as $ta) { if ($ta['status'] === 'Aktif') { $filter_ta = $ta['id']; break; } }
    }
    if (!$filter_semester) {
        foreach ($sem_list as $sm) { if ($sm['status'] === 'Aktif') { $filter_semester = $sm['id']; break; } }
    }

    // Fetch jadwal
    $q = "SELECT jp.*, k.nama_kelas, g.nama_guru, g.nip,
                 ta.tahun_ajaran, s.semester
          FROM jadwal_pelajaran jp
          JOIN kelas k ON jp.kelas_id = k.id
          JOIN guru g  ON jp.guru_id  = g.id
          JOIN tahun_ajaran ta ON jp.tahun_ajaran_id = ta.id
          JOIN semester s ON jp.semester_id = s.id
          WHERE 1=1";
    $params = [];

    if ($filter_ta)       { $q .= " AND jp.tahun_ajaran_id = :ta_id";  $params['ta_id']  = $filter_ta; }
    if ($filter_semester) { $q .= " AND jp.semester_id = :sem_id";     $params['sem_id'] = $filter_semester; }
    if ($filter_kelas)    { $q .= " AND jp.kelas_id = :kelas_id";      $params['kelas_id'] = $filter_kelas; }

    // Guru hanya lihat jadwalnya sendiri
    if (has_role('Guru') && $guru_id_session) {
        $q .= " AND jp.guru_id = :guru_filter";
        $params['guru_filter'] = $guru_id_session;
    }

    $q .= " ORDER BY FIELD(jp.hari,'Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'), jp.jam_mulai ASC";
    $stmt = $pdo->prepare($q);
    $stmt->execute($params);
    $jadwal_list = $stmt->fetchAll();

    // Group by hari
    $days = ['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
    $jadwal_by_hari = array_fill_keys($days, []);
    foreach ($jadwal_list as $j) {
        $jadwal_by_hari[$j['hari']][] = $j;
    }

} catch (Exception $e) {
    $jadwal_list = [];
    $jadwal_by_hari = array_fill_keys(['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'], []);
    $error_msg = $e->getMessage();
}
?>

<div class="glass-card">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-calendar-days me-2"></i>Jadwal Pelajaran</h5>
            <p class="text-secondary small mb-0">Kelola jadwal pelajaran per kelas, hari, dan jam di SD Kristen Petra 1.</p>
        </div>
        <?php if (has_role(['Super Admin', 'Admin'])): ?>
        <div class="d-flex gap-2">
            <a href="create.php" class="btn btn-gold"><i class="fa-solid fa-plus me-1"></i> Tambah Jadwal</a>
        </div>
        <?php endif; ?>
    </div>

    <?php if (isset($error_msg)): ?>
        <div class="alert alert-danger">
            <i class="fa-solid fa-triangle-exclamation me-2"></i>
            Tabel belum tersedia. Jalankan terlebih dahulu:
            <a href="<?php echo $base_url; ?>database/migrate_absensi_jadwal.php" class="alert-link fw-bold">database/migrate_absensi_jadwal.php</a>
        </div>
    <?php endif; ?>

    <!-- Filters -->
    <form method="GET" action="index.php" class="row g-3 mb-4 align-items-end">
        <div class="col-12 col-sm-6 col-md-3">
            <label class="form-label form-label-custom">Tahun Ajaran</label>
            <select name="tahun_ajaran_id" class="form-select form-control-custom bg-dark-select text-white">
                <?php foreach ($ta_list as $ta): ?>
                    <option value="<?php echo $ta['id']; ?>" <?php echo $filter_ta == $ta['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($ta['tahun_ajaran']); ?> <?php echo $ta['status'] === 'Aktif' ? '(Aktif)' : ''; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-sm-6 col-md-2">
            <label class="form-label form-label-custom">Semester</label>
            <select name="semester_id" class="form-select form-control-custom bg-dark-select text-white">
                <?php foreach ($sem_list as $sm): ?>
                    <option value="<?php echo $sm['id']; ?>" <?php echo $filter_semester == $sm['id'] ? 'selected' : ''; ?>>
                        Semester <?php echo htmlspecialchars($sm['semester']); ?> <?php echo $sm['status'] === 'Aktif' ? '(Aktif)' : ''; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-12 col-sm-6 col-md-3">
            <label class="form-label form-label-custom">Kelas</label>
            <select name="kelas_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="0">Semua Kelas</option>
                <?php foreach ($kelas_list as $kl): ?>
                    <option value="<?php echo $kl['id']; ?>" <?php echo $filter_kelas == $kl['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($kl['nama_kelas']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">
                <i class="fa-solid fa-filter me-1"></i> Filter
            </button>
        </div>
    </form>

    <!-- Jadwal Grid by Hari -->
    <?php
    $day_icons = [
        'Senin'  => ['bg' => 'rgba(59,130,246,.15)', 'border' => '#3B82F6', 'icon' => 'fa-1'],
        'Selasa' => ['bg' => 'rgba(168,85,247,.15)',  'border' => '#A855F7', 'icon' => 'fa-2'],
        'Rabu'   => ['bg' => 'rgba(16,185,129,.15)',  'border' => '#10B981', 'icon' => 'fa-3'],
        'Kamis'  => ['bg' => 'rgba(245,158,11,.15)',  'border' => '#F59E0B', 'icon' => 'fa-4'],
        'Jumat'  => ['bg' => 'rgba(239,68,68,.15)',   'border' => '#EF4444', 'icon' => 'fa-5'],
        'Sabtu'  => ['bg' => 'rgba(20,184,166,.15)',  'border' => '#14B8A6', 'icon' => 'fa-6'],
    ];
    ?>

    <?php if (empty($jadwal_list)): ?>
        <div class="text-center py-5">
            <i class="fa-solid fa-calendar-xmark" style="font-size: 48px; color: rgba(255,255,255,.2);"></i>
            <p class="text-secondary mt-3">Belum ada jadwal untuk filter yang dipilih.<br>
            <?php if (has_role(['Super Admin','Admin'])): ?><a href="create.php" class="text-gold">+ Tambah jadwal sekarang</a><?php endif; ?>
            </p>
        </div>
    <?php else: ?>
        <div class="row g-3">
            <?php foreach ($days as $day): ?>
                <?php if (empty($jadwal_by_hari[$day])) continue; ?>
                <div class="col-12 col-md-6">
                    <div style="background:<?php echo $day_icons[$day]['bg']; ?>; border:1px solid <?php echo $day_icons[$day]['border']; ?>; border-radius:12px; overflow:hidden;">
                        <div style="background:<?php echo $day_icons[$day]['border']; ?>22; padding:12px 16px; border-bottom:1px solid <?php echo $day_icons[$day]['border']; ?>44;">
                            <h6 class="fw-bold mb-0" style="color:<?php echo $day_icons[$day]['border']; ?>;">
                                <i class="fa-solid fa-calendar-day me-2"></i><?php echo $day; ?>
                                <span class="badge ms-2" style="background:<?php echo $day_icons[$day]['border']; ?>33; color:<?php echo $day_icons[$day]['border']; ?>; font-size:10px;">
                                    <?php echo count($jadwal_by_hari[$day]); ?> sesi
                                </span>
                            </h6>
                        </div>
                        <div style="padding:12px;">
                            <?php foreach ($jadwal_by_hari[$day] as $jd): ?>
                                <div style="background:rgba(255,255,255,.04); border-radius:8px; padding:10px 14px; margin-bottom:8px; display:flex; justify-content:space-between; align-items:center; gap:8px;">
                                    <div style="flex:1; min-width:0;">
                                        <div class="fw-semibold text-white text-truncate" style="font-size:13px;"><?php echo htmlspecialchars($jd['nama_mapel']); ?></div>
                                        <div class="text-secondary" style="font-size:11px;">
                                            <i class="fa-solid fa-chalkboard-user me-1"></i><?php echo htmlspecialchars($jd['nama_guru']); ?>
                                            &nbsp;|&nbsp;
                                            <i class="fa-solid fa-door-open me-1"></i><?php echo htmlspecialchars($jd['nama_kelas']); ?>
                                        </div>
                                    </div>
                                    <div class="text-end" style="flex-shrink:0;">
                                        <div class="fw-bold" style="color:<?php echo $day_icons[$day]['border']; ?>; font-size:12px;">
                                            <?php echo substr($jd['jam_mulai'],0,5); ?> – <?php echo substr($jd['jam_selesai'],0,5); ?>
                                        </div>
                                        <?php if (has_role(['Super Admin','Admin'])): ?>
                                        <div class="d-flex gap-1 mt-1 justify-content-end">
                                            <a href="edit.php?id=<?php echo $jd['id']; ?>" class="btn btn-xs btn-outline-warning" title="Edit" style="padding:2px 8px; font-size:10px;"><i class="fa-solid fa-pen"></i></a>
                                            <button onclick="confirmDelete('delete.php?id=<?php echo $jd['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus" style="padding:2px 8px; font-size:10px;"><i class="fa-solid fa-trash"></i></button>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Summary table -->
        <div class="mt-4">
            <div class="table-responsive">
                <table class="table table-custom" style="font-size:13px;">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Hari</th>
                            <th>Jam</th>
                            <th>Mata Pelajaran</th>
                            <th>Guru</th>
                            <th>Kelas</th>
                            <?php if (has_role(['Super Admin','Admin'])): ?><th class="no-print">Aksi</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; foreach ($jadwal_list as $jd): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><span class="badge" style="background:<?php echo $day_icons[$jd['hari']]['border']; ?>33; color:<?php echo $day_icons[$jd['hari']]['border']; ?>;"><?php echo $jd['hari']; ?></span></td>
                            <td><span class="fw-bold text-gold" style="font-size:12px;"><?php echo substr($jd['jam_mulai'],0,5); ?> – <?php echo substr($jd['jam_selesai'],0,5); ?></span></td>
                            <td class="fw-semibold text-white"><?php echo htmlspecialchars($jd['nama_mapel']); ?></td>
                            <td><?php echo htmlspecialchars($jd['nama_guru']); ?></td>
                            <td><?php echo htmlspecialchars($jd['nama_kelas']); ?></td>
                            <?php if (has_role(['Super Admin','Admin'])): ?>
                            <td class="no-print">
                                <div class="d-flex gap-1">
                                    <a href="edit.php?id=<?php echo $jd['id']; ?>" class="btn btn-xs btn-outline-warning"><i class="fa-solid fa-pen"></i> Edit</a>
                                    <button onclick="confirmDelete('delete.php?id=<?php echo $jd['id']; ?>')" class="btn btn-xs btn-outline-danger"><i class="fa-solid fa-trash"></i> Hapus</button>
                                </div>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
