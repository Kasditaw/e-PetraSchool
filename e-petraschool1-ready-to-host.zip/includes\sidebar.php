<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\includes\sidebar.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Generate base_url if not already computed
if (!isset($base_url)) {
    $project_dir = str_replace('\\', '/', dirname(__DIR__));
    $web_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
    $base_url = str_replace($web_root, '', $project_dir);
    if (empty($base_url)) {
        $base_url = '/';
    } else {
        if (substr($base_url, 0, 1) !== '/') {
            $base_url = '/' . $base_url;
        }
        if (substr($base_url, -1) !== '/') {
            $base_url .= '/';
        }
    }
    $base_url = str_replace('//', '/', $base_url);
}

$role = $_SESSION['role'] ?? '';
$username = $_SESSION['username'] ?? '';
$nama_user = $_SESSION['nama'] ?? 'Pengguna';

// Determine active page/module for active class styling
$request_uri = $_SERVER['REQUEST_URI'];
?>

<aside class="sidebar-container no-print">
    <div class="sidebar-brand">
        <div class="brand-icon">
            <img src="<?php echo $base_url; ?>assets/images/logo.png" alt="Logo Petra" style="height: 34px; width: 34px; object-fit: contain;">
        </div>
        <div>
            <div class="brand-name">e-PetraSchool</div>
            <div class="brand-sub">Electronic Management</div>
        </div>
    </div>

    <!-- List Menu Dinamis -->
    <div class="sidebar-menu">
        <nav id="sidebar-nav">
            
            <?php if ($role === 'Guru' && $username !== '201807007'): ?>
                <div class="sidebar-section-header">Menu Utama</div>
                
                <!-- Jurnal Mengajar Link -->
                <a href="<?php echo $base_url; ?>modules/jurnal/index.php" class="nav-link-custom <?php echo (strpos($request_uri, 'jurnal') !== false && strpos($request_uri, 'status=') === false) ? 'active' : ''; ?>">
                    <i class="fa-solid fa-journal-whills"></i> <span>Jurnal Mengajar</span>
                </a>

                <!-- RPP & Modul Ajar Link -->
                <a href="<?php echo $base_url; ?>modules/rpp/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'rpp') !== false ? 'active' : ''; ?>">
                    <i class="fa-solid fa-layer-group" style="color:#22c55e;"></i> <span>RPP &amp; Modul Ajar <span class="badge rounded-pill ms-1" style="background:linear-gradient(135deg,#22c55e,#16a34a);font-size:8px;padding:2px 5px;vertical-align:middle;">K-Merdeka</span></span>
                </a>

                <!-- Jadwal Pelajaran Link (Guru) -->
                <a href="<?php echo $base_url; ?>modules/jadwal/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'jadwal') !== false ? 'active' : ''; ?>">
                    <i class="fa-solid fa-calendar-days"></i> <span>Jadwal Pelajaran</span>
                </a>

                <!-- Absensi Siswa (Guru) - view only -->
                <a href="<?php echo $base_url; ?>modules/absensi_siswa/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'absensi_siswa') !== false ? 'active' : ''; ?>">
                    <i class="fa-solid fa-clipboard-check"></i> <span>Absensi Siswa</span>
                </a>

                <!-- Pengumuman Link -->
                <a href="<?php echo $base_url; ?>modules/pengumuman/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'pengumuman') !== false ? 'active' : ''; ?>">
                    <i class="fa-solid fa-bullhorn"></i> <span>Pengumuman</span>
                </a>

            <?php elseif ($username === '199302001'): ?>
                <div class="sidebar-section-header">Manajemen Inventaris</div>
                
                <a href="<?php echo $base_url; ?>modules/inventaris/dashboard.php" class="nav-link-custom <?php echo strpos($request_uri, 'inventaris/dashboard.php') !== false ? 'active' : ''; ?>">
                    <i class="fa-solid fa-chart-line"></i> <span>Dashboard Inventaris</span>
                </a>
                
                <a href="<?php echo $base_url; ?>modules/inventaris/index.php" class="nav-link-custom <?php echo (strpos($request_uri, 'inventaris/index.php') !== false && !strpos($request_uri, 'kategori') && !strpos($request_uri, 'lokasi') && !strpos($request_uri, 'supplier') && !strpos($request_uri, 'pengembalian') && !strpos($request_uri, 'perawatan') && !strpos($request_uri, 'mutasi') && !strpos($request_uri, 'penghapusan') && !strpos($request_uri, 'qrcode') && !strpos($request_uri, 'histori') && !strpos($request_uri, 'laporan')) ? 'active' : ''; ?>">
                    <i class="fa-solid fa-boxes-stacked"></i> <span>Data Inventaris</span>
                </a>

            <?php else: ?>
                <div class="sidebar-section-header">Menu Utama</div>
                
                <!-- Kepala Sekolah Dashboard -->
                <?php if ($role === 'Kepala Sekolah'): ?>
                    <div class="sidebar-section-header">Dashboard</div>
                    <a href="<?php echo $base_url; ?>modules/dashboard/kepsek.php" class="nav-link-custom <?php echo strpos($request_uri, 'dashboard/kepsek') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-gauge-high"></i> <span>Dashboard Kepsek</span>
                    </a>
                    <div class="sidebar-section-header">Monitoring</div>
                    <a href="<?php echo $base_url; ?>modules/absensi_siswa/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'absensi_siswa') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-clipboard-check"></i> <span>Absensi Siswa</span>
                    </a>
                    <a href="<?php echo $base_url; ?>modules/absensi_guru/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'absensi_guru') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-chalkboard-user"></i> <span>Absensi Guru</span>
                    </a>
                    <a href="<?php echo $base_url; ?>modules/spp/rekap.php" class="nav-link-custom <?php echo (strpos($request_uri, 'spp/rekap') !== false) ? 'active' : ''; ?>">
                        <i class="fa-solid fa-money-bill-wave"></i> <span>Rekap SPP</span>
                    </a>
                <?php endif; ?>
                
                <?php if ($role !== 'Kepala Sekolah'): ?>
                    <a href="<?php echo $base_url; ?>modules/dashboard/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'dashboard') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-table-cells-large"></i> <span>Dashboard</span>
                    </a>
                <?php endif; ?>

                <!-- Semua Siswa Link -->
                <a href="<?php echo $base_url; ?>modules/siswa/index.php" class="nav-link-custom <?php echo (strpos($request_uri, 'siswa') !== false && !isset($_GET['kelas_id'])) ? 'active' : ''; ?>">
                    <i class="fa-solid fa-users"></i> <span>Semua Siswa</span>
                </a>

                <!-- Pengumuman Link -->
                <?php if ($role !== 'Kepala Sekolah'): ?>
                    <a href="<?php echo $base_url; ?>modules/pengumuman/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'pengumuman') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-bullhorn"></i> <span>Pengumuman</span>
                    </a>
                <?php endif; ?>

                <div class="sidebar-section-header">e-Jurnal Mengajar</div>
                <!-- Jurnal Mengajar Link -->
                <?php if ($role !== 'Kepala Sekolah'): ?>
                    <a href="<?php echo $base_url; ?>modules/jurnal/index.php" class="nav-link-custom <?php echo (strpos($request_uri, 'jurnal') !== false && strpos($request_uri, 'status=') === false) ? 'active' : ''; ?>">
                        <i class="fa-solid fa-journal-whills"></i> <span>Jurnal Mengajar</span>
                    </a>
                <?php endif; ?>
                
                <!-- Verifikasi Jurnal Links (Kepsek only) -->
                <?php if (has_role(['Kepala Sekolah'])): ?>
                    <a href="<?php echo $base_url; ?>modules/jurnal/verifikasi_ks.php" class="nav-link-custom <?php echo strpos($request_uri, 'verifikasi_ks') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-shield-halved" style="color:#D4AF37;"></i> <span>Panel Verifikasi KS</span>
                    </a>
                    <a href="<?php echo $base_url; ?>modules/jurnal/index.php?status=Menunggu+Verifikasi" class="nav-link-custom <?php echo (strpos($request_uri, 'jurnal') !== false && strpos($request_uri, 'status=Menunggu+Verifikasi') !== false) ? 'active' : ''; ?>">
                        <i class="fa-solid fa-file-circle-check"></i> <span>Antrian Verifikasi</span>
                    </a>
                <?php endif; ?>

                <div class="sidebar-section-header">Data Kelas</div>
                <?php if ($role !== 'Kepala Sekolah'): ?>
                    <a href="<?php echo $base_url; ?>modules/kelas/index.php" class="nav-link-custom <?php echo (strpos($request_uri, 'modules/kelas') !== false && !isset($_GET['kelas_id'])) ? 'active' : ''; ?>">
                        <i class="fa-solid fa-folder-closed"></i> <span>Manajemen Kelas</span>
                    </a>
                <?php endif; ?>
                <?php if (has_role(['Super Admin', 'Admin'])): ?>
                    <a href="<?php echo $base_url; ?>modules/penempatan/index.php" class="nav-link-custom <?php echo (strpos($request_uri, 'modules/penempatan') !== false && strpos($request_uri, 'kenaikan.php') === false) ? 'active' : ''; ?>">
                        <i class="fa-solid fa-user-tag"></i> <span>Penempatan Kelas</span>
                    </a>
                    <a href="<?php echo $base_url; ?>modules/penempatan/kenaikan.php" class="nav-link-custom <?php echo strpos($request_uri, 'modules/penempatan/kenaikan.php') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-angles-up"></i> <span>Kenaikan Kelas</span>
                    </a>
                <?php endif; ?>
                <a href="#collapseDataKelas" class="nav-link-custom <?php echo isset($_GET['kelas_id']) ? '' : 'collapsed'; ?>" data-bs-toggle="collapse" role="button" aria-expanded="<?php echo isset($_GET['kelas_id']) ? 'true' : 'false'; ?>" aria-controls="collapseDataKelas">
                    <i class="fa-solid fa-school"></i> <span>Daftar Kelas</span> <i class="fa-solid fa-chevron-down ms-auto submenu-arrow"></i>
                </a>
                <div class="collapse <?php echo isset($_GET['kelas_id']) ? 'show' : ''; ?>" id="collapseDataKelas">
                    <ul class="sidebar-submenu" style="margin-top: 4px;">
                        <?php
                        // Fetch classes from database to render submenus
                        try {
                            $stmt_sidebar_kelas = $pdo->query("SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas ASC");
                            $sidebar_kelas_list = $stmt_sidebar_kelas->fetchAll();
                        } catch (Exception $e) {
                            $sidebar_kelas_list = [];
                        }
                        
                        foreach ($sidebar_kelas_list as $kls) {
                            $nama = $kls['nama_kelas'];
                            // Convert "Kelas 1A" -> "Kelas I A"
                            $nama_roman = preg_replace_callback('/(\d+)/', function($matches) {
                                $map = [1 => 'I', 2 => 'II', 3 => 'III', 4 => 'IV', 5 => 'V', 6 => 'VI'];
                                return $map[$matches[1]] ?? $matches[1];
                            }, $nama);
                            $nama_roman = preg_replace('/([I|V|X])([A-Z])/', '$1 $2', $nama_roman);
                            
                            $active_class = (isset($_GET['kelas_id']) && $_GET['kelas_id'] == $kls['id']) ? 'active' : '';
                            ?>
                            <li>
                                <a href="<?php echo $base_url; ?>modules/siswa/index.php?kelas_id=<?php echo $kls['id']; ?>" class="nav-link-custom <?php echo $active_class; ?>">
                                    <span><?php echo htmlspecialchars($nama_roman); ?></span>
                                </a>
                            </li>
                            <?php
                        }
                        ?>
                    </ul>
                </div>

                <div class="sidebar-section-header">Akademik</div>
                
                <!-- Raport Siswa Link (pointed to modules/raport) -->
                <?php if ($role !== 'Kepala Sekolah'): ?>
                    <a href="<?php echo $base_url; ?>modules/raport/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'raport') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-file-invoice"></i> <span>Raport Siswa</span>
                    </a>
                <?php endif; ?>

                <!-- RPP & Modul Ajar Link -->
                <a href="<?php echo $base_url; ?>modules/rpp/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'rpp') !== false ? 'active' : ''; ?>">
                    <i class="fa-solid fa-layer-group" style="color:#22c55e;"></i> <span>RPP &amp; Modul Ajar <span class="badge rounded-pill ms-1" style="background:linear-gradient(135deg,#22c55e,#16a34a);font-size:8px;padding:2px 5px;vertical-align:middle;">K-Merdeka</span></span>
                </a>

                <!-- Data Guru Link -->
                <a href="<?php echo $base_url; ?>modules/guru/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'guru') !== false ? 'active' : ''; ?>">
                    <i class="fa-solid fa-chalkboard-user"></i> <span>Data Guru</span>
                </a>

                <!-- Data Karyawan Link -->
                <?php if ($role !== 'Kepala Sekolah'): ?>
                    <a href="<?php echo $base_url; ?>modules/karyawan/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'karyawan') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-users-gear"></i> <span>Data Karyawan</span>
                    </a>
                <?php endif; ?>

                <!-- Data Alumni Link -->
                <?php if ($role !== 'Kepala Sekolah'): ?>
                    <a href="<?php echo $base_url; ?>modules/alumni/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'alumni') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-user-graduate"></i> <span>Data Alumni</span>
                    </a>
                <?php endif; ?>

                <!-- Laporan Sekolah Link (di bawah Akademik) -->
                <?php if ($role !== 'Kepala Sekolah'): ?>
                    <a href="<?php echo $base_url; ?>modules/laporan/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'laporan') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-file-invoice-dollar"></i> <span>Laporan Sekolah</span>
                    </a>
                <?php endif; ?>

                <!-- Konsolidator Ledger Link -->
                <?php if (has_role(['Super Admin', 'Admin', 'Guru'])): ?>
                    <a href="<?php echo $base_url; ?>modules/ledger_nilai/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'ledger_nilai') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-calculator text-warning"></i> <span>Konsolidator Ledger</span>
                    </a>
                <?php endif; ?>

                <div class="sidebar-section-header">Absensi &amp; Jadwal</div>

                <!-- Jadwal Pelajaran -->
                <a href="<?php echo $base_url; ?>modules/jadwal/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'jadwal') !== false ? 'active' : ''; ?>">
                    <i class="fa-solid fa-calendar-days"></i> <span>Jadwal Pelajaran</span>
                </a>

                <!-- Absensi Siswa -->
                <a href="<?php echo $base_url; ?>modules/absensi_siswa/index.php" class="nav-link-custom <?php echo (strpos($request_uri, 'absensi_siswa') !== false) ? 'active' : ''; ?>">
                    <i class="fa-solid fa-clipboard-check"></i> <span>Absensi Siswa</span>
                </a>

                <!-- Absensi Guru (Admin & Super Admin only) -->
                <?php if (has_role(['Super Admin', 'Admin'])): ?>
                    <a href="<?php echo $base_url; ?>modules/absensi_guru/index.php" class="nav-link-custom <?php echo (strpos($request_uri, 'absensi_guru') !== false) ? 'active' : ''; ?>">
                        <i class="fa-solid fa-chalkboard-user"></i> <span>Absensi Guru</span>
                    </a>
                <?php endif; ?>

                <!-- SPP & Ekskul -->
                <?php if (has_role(['Super Admin','Admin'])): ?>
                    <div class="sidebar-section-header">SPP &amp; Ekskul</div>
                    <a href="<?php echo $base_url; ?>modules/spp/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'modules/spp') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-money-bill-wave"></i> <span>SPP &amp; Keuangan</span>
                    </a>
                    <a href="<?php echo $base_url; ?>modules/ekskul/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'ekskul') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-star"></i> <span>Ekstrakurikuler</span>
                    </a>
                <?php endif; ?>

                <?php if ($role !== 'Kepala Sekolah' && can_access_inventaris()): ?>
                <!-- Collapsible Inventaris Menu -->
                <a href="#collapseInventaris" class="nav-link-custom <?php echo (strpos($request_uri, 'inventaris') !== false || strpos($request_uri, 'peminjaman') !== false || strpos($request_uri, 'ruangan') !== false) ? '' : 'collapsed'; ?>" data-bs-toggle="collapse" role="button" aria-expanded="<?php echo (strpos($request_uri, 'inventaris') !== false || strpos($request_uri, 'peminjaman') !== false || strpos($request_uri, 'ruangan') !== false) ? 'true' : 'false'; ?>" aria-controls="collapseInventaris">
                    <i class="fa-solid fa-boxes-stacked"></i> <span>Manajemen Inventaris</span> <i class="fa-solid fa-chevron-down ms-auto submenu-arrow"></i>
                </a>
                <div class="collapse <?php echo (strpos($request_uri, 'inventaris') !== false || strpos($request_uri, 'peminjaman') !== false || strpos($request_uri, 'ruangan') !== false) ? 'show' : ''; ?>" id="collapseInventaris">
                    <ul class="sidebar-submenu" style="margin-top: 4px;">
                        <li>
                            <a href="<?php echo $base_url; ?>modules/inventaris/dashboard.php" class="nav-link-custom <?php echo strpos($request_uri, 'inventaris/dashboard.php') !== false ? 'active' : ''; ?>">
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo $base_url; ?>modules/inventaris/index.php" class="nav-link-custom <?php echo (strpos($request_uri, 'inventaris/index.php') !== false && !strpos($request_uri, '?') && !strpos($request_uri, 'dashboard') && !strpos($request_uri, 'kategori') && !strpos($request_uri, 'lokasi') && !strpos($request_uri, 'supplier') && !strpos($request_uri, 'pengembalian') && !strpos($request_uri, 'perawatan') && !strpos($request_uri, 'mutasi') && !strpos($request_uri, 'penghapusan') && !strpos($request_uri, 'qrcode') && !strpos($request_uri, 'histori') && !strpos($request_uri, 'laporan')) ? 'active' : ''; ?>">
                                <span>Data Inventaris</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo $base_url; ?>modules/inventaris/kategori.php" class="nav-link-custom <?php echo strpos($request_uri, 'inventaris/kategori.php') !== false ? 'active' : ''; ?>">
                                <span>Kategori Inventaris</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo $base_url; ?>modules/inventaris/lokasi.php" class="nav-link-custom <?php echo strpos($request_uri, 'inventaris/lokasi.php') !== false ? 'active' : ''; ?>">
                                <span>Lokasi Inventaris</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo $base_url; ?>modules/inventaris/supplier.php" class="nav-link-custom <?php echo strpos($request_uri, 'inventaris/supplier.php') !== false ? 'active' : ''; ?>">
                                <span>Supplier / Vendor</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo $base_url; ?>modules/peminjaman/index.php" class="nav-link-custom <?php echo (strpos($request_uri, 'peminjaman') !== false && !strpos($request_uri, 'pengembalian')) ? 'active' : ''; ?>">
                                <span>Peminjaman Barang</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo $base_url; ?>modules/inventaris/pengembalian.php" class="nav-link-custom <?php echo strpos($request_uri, 'inventaris/pengembalian.php') !== false ? 'active' : ''; ?>">
                                <span>Pengembalian Barang</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo $base_url; ?>modules/inventaris/perawatan.php" class="nav-link-custom <?php echo strpos($request_uri, 'inventaris/perawatan.php') !== false ? 'active' : ''; ?>">
                                <span>Perawatan Barang</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo $base_url; ?>modules/inventaris/mutasi.php" class="nav-link-custom <?php echo strpos($request_uri, 'inventaris/mutasi.php') !== false ? 'active' : ''; ?>">
                                <span>Mutasi Barang</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo $base_url; ?>modules/inventaris/penghapusan.php" class="nav-link-custom <?php echo strpos($request_uri, 'inventaris/penghapusan.php') !== false ? 'active' : ''; ?>">
                                <span>Penghapusan Barang</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo $base_url; ?>modules/inventaris/qrcode.php" class="nav-link-custom <?php echo strpos($request_uri, 'inventaris/qrcode.php') !== false ? 'active' : ''; ?>">
                                <span>QR Code Inventaris</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo $base_url; ?>modules/inventaris/histori.php" class="nav-link-custom <?php echo strpos($request_uri, 'inventaris/histori.php') !== false ? 'active' : ''; ?>">
                                <span>Histori Inventaris</span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo $base_url; ?>modules/inventaris/laporan.php" class="nav-link-custom <?php echo strpos($request_uri, 'inventaris/laporan.php') !== false ? 'active' : ''; ?>">
                                <span>Laporan Inventaris</span>
                            </a>
                        </li>
                        <?php if (has_role(['Super Admin', 'Admin'])): ?>
                        <li>
                            <a href="<?php echo $base_url; ?>modules/inventaris/akses_nip.php" class="nav-link-custom <?php echo strpos($request_uri, 'inventaris/akses_nip.php') !== false ? 'active' : ''; ?>" style="color: #F59E0B !important;">
                                <span><i class="fa-solid fa-key me-1" style="font-size:10px;"></i> Kelola Akses NIP</span>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <div class="sidebar-section-header">Sistem</div>
                
                <!-- Skema Database Link (restricted to Super Admin and Admin) -->
                <?php if (has_role(['Super Admin', 'Admin'])): ?>
                    <a href="<?php echo $base_url; ?>backup.php" class="nav-link-custom <?php echo strpos($request_uri, 'backup.php') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-database"></i> <span>Skema Database</span>
                    </a>
                <?php endif; ?>

                <!-- Laporan Sekolah Dropdown -->
                <?php if ($role !== 'Kepala Sekolah'): ?>
                    <a href="#collapseLaporan" class="nav-link-custom <?php echo strpos($request_uri, 'laporan') !== false ? '' : 'collapsed'; ?>" data-bs-toggle="collapse" role="button" aria-expanded="<?php echo strpos($request_uri, 'laporan') !== false ? 'true' : 'false'; ?>" aria-controls="collapseLaporan">
                        <i class="fa-solid fa-file-invoice-dollar"></i> <span>Laporan Sekolah</span> <i class="fa-solid fa-chevron-down ms-auto submenu-arrow"></i>
                    </a>
                    <div class="collapse <?php echo strpos($request_uri, 'laporan') !== false ? 'show' : ''; ?>" id="collapseLaporan">
                        <ul class="sidebar-submenu" style="margin-top: 4px;">
                            <li>
                                <a href="<?php echo $base_url; ?>modules/laporan/index.php" class="nav-link-custom <?php echo ($request_uri === $base_url . 'modules/laporan/index.php' || $request_uri === $base_url . 'modules/laporan/') ? 'active' : ''; ?>">
                                    <span>Pusat Laporan</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo $base_url; ?>modules/laporan/index.php#card-siswa" class="nav-link-custom">
                                    <span>Laporan Siswa</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo $base_url; ?>modules/laporan/index.php#card-guru" class="nav-link-custom">
                                    <span>Laporan Guru</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo $base_url; ?>modules/laporan/index.php#card-karyawan" class="nav-link-custom">
                                    <span>Laporan Karyawan</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo $base_url; ?>modules/laporan/index.php#card-inventaris" class="nav-link-custom">
                                    <span>Laporan Inventaris</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo $base_url; ?>modules/laporan/index.php#card-barang-rusak" class="nav-link-custom">
                                    <span>Laporan Barang Rusak</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo $base_url; ?>modules/laporan/index.php#card-ruangan" class="nav-link-custom">
                                    <span>Laporan Ruangan</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo $base_url; ?>modules/laporan/index.php#card-alumni" class="nav-link-custom">
                                    <span>Laporan Alumni</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo $base_url; ?>modules/laporan/index.php#card-nilai" class="nav-link-custom">
                                    <span>Laporan Nilai</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo $base_url; ?>modules/laporan/index.php#card-peminjaman" class="nav-link-custom">
                                    <span>Laporan Peminjaman</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo $base_url; ?>modules/laporan/index.php#card-pengumuman" class="nav-link-custom">
                                    <span>Laporan Pengumuman</span>
                                </a>
                            </li>
                            <?php if (has_role(['Super Admin', 'Kepala Sekolah'])): ?>
                                <li>
                                    <a href="<?php echo $base_url; ?>modules/laporan/index.php#card-audit-log" class="nav-link-custom">
                                        <span>Laporan Audit Log</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <li>
                                <a href="<?php echo $base_url; ?>modules/laporan/index.php#section-jurnal" class="nav-link-custom">
                                    <span>Laporan Jurnal Guru</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- Audit Log Link (restricted to Super Admin and Kepala Sekolah) -->
                <?php if (has_role(['Super Admin'])): ?>
                    <a href="<?php echo $base_url; ?>modules/audit_log/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'audit_log') !== false ? 'active' : ''; ?>">
                        <i class="fa-solid fa-clipboard-list"></i> <span>Audit Log</span>
                    </a>
                <?php endif; ?>

                 <!-- Master Data e-Jurnal Configuration -->
                 <?php if (has_role(['Super Admin', 'Admin'])): ?>
                     <div class="sidebar-section-header">Konfigurasi Jurnal</div>
                     <a href="<?php echo $base_url; ?>modules/mata_pelajaran/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'mata_pelajaran') !== false ? 'active' : ''; ?>">
                         <i class="fa-solid fa-book-bookmark"></i> <span>Mata Pelajaran</span>
                     </a>
                     <a href="<?php echo $base_url; ?>modules/tahun_ajaran/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'tahun_ajaran') !== false ? 'active' : ''; ?>">
                         <i class="fa-solid fa-calendar-days"></i> <span>Tahun Ajaran</span>
                     </a>
                     <a href="<?php echo $base_url; ?>modules/semester/index.php" class="nav-link-custom <?php echo strpos($request_uri, 'semester') !== false ? 'active' : ''; ?>">
                         <i class="fa-solid fa-list-ol"></i> <span>Semester</span>
                     </a>
                      <a href="<?php echo $base_url; ?>modules/pengaturan/index.php" class="nav-link-custom <?php echo (strpos($request_uri, 'pengaturan/index.php') !== false || ($request_uri === $base_url . 'modules/pengaturan/' || $request_uri === $base_url . 'modules/pengaturan')) ? 'active' : ''; ?>">
                          <i class="fa-solid fa-sliders"></i> <span>Pengaturan Jurnal</span>
                      </a>
                      <a href="<?php echo $base_url; ?>modules/pengaturan/akun.php" class="nav-link-custom <?php echo strpos($request_uri, 'pengaturan/akun.php') !== false ? 'active' : ''; ?>">
                          <i class="fa-solid fa-user-lock"></i> <span>Kelola Akun NIP</span>
                      </a>
                 <?php endif; ?>
            <?php endif; ?>

        </nav>
    </div>

    <!-- User Profile & Action Box -->
    <div class="sidebar-footer">
        <div class="d-flex align-items-center gap-3">
            <div class="position-relative">
                <?php
                $display_name = $nama_user;
                $display_role = $role;
                if ($role === 'Super Admin') $display_name = 'Administrator Sistem';
                $first_letter = strtoupper(substr($display_name, 0, 1));
                // Cek foto profil
                $user_foto_path = '';
                try {
                    if (isset($pdo) && isset($_SESSION['user_id'])) {
                        $foto_q = $pdo->prepare("SELECT foto FROM users WHERE id=? LIMIT 1");
                        $foto_q->execute([$_SESSION['user_id']]);
                        $user_foto_path = $foto_q->fetchColumn() ?: '';
                    }
                } catch (Exception $e) {}
                ?>
                <?php if ($user_foto_path): ?>
                    <img src="<?php echo $base_url; ?>assets/uploads/foto_profil/<?php echo htmlspecialchars($user_foto_path); ?>" alt="Foto" style="width:40px;height:40px;border-radius:50%;object-fit:cover;border:2px solid rgba(212,175,55,.4);flex-shrink:0;">
                <?php else: ?>
                <div class="avatar-letter d-flex align-items-center justify-content-center rounded-circle" style="width: 40px; height: 40px; font-weight: 700; font-size: 16px; background: linear-gradient(135deg, var(--accent) 0%, var(--accent-light) 100%); color: #fff; border: 2px solid rgba(255,255,255,0.12); flex-shrink: 0;">
                    <?php echo $first_letter; ?>
                </div>
                <?php endif; ?>
                <span class="status-indicator-dot bg-success" style="bottom: 0; right: 0;"></span>
            </div>
            <div class="overflow-hidden">
                <h6 id="user-display-name" class="text-white mb-0 text-truncate fw-bold" style="font-size: 13px;"><?php echo htmlspecialchars($display_name); ?></h6>
                <span id="user-display-role" class="text-secondary small text-uppercase font-monospace" style="font-size: 9px; letter-spacing: 0.5px;"><?php echo htmlspecialchars($display_role); ?></span>
            </div>
        </div>
    </div>
</aside>
