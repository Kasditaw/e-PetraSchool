<?php
// c:\xampp\htdocs\e-petraschool1\modules\absensi_guru\index.php

$page_title = 'Absensi Guru';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$filter_guru  = isset($_GET['guru_id']) ? intval($_GET['guru_id']) : 0;
$filter_bulan = isset($_GET['bulan'])   ? intval($_GET['bulan'])   : intval(date('m'));
$filter_tahun = isset($_GET['tahun'])   ? intval($_GET['tahun'])   : intval(date('Y'));
$filter_status = isset($_GET['status']) ? trim($_GET['status'])    : '';

$bulan_names = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
$status_colors = ['Hadir'=>'#10B981','Sakit'=>'#F59E0B','Izin'=>'#3B82F6','Cuti'=>'#A855F7','Dinas Luar'=>'#14B8A6','Alfa'=>'#EF4444'];
$status_codes  = ['Hadir'=>'H','Sakit'=>'S','Izin'=>'I','Cuti'=>'C','Dinas Luar'=>'DL','Alfa'=>'A'];

try {
    $guru_list = $pdo->query("SELECT id, nama_guru, nip FROM guru ORDER BY nama_guru ASC")->fetchAll();

    $start_date = "$filter_tahun-" . str_pad($filter_bulan,2,'0',STR_PAD_LEFT) . "-01";
    $end_date   = "$filter_tahun-" . str_pad($filter_bulan,2,'0',STR_PAD_LEFT) . "-" . cal_days_in_month(CAL_GREGORIAN,$filter_bulan,$filter_tahun);
    $days_in_month = cal_days_in_month(CAL_GREGORIAN, $filter_bulan, $filter_tahun);

    // Ambil semua data absensi guru bulan ini
    $q = "SELECT ag.*, g.nama_guru, g.nip FROM absensi_guru ag JOIN guru g ON ag.guru_id = g.id WHERE ag.tanggal BETWEEN ? AND ?";
    $params = [$start_date, $end_date];
    if ($filter_guru) { $q .= " AND ag.guru_id = ?"; $params[] = $filter_guru; }
    if ($filter_status) { $q .= " AND ag.status = ?"; $params[] = $filter_status; }
    $q .= " ORDER BY ag.tanggal DESC, g.nama_guru ASC";
    $stmt = $pdo->prepare($q);
    $stmt->execute($params);
    $absensi_list = $stmt->fetchAll();

    // Matrix per guru
    $absensi_matrix = [];
    foreach ($absensi_list as $a) {
        $absensi_matrix[$a['guru_id']][$a['tanggal']] = ['status' => $a['status'], 'keterangan' => $a['keterangan']];
    }

} catch (Exception $e) {
    $absensi_list = [];
    $absensi_matrix = [];
    $error_db = $e->getMessage();
}
?>

<div class="glass-card">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-chalkboard-user me-2"></i>Absensi Guru</h5>
            <p class="text-secondary small mb-0">Rekap kehadiran guru bulan <?php echo $bulan_names[$filter_bulan]; ?> <?php echo $filter_tahun; ?>.</p>
        </div>
        <?php if (has_role(['Super Admin', 'Admin'])): ?>
        <div class="d-flex gap-2 no-print">
            <a href="input.php?bulan=<?php echo $filter_bulan; ?>&tahun=<?php echo $filter_tahun; ?>" class="btn btn-gold">
                <i class="fa-solid fa-clipboard-user me-1"></i> Input Absensi Guru
            </a>
            <a href="rekap.php?bulan=<?php echo $filter_bulan; ?>&tahun=<?php echo $filter_tahun; ?>" class="btn btn-outline-custom">
                <i class="fa-solid fa-table-list me-1"></i> Rekap Bulanan
            </a>
        </div>
        <?php endif; ?>
    </div>

    <?php if (isset($error_db)): ?>
        <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i>Tabel belum tersedia. Jalankan: <a href="<?php echo $base_url; ?>database/migrate_absensi_jadwal.php" class="alert-link">migrate_absensi_jadwal.php</a></div>
    <?php endif; ?>

    <!-- Filters -->
    <form method="GET" class="row g-3 mb-4 align-items-end no-print">
        <div class="col-6 col-md-3">
            <label class="form-label form-label-custom">Guru</label>
            <select name="guru_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua Guru</option>
                <?php foreach ($guru_list as $g): ?>
                    <option value="<?php echo $g['id']; ?>" <?php echo $filter_guru==$g['id']?'selected':''; ?>><?php echo htmlspecialchars($g['nama_guru']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Bulan</label>
            <select name="bulan" class="form-select form-control-custom bg-dark-select text-white">
                <?php for ($m=1;$m<=12;$m++): ?>
                    <option value="<?php echo $m; ?>" <?php echo $filter_bulan==$m?'selected':''; ?>><?php echo $bulan_names[$m]; ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Tahun</label>
            <input type="number" name="tahun" class="form-control form-control-custom" value="<?php echo $filter_tahun; ?>">
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Status</label>
            <select name="status" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua Status</option>
                <?php foreach (array_keys($status_colors) as $st): ?>
                    <option value="<?php echo $st; ?>" <?php echo $filter_status===$st?'selected':''; ?>><?php echo $st; ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom"><i class="fa-solid fa-filter me-1"></i> Filter</button>
        </div>
    </form>

    <!-- Legend -->
    <div class="d-flex gap-3 mb-3 flex-wrap">
        <?php foreach ($status_colors as $st => $clr): ?>
            <span style="display:inline-flex; align-items:center; gap:5px; font-size:11px; color:#94A3B8;">
                <span style="width:22px; height:18px; background:<?php echo $clr; ?>33; border:1px solid <?php echo $clr; ?>; border-radius:4px; display:inline-flex; align-items:center; justify-content:center; font-weight:700; color:<?php echo $clr; ?>; font-size:9px;"><?php echo $status_codes[$st]; ?></span>
                <?php echo $st; ?>
            </span>
        <?php endforeach; ?>
    </div>

    <!-- Matrix Guru -->
    <?php if (empty($guru_list)): ?>
        <div class="text-center py-5"><p class="text-secondary">Belum ada data guru.</p></div>
    <?php else: ?>
        <div class="table-responsive" style="overflow-x:auto;">
            <table class="table table-custom" style="font-size:11px; min-width:800px;">
                <thead>
                    <tr>
                        <th style="min-width:180px; position:sticky; left:0; background:var(--bg-card,#0d1b35); z-index:2;">Nama Guru</th>
                        <?php for ($d=1; $d<=$days_in_month; $d++):
                            $date_str = "$filter_tahun-".str_pad($filter_bulan,2,'0',STR_PAD_LEFT)."-".str_pad($d,2,'0',STR_PAD_LEFT);
                            $dow = date('N', strtotime($date_str));
                            $is_sunday = ($dow == 7);
                        ?>
                            <th style="text-align:center; padding:4px 2px; min-width:22px; <?php echo $is_sunday?'color:#EF4444;':''; ?>">
                                <?php echo $d; ?>
                                <div style="font-size:8px; color:#64748B; font-weight:400;"><?php echo ['','S','S','R','K','J','S','M'][$dow]; ?></div>
                            </th>
                        <?php endfor; ?>
                        <th style="text-align:center; color:#10B981; min-width:30px;">H</th>
                        <th style="text-align:center; color:#F59E0B; min-width:30px;">S</th>
                        <th style="text-align:center; color:#3B82F6; min-width:30px;">I</th>
                        <th style="text-align:center; color:#A855F7; min-width:30px;">C</th>
                        <th style="text-align:center; color:#14B8A6; min-width:30px;">DL</th>
                        <th style="text-align:center; color:#EF4444; min-width:30px;">A</th>
                        <th style="text-align:center; min-width:40px;">%H</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $display_gurus = $filter_guru ? array_filter($guru_list, fn($g) => $g['id'] == $filter_guru) : $guru_list;
                    foreach ($display_gurus as $guru):
                        $gdata = $absensi_matrix[$guru['id']] ?? [];
                        $totals = ['Hadir'=>0,'Sakit'=>0,'Izin'=>0,'Cuti'=>0,'Dinas Luar'=>0,'Alfa'=>0];
                        $total_input = 0;
                        for ($d=1; $d<=$days_in_month; $d++) {
                            $date_str = "$filter_tahun-".str_pad($filter_bulan,2,'0',STR_PAD_LEFT)."-".str_pad($d,2,'0',STR_PAD_LEFT);
                            $dow = date('N', strtotime($date_str));
                            if ($dow == 7) continue;
                            if (isset($gdata[$date_str])) {
                                $st = $gdata[$date_str]['status'];
                                if (isset($totals[$st])) $totals[$st]++;
                                $total_input++;
                            }
                        }
                        $pct = $total_input > 0 ? round($totals['Hadir']/$total_input*100) : 0;
                    ?>
                    <tr>
                        <td style="position:sticky; left:0; background:var(--bg-card,#0d1b35); z-index:1; white-space:nowrap;">
                            <strong class="text-white" style="font-size:12px;"><?php echo htmlspecialchars($guru['nama_guru']); ?></strong>
                            <div class="text-secondary font-monospace" style="font-size:9px;"><?php echo htmlspecialchars($guru['nip']); ?></div>
                        </td>
                        <?php for ($d=1; $d<=$days_in_month; $d++):
                            $date_str = "$filter_tahun-".str_pad($filter_bulan,2,'0',STR_PAD_LEFT)."-".str_pad($d,2,'0',STR_PAD_LEFT);
                            $dow = date('N', strtotime($date_str));
                            $is_sunday = ($dow == 7);
                            $ab = $gdata[$date_str] ?? null;
                            $st = $ab ? $ab['status'] : null;
                            $clr = $st ? ($status_colors[$st] ?? '#94A3B8') : null;
                            $code = $st ? ($status_codes[$st] ?? '?') : null;
                        ?>
                            <td style="text-align:center; padding:3px 2px;">
                                <?php if ($is_sunday): ?>
                                    <span style="color:#1e293b;">—</span>
                                <?php elseif ($st): ?>
                                    <span style="display:inline-flex; align-items:center; justify-content:center; width:20px; height:18px; background:<?php echo $clr; ?>22; border:1px solid <?php echo $clr; ?>; border-radius:3px; font-weight:700; color:<?php echo $clr; ?>; font-size:8px;" title="<?php echo $st.($ab['keterangan']?': '.$ab['keterangan']:''); ?>">
                                        <?php echo $code; ?>
                                    </span>
                                <?php else: ?>
                                    <span style="color:#334155;">·</span>
                                <?php endif; ?>
                            </td>
                        <?php endfor; ?>
                        <td style="text-align:center; color:#10B981; font-weight:700;"><?php echo $totals['Hadir']; ?></td>
                        <td style="text-align:center; color:#F59E0B; font-weight:700;"><?php echo $totals['Sakit']; ?></td>
                        <td style="text-align:center; color:#3B82F6; font-weight:700;"><?php echo $totals['Izin']; ?></td>
                        <td style="text-align:center; color:#A855F7; font-weight:700;"><?php echo $totals['Cuti']; ?></td>
                        <td style="text-align:center; color:#14B8A6; font-weight:700;"><?php echo $totals['Dinas Luar']; ?></td>
                        <td style="text-align:center; color:#EF4444; font-weight:700;"><?php echo $totals['Alfa']; ?></td>
                        <td style="text-align:center; font-weight:700; color:<?php echo $pct>=80?'#10B981':($pct>=60?'#F59E0B':'#EF4444'); ?>;">
                            <?php echo $total_input > 0 ? $pct.'%' : '-'; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
