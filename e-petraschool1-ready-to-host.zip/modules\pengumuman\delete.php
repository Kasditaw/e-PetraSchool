<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\pengumuman\delete.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    try {
        // Fetch details for logging & attachment delete
        $stmt = $pdo->prepare("SELECT judul, lampiran FROM pengumuman WHERE id = ?");
        $stmt->execute([$id]);
        $ann = $stmt->fetch();

        if ($ann) {
            // Delete file if exists
            if (!empty($ann['lampiran'])) {
                $upload_dir = dirname(dirname(__DIR__)) . '/assets/uploads/pengumuman/';
                if (file_exists($upload_dir . $ann['lampiran'])) {
                    unlink($upload_dir . $ann['lampiran']);
                }
            }

            // Delete record
            $delete_stmt = $pdo->prepare("DELETE FROM pengumuman WHERE id = ?");
            $delete_stmt->execute([$id]);
            
            write_audit_log("Menghapus pengumuman sekolah: " . $ann['judul'] . ".");
        }
    } catch (Exception $e) {
        error_log("Failed to delete announcement: " . $e->getMessage());
    }
}

header("Location: index.php");
exit;
?>
