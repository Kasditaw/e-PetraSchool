<?php
// c:\xampp\htdocs\e-petraschool1\modules\absensi_guru\rekap.php

$page_title = 'Rekap Absensi Guru';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$filter_guru  = isset($_GET['guru_id']) ? intval($_GET['guru_id']) : 0;
$filter_bulan = isset($_GET['bulan'])   ? intval($_GET['bulan'])   : intval(date('m'));
$filter_tahun = isset($_GET['tahun'])   ? intval($_GET['tahun'])   : intval(date('Y'));

$bulan_names = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
$status_colors = ['Hadir'=>'#10B981','Sakit'=>'#F59E0B','Izin'=>'#3B82F6','Cuti'=>'#A855F7','Dinas Luar'=>'#14B8A6','Alfa'=>'#EF4444'];

try {
    $guru_list = $pdo->query("SELECT id, nip, nama_guru, jabatan FROM guru ORDER BY nama_guru ASC")->fetchAll();

    $start_date = "$filter_tahun-".str_pad($filter_bulan,2,'0',STR_PAD_LEFT)."-01";
    $end_date   = "$filter_tahun-".str_pad($filter_bulan,2,'0',STR_PAD_LEFT)."-".cal_days_in_month(CAL_GREGORIAN,$filter_bulan,$filter_tahun);

    $q = "SELECT guru_id, status, COUNT(*) AS jumlah FROM absensi_guru WHERE tanggal BETWEEN ? AND ?";
    $params = [$start_date, $end_date];
    if ($filter_guru) { $q .= " AND guru_id = ?"; $params[] = $filter_guru; }
    $q .= " GROUP BY guru_id, status ORDER BY guru_id, status";
    $stmt = $pdo->prepare($q);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    // Pivot
    $rekap = [];
    foreach ($rows as $r) {
        $gid = $r['guru_id'];
        if (!isset($rekap[$gid])) {
            $rekap[$gid] = ['Hadir'=>0,'Sakit'=>0,'Izin'=>0,'Cuti'=>0,'Dinas Luar'=>0,'Alfa'=>0];
        }
        $rekap[$gid][$r['status']] = intval($r['jumlah']);
    }

} catch (Exception $e) {
    $error_db = $e->getMessage();
    $rekap = [];
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-table-list me-2"></i>Rekap Absensi Guru</h5>
            <p class="text-secondary small mb-0">Ringkasan kehadiran guru — <?php echo $bulan_names[$filter_bulan]; ?> <?php echo $filter_tahun; ?></p>
        </div>
        <div class="d-flex gap-2 no-print">
            <a href="input.php" class="btn btn-gold"><i class="fa-solid fa-clipboard-user me-1"></i> Input Absensi</a>
            <button onclick="window.print()" class="btn btn-outline-custom"><i class="fa-solid fa-print me-1"></i> Cetak</button>
        </div>
    </div>

    <?php if (isset($error_db)): ?>
        <div class="alert alert-danger">Tabel belum tersedia. Jalankan: <a href="<?php echo $base_url; ?>database/migrate_absensi_jadwal.php" class="alert-link">migrate_absensi_jadwal.php</a></div>
    <?php endif; ?>

    <!-- Filter -->
    <form method="GET" class="row g-3 mb-4 align-items-end no-print">
        <div class="col-6 col-md-3">
            <label class="form-label form-label-custom">Guru</label>
            <select name="guru_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua Guru</option>
                <?php foreach ($guru_list as $g): ?>
                    <option value="<?php echo $g['id']; ?>" <?php echo $filter_guru==$g['id']?'selected':''; ?>><?php echo htmlspecialchars($g['nama_guru']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Bulan</label>
            <select name="bulan" class="form-select form-control-custom bg-dark-select text-white">
                <?php for ($m=1;$m<=12;$m++): ?>
                    <option value="<?php echo $m; ?>" <?php echo $filter_bulan==$m?'selected':''; ?>><?php echo $bulan_names[$m]; ?></option>
                <?php endfor; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Tahun</label>
            <input type="number" name="tahun" class="form-control form-control-custom" value="<?php echo $filter_tahun; ?>">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom"><i class="fa-solid fa-filter me-1"></i> Filter</button>
        </div>
    </form>

    <?php
    $display_gurus = $filter_guru ? array_filter($guru_list, fn($g) => $g['id'] == $filter_guru) : $guru_list;
    ?>

    <?php if (!empty($rekap) || !empty($display_gurus)): ?>
    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama Guru</th>
                    <th>NIP</th>
                    <th>Jabatan</th>
                    <th style="text-align:center; color:#10B981;">Hadir</th>
                    <th style="text-align:center; color:#F59E0B;">Sakit</th>
                    <th style="text-align:center; color:#3B82F6;">Izin</th>
                    <th style="text-align:center; color:#A855F7;">Cuti</th>
                    <th style="text-align:center; color:#14B8A6;">Dinas Luar</th>
                    <th style="text-align:center; color:#EF4444;">Alfa</th>
                    <th style="text-align:center;">Total</th>
                    <th style="text-align:center;">% Hadir</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; foreach ($display_gurus as $guru):
                    $r = $rekap[$guru['id']] ?? ['Hadir'=>0,'Sakit'=>0,'Izin'=>0,'Cuti'=>0,'Dinas Luar'=>0,'Alfa'=>0];
                    $total = array_sum($r);
                    $pct = $total > 0 ? round($r['Hadir']/$total*100) : 0;
                    $pct_color = $pct>=80?'#10B981':($pct>=60?'#F59E0B':'#EF4444');
                ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><strong class="text-white"><?php echo htmlspecialchars($guru['nama_guru']); ?></strong></td>
                    <td><span class="font-monospace text-secondary" style="font-size:11px;"><?php echo htmlspecialchars($guru['nip']); ?></span></td>
                    <td style="font-size:12px;"><?php echo htmlspecialchars($guru['jabatan']); ?></td>
                    <td style="text-align:center; font-weight:700; color:#10B981;"><?php echo $r['Hadir']; ?></td>
                    <td style="text-align:center; font-weight:700; color:#F59E0B;"><?php echo $r['Sakit']; ?></td>
                    <td style="text-align:center; font-weight:700; color:#3B82F6;"><?php echo $r['Izin']; ?></td>
                    <td style="text-align:center; font-weight:700; color:#A855F7;"><?php echo $r['Cuti']; ?></td>
                    <td style="text-align:center; font-weight:700; color:#14B8A6;"><?php echo $r['Dinas Luar']; ?></td>
                    <td style="text-align:center; font-weight:700; color:#EF4444;"><?php echo $r['Alfa']; ?></td>
                    <td style="text-align:center;"><?php echo $total; ?></td>
                    <td style="text-align:center;">
                        <div style="display:flex; align-items:center; gap:8px; justify-content:center;">
                            <div style="flex:1; max-width:70px; height:6px; background:rgba(255,255,255,.1); border-radius:99px; overflow:hidden;">
                                <div style="width:<?php echo $pct; ?>%; height:100%; background:<?php echo $pct_color; ?>; border-radius:99px;"></div>
                            </div>
                            <span style="font-weight:700; color:<?php echo $pct_color; ?>; font-size:13px; min-width:38px;"><?php echo $total > 0 ? $pct.'%' : '-'; ?></span>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr style="border-top:2px solid rgba(212,175,55,.3);">
                    <td colspan="4" class="fw-bold text-gold">TOTAL</td>
                    <?php
                    $keys = ['Hadir','Sakit','Izin','Cuti','Dinas Luar','Alfa'];
                    $clrs = ['#10B981','#F59E0B','#3B82F6','#A855F7','#14B8A6','#EF4444'];
                    $tot_all = 0;
                    $tot_hadir = 0;
                    foreach ($keys as $k) {
                        $v = 0;
                        foreach ($display_gurus as $g) { $v += $rekap[$g['id']][$k] ?? 0; }
                        $tot_all += $v;
                        if ($k === 'Hadir') $tot_hadir = $v;
                    }
                    foreach ($keys as $i => $k) {
                        $v = 0; foreach ($display_gurus as $g) { $v += $rekap[$g['id']][$k] ?? 0; }
                        echo "<td style='text-align:center; font-weight:700; color:{$clrs[$i]};'>$v</td>";
                    }
                    $avg = $tot_all > 0 ? round($tot_hadir/$tot_all*100) : 0;
                    $ac = $avg>=80?'#10B981':($avg>=60?'#F59E0B':'#EF4444');
                    ?>
                    <td style="text-align:center; font-weight:700;"><?php echo $tot_all; ?></td>
                    <td style="text-align:center; font-weight:700; color:<?php echo $ac; ?>"><?php echo $tot_all>0?$avg.'%':'-'; ?></td>
                </tr>
            </tfoot>
        </table>
    </div>
    <?php else: ?>
        <div class="text-center py-5">
            <i class="fa-solid fa-inbox" style="font-size:48px; color:rgba(255,255,255,.15);"></i>
            <p class="text-secondary mt-3">Belum ada data absensi guru untuk bulan ini.</p>
        </div>
    <?php endif; ?>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
