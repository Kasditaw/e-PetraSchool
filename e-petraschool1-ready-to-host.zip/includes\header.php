<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\includes\header.php

require_once dirname(__DIR__) . '/config/auth.php';
require_once dirname(__DIR__) . '/config/csrf.php';

// Enforce login on all pages including header except login/forgot password pages
$current_page = basename($_SERVER['SCRIPT_NAME']);
if ($current_page !== 'login.php' && $current_page !== 'forgot-password.php') {
    check_login();
}

// Load dynamic notifications if logged in
$unread_notifs = [];
$notif_count = 0;
if (is_logged_in() && isset($_SESSION['user_id'])) {
    try {
        $stmt_notifs = $pdo->prepare("SELECT * FROM notifikasi WHERE user_id = ? AND is_read = 0 ORDER BY created_at DESC LIMIT 5");
        $stmt_notifs->execute([$_SESSION['user_id']]);
        $unread_notifs = $stmt_notifs->fetchAll();
        $notif_count = count($unread_notifs);
    } catch (Exception $e) {
        $unread_notifs = [];
    }
}

// Dynamically compute the web root URL relative to the server DOCUMENT_ROOT
$project_dir = str_replace('\\', '/', dirname(__DIR__));
$web_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
$base_url = str_replace($web_root, '', $project_dir);
if (empty($base_url)) {
    $base_url = '/';
} else {
    if (substr($base_url, 0, 1) !== '/') {
        $base_url = '/' . $base_url;
    }
    if (substr($base_url, -1) !== '/') {
        $base_url .= '/';
    }
}
// Replace double slashes if any
$base_url = str_replace('//', '/', $base_url);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' : ''; ?>Sistem Manajemen Sekolah - SD Kristen Petra 1</title>
    <!-- Favicon -->
    <link rel="icon" href="https://img.icons8.com/color/48/school.png" type="image/x-icon">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo $base_url; ?>assets/css/style.css?v=<?php echo filemtime(dirname(__DIR__) . '/assets/css/style.css'); ?>">
    <!-- Chart.js CDN -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- SweetAlert2 CDN -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>

    <!-- App Main Frame Layout -->
    <div id="app-frame" class="min-vh-100 d-flex">
        
        <?php if ($current_page !== 'login.php' && $current_page !== 'forgot-password.php'): ?>
            <!-- Sidebar Navigation Include -->
            <?php require_once __DIR__ . '/sidebar.php'; ?>

            <!-- Mobile sidebar overlay -->
            <div class="sidebar-overlay no-print" id="sidebar-overlay" onclick="closeMobileSidebar()"></div>

            <!-- Main Workspace Area -->
            <div class="main-workspace">
                
                <!-- Top Header -->
                <header class="top-header d-flex align-items-center justify-content-between no-print">
                    <div class="d-flex align-items-center gap-3">
                        <button class="btn-menu-toggle d-md-none" id="mobile-sidebar-toggle">
                            <i class="fa-solid fa-bars"></i>
                        </button>
                        <h5 class="mb-0 fw-bold" style="color: var(--text-1); font-size: 17px; letter-spacing: -0.2px;"><?php echo isset($page_title) ? htmlspecialchars($page_title) : 'Dashboard'; ?></h5>
                    </div>

                    <!-- Header Tools -->
                    <div class="d-flex align-items-center gap-3">
                        <!-- Online Status Badge -->
                        <span class="d-flex align-items-center gap-1.5 px-3 py-1 bg-success bg-opacity-10 text-success rounded-pill font-monospace" style="font-size: 11px; font-weight: 700; border: 1px solid rgba(16, 185, 129, 0.15);">
                            <i class="fa-solid fa-circle text-success" style="font-size: 8px;"></i> Online
                        </span>
                        

                        
                        <!-- Notifications bell -->
                        <div class="dropdown position-relative">
                            <button class="btn-icon text-theme-secondary dropdown-toggle" type="button" id="notifDropdown" data-bs-toggle="dropdown" aria-expanded="false" title="Notifikasi" style="border: none; background: transparent;">
                                <i class="fa-regular fa-bell"></i>
                                <?php if ($notif_count > 0): ?>
                                    <span class="position-absolute top-1 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 8px; padding: 2px 4px;"><?php echo $notif_count; ?></span>
                                <?php endif; ?>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end p-2 notif-dropdown-menu" aria-labelledby="notifDropdown" style="width: 280px; margin-top: 10px;">
                                <li class="dropdown-header fw-bold border-bottom pb-1 mb-1" style="color: var(--accent) !important;">Notifikasi Terbaru</li>
                                <?php if ($notif_count > 0): ?>
                                    <?php foreach ($unread_notifs as $n): ?>
                                        <li>
                                            <a class="dropdown-item notif-dropdown-item text-wrap small p-2 border-bottom border-secondary border-opacity-5" href="#" style="font-size: 11.5px; white-space: normal;">
                                                <?php echo $n['pesan']; ?>
                                            </a>
                                        </li>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <li><span class="dropdown-item notif-dropdown-item text-secondary text-center small p-2">Tidak ada notifikasi baru</span></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                        
                        <!-- Profile Dropdown -->
                        <div class="dropdown d-flex align-items-center">
                                <button class="btn btn-link dropdown-toggle text-decoration-none d-flex align-items-center gap-2 border-0 p-0" type="button" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false" style="color: var(--text-1);">
                                    <div class="avatar-letter d-flex align-items-center justify-content-center rounded-circle fw-bold" style="width: 32px; height: 32px; font-size: 13px; background: linear-gradient(135deg, var(--accent) 0%, var(--accent-light) 100%); color: #fff; border: 2px solid rgba(98,87,222,0.3); flex-shrink:0;">
                                        <?php echo strtoupper(substr($_SESSION['nama'] ?? 'P', 0, 1)); ?>
                                    </div>
                                    <span class="d-none d-md-inline small fw-semibold" style="color: var(--text-1);"><?php echo htmlspecialchars($_SESSION['nama'] ?? 'User'); ?></span>
                                </button>
                            <ul class="dropdown-menu dropdown-menu-end profile-dropdown-menu" aria-labelledby="profileDropdown">
                                <li class="px-3 py-2 border-bottom border-secondary border-opacity-10">
                                    <div class="user-name text-truncate" style="max-width: 170px;"><?php echo htmlspecialchars($_SESSION['nama'] ?? 'User'); ?></div>
                                    <span class="user-role text-uppercase"><?php echo htmlspecialchars($_SESSION['role'] ?? 'Role'); ?></span>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="<?php echo $base_url; ?>modules/profile/index.php">
                                        <i class="fa-regular fa-user"></i> Lihat Profil
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="<?php echo $base_url; ?>modules/profile/index.php?action=change_password">
                                        <i class="fa-solid fa-key"></i> Ganti Password
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <a class="dropdown-item text-danger" href="<?php echo $base_url; ?>logout.php">
                                        <i class="fa-solid fa-right-from-bracket"></i> Logout
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </header>

                <!-- Dynamic Tab Content Views -->
                <main class="workspace-content animated-view">
        <?php endif; ?>
