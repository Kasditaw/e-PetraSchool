<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\kelas\create.php

$page_title = 'Tambah Kelas';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';
$success = '';

// Process form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $kode_kelas = strtoupper(trim($_POST['kode_kelas'] ?? ''));
    $nama_kelas = trim($_POST['nama_kelas'] ?? '');
    $wali_kelas_id = $_POST['wali_kelas_id'] !== '' ? intval($_POST['wali_kelas_id']) : null;
    $lokasi_ruangan = trim($_POST['lokasi_ruangan'] ?? '');
    $tingkat = $_POST['tingkat'] ?? '1';
    $kapasitas = isset($_POST['kapasitas']) ? intval($_POST['kapasitas']) : 40;
    $status = $_POST['status'] ?? 'Aktif';

    if (empty($kode_kelas) || empty($nama_kelas) || empty($lokasi_ruangan)) {
        $error = 'Semua field wajib diisi!';
    } else {
        try {
            // Check if code already exists
            $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM kelas WHERE kode_kelas = ?");
            $check_stmt->execute([$kode_kelas]);
            if ($check_stmt->fetchColumn() > 0) {
                $error = "Kode kelas '$kode_kelas' sudah digunakan!";
            } else {
                // Insert new class
                $stmt = $pdo->prepare("INSERT INTO kelas (kode_kelas, nama_kelas, wali_kelas_id, lokasi_ruangan, tingkat, kapasitas, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$kode_kelas, $nama_kelas, $wali_kelas_id, $lokasi_ruangan, $tingkat, $kapasitas, $status]);
                
                write_audit_log("Menambahkan kelas baru: $nama_kelas (Kode: $kode_kelas, Tingkat: $tingkat, Kapasitas: $kapasitas, Status: $status).");
                $success = 'Data kelas berhasil ditambahkan!';
                
                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Data kelas berhasil ditambahkan!', 'success').then(() => {
                            window.location.href = 'index.php';
                        });
                    });
                </script>";
            }
        } catch (Exception $e) {
            $error = 'Gagal menyimpan data: ' . $e->getMessage();
        }
    }
}

// Fetch all teachers for Wali Kelas dropdown
try {
    $teachers_stmt = $pdo->query("SELECT id, nip, nama_guru FROM guru ORDER BY nama_guru ASC");
    $teachers = $teachers_stmt->fetchAll();
} catch (Exception $e) {
    $teachers = [];
}
?>

<div class="glass-card" style="max-width: 600px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-plus me-2"></i> Tambah Kelas Baru</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="create.php">
        <?php csrf_input(); ?>

        <div class="mb-3">
            <label for="kode_kelas" class="form-label form-label-custom">Kode Kelas</label>
            <input type="text" name="kode_kelas" id="kode_kelas" class="form-control form-control-custom" placeholder="Contoh: K4A" required>
        </div>

        <div class="mb-3">
            <label for="nama_kelas" class="form-label form-label-custom">Nama Kelas</label>
            <input type="text" name="nama_kelas" id="nama_kelas" class="form-control form-control-custom" placeholder="Contoh: Kelas 4A" required>
        </div>

        <div class="mb-3">
            <label for="tingkat" class="form-label form-label-custom">Tingkat</label>
            <select name="tingkat" id="tingkat" class="form-select form-control-custom bg-dark-select text-white" required>
                <option value="1">Kelas 1</option>
                <option value="2">Kelas 2</option>
                <option value="3">Kelas 3</option>
                <option value="4">Kelas 4</option>
                <option value="5">Kelas 5</option>
                <option value="6">Kelas 6</option>
            </select>
        </div>

        <div class="mb-3">
            <label for="wali_kelas_id" class="form-label form-label-custom">Guru Kelas / Wali Kelas</label>
            <select name="wali_kelas_id" id="wali_kelas_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Pilih Guru Kelas / Wali Kelas (Opsional)...</option>
                <?php foreach ($teachers as $teacher): ?>
                    <option value="<?php echo $teacher['id']; ?>"><?php echo htmlspecialchars($teacher['nama_guru']) . ' (' . htmlspecialchars($teacher['nip']) . ')'; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="kapasitas" class="form-label form-label-custom">Kapasitas</label>
            <input type="number" name="kapasitas" id="kapasitas" class="form-control form-control-custom" placeholder="Contoh: 40" value="40" required>
        </div>

        <div class="mb-3">
            <label for="status" class="form-label form-label-custom">Status</label>
            <select name="status" id="status" class="form-select form-control-custom bg-dark-select text-white" required>
                <option value="Aktif">Aktif</option>
                <option value="Nonaktif">Nonaktif</option>
            </select>
        </div>

        <div class="mb-4">
            <label for="lokasi_ruangan" class="form-label form-label-custom">Lokasi Ruangan</label>
            <input type="text" name="lokasi_ruangan" id="lokasi_ruangan" class="form-control form-control-custom" placeholder="Contoh: Gedung B Lantai 2 R.202" required>
        </div>

        <div class="d-flex justify-content-end gap-2">
            <a href="index.php" class="btn btn-outline-custom">Batal</a>
            <button type="submit" class="btn btn-gold">Simpan <i class="fa-solid fa-check ms-1"></i></button>
        </div>
    </form>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
