<?php
// c:\xampp\htdocs\e-petraschool1\modules\mata_pelajaran\index.php

$page_title = 'Data Mata Pelajaran';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$error = '';
$success = '';

// Handle subject creation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $kode_mapel = strtoupper(trim($_POST['kode_mapel'] ?? ''));
    $nama_mapel = trim($_POST['nama_mapel'] ?? '');
    $jenjang = trim($_POST['jenjang'] ?? '');
    $status = $_POST['status'] ?? 'Aktif';

    if (empty($kode_mapel) || empty($nama_mapel) || empty($jenjang)) {
        $error = 'Semua field wajib diisi!';
    } else {
        try {
            // Check if code already exists
            $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM mata_pelajaran WHERE kode_mapel = ?");
            $check_stmt->execute([$kode_mapel]);
            if ($check_stmt->fetchColumn() > 0) {
                $error = "Kode mata pelajaran '$kode_mapel' sudah digunakan!";
            } else {
                // Insert new subject
                $stmt = $pdo->prepare("INSERT INTO mata_pelajaran (kode_mapel, nama_mapel, jenjang, status) VALUES (?, ?, ?, ?)");
                $stmt->execute([$kode_mapel, $nama_mapel, $jenjang, $status]);
                
                write_audit_log("Menambahkan mata pelajaran baru: $nama_mapel (Kode: $kode_mapel).");
                
                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Mata pelajaran berhasil ditambahkan!', 'success').then(() => {
                            window.location.href = 'index.php';
                        });
                    });
                </script>";
            }
        } catch (Exception $e) {
            $error = 'Gagal menyimpan data: ' . $e->getMessage();
        }
    }
}

// Fetch subjects
try {
    $query = "SELECT * FROM mata_pelajaran WHERE 1=1";
    $params = [];
    
    if ($search !== '') {
        $query .= " AND (nama_mapel LIKE :search OR kode_mapel LIKE :search OR jenjang LIKE :search)";
        $params['search'] = "%$search%";
    }
    
    $query .= " ORDER BY kode_mapel ASC";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $subjects = $stmt->fetchAll();
} catch (Exception $e) {
    echo '<div class="alert alert-danger">Gagal memuat data mata pelajaran: ' . $e->getMessage() . '</div>';
}
?>

<div class="row g-4">
    <!-- Col-lg-4: Input Form -->
    <div class="col-lg-4 no-print">
        <div class="glass-card">
            <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-plus me-2"></i> Input Mapel Baru</h5>
            
            <?php if ($error !== ''): ?>
                <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
                    <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="index.php">
                <?php csrf_input(); ?>

                <div class="mb-3">
                    <label for="kode_mapel" class="form-label form-label-custom">Kode Mapel</label>
                    <input type="text" name="kode_mapel" id="kode_mapel" class="form-control form-control-custom" placeholder="Contoh: MP010" required>
                </div>

                <div class="mb-3">
                    <label for="nama_mapel" class="form-label form-label-custom">Nama Mata Pelajaran</label>
                    <input type="text" name="nama_mapel" id="nama_mapel" class="form-control form-control-custom" placeholder="Contoh: Matematika" required>
                </div>

                <div class="mb-3">
                    <label for="jenjang" class="form-label form-label-custom">Jenjang / Sasaran Kelas</label>
                    <input type="text" name="jenjang" id="jenjang" class="form-control form-control-custom" placeholder="Contoh: Kelas 1-6" required>
                </div>

                <div class="mb-4">
                    <label for="status" class="form-label form-label-custom">Status</label>
                    <select name="status" id="status" class="form-select form-control-custom bg-dark-select text-white">
                        <option value="Aktif">Aktif</option>
                        <option value="Tidak Aktif">Tidak Aktif</option>
                    </select>
                </div>

                <button type="submit" class="btn btn-gold w-100">Simpan Mapel <i class="fa-solid fa-check ms-1"></i></button>
            </form>
        </div>
    </div>

    <!-- Col-lg-8: Subject List Table -->
    <div class="col-lg-8">
        <div class="glass-card">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
                <div>
                    <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-book me-2"></i> Daftar Mata Pelajaran</h5>
                    <p class="text-secondary small mb-0">Kelola mata pelajaran dan jenjang ajar SD Kristen Petra 1.</p>
                </div>
            </div>

            <!-- Search Form -->
            <form method="GET" action="index.php" class="row g-2 mb-4 no-print">
                <div class="col-12 col-md-6">
                    <div class="search-input-container">
                        <i class="fa-solid fa-magnifying-glass"></i>
                        <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari kode, nama mapel, jenjang..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-outline-custom">Cari</button>
                </div>
                <?php if ($search !== ''): ?>
                    <div class="col-auto">
                        <a href="index.php" class="btn btn-outline-danger">Reset</a>
                    </div>
                <?php endif; ?>
            </form>

            <div class="table-responsive">
                <table class="table table-custom">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Kode Mapel</th>
                            <th>Nama Mata Pelajaran</th>
                            <th>Jenjang Kelas</th>
                            <th>Status</th>
                            <th class="no-print">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($subjects) > 0): ?>
                            <?php $no = 1; foreach ($subjects as $sub): ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td><span class="badge badge-secondary"><?php echo htmlspecialchars($sub['kode_mapel']); ?></span></td>
                                    <td class="fw-bold text-white"><?php echo htmlspecialchars($sub['nama_mapel']); ?></td>
                                    <td><?php echo htmlspecialchars($sub['jenjang']); ?></td>
                                    <td>
                                        <span class="badge <?php echo $sub['status'] === 'Aktif' ? 'badge-success' : 'badge-danger'; ?>">
                                            <?php echo htmlspecialchars($sub['status']); ?>
                                        </span>
                                    </td>
                                    <td class="no-print">
                                        <div class="d-flex gap-2">
                                            <a href="edit.php?id=<?php echo $sub['id']; ?>" class="btn btn-xs btn-outline-warning" title="Edit"><i class="fa-solid fa-pen"></i> Edit</a>
                                            <button onclick="confirmDelete('delete.php?id=<?php echo $sub['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i> Hapus</button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-secondary py-4">Data mata pelajaran tidak ditemukan.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
function confirmDelete(url) {
    Swal.fire({
        title: 'Apakah Anda yakin?',
        text: "Data yang dihapus tidak dapat dikembalikan!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = url;
        }
    });
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
