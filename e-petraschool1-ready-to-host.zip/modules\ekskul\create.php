<?php
// c:\xampp\htdocs\e-petraschool1\modules\ekskul\create.php

$page_title = 'Tambah Ekstrakurikuler';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin','Admin']);

$error   = '';
$filter_ta = isset($_GET['tahun_ajaran_id']) ? intval($_GET['tahun_ajaran_id']) : 0;

try {
    $guru_list = $pdo->query("SELECT id, nama_guru, nip FROM guru ORDER BY nama_guru ASC")->fetchAll();
    $ta_list   = $pdo->query("SELECT id, tahun_ajaran, status FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();
    if (!$filter_ta) { foreach ($ta_list as $t) { if ($t['status']==='Aktif') { $filter_ta = $t['id']; break; } } }
} catch (Exception $e) { $error = $e->getMessage(); }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($error)) {
    check_csrf_request();
    $nama       = trim($_POST['nama'] ?? '');
    $deskripsi  = trim($_POST['deskripsi'] ?? '');
    $pembina_id = intval($_POST['pembina_id'] ?? 0) ?: null;
    $hari       = trim($_POST['hari'] ?? '') ?: null;
    $jam_mulai  = trim($_POST['jam_mulai'] ?? '') ?: null;
    $jam_selesai= trim($_POST['jam_selesai'] ?? '') ?: null;
    $kuota      = intval($_POST['kuota'] ?? 30);
    $status     = trim($_POST['status'] ?? 'Aktif');
    $ta_id      = intval($_POST['tahun_ajaran_id'] ?? 0);

    if (!$nama || !$ta_id) { $error = 'Nama ekskul dan tahun ajaran wajib diisi!'; }
    else {
        try {
            $pdo->prepare("INSERT INTO ekskul (nama,deskripsi,pembina_id,hari,jam_mulai,jam_selesai,kuota,status,tahun_ajaran_id) VALUES (?,?,?,?,?,?,?,?,?)")
                ->execute([$nama,$deskripsi,$pembina_id,$hari,$jam_mulai,$jam_selesai,$kuota,$status,$ta_id]);
            write_audit_log("Menambahkan ekstrakurikuler baru: $nama.");
            echo "<script>document.addEventListener('DOMContentLoaded',function(){Swal.fire('Berhasil!','Ekstrakurikuler berhasil ditambahkan.','success').then(()=>{window.location.href='index.php?tahun_ajaran_id=$ta_id';});});</script>";
        } catch (Exception $e) { $error = 'Gagal: ' . $e->getMessage(); }
    }
}
?>
<div class="glass-card" style="max-width:720px;margin:0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-star me-2"></i>Tambah Ekstrakurikuler</h5>
    <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
        <div class="row g-3">
            <div class="col-md-8">
                <label class="form-label form-label-custom">Nama Ekskul <span class="text-danger">*</span></label>
                <input type="text" name="nama" class="form-control form-control-custom" required maxlength="100" value="<?php echo htmlspecialchars($_POST['nama']??''); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label form-label-custom">Tahun Ajaran <span class="text-danger">*</span></label>
                <select name="tahun_ajaran_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <?php foreach ($ta_list as $ta): ?><option value="<?php echo $ta['id']; ?>" <?php echo $filter_ta==$ta['id']?'selected':''; ?>><?php echo htmlspecialchars($ta['tahun_ajaran']); ?><?php echo $ta['status']==='Aktif'?' (Aktif)':''; ?></option><?php endforeach; ?>
                </select>
            </div>
            <div class="col-12">
                <label class="form-label form-label-custom">Deskripsi</label>
                <textarea name="deskripsi" class="form-control form-control-custom" rows="3"><?php echo htmlspecialchars($_POST['deskripsi']??''); ?></textarea>
            </div>
            <div class="col-md-6">
                <label class="form-label form-label-custom">Pembina</label>
                <select name="pembina_id" class="form-select form-control-custom bg-dark-select text-white">
                    <option value="">-- Pilih Pembina (Opsional) --</option>
                    <?php foreach ($guru_list as $g): ?><option value="<?php echo $g['id']; ?>"><?php echo htmlspecialchars($g['nama_guru']); ?></option><?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label form-label-custom">Kuota</label>
                <input type="number" name="kuota" class="form-control form-control-custom" value="30" min="1" max="200">
            </div>
            <div class="col-md-3">
                <label class="form-label form-label-custom">Status</label>
                <select name="status" class="form-select form-control-custom bg-dark-select text-white">
                    <option value="Aktif">Aktif</option>
                    <option value="Nonaktif">Nonaktif</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label form-label-custom">Hari Latihan</label>
                <select name="hari" class="form-select form-control-custom bg-dark-select text-white">
                    <option value="">-- Pilih (Opsional) --</option>
                    <?php foreach (['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'] as $h): ?><option value="<?php echo $h; ?>"><?php echo $h; ?></option><?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label form-label-custom">Jam Mulai</label>
                <input type="time" name="jam_mulai" class="form-control form-control-custom" value="14:00">
            </div>
            <div class="col-md-4">
                <label class="form-label form-label-custom">Jam Selesai</label>
                <input type="time" name="jam_selesai" class="form-control form-control-custom" value="16:00">
            </div>
        </div>
        <div class="d-flex gap-3 mt-4">
            <button type="submit" class="btn btn-gold"><i class="fa-solid fa-floppy-disk me-1"></i> Simpan</button>
            <a href="index.php?tahun_ajaran_id=<?php echo $filter_ta; ?>" class="btn btn-outline-custom">Batal</a>
        </div>
    </form>
</div>
<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
