<?php
// c:\xampp\htdocs\e-petraschool1\modules\absensi_guru\input.php

$page_title = 'Input Absensi Guru';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error   = '';
$success = '';

$filter_tanggal = isset($_GET['tanggal']) ? $_GET['tanggal'] : date('Y-m-d');
$filter_bulan   = isset($_GET['bulan'])   ? intval($_GET['bulan'])   : intval(date('m'));
$filter_tahun   = isset($_GET['tahun'])   ? intval($_GET['tahun'])   : intval(date('Y'));

$statuses = ['Hadir','Sakit','Izin','Cuti','Dinas Luar','Alfa'];
$status_colors = ['Hadir'=>'#10B981','Sakit'=>'#F59E0B','Izin'=>'#3B82F6','Cuti'=>'#A855F7','Dinas Luar'=>'#14B8A6','Alfa'=>'#EF4444'];

try {
    $guru_list = $pdo->query("SELECT id, nip, nama_guru, jabatan FROM guru ORDER BY nama_guru ASC")->fetchAll();

    // Existing records for this date
    $ex_stmt = $pdo->prepare("SELECT guru_id, status, keterangan FROM absensi_guru WHERE tanggal = ?");
    $ex_stmt->execute([$filter_tanggal]);
    $existing = [];
    foreach ($ex_stmt->fetchAll() as $e) {
        $existing[$e['guru_id']] = ['status' => $e['status'], 'keterangan' => $e['keterangan']];
    }

} catch (Exception $e) {
    $error = $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($error)) {
    check_csrf_request();

    $tanggal = $_POST['tanggal'] ?? '';
    $absensi = $_POST['absensi'] ?? [];

    if (!$tanggal || empty($absensi)) {
        $error = 'Tanggal dan data absensi wajib diisi!';
    } else {
        try {
            $ins = $pdo->prepare("
                INSERT INTO absensi_guru (guru_id, tanggal, status, keterangan, dicatat_oleh)
                VALUES (?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE status=VALUES(status), keterangan=VALUES(keterangan), dicatat_oleh=VALUES(dicatat_oleh)
            ");
            $saved = 0;
            foreach ($absensi as $guru_id => $data) {
                $st  = $data['status'] ?? 'Hadir';
                $ket = trim($data['keterangan'] ?? '');
                $ins->execute([intval($guru_id), $tanggal, $st, $ket, $_SESSION['user_id']]);
                $saved++;
            }
            write_audit_log("Input absensi guru: $saved guru pada tanggal $tanggal.");
            $success = "Absensi $saved guru berhasil disimpan!";

            // Reload existing
            $ex_stmt->execute([$tanggal]);
            $existing = [];
            foreach ($ex_stmt->fetchAll() as $e) {
                $existing[$e['guru_id']] = ['status' => $e['status'], 'keterangan' => $e['keterangan']];
            }
        } catch (Exception $e) {
            $error = 'Gagal menyimpan: ' . $e->getMessage();
        }
    }
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-clipboard-user me-2"></i>Input Absensi Guru</h5>
            <p class="text-secondary small mb-0">Catat kehadiran semua guru pada tanggal yang dipilih.</p>
        </div>
        <a href="index.php" class="btn btn-outline-custom no-print"><i class="fa-solid fa-arrow-left me-1"></i> Kembali</a>
    </div>

    <?php if ($error):   ?><div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <?php if ($success): ?><div class="alert alert-success"><i class="fa-solid fa-circle-check me-2"></i><?php echo htmlspecialchars($success); ?></div><?php endif; ?>

    <!-- Date picker -->
    <form method="GET" action="input.php" class="row g-3 mb-4 align-items-end no-print">
        <div class="col-6 col-md-3">
            <label class="form-label form-label-custom">Tanggal <span class="text-danger">*</span></label>
            <input type="date" name="tanggal" class="form-control form-control-custom" value="<?php echo htmlspecialchars($filter_tanggal); ?>" required>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom"><i class="fa-solid fa-search me-1"></i> Tampilkan</button>
        </div>
    </form>

    <!-- Quick set all -->
    <div class="d-flex gap-2 mb-3 flex-wrap no-print">
        <?php foreach ($statuses as $st): ?>
            <button type="button" onclick="setAll('<?php echo $st; ?>')"
                class="btn btn-sm"
                style="background:<?php echo $status_colors[$st]; ?>22; color:<?php echo $status_colors[$st]; ?>; border:1px solid <?php echo $status_colors[$st]; ?>; font-size:11px;">
                Semua <?php echo $st; ?>
            </button>
        <?php endforeach; ?>
        <span class="text-secondary small align-self-center">
            <i class="fa-solid fa-calendar-day me-1"></i>
            <strong class="text-white"><?php echo date('l, d F Y', strtotime($filter_tanggal)); ?></strong>
            <?php if (!empty($existing)): ?><span class="text-warning ms-2"><i class="fa-solid fa-pencil me-1"></i>Data ada (akan ditimpa)</span><?php endif; ?>
        </span>
    </div>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
        <input type="hidden" name="tanggal" value="<?php echo htmlspecialchars($filter_tanggal); ?>">

        <div class="table-responsive">
            <table class="table table-custom">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama Guru</th>
                        <th>NIP</th>
                        <th>Jabatan</th>
                        <?php foreach ($statuses as $st): ?>
                            <th style="text-align:center; color:<?php echo $status_colors[$st]; ?>;"><?php echo $st; ?></th>
                        <?php endforeach; ?>
                        <th>Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach ($guru_list as $guru):
                        $cur_status = $existing[$guru['id']]['status'] ?? 'Hadir';
                        $cur_ket    = $existing[$guru['id']]['keterangan'] ?? '';
                    ?>
                    <tr id="row-<?php echo $guru['id']; ?>">
                        <td><?php echo $no++; ?></td>
                        <td><strong class="text-white"><?php echo htmlspecialchars($guru['nama_guru']); ?></strong></td>
                        <td><span class="font-monospace text-secondary" style="font-size:11px;"><?php echo htmlspecialchars($guru['nip']); ?></span></td>
                        <td><span class="text-secondary" style="font-size:12px;"><?php echo htmlspecialchars($guru['jabatan']); ?></span></td>
                        <?php foreach ($statuses as $st):
                            $clr = $status_colors[$st];
                        ?>
                        <td style="text-align:center;">
                            <label style="cursor:pointer;">
                                <input type="radio"
                                       name="absensi[<?php echo $guru['id']; ?>][status]"
                                       value="<?php echo $st; ?>"
                                       class="guru-radio d-none"
                                       data-guru="<?php echo $guru['id']; ?>"
                                       data-status="<?php echo $st; ?>"
                                       <?php echo $cur_status === $st ? 'checked' : ''; ?>
                                       onchange="highlightRow(<?php echo $guru['id']; ?>, '<?php echo $st; ?>', '<?php echo $clr; ?>')">
                                <span class="guru-status-btn" id="gbtn-<?php echo $guru['id']; ?>-<?php echo $st; ?>"
                                      style="display:inline-flex; align-items:center; justify-content:center; width:32px; height:28px; border-radius:6px; border:2px solid <?php echo $cur_status===$st ? $clr : 'rgba(255,255,255,.1)'; ?>; background:<?php echo $cur_status===$st ? $clr.'33' : 'transparent'; ?>; color:<?php echo $cur_status===$st ? $clr : '#64748B'; ?>; font-weight:700; font-size:10px; transition:all .15s;">
                                    <?php echo substr($st,0,1); ?>
                                </span>
                            </label>
                        </td>
                        <?php endforeach; ?>
                        <td>
                            <input type="text" name="absensi[<?php echo $guru['id']; ?>][keterangan]"
                                   class="form-control form-control-custom" style="font-size:12px; padding:5px 10px;"
                                   placeholder="Opsional..." maxlength="100"
                                   value="<?php echo htmlspecialchars($cur_ket); ?>">
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="d-flex gap-3 mt-3 no-print">
            <button type="submit" class="btn btn-gold"><i class="fa-solid fa-floppy-disk me-1"></i> Simpan Absensi Guru</button>
            <a href="index.php" class="btn btn-outline-custom">Lihat Rekap</a>
        </div>
    </form>
</div>

<script>
const statusColors = <?php echo json_encode($status_colors); ?>;

function highlightRow(guruId, status, color) {
    <?php foreach ($statuses as $st): ?>
    {
        const btn = document.getElementById(`gbtn-${guruId}-<?php echo $st; ?>`);
        if (!btn) return;
        const c = statusColors['<?php echo $st; ?>'];
        if ('<?php echo $st; ?>' === status) {
            btn.style.borderColor = c; btn.style.background = c+'33'; btn.style.color = c;
        } else {
            btn.style.borderColor = 'rgba(255,255,255,.1)'; btn.style.background = 'transparent'; btn.style.color = '#64748B';
        }
    }
    <?php endforeach; ?>
}

function setAll(status) {
    document.querySelectorAll('.guru-radio').forEach(r => {
        if (r.getAttribute('data-status') === status) {
            r.checked = true;
            const guruId = r.getAttribute('data-guru');
            highlightRow(guruId, status, statusColors[status]);
        }
    });
}

// Init colors on load
document.querySelectorAll('.guru-radio:checked').forEach(r => {
    const guruId = r.getAttribute('data-guru');
    highlightRow(guruId, r.value, statusColors[r.value]);
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
