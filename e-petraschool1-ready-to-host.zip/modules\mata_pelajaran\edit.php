<?php
// c:\xampp\htdocs\e-petraschool1\modules\mata_pelajaran\edit.php

$page_title = 'Edit Mata Pelajaran';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';

try {
    $stmt = $pdo->prepare("SELECT * FROM mata_pelajaran WHERE id = ?");
    $stmt->execute([$id]);
    $subject = $stmt->fetch();
    
    if (!$subject) {
        die('<div class="alert alert-danger">Data mata pelajaran tidak ditemukan!</div>');
    }
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $kode_mapel = strtoupper(trim($_POST['kode_mapel'] ?? ''));
    $nama_mapel = trim($_POST['nama_mapel'] ?? '');
    $jenjang = trim($_POST['jenjang'] ?? '');
    $status = $_POST['status'] ?? 'Aktif';

    if (empty($kode_mapel) || empty($nama_mapel) || empty($jenjang)) {
        $error = 'Semua field wajib diisi!';
    } else {
        try {
            // Check duplicate code
            $chk = $pdo->prepare("SELECT COUNT(*) FROM mata_pelajaran WHERE kode_mapel = ? AND id != ?");
            $chk->execute([$kode_mapel, $id]);
            if ($chk->fetchColumn() > 0) {
                $error = "Kode mapel '$kode_mapel' sudah digunakan oleh mapel lain!";
            } else {
                $stmt = $pdo->prepare("UPDATE mata_pelajaran SET kode_mapel = ?, nama_mapel = ?, jenjang = ?, status = ? WHERE id = ?");
                $stmt->execute([$kode_mapel, $nama_mapel, $jenjang, $status, $id]);
                
                write_audit_log("Mengubah data mata pelajaran: $nama_mapel (Kode: $kode_mapel).");
                
                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Mata pelajaran berhasil diubah!', 'success').then(() => {
                            window.location.href = 'index.php';
                        });
                    });
                </script>";
            }
        } catch (Exception $e) {
            $error = 'Error database: ' . $e->getMessage();
        }
    }
}
?>

<div class="glass-card" style="max-width: 600px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-pen me-2"></i> Edit Mata Pelajaran</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="edit.php?id=<?php echo $id; ?>">
        <?php csrf_input(); ?>

        <div class="mb-3">
            <label for="kode_mapel" class="form-label form-label-custom">Kode Mapel</label>
            <input type="text" name="kode_mapel" id="kode_mapel" class="form-control form-control-custom" value="<?php echo htmlspecialchars($subject['kode_mapel']); ?>" required>
        </div>

        <div class="mb-3">
            <label for="nama_mapel" class="form-label form-label-custom">Nama Mata Pelajaran</label>
            <input type="text" name="nama_mapel" id="nama_mapel" class="form-control form-control-custom" value="<?php echo htmlspecialchars($subject['nama_mapel']); ?>" required>
        </div>

        <div class="mb-3">
            <label for="jenjang" class="form-label form-label-custom">Jenjang / Sasaran Kelas</label>
            <input type="text" name="jenjang" id="jenjang" class="form-control form-control-custom" value="<?php echo htmlspecialchars($subject['jenjang']); ?>" required>
        </div>

        <div class="mb-4">
            <label for="status" class="form-label form-label-custom">Status</label>
            <select name="status" id="status" class="form-select form-control-custom bg-dark-select text-white">
                <option value="Aktif" <?php echo $subject['status'] === 'Aktif' ? 'selected' : ''; ?>>Aktif</option>
                <option value="Tidak Aktif" <?php echo $subject['status'] === 'Tidak Aktif' ? 'selected' : ''; ?>>Tidak Aktif</option>
            </select>
        </div>

        <div class="d-flex justify-content-end gap-2">
            <a href="index.php" class="btn btn-outline-custom">Batal</a>
            <button type="submit" class="btn btn-gold">Simpan Perubahan <i class="fa-solid fa-check ms-1"></i></button>
        </div>
    </form>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
