<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\inventaris\create.php

$page_title = 'Tambah Aset Inventaris';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $kode_barang = strtoupper(trim($_POST['kode_barang'] ?? ''));
    $nama_barang = trim($_POST['nama_barang'] ?? '');
    $kategori_id = intval($_POST['kategori_id'] ?? 0);
    $merk = trim($_POST['merk'] ?? '');
    $jumlah = intval($_POST['jumlah'] ?? 1);
    $kondisi = $_POST['kondisi'] ?? 'Baik';
    $lokasi_nama = trim($_POST['lokasi_nama'] ?? '');
    $ruangan_id = null;
    if ($lokasi_nama !== '') {
        // Try to find existing room by name
        $room_chk = $pdo->prepare("SELECT id FROM ruangan WHERE LOWER(nama_ruangan) = LOWER(?) LIMIT 1");
        $room_chk->execute([$lokasi_nama]);
        $existing_room = $room_chk->fetchColumn();
        if ($existing_room) {
            $ruangan_id = intval($existing_room);
        } else {
            // Auto-create the room
            $kode_auto = 'RG' . date('ymd') . rand(10, 99);
            $ins_room = $pdo->prepare("INSERT INTO ruangan (kode_ruangan, nama_ruangan, lantai, kapasitas, kondisi) VALUES (?, ?, '1', 0, 'Baik')");
            $ins_room->execute([$kode_auto, $lokasi_nama]);
            $ruangan_id = intval($pdo->lastInsertId());
        }
    }
    $tanggal_beli = date('Y-m-d');
    $harga = 0.00;
    $sumber_dana = trim($_POST['sumber_dana'] ?? '');

    // File upload
    $foto_name = null;
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['foto']['tmp_name'];
        $file_name = $_FILES['foto']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed_exts = ['jpg', 'jpeg', 'png'];
        $mime_type = mime_content_type($file_tmp);
        $allowed_mimes = ['image/jpeg', 'image/png', 'image/pjpeg'];
        
        if (in_array($file_ext, $allowed_exts) && in_array($mime_type, $allowed_mimes)) {
            $upload_dir = dirname(dirname(__DIR__)) . '/assets/uploads/inventaris/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $foto_name = 'asset_' . $kode_barang . '_' . time() . '.' . $file_ext;
            if (move_uploaded_file($file_tmp, $upload_dir . $foto_name)) {
                // Success
            } else {
                $error = 'Gagal menyimpan foto aset.';
            }
        } else {
            $error = 'Format file foto salah. Hanya menerima JPG, JPEG, atau PNG.';
        }
    }

    if ($error === '') {
        if (empty($nama_barang) || $kategori_id === 0 || empty($sumber_dana)) {
            $error = 'Field Nama Barang, Kategori, dan Sumber Dana wajib diisi!';
        } else {
            try {
                // Auto generate kode_barang if empty
                if (empty($kode_barang)) {
                    $cat_stmt = $pdo->prepare("SELECT kode_kategori FROM kategori_barang WHERE id = ?");
                    $cat_stmt->execute([$kategori_id]);
                    $cat_code = $cat_stmt->fetchColumn() ?: 'GEN';
                    $kode_barang = 'INV/' . $cat_code . '/' . date('Y') . '/' . sprintf('%03d', rand(1, 999));
                }

                // Check duplicate code
                $chk = $pdo->prepare("SELECT COUNT(*) FROM inventaris WHERE kode_barang = ?");
                $chk->execute([$kode_barang]);
                if ($chk->fetchColumn() > 0) {
                    $error = "Kode barang '$kode_barang' sudah terdaftar!";
                } else {
                    $qr_code_value = $kode_barang;

                    $tipe_model = trim($_POST['tipe_model'] ?? '');
                    $nomor_seri = trim($_POST['nomor_seri'] ?? '');
                    $tahun_perolehan = intval($_POST['tahun_perolehan'] ?? date('Y'));
                    
                    $sn_cpu = trim($_POST['sn_cpu'] ?? '');
                    $sn_monitor = trim($_POST['sn_monitor'] ?? '');
                    $sn_keyboard = trim($_POST['sn_keyboard'] ?? '');
                    $sn_mouse = trim($_POST['sn_mouse'] ?? '');

                    $kode_cpu = trim($_POST['kode_cpu'] ?? '');
                    $kode_monitor = trim($_POST['kode_monitor'] ?? '');
                    $kode_keyboard = trim($_POST['kode_keyboard'] ?? '');
                    $kode_mouse = trim($_POST['kode_mouse'] ?? '');

                    // Upload files (Nota & Garansi)
                    $nota_name = null;
                    if (isset($_FILES['nota_pembelian']) && $_FILES['nota_pembelian']['error'] === UPLOAD_ERR_OK) {
                        $file_tmp = $_FILES['nota_pembelian']['tmp_name'];
                        $file_name = $_FILES['nota_pembelian']['name'];
                        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                        $upload_dir = dirname(dirname(__DIR__)) . '/assets/uploads/inventaris/docs/';
                        if (!is_dir($upload_dir)) {
                            mkdir($upload_dir, 0777, true);
                        }
                        $nota_name = 'nota_' . str_replace('/', '_', $kode_barang) . '_' . time() . '.' . $file_ext;
                        move_uploaded_file($file_tmp, $upload_dir . $nota_name);
                    }

                    $garansi_name = null;
                    if (isset($_FILES['dokumen_garansi']) && $_FILES['dokumen_garansi']['error'] === UPLOAD_ERR_OK) {
                        $file_tmp = $_FILES['dokumen_garansi']['tmp_name'];
                        $file_name = $_FILES['dokumen_garansi']['name'];
                        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
                        $upload_dir = dirname(dirname(__DIR__)) . '/assets/uploads/inventaris/docs/';
                        if (!is_dir($upload_dir)) {
                            mkdir($upload_dir, 0777, true);
                        }
                        $garansi_name = 'garansi_' . str_replace('/', '_', $kode_barang) . '_' . time() . '.' . $file_ext;
                        move_uploaded_file($file_tmp, $upload_dir . $garansi_name);
                    }

                    // Insert asset
                    $stmt = $pdo->prepare("INSERT INTO inventaris (kode_barang, nama_barang, kategori_id, merk, tipe_model, nomor_seri, tahun_perolehan, jumlah, kondisi, ruangan_id, tanggal_beli, harga, sumber_dana, foto_barang, qr_code, nota_pembelian, dokumen_garansi, sn_cpu, sn_monitor, sn_keyboard, sn_mouse, kode_cpu, kode_monitor, kode_keyboard, kode_mouse) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$kode_barang, $nama_barang, $kategori_id, $merk, $tipe_model, $nomor_seri, $tahun_perolehan, $jumlah, $kondisi, $ruangan_id, $tanggal_beli, $harga, $sumber_dana, $foto_name, $qr_code_value, $nota_name, $garansi_name, $sn_cpu, $sn_monitor, $sn_keyboard, $sn_mouse, $kode_cpu, $kode_monitor, $kode_keyboard, $kode_mouse]);
                    
                    $last_id = $pdo->lastInsertId();
                    
                    // Write to history log
                    $insert_hist = $pdo->prepare("INSERT INTO histori_inventaris (inventaris_id, aktivitas, pengguna, keterangan) VALUES (?, 'Pengadaan', ?, ?)");
                    $insert_hist->execute([$last_id, $_SESSION['nama'] ?? 'Admin', "Pengadaan aset baru: $nama_barang sebanyak $jumlah unit."]);

                    write_audit_log("Menambahkan data aset inventaris baru: $nama_barang (Kode: $kode_barang).");

                    echo "<script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire('Berhasil', 'Data aset berhasil ditambahkan!', 'success').then(() => {
                                window.location.href = 'index.php';
                            });
                        });
                    </script>";
                }
            } catch (Exception $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

// Fetch categories and rooms
try {
    $categories = $pdo->query("SELECT id, nama_kategori FROM kategori_barang ORDER BY nama_kategori ASC")->fetchAll();
    $rooms = $pdo->query("SELECT id, kode_ruangan, nama_ruangan FROM ruangan ORDER BY nama_ruangan ASC")->fetchAll();
} catch (Exception $e) {
    $categories = [];
    $rooms = [];
}

// Common room suggestions
$room_suggestions = [
    'Ruang Kelas 1A', 'Ruang Kelas 1B', 'Ruang Kelas 2A', 'Ruang Kelas 2B',
    'Ruang Kelas 3A', 'Ruang Kelas 3B', 'Ruang Kelas 4A', 'Ruang Kelas 4B',
    'Ruang Kelas 5A', 'Ruang Kelas 5B', 'Ruang Kelas 6A', 'Ruang Kelas 6B',
    'Ruang Guru', 'Ruang Kepala Sekolah', 'Ruang Tata Usaha', 'Ruang UKS',
    'Perpustakaan', 'Laboratorium Komputer', 'Laboratorium IPA', 'Aula',
    'Kantin', 'Gudang', 'Dapur', 'Mushola', 'Lapangan Olahraga'
];
?>

<div class="glass-card" style="max-width: 750px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-plus me-2"></i> Tambah Aset Inventaris Baru</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="create.php" enctype="multipart/form-data">
        <?php csrf_input(); ?>

        <div class="row g-3">
            <div class="col-12 col-md-6" id="field_kode_barang">
                <label for="kode_barang" class="form-label form-label-custom">Kode Barang / Aset <span class="text-secondary">(Otomatis jika kosong)</span></label>
                <input type="text" name="kode_barang" id="kode_barang" class="form-control form-control-custom" placeholder="Contoh: INV/GEN/2026/001">
            </div>
            
            <div class="col-12 col-md-6">
                <label for="nama_barang" class="form-label form-label-custom">Nama Barang / Aset <span class="text-danger">*</span></label>
                <input type="text" name="nama_barang" id="nama_barang" class="form-control form-control-custom" placeholder="Contoh: AC Split LG 1 PK" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="kategori_id" class="form-label form-label-custom">Kategori Aset <span class="text-danger">*</span></label>
                <select name="kategori_id" id="kategori_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="" disabled selected>Pilih Kategori...</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo $cat['id']; ?>" data-nama="<?php echo htmlspecialchars($cat['nama_kategori']); ?>"><?php echo htmlspecialchars($cat['nama_kategori']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-12 col-md-6">
                <label for="merk" class="form-label form-label-custom">Merk / Brand</label>
                <input type="text" name="merk" id="merk" class="form-control form-control-custom" placeholder="Contoh: LG, Chitose, Sharp">
            </div>

            <div class="col-12 col-md-6">
                <label for="tipe_model" class="form-label form-label-custom">Tipe / Model</label>
                <input type="text" name="tipe_model" id="tipe_model" class="form-control form-control-custom" placeholder="Contoh: Model X, LN-40">
            </div>

            <div class="col-12 col-md-3" id="field_nomor_seri">
                <label for="nomor_seri" class="form-label form-label-custom">Nomor Seri (Serial Number)</label>
                <input type="text" name="nomor_seri" id="nomor_seri" class="form-control form-control-custom" placeholder="Contoh: SN-12930492">
            </div>

            <div class="col-12 col-md-3">
                <label for="tahun_perolehan" class="form-label form-label-custom">Tahun Perolehan</label>
                <input type="number" name="tahun_perolehan" id="tahun_perolehan" class="form-control form-control-custom" value="<?php echo date('Y'); ?>">
            </div>

            <div class="col-6 col-md-3">
                <label for="jumlah" class="form-label form-label-custom">Jumlah Unit</label>
                <input type="number" name="jumlah" id="jumlah" class="form-control form-control-custom" value="1" min="1">
            </div>

            <div class="col-6 col-md-3">
                <label for="kondisi" class="form-label form-label-custom">Kondisi</label>
                <select name="kondisi" id="kondisi" class="form-select form-control-custom bg-dark-select text-white">
                    <option value="Baik" selected>Baik</option>
                    <option value="Cukup">Cukup</option>
                    <option value="Rusak Ringan">Rusak Ringan</option>
                    <option value="Rusak Berat">Rusak Berat</option>
                </select>
            </div>

            <div class="col-12 col-md-6">
                <label for="lokasi_nama" class="form-label form-label-custom">
                    <i class="fa-solid fa-location-dot me-1 text-gold"></i> Lokasi Penempatan
                    <small class="text-secondary ms-1">(Ketik nama ruangan – baru otomatis dibuat)</small>
                </label>
                <input type="text"
                       name="lokasi_nama"
                       id="lokasi_nama"
                       list="daftar_ruangan"
                       class="form-control form-control-custom"
                       placeholder="Contoh: Ruang Kelas 5A, Lab Komputer, Gudang..."
                       autocomplete="off">
                <datalist id="daftar_ruangan">
                    <?php
                    // Show rooms already in DB first
                    foreach ($rooms as $rm):
                    ?>
                        <option value="<?php echo htmlspecialchars($rm['nama_ruangan']); ?>">
                    <?php endforeach; ?>
                    <?php
                    // Then show suggestions not yet in DB
                    $existing_names = array_column($rooms, 'nama_ruangan');
                    foreach ($room_suggestions as $sug):
                        if (!in_array($sug, $existing_names)):
                    ?>
                        <option value="<?php echo htmlspecialchars($sug); ?>">
                    <?php
                        endif;
                    endforeach;
                    ?>
                </datalist>
                <div class="form-text text-secondary mt-1">
                    <i class="fa-solid fa-circle-info me-1"></i>
                    Pilih dari daftar atau ketik lokasi baru — sistem akan menyimpan otomatis.
                </div>
            </div>

            <div class="col-12 col-md-6">
                <label for="sumber_dana" class="form-label form-label-custom">Sumber Dana <span class="text-danger">*</span></label>
                <input type="text" name="sumber_dana" id="sumber_dana" class="form-control form-control-custom" placeholder="Contoh: Dana BOS, Yayasan, Sumbangan" required>
            </div>

            <!-- Serial Number (SN) and Kode Barang Fields for PC Desktop Unit / PC AIO -->
            <div class="col-12 mt-4" id="sn_peripheral_container" style="display: none;">
                <hr style="border-color: rgba(255,255,255,0.08);">
                <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-desktop me-2"></i> Detail Peripheral (<span id="sn_peripheral_title"></span>)</h6>
                <div class="row g-3">
                    <!-- CPU -->
                    <div class="col-md-6" id="field_sn_cpu">
                        <label for="sn_cpu" class="form-label form-label-custom">SN CPU</label>
                        <input type="text" name="sn_cpu" id="sn_cpu" class="form-control form-control-custom" placeholder="Contoh: SN-CPU12345">
                    </div>
                    <div class="col-md-6" id="field_kode_cpu">
                        <label for="kode_cpu" class="form-label form-label-custom">Kode Barang CPU</label>
                        <input type="text" name="kode_cpu" id="kode_cpu" class="form-control form-control-custom" placeholder="Contoh: CPU-12345">
                    </div>
                    
                    <!-- Monitor -->
                    <div class="col-md-6" id="field_sn_monitor">
                        <label for="sn_monitor" class="form-label form-label-custom">SN Monitor</label>
                        <input type="text" name="sn_monitor" id="sn_monitor" class="form-control form-control-custom" placeholder="Contoh: SN-MON12345">
                    </div>
                    <div class="col-md-6" id="field_kode_monitor">
                        <label for="kode_monitor" class="form-label form-label-custom">Kode Barang Monitor</label>
                        <input type="text" name="kode_monitor" id="kode_monitor" class="form-control form-control-custom" placeholder="Contoh: MON-12345">
                    </div>

                    <!-- Keyboard -->
                    <div class="col-md-6" id="field_sn_keyboard">
                        <label for="sn_keyboard" class="form-label form-label-custom">SN Keyboard</label>
                        <input type="text" name="sn_keyboard" id="sn_keyboard" class="form-control form-control-custom" placeholder="Contoh: SN-KB12345">
                    </div>
                    <div class="col-md-6" id="field_kode_keyboard">
                        <label for="kode_keyboard" class="form-label form-label-custom">Kode Barang Keyboard</label>
                        <input type="text" name="kode_keyboard" id="kode_keyboard" class="form-control form-control-custom" placeholder="Contoh: KB-12345">
                    </div>

                    <!-- Mouse -->
                    <div class="col-md-6" id="field_sn_mouse">
                        <label for="sn_mouse" class="form-label form-label-custom">SN Mouse</label>
                        <input type="text" name="sn_mouse" id="sn_mouse" class="form-control form-control-custom" placeholder="Contoh: SN-MS12345">
                    </div>
                    <div class="col-md-6" id="field_kode_mouse">
                        <label for="kode_mouse" class="form-label form-label-custom">Kode Barang Mouse</label>
                        <input type="text" name="kode_mouse" id="kode_mouse" class="form-control form-control-custom" placeholder="Contoh: MS-12345">
                    </div>
                </div>
            </div>

            <div class="col-12 d-flex justify-content-end gap-2 mt-4">
                <a href="index.php" class="btn btn-outline-custom">Batal</a>
                <button type="submit" class="btn btn-gold">Simpan <i class="fa-solid fa-check ms-1"></i></button>
            </div>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const kategoriSelect = document.getElementById('kategori_id');
    const container = document.getElementById('sn_peripheral_container');
    const titleSpan = document.getElementById('sn_peripheral_title');
    
    const fieldCpu = document.getElementById('field_sn_cpu');
    const fieldKodeCpu = document.getElementById('field_kode_cpu');
    const fieldMonitor = document.getElementById('field_sn_monitor');
    const fieldKodeMonitor = document.getElementById('field_kode_monitor');
    const fieldKeyboard = document.getElementById('field_sn_keyboard');
    const fieldKodeKeyboard = document.getElementById('field_kode_keyboard');
    const fieldMouse = document.getElementById('field_sn_mouse');
    const fieldKodeMouse = document.getElementById('field_kode_mouse');

    const inputCpu = document.getElementById('sn_cpu');
    const inputKodeCpu = document.getElementById('kode_cpu');
    const inputMonitor = document.getElementById('sn_monitor');
    const inputKodeMonitor = document.getElementById('kode_monitor');
    const inputKeyboard = document.getElementById('sn_keyboard');
    const inputKodeKeyboard = document.getElementById('kode_keyboard');
    const inputMouse = document.getElementById('sn_mouse');
    const inputKodeMouse = document.getElementById('kode_mouse');

    const fieldNomorSeri = document.getElementById('field_nomor_seri');
    const inputNomorSeri = document.getElementById('nomor_seri');
    const fieldKodeBarang = document.getElementById('field_kode_barang');
    const inputKodeBarang = document.getElementById('kode_barang');

    function updateFields() {
        const selectedOption = kategoriSelect.options[kategoriSelect.selectedIndex];
        if (!selectedOption || selectedOption.value === "") {
            container.style.display = 'none';
            if (fieldNomorSeri) fieldNomorSeri.style.display = 'block';
            if (fieldKodeBarang) fieldKodeBarang.style.display = 'block';
            return;
        }
        const catName = selectedOption.getAttribute('data-nama');

        if (catName === 'PC Desktop Unit') {
            container.style.display = 'block';
            titleSpan.textContent = 'PC Desktop';
            
            fieldCpu.style.display = 'block';
            fieldKodeCpu.style.display = 'block';
            fieldMonitor.style.display = 'block';
            fieldKodeMonitor.style.display = 'block';
            fieldKeyboard.style.display = 'block';
            fieldKodeKeyboard.style.display = 'block';
            fieldMouse.style.display = 'block';
            fieldKodeMouse.style.display = 'block';

            if (fieldNomorSeri) {
                fieldNomorSeri.style.display = 'none';
                if (inputNomorSeri) inputNomorSeri.value = '';
            }
            if (fieldKodeBarang) {
                fieldKodeBarang.style.display = 'none';
                if (inputKodeBarang) inputKodeBarang.value = '';
            }
        } else if (catName === 'PC AIO') {
            container.style.display = 'block';
            titleSpan.textContent = 'PC All-in-One';
            
            fieldCpu.style.display = 'none';
            fieldKodeCpu.style.display = 'none';
            fieldMonitor.style.display = 'block';
            fieldKodeMonitor.style.display = 'block';
            fieldKeyboard.style.display = 'block';
            fieldKodeKeyboard.style.display = 'block';
            fieldMouse.style.display = 'block';
            fieldKodeMouse.style.display = 'block';

            inputCpu.value = ''; 
            inputKodeCpu.value = '';

            if (fieldNomorSeri) {
                fieldNomorSeri.style.display = 'none';
                if (inputNomorSeri) inputNomorSeri.value = '';
            }
            if (fieldKodeBarang) {
                fieldKodeBarang.style.display = 'none';
                if (inputKodeBarang) inputKodeBarang.value = '';
            }
        } else {
            container.style.display = 'none';
            inputCpu.value = '';
            inputKodeCpu.value = '';
            inputMonitor.value = '';
            inputKodeMonitor.value = '';
            inputKeyboard.value = '';
            inputKodeKeyboard.value = '';
            inputMouse.value = '';
            inputKodeMouse.value = '';
            if (fieldNomorSeri) fieldNomorSeri.style.display = 'block';
            if (fieldKodeBarang) fieldKodeBarang.style.display = 'block';
        }
    }

    if (kategoriSelect) {
        kategoriSelect.addEventListener('change', updateFields);
        updateFields(); // Run on load
    }
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
