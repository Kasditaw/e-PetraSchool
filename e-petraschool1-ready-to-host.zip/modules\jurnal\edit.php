<?php
// c:\xampp\htdocs\e-petraschool1\modules\jurnal\edit.php

$page_title = 'Edit Jurnal Mengajar';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role('Guru');

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';
$guru_id = $_SESSION['guru_id'];

try {
    // Fetch journal
    $jurnal_stmt = $pdo->prepare("SELECT j.*, g.nama_guru, g.nip, s.semester, t.tahun_ajaran 
                                  FROM jurnal_mengajar j
                                  JOIN guru g ON j.guru_id = g.id
                                  JOIN semester s ON j.semester_id = s.id
                                  JOIN tahun_ajaran t ON j.tahun_ajaran_id = t.id
                                  WHERE j.id = ?");
    $jurnal_stmt->execute([$id]);
    $jurnal = $jurnal_stmt->fetch();

    if (!$jurnal) {
        die('<div class="alert alert-danger">Jurnal mengajar tidak ditemukan!</div>');
    }

    // Verify owner
    if ($jurnal['guru_id'] != $guru_id) {
        die('<div class="alert alert-danger">Anda tidak memiliki izin untuk mengedit jurnal ini!</div>');
    }

    // Verify status
    if ($jurnal['status'] === 'Disetujui') {
        die('<div class="alert alert-danger">Jurnal yang sudah terverifikasi tidak dapat diedit kembali!</div>');
    }

    // Fetch classes
    $classes = $pdo->query("SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas ASC")->fetchAll();

    // Fetch Active Subjects
    $subjects = $pdo->query("SELECT id, nama_mapel, kode_mapel FROM mata_pelajaran WHERE status = 'Aktif' ORDER BY nama_mapel ASC")->fetchAll();

    // Fetch All Semesters
    $semesters_list = $pdo->query("SELECT * FROM semester ORDER BY semester ASC")->fetchAll();

    // Fetch All Years
    $years_list = $pdo->query("SELECT * FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();

    // Fetch current details
    $details_stmt = $pdo->prepare("SELECT * FROM jurnal_mengajar_detail WHERE jurnal_id = ?");
    $details_stmt->execute([$id]);
    $details_raw = $details_stmt->fetchAll();

    $details = [];
    foreach ($details_raw as $det) {
        $details[$det['jam_ke']] = $det;
    }

} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $jabatan = trim($_POST['jabatan'] ?? '');
    $hari = trim($_POST['hari'] ?? '');
    $tanggal = $_POST['tanggal'] ?? '';
    $signature_data = $_POST['signature_data'] ?? ''; // base64 string
    
    // File upload fallback
    if (isset($_FILES['signature_file']) && $_FILES['signature_file']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['signature_file']['tmp_name'];
        $file_name = $_FILES['signature_file']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed_exts = ['jpg', 'jpeg', 'png'];
        if (in_array($file_ext, $allowed_exts)) {
            $data = file_get_contents($file_tmp);
            $signature_data = 'data:image/' . $file_ext . ';base64,' . base64_encode($data);
        }
    }

    // If signature is not changed, keep the old one
    if (empty($signature_data)) {
        $signature_data = $jurnal['tanda_tangan'];
    }

    if (empty($jabatan) || empty($hari) || empty($tanggal)) {
        $error = 'Semua identitas jurnal wajib diisi!';
    } else {
        try {
            $pdo->beginTransaction();

            $semester_id = isset($_POST['semester_id']) ? intval($_POST['semester_id']) : $jurnal['semester_id'];
            $tahun_ajaran_id = isset($_POST['tahun_ajaran_id']) ? intval($_POST['tahun_ajaran_id']) : $jurnal['tahun_ajaran_id'];

            // Update jurnal_mengajar (Reset status to Menunggu Verifikasi upon edits)
            $stmt = $pdo->prepare("UPDATE jurnal_mengajar SET semester_id = ?, tahun_ajaran_id = ?, jabatan = ?, hari = ?, tanggal = ?, tanda_tangan = ?, status = 'Menunggu Verifikasi' WHERE id = ?");
            $stmt->execute([
                $semester_id,
                $tahun_ajaran_id,
                $jabatan,
                $hari,
                $tanggal,
                $signature_data,
                $id
            ]);

            // Clear old details
            $delete_details = $pdo->prepare("DELETE FROM jurnal_mengajar_detail WHERE jurnal_id = ?");
            $delete_details->execute([$id]);

            // Insert new details
            $detail_stmt = $pdo->prepare("INSERT INTO jurnal_mengajar_detail (jurnal_id, jam_ke, mapel_id, kelas_id, materi, kegiatan) VALUES (?, ?, ?, ?, ?, ?)");
            
            for ($jam = 0; $jam <= 9; $jam++) {
                $mapel_id = $_POST['mapel_' . $jam] !== '' ? intval($_POST['mapel_' . $jam]) : null;
                $kelas_id = $_POST['kelas_' . $jam] !== '' ? intval($_POST['kelas_' . $jam]) : null;
                $materi = trim($_POST['materi_' . $jam] ?? '');
                $kegiatan = trim($_POST['kegiatan_' . $jam] ?? '');

                if ($mapel_id !== null || $kelas_id !== null || !empty($materi) || !empty($kegiatan)) {
                    $detail_stmt->execute([
                        $id,
                        $jam,
                        $mapel_id,
                        $kelas_id,
                        $materi,
                        $kegiatan
                    ]);
                }
            }

            // Create notification for Kepsek
            $kepsek_ids = $pdo->query("SELECT id FROM users WHERE role_id IN (1, 2, 4)")->fetchAll(PDO::FETCH_COLUMN);
            $notif_stmt = $pdo->prepare("INSERT INTO notifikasi (user_id, pesan) VALUES (?, ?)");
            foreach ($kepsek_ids as $k_id) {
                $notif_stmt->execute([$k_id, "Guru <strong>" . htmlspecialchars($jurnal['nama_guru']) . "</strong> telah memperbarui jurnal mengajar tanggal " . date('d/m/Y', strtotime($tanggal)) . " (menunggu verifikasi ulang)."]);
            }

            $pdo->commit();

            write_audit_log("Mengubah jurnal mengajar ID: $id tanggal $tanggal.");

            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire('Berhasil', 'Jurnal mengajar berhasil diperbarui!', 'success').then(() => {
                        window.location.href = 'index.php';
                    });
                });
            </script>";

        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = 'Database Error: ' . $e->getMessage();
        }
    }
}
?>

<div class="glass-card" style="max-width: 1000px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-file-signature me-2"></i> Edit Jurnal Mengajar Harian</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="edit.php?id=<?php echo $id; ?>" enctype="multipart/form-data" id="jurnal-form">
        <?php csrf_input(); ?>

        <!-- Identity Section -->
        <div class="row g-3 mb-4">
            <div class="col-12 col-md-4">
                <label class="form-label form-label-custom">Nama Guru</label>
                <input type="text" class="form-control form-control-custom text-white" value="<?php echo htmlspecialchars($jurnal['nama_guru']); ?>" readonly style="background: rgba(255,255,255,0.05) !important;">
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label form-label-custom">NIP Guru</label>
                <input type="text" class="form-control form-control-custom text-white" value="<?php echo htmlspecialchars($jurnal['nip']); ?>" readonly style="background: rgba(255,255,255,0.05) !important;">
            </div>

            <div class="col-12 col-md-4">
                <label class="form-label form-label-custom">Tahun Ajaran / Semester <span class="text-danger">*</span></label>
                <div class="d-flex gap-2">
                    <input type="hidden" name="tahun_ajaran_id" id="tahun_ajaran_id" value="<?php echo $jurnal['tahun_ajaran_id']; ?>">
                    <input type="hidden" name="semester_id" id="semester_id" value="<?php echo $jurnal['semester_id']; ?>">
                    <select name="tahun_ajaran_id_display" id="tahun_ajaran_id_display" class="form-select form-control-custom bg-dark-select text-white" disabled>
                        <?php foreach ($years_list as $yr): ?>
                            <option value="<?php echo $yr['id']; ?>" <?php echo $jurnal['tahun_ajaran_id'] == $yr['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($yr['tahun_ajaran']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <select name="semester_id_display" id="semester_id_display" class="form-select form-control-custom bg-dark-select text-white" disabled>
                        <?php foreach ($semesters_list as $sem): ?>
                            <option value="<?php echo $sem['id']; ?>" <?php echo $jurnal['semester_id'] == $sem['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($sem['semester']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="col-12 col-sm-4">
                <label for="jabatan" class="form-label form-label-custom">Jabatan Mengajar <span class="text-danger">*</span></label>
                <select name="jabatan" id="jabatan" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="Guru Kelas" <?php echo $jurnal['jabatan'] === 'Guru Kelas' ? 'selected' : ''; ?>>Guru Kelas</option>
                    <option value="Guru Mata Pelajaran" <?php echo $jurnal['jabatan'] === 'Guru Mata Pelajaran' ? 'selected' : ''; ?>>Guru Mata Pelajaran</option>
                    <option value="Wali Kelas" <?php echo $jurnal['jabatan'] === 'Wali Kelas' ? 'selected' : ''; ?>>Wali Kelas</option>
                    <option value="Kepala Sekolah" <?php echo $jurnal['jabatan'] === 'Kepala Sekolah' ? 'selected' : ''; ?>>Kepala Sekolah</option>
                </select>
            </div>

            <div class="col-12 col-sm-4">
                <label for="hari" class="form-label form-label-custom">Hari <span class="text-danger">*</span></label>
                <select name="hari" id="hari" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="Senin" <?php echo $jurnal['hari'] === 'Senin' ? 'selected' : ''; ?>>Senin</option>
                    <option value="Selasa" <?php echo $jurnal['hari'] === 'Selasa' ? 'selected' : ''; ?>>Selasa</option>
                    <option value="Rabu" <?php echo $jurnal['hari'] === 'Rabu' ? 'selected' : ''; ?>>Rabu</option>
                    <option value="Kamis" <?php echo $jurnal['hari'] === 'Kamis' ? 'selected' : ''; ?>>Kamis</option>
                    <option value="Jumat" <?php echo $jurnal['hari'] === 'Jumat' ? 'selected' : ''; ?>>Jumat</option>
                </select>
            </div>

            <div class="col-12 col-sm-4">
                <label for="tanggal" class="form-label form-label-custom">Tanggal <span class="text-danger">*</span></label>
                <input type="date" name="tanggal" id="tanggal" class="form-control form-control-custom text-white" value="<?php echo htmlspecialchars($jurnal['tanggal']); ?>" required>
            </div>
        </div>

        <!-- Hourly Schedule Table -->
        <h6 class="text-gold border-bottom border-secondary border-opacity-25 pb-2 mb-3"><i class="fa-solid fa-list-check me-2"></i> Rincian KBM Harian (Jam Ke-1 s/d Jam Ke-9)</h6>
        
        <div class="table-responsive mb-4">
            <table class="table table-custom table-bordered" style="border-color: var(--border-color);">
                <thead>
                    <tr>
                        <th style="width: 80px; text-align: center;">Jam Ke</th>
                        <th style="width: 230px;">Mata Pelajaran</th>
                        <th style="width: 150px;">Kelas</th>
                        <th>Materi Pembelajaran</th>
                        <th>Kegiatan Pembelajaran</th>
                        <th style="width: 80px; text-align: center;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php for ($jam = 0; $jam <= 9; $jam++): 
                        $det = $details[$jam] ?? ['mapel_id' => '', 'kelas_id' => '', 'materi' => '', 'kegiatan' => ''];
                    ?>
                        <tr id="row-<?php echo $jam; ?>">
                            <td class="text-center fw-bold text-white pt-3"># <?php echo $jam; ?></td>
                            <td>
                                <select name="mapel_<?php echo $jam; ?>" id="mapel_<?php echo $jam; ?>" class="form-select form-control-custom bg-dark-select text-white py-1.5">
                                    <option value="">Pilih Mapel...</option>
                                    <?php foreach ($subjects as $sub): ?>
                                        <option value="<?php echo $sub['id']; ?>" <?php echo $det['mapel_id'] == $sub['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($sub['nama_mapel']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select name="kelas_<?php echo $jam; ?>" id="kelas_<?php echo $jam; ?>" class="form-select form-control-custom bg-dark-select text-white py-1.5">
                                    <option value="">Pilih Kelas...</option>
                                    <?php foreach ($classes as $cl): ?>
                                        <option value="<?php echo $cl['id']; ?>" <?php echo $det['kelas_id'] == $cl['id'] ? 'selected' : ''; ?>><?php echo htmlspecialchars($cl['nama_kelas']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <input type="text" name="materi_<?php echo $jam; ?>" id="materi_<?php echo $jam; ?>" class="form-control form-control-custom py-1.5" value="<?php echo htmlspecialchars($det['materi']); ?>" placeholder="Materi pokok bahasan">
                            </td>
                            <td>
                                <input type="text" name="kegiatan_<?php echo $jam; ?>" id="kegiatan_<?php echo $jam; ?>" class="form-control form-control-custom py-1.5" value="<?php echo htmlspecialchars($det['kegiatan']); ?>" placeholder="Kegiatan KBM">
                            </td>
                            <td class="text-center pt-2">
                                <button type="button" class="btn btn-xs btn-outline-danger" onclick="clearRow(<?php echo $jam; ?>)" title="Kosongkan"><i class="fa-solid fa-eraser"></i></button>
                            </td>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>

        <!-- Signature Section -->
        <h6 class="text-gold border-bottom border-secondary border-opacity-25 pb-2 mb-3"><i class="fa-solid fa-signature me-2"></i> Tanda Tangan Guru</h6>
        <div class="row g-4 mb-4">
            <div class="col-12 col-md-6">
                <label class="form-label form-label-custom">Tanda Tangan Digital (Gambar ulang jika ingin mengubah)</label>
                <div class="glass-card mb-2 p-0 position-relative" style="background: rgba(0,0,0,0.4); border: 2px dashed var(--border-color); overflow: hidden;">
                    <canvas id="sig-canvas" width="450" height="200" style="cursor: crosshair; touch-action: none; width: 100%; display: block;"></canvas>
                </div>
                <div class="d-flex justify-content-between align-items-center">
                    <button type="button" class="btn btn-xs btn-outline-warning" id="btn-clear-sig"><i class="fa-solid fa-rotate-left me-1"></i> Bersihkan Kanvas</button>
                    <?php if (!empty($jurnal['tanda_tangan'])): ?>
                        <span class="text-info small"><i class="fa-solid fa-check-double"></i> Tanda Tangan Lama Tersimpan</span>
                    <?php endif; ?>
                </div>
                <input type="hidden" name="signature_data" id="signature_data">
            </div>
            
            <div class="col-12 col-md-6">
                <label class="form-label form-label-custom">Alternatif: Unggah Tanda Tangan Baru (Format Gambar)</label>
                <div class="p-4 rounded border border-secondary border-opacity-10 bg-dark bg-opacity-25 text-center d-flex flex-column align-items-center justify-content-center h-100" style="min-height: 200px;">
                    <?php if (!empty($jurnal['tanda_tangan'])): ?>
                        <div class="mb-2 p-2 bg-white rounded" style="width: 150px; height: 70px; display: flex; align-items: center; justify-content: center;">
                            <img src="<?php echo $jurnal['tanda_tangan']; ?>" alt="Tanda Tangan Lama" style="max-width: 100%; max-height: 100%; object-fit: contain;">
                        </div>
                    <?php endif; ?>
                    <input type="file" name="signature_file" id="signature_file" class="form-control form-control-custom w-75" accept="image/*">
                    <span class="text-secondary small mt-2">Format: JPG, JPEG, PNG. Biarkan kosong jika ingin menggunakan tanda tangan lama.</span>
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-end gap-2 border-top border-secondary border-opacity-10 pt-4 mt-4">
            <a href="index.php" class="btn btn-outline-custom px-4">Batal</a>
            <button type="submit" class="btn btn-gold px-4" id="btn-submit-jurnal">Perbarui Jurnal Mengajar <i class="fa-solid fa-check ms-1"></i></button>
        </div>
    </form>
</div>

<script>
function clearRow(jam) {
    document.getElementById('mapel_' + jam).value = '';
    document.getElementById('kelas_' + jam).value = '';
    document.getElementById('materi_' + jam).value = '';
    document.getElementById('kegiatan_' + jam).value = '';
}

document.addEventListener('DOMContentLoaded', function() {
    // Auto-update Tahun Ajaran / Semester / Hari berdasarkan Tanggal
    const tanggalInput = document.getElementById('tanggal');
    if (tanggalInput) {
        tanggalInput.addEventListener('change', updateAcademicYearAndSemester);
        // Sync on page load
        updateAcademicYearAndSemester();
    }

    function updateAcademicYearAndSemester() {
        const tanggalVal = tanggalInput.value;
        if (!tanggalVal) return;
        
        const parts = tanggalVal.split('-');
        if (parts.length !== 3) return;
        
        const year = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10);
        const day = parseInt(parts[2], 10);
        
        let targetSemester = '';
        let targetTahunAjaran = '';
        
        // July - December = Ganjil, January - June = Genap
        if (month >= 7 && month <= 12) {
            targetSemester = 'Ganjil';
            targetTahunAjaran = year + '/' + (year + 1);
        } else if (month >= 1 && month <= 6) {
            targetSemester = 'Genap';
            targetTahunAjaran = (year - 1) + '/' + year;
        }
        
        // Select Tahun Ajaran
        const taSelect = document.getElementById('tahun_ajaran_id_display');
        const taHidden = document.getElementById('tahun_ajaran_id');
        if (taSelect) {
            for (let i = 0; i < taSelect.options.length; i++) {
                if (taSelect.options[i].text.trim() === targetTahunAjaran) {
                    taSelect.selectedIndex = i;
                    if (taHidden) {
                        taHidden.value = taSelect.options[i].value;
                    }
                    break;
                }
            }
        }
        
        // Select Semester
        const semSelect = document.getElementById('semester_id_display');
        const semHidden = document.getElementById('semester_id');
        if (semSelect) {
            for (let i = 0; i < semSelect.options.length; i++) {
                if (semSelect.options[i].text.trim().toLowerCase() === targetSemester.toLowerCase()) {
                    semSelect.selectedIndex = i;
                    if (semHidden) {
                        semHidden.value = semSelect.options[i].value;
                    }
                    break;
                }
            }
        }
        
        // Select Hari
        const hariSelect = document.getElementById('hari');
        if (hariSelect) {
            const dateObj = new Date(year, month - 1, day);
            const dayOfWeek = dateObj.getDay(); // 0 = Sunday, 1 = Monday, ...
            const indonesianDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
            const targetDay = indonesianDays[dayOfWeek];
            
            for (let i = 0; i < hariSelect.options.length; i++) {
                if (hariSelect.options[i].value === targetDay) {
                    hariSelect.selectedIndex = i;
                    break;
                }
            }
        }
    }

    const canvas = document.getElementById('sig-canvas');
    const ctx = canvas.getContext('2d');
    const clearBtn = document.getElementById('btn-clear-sig');
    const signatureInput = document.getElementById('signature_data');
    const form = document.getElementById('jurnal-form');
    
    ctx.strokeStyle = "#000000";
    ctx.lineWidth = 3;
    ctx.lineJoin = 'round';
    ctx.lineCap = 'round';

    let drawing = false;
    let lastX = 0;
    let lastY = 0;

    function getPos(e) {
        const rect = canvas.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        
        return {
            x: (clientX - rect.left) * (canvas.width / rect.width),
            y: (clientY - rect.top) * (canvas.height / rect.height)
        };
    }

    function startDrawing(e) {
        drawing = true;
        const pos = getPos(e);
        lastX = pos.x;
        lastY = pos.y;
    }

    function draw(e) {
        if (!drawing) return;
        e.preventDefault();
        const pos = getPos(e);

        ctx.beginPath();
        ctx.moveTo(lastX, lastY);
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();

        lastX = pos.x;
        lastY = pos.y;
    }

    function stopDrawing() {
        drawing = false;
    }

    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseout', stopDrawing);

    canvas.addEventListener('touchstart', startDrawing);
    canvas.addEventListener('touchmove', draw);
    canvas.addEventListener('touchend', stopDrawing);

    clearBtn.addEventListener('click', function() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        signatureInput.value = '';
    });

    form.addEventListener('submit', function(e) {
        const isBlank = isCanvasBlank(canvas);
        if (!isBlank) {
            const dataUrl = canvas.toDataURL('image/png');
            signatureInput.value = dataUrl;
        }
    });

    function isCanvasBlank(c) {
        const blank = document.createElement('canvas');
        blank.width = c.width;
        blank.height = c.height;
        return c.toDataURL() === blank.toDataURL();
    }
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
