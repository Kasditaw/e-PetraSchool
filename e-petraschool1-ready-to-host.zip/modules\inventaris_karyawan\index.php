<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris_karyawan\index.php

$page_title = 'Inventaris Karyawan';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_inventaris_access();

$karyawan_id = isset($_GET['karyawan_id']) ? intval($_GET['karyawan_id']) : 0;
if ($karyawan_id <= 0) {
    header("Location: ../karyawan/index.php");
    exit;
}

$error = '';
$success = '';

// Fetch karyawan details
try {
    $stmt = $pdo->prepare("SELECT * FROM karyawan WHERE id = ?");
    $stmt->execute([$karyawan_id]);
    $karyawan = $stmt->fetch();
    
    if (!$karyawan) {
        die("<div class='alert alert-danger m-4'>Data karyawan tidak ditemukan.</div>");
    }
} catch (Exception $e) {
    die("<div class='alert alert-danger m-4'>Database Error: " . $e->getMessage() . "</div>");
}

// Handle complete assignment (Selesaikan)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'complete_assignment') {
    require_role(['Super Admin', 'Admin']);
    check_csrf_request();
    
    $assignment_id = intval($_POST['assignment_id'] ?? 0);
    if ($assignment_id > 0) {
        try {
            $stmt = $pdo->prepare("UPDATE inventaris_karyawan SET status = 'Selesai', tanggal_selesai = ? WHERE id = ? AND karyawan_id = ?");
            $stmt->execute([date('Y-m-d'), $assignment_id, $karyawan_id]);
            
            // Get asset name for audit log
            $ast_stmt = $pdo->prepare("
                SELECT i.nama_barang, i.kode_barang 
                FROM inventaris_karyawan ik 
                JOIN inventaris i ON ik.inventaris_id = i.id 
                WHERE ik.id = ?
            ");
            $ast_stmt->execute([$assignment_id]);
            $asset = $ast_stmt->fetch();
            
            $log_msg = "Menyelesaikan penugasan inventaris aset " . ($asset ? $asset['nama_barang'] . " (" . $asset['kode_barang'] . ")" : "") . " untuk karyawan: {$karyawan['nama']} (NIP: {$karyawan['nik']}).";
            write_audit_log($log_msg);
            
            $success = 'Penugasan aset berhasil diselesaikan.';
        } catch (Exception $e) {
            $error = 'Gagal menyelesaikan penugasan: ' . $e->getMessage();
        }
    } else {
        $error = 'ID penugasan tidak valid.';
    }
}

// Fetch all assignments for this employee
try {
    $stmt = $pdo->prepare("
        SELECT ik.*, i.kode_barang, i.nama_barang, i.foto_barang, i.kondisi 
        FROM inventaris_karyawan ik 
        JOIN inventaris i ON ik.inventaris_id = i.id 
        WHERE ik.karyawan_id = ? 
        ORDER BY ik.status ASC, ik.tanggal_mulai DESC
    ");
    $stmt->execute([$karyawan_id]);
    $assignments = $stmt->fetchAll();
} catch (Exception $e) {
    $error = 'Gagal memuat data penugasan: ' . $e->getMessage();
    $assignments = [];
}
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
    </div>
<?php endif; ?>

<?php if ($success !== ''): ?>
    <div class="alert border-0 small mb-4 py-2" style="background:rgba(16,185,129,0.15);color:#34d399;" role="alert">
        <i class="fa-solid fa-circle-check me-2"></i> <?php echo htmlspecialchars($success); ?>
    </div>
<?php endif; ?>

<!-- Employee Card Summary -->
<div class="glass-card mb-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div class="d-flex align-items-center gap-3">
            <div class="bg-gold bg-opacity-10 text-gold rounded p-3 d-flex align-items-center justify-content-center" style="width: 60px; height: 60px; font-size: 24px;">
                <i class="fa-solid fa-user-tie"></i>
            </div>
            <div>
                <h5 class="text-white fw-bold mb-1"><?php echo htmlspecialchars($karyawan['nama']); ?></h5>
                <p class="text-secondary small mb-0">
                    <span class="font-monospace text-gold me-3">NIP: <?php echo htmlspecialchars($karyawan['nik']); ?></span>
                    <span class="me-3"><i class="fa-solid fa-briefcase text-secondary me-1"></i> <?php echo htmlspecialchars($karyawan['jabatan']); ?></span>
                    <span><i class="fa-solid fa-building text-secondary me-1"></i> <?php echo htmlspecialchars($karyawan['unit_kerja']); ?></span>
                </p>
            </div>
        </div>
        <div class="d-flex gap-2">
            <a href="../karyawan/index.php" class="btn btn-outline-custom text-gold">
                <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Karyawan
            </a>
            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                <a href="create.php?karyawan_id=<?php echo $karyawan_id; ?>" class="btn btn-gold">
                    <i class="fa-solid fa-plus me-1"></i> Tugaskan Aset
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Assignments Table -->
<div class="glass-card">
    <h6 class="text-gold fw-bold mb-3">
        <i class="fa-solid fa-boxes-stacked me-2"></i> Aset yang Dipegang / Ditugaskan
        <span class="badge badge-secondary ms-2"><?php echo count($assignments); ?> Aset</span>
    </h6>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th style="width: 60px;">No</th>
                    <th style="width: 80px;">Foto</th>
                    <th style="width: 150px;">Kode Aset</th>
                    <th>Nama Aset / Barang</th>
                    <th>Tanggal Mulai</th>
                    <th>Tanggal Selesai</th>
                    <th>Status</th>
                    <th>Keterangan</th>
                    <?php if (has_role(['Super Admin', 'Admin'])): ?>
                        <th style="text-align: right; width: 220px;" class="no-print">Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (count($assignments) > 0): ?>
                    <?php $no = 1; foreach ($assignments as $asg): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td>
                                <?php if (!empty($asg['foto_barang'])): ?>
                                    <img src="<?php echo $base_url; ?>assets/uploads/inventaris/<?php echo $asg['foto_barang']; ?>" alt="Foto" class="rounded border" style="width: 45px; height: 40px; object-fit: cover;">
                                <?php else: ?>
                                    <div class="rounded border bg-dark text-secondary d-flex align-items-center justify-content-center" style="width: 45px; height: 40px; font-size: 14px;">
                                        <i class="fa-solid fa-box"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong class="text-white font-monospace"><?php echo htmlspecialchars($asg['kode_barang']); ?></strong>
                            </td>
                            <td>
                                <strong class="text-white"><?php echo htmlspecialchars($asg['nama_barang']); ?></strong>
                                <span class="badge badge-dark border text-secondary small d-block mt-0.5" style="width: fit-content; font-size: 9px; padding: 2px 6px;">Kondisi: <?php echo htmlspecialchars($asg['kondisi']); ?></span>
                            </td>
                            <td><?php echo date('d M Y', strtotime($asg['tanggal_mulai'])); ?></td>
                            <td>
                                <?php echo !empty($asg['tanggal_selesai']) ? date('d M Y', strtotime($asg['tanggal_selesai'])) : '<em class="text-secondary small">—</em>'; ?>
                            </td>
                            <td>
                                <?php if ($asg['status'] === 'Aktif'): ?>
                                    <span class="badge badge-success"><i class="fa-solid fa-circle-check me-1"></i> Aktif</span>
                                <?php else: ?>
                                    <span class="badge badge-secondary"><i class="fa-solid fa-circle-xmark me-1"></i> Selesai</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-secondary small"><?php echo htmlspecialchars($asg['keterangan'] ?: '—'); ?></td>
                            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                <td style="text-align: right;" class="no-print">
                                    <div class="d-flex gap-2 justify-content-end">
                                        <?php if ($asg['status'] === 'Aktif'): ?>
                                            <form method="POST" action="index.php?karyawan_id=<?php echo $karyawan_id; ?>" class="d-inline form-complete">
                                                <?php csrf_input(); ?>
                                                <input type="hidden" name="action" value="complete_assignment">
                                                <input type="hidden" name="assignment_id" value="<?php echo $asg['id']; ?>">
                                                <button type="button" class="btn btn-xs btn-outline-success btn-complete" data-barang="<?php echo htmlspecialchars($asg['nama_barang']); ?>">
                                                    <i class="fa-solid fa-check"></i> Selesai
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        <a href="edit.php?id=<?php echo $asg['id']; ?>" class="btn btn-xs btn-outline-warning">
                                            <i class="fa-solid fa-pen"></i> Edit
                                        </a>
                                        <form method="POST" action="delete.php" class="d-inline form-delete">
                                            <?php csrf_input(); ?>
                                            <input type="hidden" name="id" value="<?php echo $asg['id']; ?>">
                                            <input type="hidden" name="karyawan_id" value="<?php echo $karyawan_id; ?>">
                                            <button type="button" class="btn btn-xs btn-outline-danger btn-delete" data-barang="<?php echo htmlspecialchars($asg['nama_barang']); ?>">
                                                <i class="fa-solid fa-trash"></i> Hapus
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="<?php echo has_role(['Super Admin', 'Admin']) ? 9 : 8; ?>" class="text-center text-secondary py-5">
                            <i class="fa-solid fa-boxes-stacked fa-2x mb-2 d-block opacity-25"></i>
                            Karyawan ini belum memegang barang inventaris aktif.<br>
                            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                <small>Klik tombol <strong>Tugaskan Aset</strong> di atas untuk menetapkan aset kepada karyawan ini.</small>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Complete Assignment SweetAlert
    const completeButtons = document.querySelectorAll('.btn-complete');
    completeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const form = this.closest('form');
            const barang = this.getAttribute('data-barang');
            
            Swal.fire({
                title: 'Selesaikan Penugasan?',
                text: `Apakah Anda yakin ingin menyelesaikan masa pemakaian barang "${barang}" oleh karyawan ini?`,
                icon: 'question',
                showCancelButton: true,
                confirmButtonColor: '#10b981',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ya, Selesaikan!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    });

    // Delete Assignment SweetAlert
    const deleteButtons = document.querySelectorAll('.btn-delete');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const form = this.closest('form');
            const barang = this.getAttribute('data-barang');
            
            Swal.fire({
                title: 'Hapus Penugasan?',
                text: `Apakah Anda yakin ingin menghapus data penugasan barang "${barang}"? Tindakan ini permanen dan tidak bisa dikembalikan!`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#ef4444',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    form.submit();
                }
            });
        });
    });
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
