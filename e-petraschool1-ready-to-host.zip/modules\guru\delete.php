<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\guru\delete.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    try {
        // Fetch teacher details for photo deletion and logging
        $stmt = $pdo->prepare("SELECT nama_guru, foto FROM guru WHERE id = ?");
        $stmt->execute([$id]);
        $teacher = $stmt->fetch();

        if ($teacher) {
            // Delete photo if exists
            if (!empty($teacher['foto'])) {
                $upload_dir = dirname(dirname(__DIR__)) . '/assets/uploads/guru/';
                if (file_exists($upload_dir . $teacher['foto'])) {
                    unlink($upload_dir . $teacher['foto']);
                }
            }

            // Delete teacher
            $delete_stmt = $pdo->prepare("DELETE FROM guru WHERE id = ?");
            $delete_stmt->execute([$id]);
            
            write_audit_log("Menghapus data guru: " . $teacher['nama_guru'] . ".");
        }
    } catch (Exception $e) {
        error_log("Failed to delete teacher: " . $e->getMessage());
    }
}

header("Location: index.php");
exit;
?>
