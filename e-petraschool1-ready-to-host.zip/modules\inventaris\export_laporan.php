<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris\export_laporan.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
if (!has_role('Kepala Sekolah')) {
    require_inventaris_access();
}

$kategori_id = isset($_GET['kategori_id']) && $_GET['kategori_id'] !== '' ? intval($_GET['kategori_id']) : '';
$ruangan_id = isset($_GET['ruangan_id']) && $_GET['ruangan_id'] !== '' ? intval($_GET['ruangan_id']) : '';
$kondisi = isset($_GET['kondisi']) ? trim($_GET['kondisi']) : '';
$status_pinjam = isset($_GET['status_pinjam']) ? trim($_GET['status_pinjam']) : '';
$status_rusak = isset($_GET['status_rusak']) ? trim($_GET['status_rusak']) : '';
$tahun = isset($_GET['tahun']) && $_GET['tahun'] !== '' ? intval($_GET['tahun']) : '';

try {
    $query = "
        SELECT i.*, k.nama_kategori, r.nama_ruangan 
        FROM inventaris i 
        JOIN kategori_barang k ON i.kategori_id = k.id 
        LEFT JOIN ruangan r ON i.ruangan_id = r.id 
        WHERE i.status_aktif = 'Aktif'
    ";
    
    $params = [];
    
    if ($kategori_id !== '') {
        $query .= " AND i.kategori_id = :kategori_id";
        $params['kategori_id'] = $kategori_id;
    }
    if ($ruangan_id !== '') {
        $query .= " AND i.ruangan_id = :ruangan_id";
        $params['ruangan_id'] = $ruangan_id;
    }
    if ($kondisi !== '') {
        $query .= " AND i.kondisi = :kondisi";
        $params['kondisi'] = $kondisi;
    }
    if ($status_rusak === '1') {
        $query .= " AND i.kondisi IN ('Rusak Ringan', 'Rusak Berat')";
    }
    if ($tahun !== '') {
        $query .= " AND i.tahun_perolehan = :tahun";
        $params['tahun'] = $tahun;
    }
    if ($status_pinjam !== '') {
        if ($status_pinjam === 'Dipinjam') {
            $query .= " AND i.id IN (SELECT DISTINCT inventaris_id FROM peminjaman WHERE status = 'Dipinjam')";
        } elseif ($status_pinjam === 'Tersedia') {
            $query .= " AND i.id NOT IN (SELECT DISTINCT inventaris_id FROM peminjaman WHERE status = 'Dipinjam')";
        }
    }

    $query .= " ORDER BY i.kode_barang ASC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

// Set CSV headers
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=laporan_inventaris_' . date('Y-m-d_H-i') . '.csv');

// Write UTF-8 BOM
echo "\xEF\xBB\xBF";

$output = fopen('php://output', 'w');

// Header row
fputcsv($output, [
    'No', 
    'Kode Barang', 
    'Nama Barang', 
    'Kategori', 
    'Lokasi', 
    'Merk', 
    'Tipe/Model', 
    'Kondisi', 
    'Tahun Perolehan', 
    'Harga Perolehan (Rp)', 
    'Sumber Dana'
]);

$no = 1;
$total_harga = 0;
foreach ($assets as $ast) {
    fputcsv($output, [
        $no++,
        $ast['kode_barang'],
        $ast['nama_barang'],
        $ast['nama_kategori'],
        $ast['nama_ruangan'] ?: 'Gudang / Belum Alokasi',
        $ast['merk'] ?: '-',
        $ast['tipe_model'] ?: '-',
        $ast['kondisi'],
        $ast['tahun_perolehan'] ?: '-',
        $ast['harga'],
        $ast['sumber_dana']
    ]);
    $total_harga += $ast['harga'];
}

// Add Total row at bottom
fputcsv($output, []);
fputcsv($output, [
    '', '', '', '', '', '', '', '', 'Total Nilai Aset:', $total_harga, ''
]);

fclose($output);
exit;
