<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\peminjaman\delete.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    try {
        // Fetch details for logging
        $stmt = $pdo->prepare("SELECT p.kode_peminjaman, i.nama_barang FROM peminjaman p JOIN inventaris i ON p.inventaris_id = i.id WHERE p.id = ?");
        $stmt->execute([$id]);
        $data = $stmt->fetch();

        if ($data) {
            $delete_stmt = $pdo->prepare("DELETE FROM peminjaman WHERE id = ?");
            $delete_stmt->execute([$id]);
            write_audit_log("Menghapus log peminjaman " . $data['nama_barang'] . " (Kode Transaksi: " . $data['kode_peminjaman'] . ").");
        }
    } catch (Exception $e) {
        error_log("Failed to delete borrowing: " . $e->getMessage());
    }
}

header("Location: index.php");
exit;
?>
