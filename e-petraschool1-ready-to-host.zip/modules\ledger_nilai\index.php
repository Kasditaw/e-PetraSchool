<?php
// c:\xampp\htdocs\e-petraschool1\modules\ledger_nilai\index.php

// ============================================================
// AJAX HANDLER — must run BEFORE header.php outputs any HTML
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'save_local_grades') {
    // Buffer any unexpected output (e.g. db.php die()) so it won't corrupt JSON
    ob_start();
    require_once dirname(dirname(__DIR__)) . '/config/auth.php';
    ob_end_clean(); // discard any stray output from includes

    header('Content-Type: application/json');
    try {
        // Read raw JSON body
        $raw   = file_get_contents('php://input');
        $input = json_decode($raw, true);
        if (!$input || !isset($input['ledger_data'])) {
            throw new Exception("Data tidak valid atau kosong.");
        }

        // Manual CSRF validation — token is in JSON body, NOT in $_POST
        if (session_status() === PHP_SESSION_NONE) session_start();
        $csrf_token = $input['csrf_token'] ?? '';
        if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $csrf_token)) {
            throw new Exception("Token keamanan tidak valid. Silakan refresh halaman dan coba lagi.");
        }

        $ledger_data      = $input['ledger_data'];
        $guru_id          = intval($input['guru_id'] ?? 1);
        $semester_mapping = $input['semester_mapping'] ?? [];

        // Helper: map short code to full DB subject name
        $subject_mappings = [
            'PAK'      => 'Agama Kristen',
            'PP'       => 'Pendidikan Pancasila',
            'BIN'      => 'Bahasa Indonesia',
            'BIG'      => 'Bahasa Inggris',
            'MTK'      => 'Matematika',
            'IPAS'     => 'IPA (Ilmu Pengetahuan Alam)',
            'PJOK'     => 'PJOK (Pendidikan Jasmani)',
            'SENI'     => 'Seni Budaya & Prakarya',
            'MANDARIN' => 'Bahasa Mandarin',
        ];

        // Fetch all active subjects to allow fuzzy matching of custom codes
        $mapel_stmt = $pdo->query("SELECT nama_mapel FROM mata_pelajaran WHERE status = 'Aktif'");
        $db_subjects = $mapel_stmt->fetchAll(PDO::FETCH_ASSOC);

        function _ajax_map_subject($code, $mappings, $db_subjects) {
            $code = strtoupper(trim($code));
            if (isset($mappings[$code])) return $mappings[$code];
            foreach ($db_subjects as $sub) {
                $clean_db   = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $sub['nama_mapel']));
                $clean_code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $code));
                if ($clean_db === $clean_code || strpos($clean_db, $clean_code) !== false || strpos($clean_code, $clean_db) !== false) {
                    return $sub['nama_mapel'];
                }
            }
            return $code;
        }

        $pdo->beginTransaction();
        $inserted = 0;
        $updated  = 0;

        foreach ($ledger_data as $student) {
            $nis = $student['nis'];
            if (strpos($nis, 'NEW-') === 0) continue;

            $s_stmt = $pdo->prepare("SELECT id FROM siswa WHERE nis = ? LIMIT 1");
            $s_stmt->execute([$nis]);
            $siswa_id = $s_stmt->fetchColumn();
            if (!$siswa_id) continue;

            $grades = $student['grades'] ?? [];
            foreach ($grades as $sem_key => $subject_grades) {
                if (!isset($semester_mapping[$sem_key])) continue;
                $sem_val  = $semester_mapping[$sem_key];
                $parts    = explode('-', $sem_val);
                if (count($parts) < 2) continue;
                $tahun_ajaran = $parts[0];
                $semester_num = $parts[1];

                foreach ($subject_grades as $short_mapel => $grade_val) {
                    if ($grade_val === null || $grade_val === '') continue;

                    $db_mapel = _ajax_map_subject($short_mapel, $subject_mappings, $db_subjects);
                    $tugas  = floatval($grade_val);
                    $uts    = floatval($grade_val);
                    $uas    = floatval($grade_val);
                    $akhir  = floatval($grade_val);

                    $predikat = 'E';
                    if ($akhir >= 86) $predikat = 'A';
                    elseif ($akhir >= 75) $predikat = 'B';
                    elseif ($akhir >= 60) $predikat = 'C';
                    elseif ($akhir >= 45) $predikat = 'D';

                    $check_stmt = $pdo->prepare("
                        SELECT id FROM nilai
                        WHERE siswa_id = ? AND mata_pelajaran = ? AND semester = ? AND tahun_ajaran = ?
                        LIMIT 1
                    ");
                    $check_stmt->execute([$siswa_id, $db_mapel, $semester_num, $tahun_ajaran]);
                    $existing_id = $check_stmt->fetchColumn();

                    if ($existing_id) {
                        $pdo->prepare("
                            UPDATE nilai
                            SET guru_id=?, nilai_tugas=?, nilai_uts=?, nilai_uas=?, nilai_akhir=?, predikat=?
                            WHERE id=?
                        ")->execute([$guru_id, $tugas, $uts, $uas, $akhir, $predikat, $existing_id]);
                        $updated++;
                    } else {
                        $pdo->prepare("
                            INSERT INTO nilai (siswa_id, guru_id, semester, tahun_ajaran, mata_pelajaran, nilai_tugas, nilai_uts, nilai_uas, nilai_akhir, predikat)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        ")->execute([$siswa_id, $guru_id, $semester_num, $tahun_ajaran, $db_mapel, $tugas, $uts, $uas, $akhir, $predikat]);
                        $inserted++;
                    }
                }
            }
        }

        $pdo->commit();
        write_audit_log("Sinkronisasi nilai ledger: $inserted ditambahkan, $updated diperbarui.");
        echo json_encode(['status' => 'success', 'message' => "Berhasil sinkronisasi nilai! ($inserted ditambahkan, $updated diperbarui)"]);
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
    exit;
}
// ============================================================
// END AJAX HANDLER
// ============================================================

$page_title = 'Sistem Penggabung Ledger Nilai';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin', 'Kepala Sekolah', 'Guru']);

// Helper to map UI shortcodes to official DB names (used in page context)
function map_subject_code_to_db_name($code, $db_subjects) {
    $code = strtoupper(trim($code));
    $mappings = [
        'PAK'      => 'Agama Kristen',
        'PP'       => 'Pendidikan Pancasila',
        'BIN'      => 'Bahasa Indonesia',
        'BIG'      => 'Bahasa Inggris',
        'MTK'      => 'Matematika',
        'IPAS'     => 'IPA (Ilmu Pengetahuan Alam)',
        'PJOK'     => 'PJOK (Pendidikan Jasmani)',
        'SENI'     => 'Seni Budaya & Prakarya',
        'MANDARIN' => 'Bahasa Mandarin',
    ];
    if (isset($mappings[$code])) return $mappings[$code];
    foreach ($db_subjects as $sub) {
        $clean_db   = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $sub['nama_mapel']));
        $clean_code = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $code));
        if ($clean_db === $clean_code || strpos($clean_db, $clean_code) !== false || strpos($clean_code, $clean_db) !== false) {
            return $sub['nama_mapel'];
        }
    }
    return $code;
}

try {
    $students_stmt = $pdo->query("SELECT s.id, s.nis, s.nama_lengkap, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON s.kelas_id = k.id WHERE s.status_siswa = 'Aktif' ORDER BY s.nama_lengkap ASC");
    $local_students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $local_students = [];
}

// Fetch classes
try {
    $classes_stmt = $pdo->query("SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas ASC");
    $local_classes = $classes_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $local_classes = [];
}

// Fetch active teachers
try {
    $teachers_stmt = $pdo->query("SELECT id, nip, nama_guru FROM guru ORDER BY nama_guru ASC");
    $local_teachers = $teachers_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $local_teachers = [];
}

// Fetch all local grades to pre-fill dynamic view on load
try {
    $grades_stmt = $pdo->query("
        SELECT s.nis, n.semester, n.tahun_ajaran, n.mata_pelajaran, n.nilai_akhir
        FROM nilai n
        JOIN siswa s ON n.siswa_id = s.id
        WHERE s.status_siswa = 'Aktif'
    ");
    $local_grades = $grades_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $local_grades = [];
}
?>

<!-- Tailwind CSS & Font Awesome CDN -->
<script src="https://cdn.tailwindcss.com"></script>
<!-- Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<!-- html2pdf.js CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

<script>
  tailwind.config = {
    corePlugins: {
      preflight: false,
    },
    theme: {
      extend: {
        colors: {
          petrapurple: {
            100: '#e0e7ff',
            500: '#6366f1',
            600: '#4f46e5',
            700: '#4338ca',
            800: '#3730a3',
            900: '#1e1b4b',
          },
          gold: {
            400: '#fbbf24',
            500: '#f59e0b',
            600: '#d97706',
          }
        }
      }
    }
  }
</script>

<style>
  /* Premium Light Dashboard Styles */
  .ledger-glass-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 1rem;
    padding: 1.5rem;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.02);
  }
  .ledger-gradient-banner {
    background: linear-gradient(135deg, #6366f1 0%, #a855f7 100%);
    box-shadow: 0 4px 20px rgba(99, 102, 241, 0.25);
  }
  .ledger-scroll::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }
  .ledger-scroll::-webkit-scrollbar-track {
    background: #f8fafc;
  }
  .ledger-scroll::-webkit-scrollbar-thumb {
    background: #cbd5e1;
    border-radius: 4px;
  }
  .ledger-scroll::-webkit-scrollbar-thumb:hover {
    background: #94a3b8;
  }
  
  .tab-sem-active {
    background-color: #6366f1 !important;
    color: #ffffff !important;
    border-color: #6366f1 !important;
  }
  .tab-sem-inactive {
    background-color: #ffffff !important;
    color: #475569 !important;
    border: 1px solid #e2e8f0 !important;
  }
  .tab-sem-inactive:hover {
    background-color: #f8fafc !important;
  }
  
  /* Form components override for custom light theme integration */
  .control-dark-input {
    background-color: #ffffff !important;
    border: 1px solid #cbd5e1 !important;
    color: #0f172a !important;
  }
  .control-dark-input:focus {
    border-color: #6366f1 !important;
    box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.2) !important;
  }
  .badge-gold-pill {
    border: 1px solid #f59e0b;
    background: rgba(245, 158, 11, 0.08);
    color: #d97706;
    font-size: 10px;
    font-weight: 700;
    padding: 3px 8px;
    border-radius: 12px;
  }
  
  /* Chart Panel Styles */
  .chart-panel-card {
    background: #ffffff;
    border: 1px solid #e2e8f0;
    border-radius: 1rem;
    padding: 1.5rem;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.02);
  }
  .chart-student-tag {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    border: 1px solid;
  }
  .chart-student-tag:hover {
    opacity: 0.8;
    transform: translateY(-1px);
  }
  .chart-student-tag .remove-tag {
    font-size: 10px;
    opacity: 0.7;
  }
  .chart-student-tag:hover .remove-tag {
    opacity: 1;
  }
  .row-clickable {
    cursor: pointer;
    transition: background 0.15s;
  }
  .row-clickable:hover td {
    background: rgba(99, 102, 241, 0.04) !important;
  }
  .row-in-chart td:first-child {
    border-left: 3px solid;
  }
  
  #main-ledger-table thead tr th {
    background-color: #f8fafc;
    color: #475569;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 10px;
    letter-spacing: 0.05em;
    padding: 10px 8px;
    border-bottom: 2px solid #e2e8f0;
  }

  .chart-empty-state {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 280px;
    color: #64748b;
    gap: 12px;
  }
  .chart-empty-state i {
    font-size: 48px;
    opacity: 0.35;
  }
  @keyframes chart-fade-in {
    from { opacity: 0; transform: translateY(12px); }
    to   { opacity: 1; transform: translateY(0); }
  }
  .chart-animate-in {
    animation: chart-fade-in 0.4s ease both;
  }
</style>

<!-- Hidden CSRF token value for AJAX -->
<input type="hidden" id="csrf-token-val" value="<?php echo generate_csrf_token(); ?>">

<!-- Main Container -->
<div class="container-fluid px-4 py-2">
    
    <!-- Redesigned Premium Header -->
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 mb-4">
        <div class="flex items-center gap-3">
            <div class="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center shadow-md shadow-indigo-600/20">
                <i class="fa-solid fa-graduation-cap text-white text-xl"></i>
            </div>
            <div>
                <h5 class="text-slate-800 font-bold text-lg mb-0 font-sans tracking-wide">Sistem Penggabung Ledger Nilai</h5>
                <p class="text-slate-500 text-xs mb-0">Konsolidasi otomatis multi-mapel acak Semester Dinamis</p>
            </div>
        </div>
        <div class="flex items-center gap-2">
            <span class="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold bg-sky-50 text-sky-600 border border-sky-200">
                <span class="w-2 h-2 rounded-full bg-sky-500"></span> Tersimpan (Lokal)
            </span>
            <button id="btn-demo" class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-50 text-indigo-600 border border-indigo-200 hover:bg-indigo-100 transition-all">
                <i class="fa-solid fa-wand-magic-sparkles"></i> Coba Data Demo
            </button>
            <button id="btn-reset-all" class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-50 text-rose-600 border border-rose-200 hover:bg-rose-100 transition-all">
                <i class="fa-solid fa-trash-can"></i> Reset
            </button>
        </div>
    </div>

    <!-- Purple Hero Solution Banner -->
    <div class="ledger-gradient-banner rounded-xl p-4 mb-4 text-white flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
        <div class="max-w-3xl">
            <h6 class="font-bold text-sm md:text-base flex items-center gap-2 mb-1.5">
                Solusi Integrasi Ledger & Rapor Fleksibel 
                <span class="bg-indigo-800/60 text-indigo-200 text-2xs px-2 py-0.5 rounded border border-indigo-400/20"><i class="fa-solid fa-lock text-3xs"></i> Simpan Otomatis Lokal</span>
            </h6>
            <p class="text-xs text-indigo-100 mb-0 opacity-90 leading-relaxed">
                Sistem ini kini sepenuhnya fleksibel! Anda bebas menambah/mengurangi jumlah semester serta mata pelajaran. Anda bahkan dapat mengubah nama mata pelajaran kapan saja tanpa khawatir kehilangan data nilai yang sudah dimasukkan.
            </p>
        </div>
    </div>

    <!-- Layout Grid -->
    <div class="grid grid-cols-1 xl:grid-cols-12 gap-4">
        
        <!-- LEFT PANEL (xl:col-span-5) -->
        <div class="xl:col-span-5 flex flex-col gap-4">
            
            <!-- Card 1: Pengaturan Struktur Ledger -->
            <div class="ledger-glass-card">
                <div class="flex justify-between items-center border-b border-slate-200 pb-2 mb-3">
                    <h6 class="text-slate-800 font-bold text-xs flex items-center gap-2 mb-0">
                        <i class="fa-solid fa-sliders text-indigo-600"></i> Pengaturan Struktur Ledger
                    </h6>
                    <span class="text-3xs text-indigo-600 font-bold bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">Konfigurasi Alat</span>
                </div>
                
                <div class="mb-4">
                    <label class="text-slate-500 text-2xs font-semibold uppercase tracking-wider block mb-2">JUMLAH SEMESTER AKTIF:</label>
                    <div class="flex items-center gap-2">
                        <button id="btn-sem-minus" class="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200 transition-all font-bold">-</button>
                        <div id="label-sem-count" class="px-4 py-1.5 bg-white rounded-lg text-xs font-bold text-slate-800 border border-slate-200 w-28 text-center select-none">6 Semester</div>
                        <button id="btn-sem-plus" class="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 hover:bg-indigo-100 border border-indigo-200 transition-all font-bold">+</button>
                    </div>
                </div>
                
                <div>
                    <div class="flex justify-between items-center mb-2">
                        <label class="text-slate-500 text-2xs font-semibold uppercase tracking-wider block mb-0">MATA PELAJARAN & EDIT NAMA:</label>
                        <button id="btn-add-subject" class="text-indigo-600 hover:text-indigo-700 text-2xs font-bold flex items-center gap-1 bg-indigo-50 px-2 py-1 rounded border border-indigo-200 transition-all">
                            <i class="fa-solid fa-plus"></i> Tambah Mapel
                        </button>
                    </div>
                    
                    <!-- Subject List Container (Scrollable) -->
                    <div id="subject-list-container" class="ledger-scroll space-y-2 overflow-y-auto max-h-56 pr-1">
                        <!-- Rendered Dynamically via JS -->
                    </div>
                </div>
            </div>
            
            <!-- Card 2: Input Data per Semester -->
            <div class="ledger-glass-card">
                <div class="flex items-center border-b border-slate-200 pb-2 mb-3">
                    <h6 class="text-slate-800 font-bold text-xs flex items-center gap-2 mb-0">
                        <i class="fa-solid fa-file-import text-indigo-600"></i> Input Data per Semester
                    </h6>
                </div>
                
                <!-- Dynamic Semester Tabs Grid -->
                <div id="semester-tabs-container" class="grid grid-cols-6 gap-1.5 mb-3">
                    <!-- Rendered Dynamically -->
                </div>
                
                <div class="flex justify-between items-center mb-2">
                    <span class="text-xs font-semibold text-slate-700">Masukkan Data untuk <span id="label-target-semester-text" class="text-indigo-600">Semester 1</span></span>
                    <span class="text-slate-500 text-2xs font-medium"><span id="parsed-rows-count-text">0</span> baris terdeteksi</span>
                </div>
                
                <!-- Format Column Box -->
                <div class="bg-slate-50 rounded-lg border border-slate-200 p-2.5 mb-3">
                    <div class="flex justify-between items-center mb-1">
                        <span class="text-3xs uppercase tracking-wider text-slate-500 font-semibold">URUTAN KOLOM EXCEL / TAB:</span>
                        <button id="btn-copy-format" class="text-3xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1">
                            <i class="fa-solid fa-copy"></i> Salin Format
                        </button>
                    </div>
                    <div id="excel-format-preview" class="text-xs font-mono text-indigo-600 overflow-x-auto whitespace-nowrap py-1 ledger-scroll">
                        Nama_Siswa PAK PP BIN BIG MTK IPAS PJOK SENI JAWA MANDARIN
                    </div>
                </div>
                
                <!-- Excel paste Area -->
                <textarea id="paste-grades-area" rows="6" class="w-full control-dark-input rounded-lg p-2.5 text-xs font-mono mb-2" placeholder="Contoh salinan Excel:&#10;Aditya Pratama	80	85	90	82	78... (sesuai kolom)"></textarea>

                <!-- Step 1: Parse Excel button -->
                <button id="btn-parse-excel" class="w-full flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold bg-sky-600 text-white hover:bg-sky-700 border border-sky-600 transition-all shadow-sm mb-3">
                    <i class="fa-solid fa-table-cells-large"></i> Proses &amp; Gabungkan Data Excel
                </button>
                
                <!-- Guru Selector Dropdown (Aligned with DB save needs) -->
                <div class="mb-4">
                    <label class="text-slate-500 text-2xs font-semibold uppercase tracking-wider block mb-1">GURU PENGAJAR (UNTUK DATABASE):</label>
                    <select id="select-guru-id" class="w-full control-dark-input rounded p-2 text-xs" <?php echo $_SESSION['role'] === 'Guru' ? 'disabled' : ''; ?>>
                        <?php foreach ($local_teachers as $teacher): ?>
                            <option value="<?php echo $teacher['id']; ?>" <?php echo (isset($_SESSION['guru_id']) && $_SESSION['guru_id'] == $teacher['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($teacher['nama_guru']); ?> (NIP: <?php echo htmlspecialchars($teacher['nip']); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
 
                <!-- Step 2: Sync to DB button -->
                <button id="btn-save-grades" class="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-bold bg-indigo-600 text-white hover:bg-indigo-700 border border-indigo-600 transition-all shadow-sm">
                    <i class="fa-solid fa-floppy-disk"></i> Simpan &amp; Sinkronkan Nilai ke Database
                </button>
            </div>
 
            <!-- Card 3: Petunjuk Integrasi -->
            <div class="ledger-glass-card">
                <div class="flex items-center gap-2 mb-2 text-amber-600">
                    <i class="fa-solid fa-circle-info"></i>
                    <span class="text-xs font-bold">Petunjuk Integrasi:</span>
                </div>
                <ul class="list-disc pl-4 text-xs text-slate-600 space-y-1">
                    <li>Sesuaikan urutan mapel di kolom Excel dengan susunan nama mapel di atas.</li>
                    <li>Tekan <span class="bg-slate-100 px-1 py-0.5 rounded text-3xs font-mono text-slate-700 border border-slate-200">Salin Format</span> untuk mencocokkan header kolom Excel Anda.</li>
                    <li>Sistem otomatis menggabungkan nama siswa yang sama meskipun posisinya acak di tiap semester.</li>
                </ul>
            </div>
        </div>
        
        <!-- RIGHT PANEL (xl:col-span-7) -->
        <div class="xl:col-span-7 flex flex-col gap-4">
            
            <!-- Summary Stats Panel -->
            <div class="grid grid-cols-3 gap-3">
                <div class="ledger-glass-card flex flex-col justify-center items-start py-3">
                    <span class="text-3xs uppercase tracking-wider text-slate-500 font-bold mb-1">TOTAL SISWA TERDATA</span>
                    <span id="stat-total-students" class="text-2xl font-bold text-slate-800 leading-none">10</span>
                </div>
                <div class="ledger-glass-card flex flex-col justify-center items-start py-3">
                    <span class="text-3xs uppercase tracking-wider text-slate-500 font-bold mb-1">SISWA DATA LENGKAP</span>
                    <span id="stat-complete-students" class="text-2xl font-bold text-indigo-600 leading-none">10</span>
                </div>
                <div class="ledger-glass-card flex flex-col justify-center items-start py-3">
                    <span class="text-3xs uppercase tracking-wider text-slate-500 font-bold mb-1">RATA-RATA SEKOLAH</span>
                    <span id="stat-school-avg" class="text-2xl font-bold text-emerald-600 leading-none">87.22</span>
                </div>
            </div>
            
            <!-- Hasil Konsolidasi Ledger -->
            <div class="ledger-glass-card">
                
                <!-- Table Header Controls -->
                <div class="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-200 pb-3 mb-3 gap-3">
                    <div>
                        <h6 id="main-ledger-card-title" class="text-slate-800 font-bold text-xs flex items-center gap-2 mb-0.5">
                            <i class="fa-solid fa-table text-emerald-600"></i> Ledger Gabungan Semester 1-6
                        </h6>
                        <span class="text-slate-500 text-3xs">Urutan otomatis dikelompokkan berdasarkan nama siswa</span>
                    </div>
                    <div class="flex items-center gap-2 flex-wrap">
                        <button id="btn-export-excel" class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white border border-emerald-600 transition-all shadow-sm">
                            <i class="fa-solid fa-file-excel"></i> Ekspor Excel Ledger
                        </button>
                        <button id="btn-export-pdf" class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white border border-rose-600 transition-all shadow-sm">
                            <i class="fa-solid fa-file-pdf"></i> Ekspor PDF Ledger
                        </button>
                        <button id="btn-export-csv" class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-600 hover:bg-slate-700 text-white border border-slate-600 transition-all shadow-sm">
                            <i class="fa-solid fa-file-csv"></i> Ekspor CSV Ledger
                        </button>
                    </div>
                </div>
                
                <!-- Filters Bar -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-3 mb-3">
                    <div>
                        <label class="text-slate-500 text-3xs font-semibold uppercase tracking-wider block mb-1">MODE TAMPILAN TABEL:</label>
                        <select id="select-view-mode" class="w-full control-dark-input rounded p-1.5 text-xs">
                            <option value="ALL_AVERAGE">Tampilkan Rata-rata Seluruh Mapel</option>
                            <!-- Subject items will render dynamically -->
                        </select>
                    </div>
                    <div>
                        <label class="text-slate-500 text-3xs font-semibold uppercase tracking-wider block mb-1">URUTKAN TABEL:</label>
                        <select id="select-sort-mode" class="w-full control-dark-input rounded p-1.5 text-xs">
                            <option value="NAME_ASC">Nama Siswa (A - Z)</option>
                            <option value="NAME_DESC">Nama Siswa (Z - A)</option>
                            <option value="AVG_DESC">Rerata Tertinggi</option>
                            <option value="AVG_ASC">Rerata Terendah</option>
                        </select>
                    </div>
                    <div>
                        <label class="text-slate-500 text-3xs font-semibold uppercase tracking-wider block mb-1">CARI SISWA:</label>
                        <div class="relative">
                            <input type="text" id="search-student-input" class="w-full control-dark-input rounded p-1.5 text-xs pl-8" placeholder="Ketik nama siswa di sini...">
                            <i class="fa-solid fa-magnifying-glass text-slate-400 absolute left-2.5 top-2.5 text-xs"></i>
                        </div>
                    </div>
                </div>
                
                <!-- Consolidated Ledger Table -->
                <div class="table-responsive ledger-scroll overflow-y-auto pr-1" style="max-height: 480px;">
                    <table class="table table-custom table-sm text-xs w-full text-left" id="main-ledger-table">
                        <thead>
                            <tr id="table-header-row" class="text-slate-500 border-b border-slate-200 text-2xs uppercase">
                                <th class="py-2">NO</th>
                                <th class="py-2">NAMA SISWA</th>
                                <th class="py-2 text-center">PERINGKAT</th>
                                <!-- Dynamic semester cols -->
                                <th class="py-2 text-right">RERATA</th>
                            </tr>
                        </thead>
                        <tbody id="table-body-rows">
                            <!-- Dynamic rows via JS -->
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>
    </div>
</div>

<!-- ============================================================ -->
<!-- CHART VISUALIZATION PANEL - FULL WIDTH BELOW GRID -->
<!-- ============================================================ -->
<div class="container-fluid px-4 pb-4">
    <div class="chart-panel-card chart-animate-in" id="chart-section">

        <!-- Chart Header -->
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-slate-200 pb-3 mb-4 gap-3">
            <div>
                <h6 class="text-slate-800 font-bold text-sm flex items-center gap-2 mb-1">
                    <div class="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shadow-md shadow-indigo-600/20 flex-shrink-0">
                        <i class="fa-solid fa-chart-line text-white text-sm"></i>
                    </div>
                    Visualisasi Tren Nilai Siswa
                </h6>
                <span class="text-slate-500 text-xs ml-10">Klik nama siswa pada tabel di atas untuk menampilkan grafik tren nilainya per semester &mdash; bisa pilih hingga 8 siswa sekaligus untuk perbandingan</span>
            </div>
            <div class="flex items-center gap-2 flex-wrap">
                <!-- Subject selector for chart -->
                <div class="flex items-center gap-2">
                    <label class="text-slate-500 text-2xs font-semibold uppercase tracking-wider whitespace-nowrap">TAMPILKAN:</label>
                    <select id="chart-subject-select" class="control-dark-input rounded p-1.5 text-xs" style="min-width:180px;">
                        <option value="ALL_AVERAGE">Rata-rata Semua Mapel</option>
                    </select>
                </div>
                <!-- Chart type toggle -->
                <div class="flex items-center gap-1">
                    <button id="btn-chart-type-line" title="Line Chart" class="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center text-sm border border-indigo-600 transition-all shadow-sm">
                        <i class="fa-solid fa-chart-line"></i>
                    </button>
                    <button id="btn-chart-type-bar" title="Bar Chart" class="w-8 h-8 rounded-lg bg-slate-100 text-slate-500 flex items-center justify-center text-sm border border-slate-200 hover:bg-slate-200 transition-all">
                        <i class="fa-solid fa-chart-bar"></i>
                    </button>
                </div>
                <!-- Clear chart -->
                <button id="btn-clear-chart" class="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-rose-50 text-rose-600 border border-rose-200 hover:bg-rose-100 transition-all">
                    <i class="fa-solid fa-xmark"></i> Hapus Semua
                </button>
            </div>
        </div>

        <!-- Selected Students Tags -->
        <div id="chart-student-tags" class="flex flex-wrap gap-2 mb-4 min-h-8">
            <!-- Tags rendered here -->
        </div>

        <!-- Chart Canvas or Empty State -->
        <div id="chart-canvas-wrapper" class="relative" style="height: 400px;">
            <div id="chart-empty-state" class="chart-empty-state">
                <i class="fa-solid fa-chart-line" style="font-size:56px; color:rgba(99,102,241,0.4);"></i>
                <div class="text-center">
                    <p class="text-base font-semibold text-slate-600 mb-2">Belum ada siswa dipilih</p>
                    <p class="text-xs text-slate-500 max-w-md">Klik nama siswa pada tabel ledger di atas untuk menampilkan grafik tren nilai mereka per semester. Anda dapat membandingkan hingga 8 siswa sekaligus.</p>
                </div>
            </div>
            <canvas id="ledger-trend-chart" style="display:none;"></canvas>
        </div>

        <!-- Chart Stats Summary Row -->
        <div id="chart-stats-row" class="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4 hidden">
            <!-- Rendered via JS -->
        </div>
    </div>
</div>

<!-- ============================================================ -->
<!-- CHART.JS VISUALIZATION LOGIC -->
<!-- ============================================================ -->
<script>
// --- CHART MODULE ---
// Runs independently alongside the main ledger script
document.addEventListener('DOMContentLoaded', () => {

    // Color palette for multiple students
    // Color palette for multiple students (suitable for light backgrounds)
    const CHART_COLORS = [
        { border: '#4f46e5', bg: 'rgba(79,70,229,0.08)' },
        { border: '#10b981', bg: 'rgba(16,185,129,0.08)' },
        { border: '#d97706', bg: 'rgba(217,119,6,0.08)' },
        { border: '#e11d48', bg: 'rgba(225,29,72,0.08)' },
        { border: '#9333ea', bg: 'rgba(147,51,234,0.08)' },
        { border: '#0891b2', bg: 'rgba(8,145,178,0.08)' },
        { border: '#db2777', bg: 'rgba(219,39,119,0.08)' },
        { border: '#65a30d', bg: 'rgba(101,163,13,0.08)' },
    ];

    let chartInstance = null;
    let chartType = 'line';
    let chartSelectedStudents = []; // [{ nis, nama, colorIdx }]
    let chartSubjectMode = 'ALL_AVERAGE'; // or a specific mapel code

    // ----------------------------------------------------------------
    // Init Chart.js instance
    // ----------------------------------------------------------------
    function initChart() {
        const ctx = document.getElementById('ledger-trend-chart').getContext('2d');

        Chart.defaults.color = '#475569';
        Chart.defaults.font.family = "'Inter', 'Outfit', sans-serif";

        chartInstance = new Chart(ctx, {
            type: chartType,
            data: { labels: [], datasets: [] },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    duration: 600,
                    easing: 'easeInOutQuart'
                },
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                plugins: {
                    legend: {
                        display: false // we use custom tags
                    },
                    tooltip: {
                        backgroundColor: '#0f172a',
                        borderColor: 'rgba(99,102,241,0.2)',
                        borderWidth: 1,
                        titleColor: '#f8fafc',
                        bodyColor: '#cbd5e1',
                        padding: 12,
                        cornerRadius: 10,
                        callbacks: {
                            label: (ctx) => {
                                const val = ctx.raw;
                                if (val === null || val === undefined) return null;
                                return ` ${ctx.dataset.label}: ${val.toFixed(2)}`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            color: 'rgba(226,232,240,0.8)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#64748b',
                            font: { size: 11, weight: '600' }
                        }
                    },
                    y: {
                        min: 0,
                        max: 100,
                        grid: {
                            color: 'rgba(226,232,240,0.8)',
                            drawBorder: false
                        },
                        ticks: {
                            color: '#64748b',
                            font: { size: 11 },
                            stepSize: 10,
                            callback: (val) => val
                        }
                    }
                }
            }
        });
    }

    // ----------------------------------------------------------------
    // Compute grade value for a student & semester based on subject mode
    // ----------------------------------------------------------------
    function getStudentSemValue(studData, semKey, subjectMode) {
        const semGrades = (studData.grades && studData.grades[semKey]) ? studData.grades[semKey] : {};
        // Use window.activeSubjects exposed by main ledger script
        const subjects = window.ledgerActiveSubjects || [];

        if (subjectMode === 'ALL_AVERAGE') {
            let sum = 0, count = 0;
            subjects.forEach(mapel => {
                if (semGrades[mapel] !== undefined) { sum += semGrades[mapel]; count++; }
            });
            return count > 0 ? parseFloat((sum / count).toFixed(2)) : null;
        } else {
            return semGrades[subjectMode] !== undefined ? semGrades[subjectMode] : null;
        }
    }

    // ----------------------------------------------------------------
    // Build datasets and update chart
    // ----------------------------------------------------------------
    function updateChart() {
        if (!chartInstance) initChart();

        const semCount = window.ledgerActiveSemCount || 6;
        const labels = [];
        for (let i = 1; i <= semCount; i++) labels.push('Sem ' + i);

        const datasets = chartSelectedStudents.map(sel => {
            const studData = window.ledgerData ? window.ledgerData[sel.nis] : null;
            const color = CHART_COLORS[sel.colorIdx % CHART_COLORS.length];
            const data = [];

            for (let i = 1; i <= semCount; i++) {
                const val = studData ? getStudentSemValue(studData, 'S' + i, chartSubjectMode) : null;
                data.push(val);
            }

            return {
                label: sel.nama,
                data: data,
                borderColor: color.border,
                backgroundColor: color.bg,
                pointBackgroundColor: color.border,
                pointBorderColor: '#ffffff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 8,
                borderWidth: 2.5,
                fill: chartType === 'line',
                tension: 0.4,
                spanGaps: true
            };
        });

        chartInstance.config.type = chartType;
        chartInstance.data.labels = labels;
        chartInstance.data.datasets = datasets;
        chartInstance.update();

        toggleChartVisibility();
        renderChartStats();
    }

    // Show/hide empty state vs canvas
    // Show/hide empty state vs canvas
    function toggleChartVisibility() {
        const isEmpty = chartSelectedStudents.length === 0;
        document.getElementById('chart-empty-state').style.display = isEmpty ? 'flex' : 'none';
        document.getElementById('ledger-trend-chart').style.display = isEmpty ? 'none' : 'block';
        const statsRow = document.getElementById('chart-stats-row');
        if (isEmpty) statsRow.classList.add('hidden');
        else statsRow.classList.remove('hidden');
    }

    // Render summary stat cards below chart
    function renderChartStats() {
        const statsRow = document.getElementById('chart-stats-row');
        statsRow.innerHTML = '';

        const semCount = window.ledgerActiveSemCount || 6;

        chartSelectedStudents.forEach(sel => {
            const studData = window.ledgerData ? window.ledgerData[sel.nis] : null;
            const color = CHART_COLORS[sel.colorIdx % CHART_COLORS.length];
            let sum = 0, count = 0, minVal = 999, maxVal = -1;

            for (let i = 1; i <= semCount; i++) {
                const v = studData ? getStudentSemValue(studData, 'S' + i, chartSubjectMode) : null;
                if (v !== null) {
                    sum += v; count++;
                    if (v < minVal) minVal = v;
                    if (v > maxVal) maxVal = v;
                }
            }
            const avg = count > 0 ? (sum / count).toFixed(2) : '—';
            const trend = count >= 2 ? (() => {
                // find last two non-null values
                let vals = [];
                for (let i = 1; i <= semCount; i++) {
                    const v = studData ? getStudentSemValue(studData, 'S' + i, chartSubjectMode) : null;
                    if (v !== null) vals.push(v);
                }
                if (vals.length < 2) return null;
                return vals[vals.length - 1] - vals[vals.length - 2];
            })() : null;

            const trendHtml = trend === null ? '' :
                trend > 0 ? `<span class="text-emerald-600 text-2xs font-bold ml-1"><i class="fa-solid fa-arrow-trend-up"></i> +${trend.toFixed(1)}</span>` :
                trend < 0 ? `<span class="text-rose-600 text-2xs font-bold ml-1"><i class="fa-solid fa-arrow-trend-down"></i> ${trend.toFixed(1)}</span>` :
                `<span class="text-slate-400 text-2xs ml-1"><i class="fa-solid fa-minus"></i> Stabil</span>`;

            const card = document.createElement('div');
            card.className = 'ledger-glass-card py-3 px-4';
            card.style.borderLeft = `3px solid ${color.border}`;
            card.innerHTML = `
                <div class="text-3xs uppercase tracking-wider font-bold mb-1" style="color:${color.border};">
                    ${sel.nama.split(' ').slice(0,2).join(' ')}
                </div>
                <div class="flex items-end gap-1">
                    <span class="text-xl font-bold text-slate-800 leading-none">${avg}</span>
                    ${trendHtml}
                </div>
                <div class="text-3xs text-slate-500 mt-1">
                    Min: ${minVal < 999 ? minVal.toFixed(1) : '—'} &middot; Maks: ${maxVal > -1 ? maxVal.toFixed(1) : '—'}
                </div>
            `;
            statsRow.appendChild(card);
        });
    }

    // ----------------------------------------------------------------
    // Render student tags above chart
    // ----------------------------------------------------------------
    function renderStudentTags() {
        const container = document.getElementById('chart-student-tags');
        container.innerHTML = '';

        if (chartSelectedStudents.length === 0) {
            container.innerHTML = '<span class="text-slate-600 text-xs italic">Belum ada siswa dipilih — klik nama siswa di tabel</span>';
            return;
        }

        chartSelectedStudents.forEach((sel, idx) => {
            const color = CHART_COLORS[sel.colorIdx % CHART_COLORS.length];
            const tag = document.createElement('span');
            tag.className = 'chart-student-tag';
            tag.style.borderColor = color.border;
            tag.style.backgroundColor = color.bg;
            tag.style.color = color.border;
            tag.innerHTML = `
                <span class="w-2 h-2 rounded-full flex-shrink-0" style="background:${color.border};"></span>
                ${sel.nama}
                <button class="remove-tag ml-1 hover:scale-110 transition-transform" data-idx="${idx}" title="Hapus">&times;</button>
            `;
            tag.querySelector('.remove-tag').addEventListener('click', (e) => {
                e.stopPropagation();
                const i = parseInt(e.currentTarget.dataset.idx);
                const removedNis = chartSelectedStudents[i].nis;
                chartSelectedStudents.splice(i, 1);
                // Remove active highlight in table
                const tr = document.querySelector(`tr[data-nis="${removedNis}"]`);
                if (tr) tr.classList.remove('row-in-chart');
                renderStudentTags();
                updateChart();
            });
            container.appendChild(tag);
        });
    }

    // ----------------------------------------------------------------
    // Toggle student in/out of chart (called from table click)
    // ----------------------------------------------------------------
    window.chartToggleStudent = function(nis, nama) {
        const existingIdx = chartSelectedStudents.findIndex(s => s.nis === nis);
        const tr = document.querySelector(`tr[data-nis="${nis}"]`);

        if (existingIdx !== -1) {
            // Remove
            const removedColor = chartSelectedStudents[existingIdx].colorIdx;
            chartSelectedStudents.splice(existingIdx, 1);
            if (tr) {
                tr.classList.remove('row-in-chart');
                tr.style.removeProperty('--chart-row-color');
            }
        } else {
            // Add (limit to 8 students)
            if (chartSelectedStudents.length >= 8) {
                Swal.fire({
                    title: 'Batas Maksimal',
                    text: 'Grafik dapat menampilkan maksimal 8 siswa sekaligus.',
                    icon: 'warning',
                    timer: 2000,
                    showConfirmButton: false
                });
                return;
            }
            // Pick next available color idx
            const usedColors = new Set(chartSelectedStudents.map(s => s.colorIdx));
            let colorIdx = 0;
            while (usedColors.has(colorIdx)) colorIdx++;

            chartSelectedStudents.push({ nis, nama, colorIdx });
            const color = CHART_COLORS[colorIdx % CHART_COLORS.length];

            if (tr) {
                tr.classList.add('row-in-chart');
                tr.style.setProperty('--chart-row-color', color.border);
                const firstTd = tr.querySelector('td:first-child');
                if (firstTd) firstTd.style.borderLeftColor = color.border;
            }
        }

        renderStudentTags();
        updateChart();

        // Scroll to chart smoothly
        if (chartSelectedStudents.length === 1) {
            document.getElementById('chart-section').scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    };

    // ----------------------------------------------------------------
    // Chart subject dropdown sync
    // ----------------------------------------------------------------
    window.syncChartSubjectDropdown = function(subjects) {
        const sel = document.getElementById('chart-subject-select');
        const currentVal = sel.value;
        sel.innerHTML = '<option value="ALL_AVERAGE">Rata-rata Semua Mapel</option>';
        subjects.forEach(mapel => {
            const opt = document.createElement('option');
            opt.value = mapel;
            opt.textContent = `Mapel: ${mapel}`;
            sel.appendChild(opt);
        });
        if (subjects.includes(currentVal) || currentVal === 'ALL_AVERAGE') {
            sel.value = currentVal;
        }
    };

    document.getElementById('chart-subject-select').addEventListener('change', (e) => {
        chartSubjectMode = e.target.value;
        if (chartSelectedStudents.length > 0) updateChart();
    });

    // Chart type toggle buttons
    document.getElementById('btn-chart-type-line').addEventListener('click', () => {
        chartType = 'line';
        document.getElementById('btn-chart-type-line').className = 'w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center text-sm border border-indigo-600 transition-all';
        document.getElementById('btn-chart-type-bar').className  = 'w-8 h-8 rounded-lg bg-slate-100 text-slate-500 flex items-center justify-center text-sm border border-slate-200 hover:bg-slate-200 transition-all';
        if (chartInstance) { chartInstance.destroy(); chartInstance = null; }
        if (chartSelectedStudents.length > 0) updateChart();
    });
    document.getElementById('btn-chart-type-bar').addEventListener('click', () => {
        chartType = 'bar';
        document.getElementById('btn-chart-type-bar').className  = 'w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center text-sm border border-indigo-600 transition-all';
        document.getElementById('btn-chart-type-line').className = 'w-8 h-8 rounded-lg bg-slate-100 text-slate-500 flex items-center justify-center text-sm border border-slate-200 hover:bg-slate-200 transition-all';
        if (chartInstance) { chartInstance.destroy(); chartInstance = null; }
        if (chartSelectedStudents.length > 0) updateChart();
    });

    // Clear all
    document.getElementById('btn-clear-chart').addEventListener('click', () => {
        chartSelectedStudents = [];
        document.querySelectorAll('tr[data-nis]').forEach(tr => {
            tr.classList.remove('row-in-chart');
            tr.style.removeProperty('--chart-row-color');
        });
        renderStudentTags();
        toggleChartVisibility();
        if (chartInstance) {
            chartInstance.data.datasets = [];
            chartInstance.update();
        }
    });

    // Initial empty state
    renderStudentTags();
    toggleChartVisibility();
});
</script>

<script>
document.addEventListener('DOMContentLoaded', () => {
    
    // ----------------------------------------------------
    // STATE VARIABLES
    // ----------------------------------------------------
    let activeSemestersCount = 6;
    let activeSubjects = ['PAK', 'PP', 'BIN', 'BIG', 'MTK', 'IPAS', 'PJOK', 'SENI', 'JAWA', 'MANDARIN'];
    let currentSemesterTab = 1; // S1
    
    // Primary storage object
    // Format: { student_nis: { nis, nama, kelas, grades: { S1: { PAK: 80, PP: 85, ... }, S2: ... } } }
    let ledgerData = {};
    
    // Semester maps to official DB values
    window.semesterMapping = {
        'S1': '2023/2024-1',
        'S2': '2023/2024-2',
        'S3': '2024/2025-1',
        'S4': '2024/2025-2',
        'S5': '2025/2026-1',
        'S6': '2025/2026-2',
        'S7': '2026/2027-1',
        'S8': '2026/2027-2',
        'S9': '2027/2028-1',
        'S10': '2027/2028-2',
        'S11': '2028/2029-1',
        'S12': '2028/2029-2'
    };
    
    // Pass PHP arrays to JS scope
    const localStudents = <?php echo json_encode($local_students); ?>;
    const localGrades = <?php echo json_encode($local_grades); ?>;
    
    // ----------------------------------------------------
    // INITIALIZATION & CACHE LOADING
    // ----------------------------------------------------
    loadFromLocalStorage();
    loadExistingGradesFromDB();
    renderAll();
    // Expose initial state to chart module
    window.ledgerActiveSemCount = activeSemestersCount;
    window.ledgerActiveSubjects = activeSubjects;
    window.ledgerData = ledgerData;

    // ----------------------------------------------------
    // LOCAL STORAGE SYNC FUNCTIONS
    // ----------------------------------------------------
    function saveToLocalStorage() {
        localStorage.setItem('ledger_active_sem_count', activeSemestersCount);
        localStorage.setItem('ledger_active_subjects', JSON.stringify(activeSubjects));
        localStorage.setItem('ledger_data', JSON.stringify(ledgerData));
        // Expose to chart module
        window.ledgerActiveSemCount = activeSemestersCount;
        window.ledgerActiveSubjects = activeSubjects;
        window.ledgerData = ledgerData;
    }
    
    function loadFromLocalStorage() {
        const count = localStorage.getItem('ledger_active_sem_count');
        if (count) activeSemestersCount = parseInt(count);
        
        const subjects = localStorage.getItem('ledger_active_subjects');
        if (subjects) activeSubjects = JSON.parse(subjects);
        
        const data = localStorage.getItem('ledger_data');
        if (data) ledgerData = JSON.parse(data);
    }
    
    // Process existing database grades (from MariaDB table) into dynamic state
    function loadExistingGradesFromDB() {
        if (!localGrades || localGrades.length === 0) return;
        
        // Reverse mapping of semVal to Sx keys
        const reverseSemMapping = {};
        for (const [key, val] of Object.entries(window.semesterMapping)) {
            reverseSemMapping[val] = key;
        }
        
        const dbNameToShortCode = {
            'Agama Kristen': 'PAK',
            'Pendidikan Pancasila': 'PP',
            'Bahasa Indonesia': 'BIN',
            'Bahasa Inggris': 'BIG',
            'Matematika': 'MTK',
            'IPA': 'IPAS',
            'IPS': 'IPAS',
            'IPA (Ilmu Pengetahuan Alam)': 'IPAS',
            'IPS (Ilmu Pengetahuan Sosial)': 'IPAS',
            'PJOK': 'PJOK',
            'PJOK (Pendidikan Jasmani)': 'PJOK',
            'Seni Budaya': 'SENI',
            'Seni Budaya & Prakarya': 'SENI',
            'Bahasa Jawa': 'JAWA',
            'Bahasa Mandarin': 'MANDARIN'
        };
        
        localGrades.forEach(g => {
            const nis = g.nis;
            const semVal = g.tahun_ajaran + '-' + g.semester; // e.g. "2025/2026-1"
            const semKey = reverseSemMapping[semVal]; // S1, S2, etc.
            if (!semKey) return; // ignore out of range
            
            const studObj = localStudents.find(s => s.nis === nis);
            if (!studObj) return;
            
            const dbMapel = g.mata_pelajaran;
            let shortMapel = dbNameToShortCode[dbMapel];
            if (!shortMapel) {
                const matched = activeSubjects.find(s => {
                    return dbMapel.toUpperCase().includes(s.toUpperCase()) || s.toUpperCase().includes(dbMapel.toUpperCase());
                });
                shortMapel = matched || dbMapel.substring(0, 5).toUpperCase();
            }
            
            // Populate ledgerData (only overwrite if no local user input has been stored)
            if (!ledgerData[nis]) {
                ledgerData[nis] = {
                    nis: nis,
                    nama: studObj.nama_lengkap,
                    kelas: studObj.nama_kelas || 'Umum',
                    grades: {}
                };
            }
            if (!ledgerData[nis].grades[semKey]) {
                ledgerData[nis].grades[semKey] = {};
            }
            if (ledgerData[nis].grades[semKey][shortMapel] === undefined) {
                ledgerData[nis].grades[semKey][shortMapel] = parseFloat(g.nilai_akhir);
            }
        });
    }
    
    // Smart matching algorithm for student name search
    function smartMatchStudentName(pastedName) {
        const clean = (str) => str.toLowerCase().replace(/[^a-z0-9]/g, '').trim();
        const pastedClean = clean(pastedName);
        if (!pastedClean) return null;
        
        // Exact
        let match = localStudents.find(s => clean(s.nama_lengkap) === pastedClean);
        if (match) return match;
        
        // Partial substring
        match = localStudents.find(s => {
            const localClean = clean(s.nama_lengkap);
            return localClean.includes(pastedClean) || pastedClean.includes(localClean);
        });
        return match;
    }

    // ----------------------------------------------------
    // RENDERING LOGIC
    // ----------------------------------------------------
    function renderAll() {
        renderSubjectList();
        renderExcelFormatPreview();
        renderSemesterTabs();
        renderViewModeOptions();
        renderLedgerTable();
        // Sync chart globals whenever state changes
        window.ledgerActiveSemCount = activeSemestersCount;
        window.ledgerActiveSubjects = activeSubjects;
        window.ledgerData = ledgerData;
        if (typeof window.syncChartSubjectDropdown === 'function') {
            window.syncChartSubjectDropdown(activeSubjects);
        }
    }
    
    // Render subjects panel inputs
    function renderSubjectList() {
        const container = document.getElementById('subject-list-container');
        container.innerHTML = '';
        
        activeSubjects.forEach((subj, idx) => {
            const div = document.createElement('div');
            div.className = 'flex items-center gap-2';
            div.innerHTML = `
                <input type="text" class="w-full control-dark-input rounded p-1 text-xs" value="${subj}" data-index="${idx}">
                <button class="btn-delete-subject text-rose-600 hover:text-rose-700 p-1.5 text-xs bg-rose-50 border border-rose-200 rounded transition-all" data-index="${idx}">
                    <i class="fa-solid fa-trash-can"></i>
                </button>
            `;
            container.appendChild(div);
        });
        
        // Listeners for changes in names
        container.querySelectorAll('input[type="text"]').forEach(input => {
            input.addEventListener('change', (e) => {
                const idx = parseInt(e.target.dataset.index);
                const oldVal = activeSubjects[idx];
                const newVal = e.target.value.trim().toUpperCase();
                
                if (newVal && oldVal !== newVal) {
                    // Update key in all ledger records
                    activeSubjects[idx] = newVal;
                    updateSubjectKeyInGrades(oldVal, newVal);
                    saveToLocalStorage();
                    renderAll();
                }
            });
        });
        
        // Trash actions
        container.querySelectorAll('.btn-delete-subject').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const idx = parseInt(e.currentTarget.dataset.index);
                const deletedMapel = activeSubjects[idx];
                
                activeSubjects.splice(idx, 1);
                removeSubjectFromGrades(deletedMapel);
                saveToLocalStorage();
                renderAll();
            });
        });
    }
    
    function updateSubjectKeyInGrades(oldVal, newVal) {
        Object.values(ledgerData).forEach(stud => {
            Object.values(stud.grades).forEach(semGrades => {
                if (semGrades[oldVal] !== undefined) {
                    semGrades[newVal] = semGrades[oldVal];
                    delete semGrades[oldVal];
                }
            });
        });
    }
    
    function removeSubjectFromGrades(mapel) {
        Object.values(ledgerData).forEach(stud => {
            Object.values(stud.grades).forEach(semGrades => {
                if (semGrades[mapel] !== undefined) {
                    delete semGrades[mapel];
                }
            });
        });
    }
    
    // Copy format text
    function renderExcelFormatPreview() {
        const preview = document.getElementById('excel-format-preview');
        preview.textContent = "Nama_Siswa\t" + activeSubjects.join("\t");
    }
    
    // Copy format trigger - with fallback for HTTP/localhost (XAMPP)
    document.getElementById('btn-copy-format').addEventListener('click', () => {
        const text = "Nama_Siswa\t" + activeSubjects.join("\t");

        function onCopySuccess() {
            const btn = document.getElementById('btn-copy-format');
            const originalHTML = btn.innerHTML;
            btn.innerHTML = '<i class="fa-solid fa-check"></i> Tersalin!';
            btn.style.color = '#16a34a';
            setTimeout(() => {
                btn.innerHTML = originalHTML;
                btn.style.color = '';
            }, 2000);
            Swal.fire({
                title: 'Format Disalin!',
                text: 'Format kolom berhasil disalin ke clipboard Anda.',
                icon: 'success',
                timer: 1500,
                showConfirmButton: false
            });
        }

        function onCopyFail() {
            // Show the text in a prompt so user can manually copy
            prompt('Salin teks berikut secara manual (Ctrl+A lalu Ctrl+C):', text);
        }

        // Try modern Clipboard API first
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(onCopySuccess).catch(() => {
                // Fallback to legacy method
                legacyCopy(text);
            });
        } else {
            // Fallback for HTTP / XAMPP local environment
            legacyCopy(text);
        }

        function legacyCopy(str) {
            const ta = document.createElement('textarea');
            ta.value = str;
            ta.style.position = 'fixed';
            ta.style.top = '-9999px';
            ta.style.left = '-9999px';
            document.body.appendChild(ta);
            ta.focus();
            ta.select();
            try {
                const ok = document.execCommand('copy');
                document.body.removeChild(ta);
                if (ok) onCopySuccess();
                else onCopyFail();
            } catch (err) {
                document.body.removeChild(ta);
                onCopyFail();
            }
        }
    });

    // Render S1-Sx tab headers
    function renderSemesterTabs() {
        const container = document.getElementById('semester-tabs-container');
        container.innerHTML = '';
        
        for (let i = 1; i <= activeSemestersCount; i++) {
            const btn = document.createElement('button');
            btn.className = `py-1.5 text-center text-xs font-bold rounded-lg transition-all focus:outline-none ${i === currentSemesterTab ? 'tab-sem-active' : 'tab-sem-inactive'}`;
            btn.textContent = `S${i}`;
            btn.addEventListener('click', () => {
                currentSemesterTab = i;
                document.getElementById('label-target-semester-text').textContent = `Semester ${i}`;
                document.getElementById('paste-grades-area').value = '';
                document.getElementById('parsed-rows-count-text').textContent = '0';
                renderSemesterTabs();
            });
            container.appendChild(btn);
        }
    }
    
    // View Mode Dropdown Select options
    function renderViewModeOptions() {
        const select = document.getElementById('select-view-mode');
        const currentVal = select.value;
        
        select.innerHTML = '<option value="ALL_AVERAGE">Tampilkan Rata-rata Seluruh Mapel</option>';
        activeSubjects.forEach(mapel => {
            const opt = document.createElement('option');
            opt.value = mapel;
            opt.textContent = `Nilai Mapel: ${mapel}`;
            select.appendChild(opt);
        });
        
        // Restore val if still exists
        if (activeSubjects.includes(currentVal) || currentVal === 'ALL_AVERAGE') {
            select.value = currentVal;
        }
    }
    
    // Live parsing count indicators
    document.getElementById('paste-grades-area').addEventListener('input', (e) => {
        const text = e.target.value.trim();
        if (!text) {
            document.getElementById('parsed-rows-count-text').textContent = '0';
            return;
        }
        const lines = text.split('\n').filter(l => l.trim() !== '');
        document.getElementById('parsed-rows-count-text').textContent = lines.length;
    });

    // ----------------------------------------------------
    // EXCEL PARSING & MERGING
    // ----------------------------------------------------
    function parseAndMergeExcelInput() {
        const text = document.getElementById('paste-grades-area').value.trim();
        if (!text) {
            Swal.fire('Error', 'Silakan tempel data dari Excel terlebih dahulu!', 'error');
            return;
        }
        
        const lines = text.split('\n');
        const activeSemKey = 'S' + currentSemesterTab;
        
        let matchCount = 0;
        let newCount = 0;
        
        lines.forEach(line => {
            if (!line.trim()) return;
            const cols = line.split('\t');
            const rawName = cols[0] ? cols[0].trim() : '';
            if (!rawName) return;
            
            // Smart matching
            const match = smartMatchStudentName(rawName);
            let nis = '';
            let finalName = '';
            let kelas = '';
            
            if (match) {
                nis = match.nis;
                finalName = match.nama_lengkap;
                kelas = match.nama_kelas || 'Umum';
                matchCount++;
            } else {
                // Generate temp NIS
                nis = 'NEW-' + Math.random().toString(36).substring(2, 7).toUpperCase();
                finalName = rawName;
                kelas = 'Unassigned';
                newCount++;
            }
            
            if (!ledgerData[nis]) {
                ledgerData[nis] = {
                    nis: nis,
                    nama: finalName,
                    kelas: kelas,
                    grades: {}
                };
            }
            if (!ledgerData[nis].grades[activeSemKey]) {
                ledgerData[nis].grades[activeSemKey] = {};
            }
            
            // Assign subject grades
            activeSubjects.forEach((mapel, index) => {
                const colVal = cols[index + 1] ? cols[index + 1].trim().replace(',', '.') : '';
                if (colVal !== '') {
                    const parsed = parseFloat(colVal);
                    if (!isNaN(parsed)) {
                        ledgerData[nis].grades[activeSemKey][mapel] = parseFloat(parsed.toFixed(2));
                    }
                }
            });
        });
        
        // Clear paste area
        document.getElementById('paste-grades-area').value = '';
        document.getElementById('parsed-rows-count-text').textContent = '0';
        
        saveToLocalStorage();
        renderAll();
        
        Swal.fire({
            title: 'Berhasil Gabung!',
            html: `Berhasil mencocokkan <b>${matchCount}</b> siswa terdaftar dan menambahkan <b>${newCount}</b> siswa baru ke Semester ${currentSemesterTab}.`,
            icon: 'success',
            confirmButtonColor: '#6366f1'
        });
    }

    // ----------------------------------------------------
    // MAIN LEDGER TABLE RENDER & RANKING
    // ----------------------------------------------------
    function renderLedgerTable() {
        const viewMode = document.getElementById('select-view-mode').value;
        const sortMode = document.getElementById('select-sort-mode').value;
        const searchQuery = document.getElementById('search-student-input').value.trim().toLowerCase();
        
        // Update Table card headers
        document.getElementById('main-ledger-card-title').innerHTML = `
            <i class="fa-solid fa-table text-emerald-400"></i> Ledger Gabungan Semester 1-${activeSemestersCount}
        `;
        
        // Update header row columns
        const headerRow = document.getElementById('table-header-row');
        let headerHtml = '<th class="py-2">NO</th><th class="py-2">NAMA SISWA</th><th class="py-2 text-center">PERINGKAT</th>';
        
        for (let i = 1; i <= activeSemestersCount; i++) {
            headerHtml += `<th class="py-2 text-center">S${i}</th>`;
        }
        headerHtml += '<th class="py-2 text-right">RERATA</th>';
        headerRow.innerHTML = headerHtml;
        
        // Compile student data rows
        let studentRowsList = [];
        
        Object.values(ledgerData).forEach(stud => {
            const rowObj = {
                nis: stud.nis,
                nama: stud.nama,
                kelas: stud.kelas,
                grades: stud.grades,
                semValues: [], // values for S1 s.d. SN
                rerata: 0
            };
            
            let totalSemValueSum = 0;
            let totalSemCount = 0;
            
            for (let i = 1; i <= activeSemestersCount; i++) {
                const semKey = 'S' + i;
                const semGrades = stud.grades[semKey] || {};
                
                if (viewMode === 'ALL_AVERAGE') {
                    // Calculate overall average for this semester across all active subjects
                    let subjSum = 0;
                    let subjCount = 0;
                    activeSubjects.forEach(mapel => {
                        if (semGrades[mapel] !== undefined) {
                            subjSum += semGrades[mapel];
                            subjCount++;
                        }
                    });
                    
                    const avg = subjCount > 0 ? parseFloat((subjSum / subjCount).toFixed(2)) : null;
                    rowObj.semValues.push(avg);
                    if (avg !== null) {
                        totalSemValueSum += avg;
                        totalSemCount++;
                    }
                } else {
                    // Show specific subject value
                    const grade = semGrades[viewMode] !== undefined ? semGrades[viewMode] : null;
                    rowObj.semValues.push(grade);
                    if (grade !== null) {
                        totalSemValueSum += grade;
                        totalSemCount++;
                    }
                }
            }
            
            rowObj.rerata = totalSemCount > 0 ? parseFloat((totalSemValueSum / totalSemCount).toFixed(2)) : 0;
            rowObj.totalSemCount = totalSemCount;
            
            studentRowsList.push(rowObj);
        });
        
        // Calculate Rankings (Peringkat) based on overall average (RERATA)
        // Sort descending
        const rankingSorted = [...studentRowsList].sort((a, b) => b.rerata - a.rerata);
        studentRowsList.forEach(stud => {
            if (stud.rerata > 0) {
                stud.rank = rankingSorted.findIndex(r => r.nis === stud.nis) + 1;
            } else {
                stud.rank = '-';
            }
        });
        
        // Filter by Search Query
        let filteredList = studentRowsList;
        if (searchQuery) {
            filteredList = studentRowsList.filter(s => s.nama.toLowerCase().includes(searchQuery));
        }
        
        // Sort according to Sort Mode
        if (sortMode === 'NAME_ASC') {
            filteredList.sort((a, b) => a.nama.localeCompare(b.nama));
        } else if (sortMode === 'NAME_DESC') {
            filteredList.sort((a, b) => b.nama.localeCompare(a.nama));
        } else if (sortMode === 'AVG_DESC') {
            filteredList.sort((a, b) => b.rerata - a.rerata);
        } else if (sortMode === 'AVG_ASC') {
            filteredList.sort((a, b) => a.rerata - b.rerata);
        }
        
        // Render Rows
        const tbody = document.getElementById('table-body-rows');
        tbody.innerHTML = '';
        
        if (filteredList.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="${4 + activeSemestersCount}" class="text-center text-slate-500 py-8">
                        <i class="fa-solid fa-folder-open d-block text-lg mb-2 text-indigo-600 opacity-60"></i>
                        Tidak ada data yang cocok untuk filter terpilih.
                    </td>
                </tr>
            `;
        } else {
            filteredList.forEach((stud, index) => {
                const tr = document.createElement('tr');
                // Make row clickable for chart
                tr.className = 'border-b border-slate-100 hover:bg-slate-50 transition-all text-slate-700 row-clickable';
                tr.setAttribute('data-nis', stud.nis);
                tr.setAttribute('title', 'Klik untuk tampilkan di grafik tren');
                tr.addEventListener('click', () => {
                    if (typeof window.chartToggleStudent === 'function') {
                        window.chartToggleStudent(stud.nis, stud.nama);
                    }
                });
                
                let semColsHtml = '';
                stud.semValues.forEach(val => {
                    if (val !== null) {
                        const colorClass = val >= 86 ? 'text-emerald-600 font-semibold' : val >= 75 ? 'text-indigo-600 font-semibold' : val >= 60 ? 'text-amber-600 font-semibold' : 'text-rose-600 font-semibold';
                        semColsHtml += `<td class="py-2.5 text-center font-medium ${colorClass}">${val.toFixed(1)}</td>`;
                    } else {
                        semColsHtml += `<td class="py-2.5 text-center text-slate-400 font-light">—</td>`;
                    }
                });
                
                const rankText = stud.rank !== '-' ? `Peringkat ${stud.rank}` : '—';
                const rankHtml = stud.rank !== '-' 
                    ? `<span class="badge-gold-pill block text-center mx-auto" style="max-width: 80px;">${rankText}</span>`
                    : '<span class="text-slate-400 block text-center">—</span>';
                
                tr.innerHTML = `
                    <td class="py-2.5 text-slate-400 font-mono text-xs">${index + 1}</td>
                    <td class="py-2.5 font-bold text-slate-800 max-w-xs truncate">
                        <span class="flex items-center gap-1.5">
                            <i class="fa-solid fa-chart-line text-3xs text-slate-400 opacity-60"></i>
                            ${stud.nama}
                        </span>
                    </td>
                    <td class="py-2.5">${rankHtml}</td>
                    ${semColsHtml}
                    <td class="py-2.5 text-right font-bold text-indigo-600">${stud.rerata > 0 ? stud.rerata.toFixed(2) : '—'}</td>
                `;
                tbody.appendChild(tr);
            });
        }
        
        // Update Summary Cards Stats
        updateSummaryStats(studentRowsList);
    }
    
    // Update top stats cards values
    function updateSummaryStats(list) {
        // Total Students
        const total = list.length;
        document.getElementById('stat-total-students').textContent = total;
        
        // Complete Data (has entries in all semesters)
        const complete = list.filter(s => s.totalSemCount === activeSemestersCount).length;
        document.getElementById('stat-complete-students').textContent = complete;
        
        // School Average
        let sum = 0;
        let count = 0;
        list.forEach(s => {
            if (s.rerata > 0) {
                sum += s.rerata;
                count++;
            }
        });
        const schoolAvg = count > 0 ? (sum / count).toFixed(2) : '0.00';
        document.getElementById('stat-school-avg').textContent = schoolAvg;
    }

    // ----------------------------------------------------
    // EVENT LISTENERS & FILTER TRIGGERS
    // ----------------------------------------------------
    
    // Semester counters adjustments
    document.getElementById('btn-sem-minus').addEventListener('click', () => {
        if (activeSemestersCount > 1) {
            activeSemestersCount--;
            document.getElementById('label-sem-count').textContent = `${activeSemestersCount} Semester`;
            if (currentSemesterTab > activeSemestersCount) {
                currentSemesterTab = activeSemestersCount;
                document.getElementById('label-target-semester-text').textContent = `Semester ${currentSemesterTab}`;
            }
            saveToLocalStorage();
            renderAll();
        }
    });
    
    document.getElementById('btn-sem-plus').addEventListener('click', () => {
        if (activeSemestersCount < 12) {
            activeSemestersCount++;
            document.getElementById('label-sem-count').textContent = `${activeSemestersCount} Semester`;
            saveToLocalStorage();
            renderAll();
        }
    });
    
    // Subject dynamic adder
    document.getElementById('btn-add-subject').addEventListener('click', () => {
        Swal.fire({
            title: 'Tambah Mata Pelajaran',
            text: 'Masukkan kode singkat mata pelajaran baru (e.g. BHR, IPA, IPS):',
            input: 'text',
            inputPlaceholder: 'Ketik kode...',
            showCancelButton: true,
            confirmButtonColor: '#6366f1',
            confirmButtonText: 'Tambah',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                const code = result.value.trim().toUpperCase();
                if (code) {
                    if (activeSubjects.includes(code)) {
                        Swal.fire('Error', 'Mata pelajaran tersebut sudah ada!', 'error');
                        return;
                    }
                    activeSubjects.push(code);
                    saveToLocalStorage();
                    renderAll();
                }
            }
        });
    });
    
    // Table mode/sort change
    document.getElementById('select-view-mode').addEventListener('change', renderLedgerTable);
    document.getElementById('select-sort-mode').addEventListener('change', renderLedgerTable);
    document.getElementById('search-student-input').addEventListener('input', renderLedgerTable);
    
    // Reset Data
    document.getElementById('btn-reset-all').addEventListener('click', () => {
        Swal.fire({
            title: 'Reset Seluruh Data?',
            text: 'Ini akan mengosongkan seluruh data ledger yang tersimpan di browser Anda.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#ef4444',
            cancelButtonColor: '#94a3b8',
            confirmButtonText: 'Ya, Reset!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                ledgerData = {};
                activeSubjects = ['PAK', 'PP', 'BIN', 'BIG', 'MTK', 'IPAS', 'PJOK', 'SENI', 'JAWA', 'MANDARIN'];
                activeSemestersCount = 6;
                currentSemesterTab = 1;
                saveToLocalStorage();
                renderAll();
                Swal.fire('Direset!', 'Seluruh data sementara berhasil direset.', 'success');
            }
        });
    });
    
    // Excel Data Parser - bound to dedicated parse button
    document.getElementById('btn-parse-excel').addEventListener('click', parseAndMergeExcelInput);

    // ----------------------------------------------------
    // INJECT DEMO DATA (Matching the screenshot mockups)
    // ----------------------------------------------------
    document.getElementById('btn-demo').addEventListener('click', () => {
        activeSemestersCount = 6;
        activeSubjects = ['PAK', 'PP', 'BIN', 'BIG', 'MTK', 'IPAS', 'PJOK', 'SENI', 'JAWA', 'MANDARIN'];
        document.getElementById('label-sem-count').textContent = '6 Semester';
        
        const demoMockData = [
            { nis: '202401', nama: 'Aditya Pratama', kelas: 'Kelas 1A', bases: [80.8, 82.8, 84.9, 87.0, 89.0, 91.0] },
            { nis: '202402', nama: 'Budi Santoso', kelas: 'Kelas 1A', bases: [75.5, 77.9, 80.1, 82.3, 84.4, 86.6] },
            { nis: '202301', nama: 'Citra Lestari', kelas: 'Kelas 2A', bases: [88.5, 90.7, 92.8, 94.9, 96.6, 98.0] },
            { nis: '202302', nama: 'Dewi Sartika', kelas: 'Kelas 2A', bases: [82.1, 84.1, 86.1, 88.1, 90.1, 92.1] },
            { nis: '202201', nama: 'Eko Prasetyo', kelas: 'Kelas 3A', bases: [85.9, 87.9, 89.9, 91.9, 93.9, 95.9] },
            { nis: '202101', nama: 'Felix Nathaniel', kelas: 'Kelas 4A', bases: [91.0, 93.0, 95.0, 96.0, 98.0, 100.0] },
            { nis: '202102', nama: 'Gisella Anastasia', kelas: 'Kelas 4A', bases: [87.0, 89.0, 90.0, 92.0, 94.5, 96.5] },
            { nis: '202001', nama: 'Hendra Wijaya', kelas: 'Kelas 5A', bases: [81.5, 83.5, 85.0, 87.0, 89.0, 91.5] },
            { nis: '202002', nama: 'Katelyn Victoria', kelas: 'Kelas 5A', bases: [78.0, 80.0, 82.0, 84.0, 86.0, 91.0] },
            { nis: '201901', nama: 'Leon Steven', kelas: 'Umum', bases: [74.0, 76.0, 78.0, 80.0, 82.0, 87.0] }
        ];
        
        ledgerData = {};
        
        demoMockData.forEach(student => {
            ledgerData[student.nis] = {
                nis: student.nis,
                nama: student.nama,
                kelas: student.kelas,
                grades: {}
            };
            
            for (let i = 1; i <= 6; i++) {
                const semKey = 'S' + i;
                ledgerData[student.nis].grades[semKey] = {};
                
                // Set grade values for subjects with tiny variations matching average base
                const baseAvg = student.bases[i - 1];
                activeSubjects.forEach((mapel, index) => {
                    const variance = (index % 3 - 1) * 1.5; // slight variance per subject
                    const finalGrade = Math.min(100, Math.max(0, baseAvg + variance));
                    ledgerData[student.nis].grades[semKey][mapel] = parseFloat(finalGrade.toFixed(1));
                });
            }
        });
        
        saveToLocalStorage();
        renderAll();
        
        Swal.fire({
            title: 'Data Demo Terisi!',
            text: 'Data demo 10 siswa berhasil dimuat sesuai dengan petunjuk.',
            icon: 'info',
            confirmButtonColor: '#6366f1'
        });
    });

    // ----------------------------------------------------
    // EXCEL EXPORTER (Rich XML Spreadsheet Format)
    // ----------------------------------------------------
    document.getElementById('btn-export-excel').addEventListener('click', () => {
        const students = Object.values(ledgerData).sort((a, b) => a.nama.localeCompare(b.nama));
        
        if (students.length === 0) {
            Swal.fire('Info', 'Tidak ada data untuk diekspor.', 'info');
            return;
        }

        // Rank sorted calculation
        const rankingSorted = [...students].map(s => {
            let totalSemValueSum = 0;
            let totalSemCount = 0;
            for (let i = 1; i <= activeSemestersCount; i++) {
                const semKey = 'S' + i;
                const semGrades = s.grades[semKey] || {};
                let subjSum = 0;
                let subjCount = 0;
                activeSubjects.forEach(mapel => {
                    if (semGrades[mapel] !== undefined) {
                        subjSum += semGrades[mapel];
                        subjCount++;
                    }
                });
                const avg = subjCount > 0 ? parseFloat((subjSum / subjCount).toFixed(2)) : null;
                if (avg !== null) {
                    totalSemValueSum += avg;
                    totalSemCount++;
                }
            }
            const rerata = totalSemCount > 0 ? parseFloat((totalSemValueSum / totalSemCount).toFixed(2)) : 0;
            return { nis: s.nis, rerata };
        }).sort((a, b) => b.rerata - a.rerata);

        // Generate styled HTML string for Excel download
        let excelHtml = `
        <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
        <head>
        <meta charset="utf-8">
        <!--[if gte mso 9]>
        <xml>
         <x:ExcelWorkbook>
          <x:ExcelWorksheets>
           <x:ExcelWorksheet>
            <x:Name>Ledger Gabungan</x:Name>
            <x:WorksheetOptions>
             <x:DisplayGridlines/>
            </x:WorksheetOptions>
           </x:ExcelWorksheet>
          </x:ExcelWorksheets>
         </x:ExcelWorkbook>
        </xml>
        <![endif]-->
        <style>
          body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
          table { border-collapse: collapse; width: 100%; }
          th { background-color: #059669; color: #ffffff; font-weight: bold; border: 1px solid #cbd5e1; padding: 8px 6px; text-align: center; }
          td { border: 1px solid #cbd5e1; padding: 6px; color: #334155; }
          .text-center { text-align: center; }
          .text-right { text-align: right; }
          .font-bold { font-weight: bold; }
          .title-header { text-align: center; font-size: 16px; font-weight: bold; color: #064e3b; margin-bottom: 20px; }
        </style>
        </head>
        <body>
        <div class="title-header">LEDGER GABUNGAN SEMESTER 1-${activeSemestersCount} - SD KRISTEN PETRA 1</div>
        <table>
          <thead>
            <tr>
              <th>NO</th>
              <th>NAMA SISWA</th>
              <th>KELAS</th>
              <th>PERINGKAT</th>
        `;
        for (let i = 1; i <= activeSemestersCount; i++) {
            excelHtml += `<th>S${i}</th>`;
        }
        excelHtml += `
              <th>RERATA</th>
            </tr>
          </thead>
          <tbody>
        `;

        students.forEach((stud, idx) => {
            let semValues = [];
            let totalSemValueSum = 0;
            let totalSemCount = 0;
            for (let i = 1; i <= activeSemestersCount; i++) {
                const semKey = 'S' + i;
                const semGrades = stud.grades[semKey] || {};
                let subjSum = 0;
                let subjCount = 0;
                activeSubjects.forEach(mapel => {
                    if (semGrades[mapel] !== undefined) {
                        subjSum += semGrades[mapel];
                        subjCount++;
                    }
                });
                const avg = subjCount > 0 ? parseFloat((subjSum / subjCount).toFixed(2)) : null;
                semValues.push(avg);
                if (avg !== null) {
                    totalSemValueSum += avg;
                    totalSemCount++;
                }
            }
            const rerata = totalSemCount > 0 ? parseFloat((totalSemValueSum / totalSemCount).toFixed(2)) : 0;
            const rank = rerata > 0 ? rankingSorted.findIndex(r => r.nis === stud.nis) + 1 : '-';
            
            excelHtml += `<tr>`;
            excelHtml += `<td class="text-center">${idx + 1}</td>`;
            excelHtml += `<td>${stud.nama}</td>`;
            excelHtml += `<td>${stud.kelas}</td>`;
            excelHtml += `<td class="text-center">${rank !== '-' ? 'Peringkat ' + rank : '—'}</td>`;
            semValues.forEach(val => {
                if (val !== null) {
                    excelHtml += `<td class="text-center">${val.toFixed(1)}</td>`;
                } else {
                    excelHtml += `<td class="text-center">—</td>`;
                }
            });
            excelHtml += `<td class="text-right font-bold">${rerata > 0 ? rerata.toFixed(2) : '—'}</td>`;
            excelHtml += `</tr>`;
        });

        excelHtml += `
          </tbody>
        </table>
        </body>
        </html>
        `;

        // Trigger Excel download
        const blob = new Blob([excelHtml], { type: 'application/vnd.ms-excel;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `Ledger_Gabungan_S1_${activeSemestersCount}.xls`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });

    // ----------------------------------------------------
    // PDF EXPORTER (Using html2pdf.js)
    // ----------------------------------------------------
    document.getElementById('btn-export-pdf').addEventListener('click', () => {
        const students = Object.values(ledgerData);
        if (students.length === 0) {
            Swal.fire('Info', 'Tidak ada data untuk diekspor.', 'info');
            return;
        }

        const element = document.createElement('div');
        element.className = 'p-6 bg-white text-slate-800 font-sans';
        
        // Add title / header
        element.innerHTML = `
            <div style="text-align: center; margin-bottom: 20px; border-bottom: 2px solid #334155; padding-bottom: 10px;">
                <h2 style="margin: 0; color: #1e1b4b; font-size: 20px; font-weight: 800;">SD KRISTEN PETRA 1</h2>
                <h3 style="margin: 5px 0 0 0; color: #4338ca; font-size: 15px; font-weight: 700;">LAPORAN LEDGER GABUNGAN NILAI</h3>
                <p style="margin: 5px 0 0 0; color: #64748b; font-size: 11px;">Semester Acak Dinamis (S1 - S${activeSemestersCount})</p>
            </div>
            <!-- Insert table clone -->
            ${document.getElementById('main-ledger-table').outerHTML}
            <div style="margin-top: 40px; display: flex; justify-content: space-between; font-size: 11px; color: #475569; page-break-inside: avoid;">
                <div>Dicetak pada: ${new Date().toLocaleString('id-ID')}</div>
                <div style="text-align: right; width: 200px;">
                    <p style="margin-bottom: 60px;">Kepala Sekolah,</p>
                    <p style="font-weight: bold; border-top: 1px solid #000; display: inline-block; padding-top: 3px; min-width: 150px; text-align: center;">Lilia, S.Pd., M.Psi.</p>
                </div>
            </div>
        `;

        // Style cleanup for PDF table presentation
        const table = element.querySelector('table');
        table.style.width = '100%';
        table.style.borderCollapse = 'collapse';
        table.style.marginTop = '10px';
        table.style.fontSize = '10px';
        
        element.querySelectorAll('th').forEach(th => {
            th.style.border = '1px solid #cbd5e1';
            th.style.backgroundColor = '#f8fafc';
            th.style.color = '#334155';
            th.style.padding = '8px 5px';
            th.style.fontWeight = 'bold';
            th.style.textAlign = th.classList.contains('text-right') ? 'right' : th.classList.contains('text-center') ? 'center' : 'left';
        });
        
        element.querySelectorAll('td').forEach(td => {
            td.style.border = '1px solid #e2e8f0';
            td.style.padding = '6px 5px';
            td.style.color = '#334155';
            td.style.textAlign = td.classList.contains('text-right') ? 'right' : td.classList.contains('text-center') ? 'center' : 'left';
            
            // Clean up visual badges inside TD for clean PDF
            const goldBadge = td.querySelector('.badge-gold-pill');
            if (goldBadge) {
                td.innerHTML = goldBadge.textContent;
            }
        });

        const opt = {
            margin:       10,
            filename:     `Ledger_Gabungan_S1_${activeSemestersCount}.pdf`,
            image:        { type: 'jpeg', quality: 0.98 },
            html2canvas:  { scale: 2, useCORS: true },
            jsPDF:        { unit: 'mm', format: 'a4', orientation: 'landscape' }
        };
        
        // Generate PDF
        html2pdf().set(opt).from(element).save();
    });

    // ----------------------------------------------------
    // CSV EXPORTER
    // ----------------------------------------------------
    document.getElementById('btn-export-csv').addEventListener('click', () => {
        const students = Object.values(ledgerData).sort((a, b) => a.nama.localeCompare(b.nama));
        
        if (students.length === 0) {
            Swal.fire('Info', 'Tidak ada data untuk diekspor.', 'info');
            return;
        }
        
        // Build headers dynamically
        let csvContent = 'NIS,Nama Siswa,Kelas,';
        for (let i = 1; i <= activeSemestersCount; i++) {
            activeSubjects.forEach(mapel => {
                csvContent += `S${i}_${mapel},`;
            });
        }
        csvContent += 'Rata-rata Akhir\n';
        
        // Build rows
        students.forEach(stud => {
            let row = `"${stud.nis}","${stud.nama}","${stud.kelas}",`;
            let totalSum = 0;
            let totalCount = 0;
            
            for (let i = 1; i <= activeSemestersCount; i++) {
                const semKey = 'S' + i;
                const semGrades = stud.grades[semKey] || {};
                
                activeSubjects.forEach(mapel => {
                    const val = semGrades[mapel] !== undefined ? semGrades[mapel] : null;
                    if (val !== null) {
                        row += `"${val}",`;
                        totalSum += val;
                        totalCount++;
                    } else {
                        row += '"—",';
                    }
                });
            }
            
            const avg = totalCount > 0 ? (totalSum / totalCount).toFixed(2) : '0.00';
            row += `"${avg}"\n`;
            csvContent += row;
        });
        
        // Trigger download
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `Ledger_Gabungan_Lengkap_S1_${activeSemestersCount}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    });

    // ----------------------------------------------------
    // SYNC TO LOCAL DATABASE (MariaDB AJAX POST)
    // ----------------------------------------------------
    document.getElementById('btn-save-grades').addEventListener('click', () => {
        const students = Object.values(ledgerData);
        if (students.length === 0) {
            Swal.fire('Error', 'Tidak ada data nilai di ledger yang bisa disinkronkan ke database.', 'error');
            return;
        }
        
        const guruId = document.getElementById('select-guru-id').value;
        const csrfToken = document.getElementById('csrf-token-val').value;
        
        Swal.fire({
            title: 'Sinkronkan ke DB Sekolah?',
            text: `Data nilai ledger siswa akan diunggah dan disimpan secara permanen di database lokal MariaDB untuk guru terpilih.`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#6366f1',
            confirmButtonText: 'Ya, Sinkronkan!',
            cancelButtonText: 'Batal',
            showLoaderOnConfirm: true,
            preConfirm: () => {
                return fetch('index.php?action=save_local_grades', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        csrf_token: csrfToken,
                        guru_id: guruId,
                        semester_mapping: window.semesterMapping,
                        ledger_data: students
                    })
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Koneksi jaringan gagal');
                    }
                    return response.json();
                })
                .catch(error => {
                    Swal.showValidationMessage(`Request failed: ${error}`);
                });
            },
            allowOutsideClick: () => !Swal.isLoading()
        }).then((result) => {
            if (result.isConfirmed) {
                const res = result.value;
                if (res.status === 'success') {
                    Swal.fire({
                        title: 'Sync Berhasil!',
                        text: res.message,
                        icon: 'success',
                        confirmButtonColor: '#6366f1'
                    }).then(() => {
                        window.location.reload();
                    });
                } else {
                    Swal.fire('Error', res.message || 'Gagal menyimpan ke database.', 'error');
                }
            }
        });
    });
    
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
