<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris\penghapusan.php

$page_title = 'Penghapusan Aset';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_inventaris_access();

$error = '';
$success = '';

// Handle Asset Disposal Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'dispose') {
    require_role(['Super Admin', 'Admin']);
    check_csrf_request();

    $inventaris_id = intval($_POST['inventaris_id'] ?? 0);
    $tanggal_penghapusan = $_POST['tanggal_penghapusan'] ?? date('Y-m-d');
    $metode = $_POST['metode'] ?? 'Dimusnahkan';
    $alasan = trim($_POST['alasan'] ?? '');

    // File Upload handling for Dokumen Pendukung
    $dokumen_name = null;
    if (isset($_FILES['dokumen_pendukung']) && $_FILES['dokumen_pendukung']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['dokumen_pendukung']['tmp_name'];
        $file_name = $_FILES['dokumen_pendukung']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed_exts = ['jpg', 'jpeg', 'png', 'pdf'];
        
        if (in_array($file_ext, $allowed_exts)) {
            $upload_dir = dirname(dirname(__DIR__)) . '/assets/uploads/inventaris/docs/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $dokumen_name = 'disposal_' . $inventaris_id . '_' . time() . '.' . $file_ext;
            if (move_uploaded_file($file_tmp, $upload_dir . $dokumen_name)) {
                // Success
            } else {
                $error = 'Gagal menyimpan dokumen pendukung penghapusan.';
            }
        } else {
            $error = 'Format dokumen tidak didukung. Hanya JPG, JPEG, PNG, atau PDF.';
        }
    }

    if ($inventaris_id === 0 || empty($alasan)) {
        $error = 'Pilih Aset dan isi Alasan Penghapusan!';
    }

    if ($error === '') {
        try {
            $pdo->beginTransaction();

            // Fetch asset details before update
            $ast_stmt = $pdo->prepare("SELECT nama_barang, kode_barang FROM inventaris WHERE id = ? AND status_aktif = 'Aktif'");
            $ast_stmt->execute([$inventaris_id]);
            $asset = $ast_stmt->fetch();

            if ($asset) {
                // Insert disposal record
                $ins = $pdo->prepare("
                    INSERT INTO penghapusan_barang (inventaris_id, tanggal_penghapusan, alasan, metode, dokumen_pendukung) 
                    VALUES (?, ?, ?, ?, ?)
                ");
                $ins->execute([$inventaris_id, $tanggal_penghapusan, $alasan, $metode, $dokumen_name]);

                // Set status_aktif = 'Dihapus' in inventaris
                $upd = $pdo->prepare("UPDATE inventaris SET status_aktif = 'Dihapus' WHERE id = ?");
                $upd->execute([$inventaris_id]);

                // Insert into history log
                $hist = $pdo->prepare("INSERT INTO histori_inventaris (inventaris_id, aktivitas, pengguna, keterangan) VALUES (?, 'Penghapusan', ?, ?)");
                $hist->execute([
                    $inventaris_id,
                    $_SESSION['nama'] ?? 'Admin',
                    "Aset dihapus/di-write-off dari inventaris aktif. Metode: $metode. Alasan: $alasan"
                ]);

                write_audit_log("Melakukan penghapusan aset " . $asset['nama_barang'] . " (" . $asset['kode_barang'] . ") dengan metode $metode");

                $pdo->commit();
                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Aset berhasil dihapus dari inventaris aktif!', 'success').then(() => {
                            window.location.href = 'penghapusan.php';
                        });
                    });
                </script>";
                exit;
            } else {
                $error = 'Data barang tidak ditemukan atau sudah tidak aktif.';
                $pdo->rollBack();
            }
        } catch (Exception $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $error = 'Gagal memproses penghapusan: ' . $e->getMessage();
        }
    }
}

// Fetch disposal list
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
try {
    $query = "
        SELECT p.*, i.nama_barang, i.kode_barang 
        FROM penghapusan_barang p 
        JOIN inventaris i ON p.inventaris_id = i.id
    ";
    if ($search !== '') {
        $query .= " WHERE i.nama_barang LIKE :search OR i.kode_barang LIKE :search OR p.alasan LIKE :search OR p.metode LIKE :search";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['search' => "%$search%"]);
    } else {
        $stmt = $pdo->query($query . " ORDER BY p.tanggal_penghapusan DESC, p.id DESC");
    }
    $disposals = $stmt->fetchAll();

    // Fetch active assets for selection dropdown
    $assets = $pdo->query("SELECT id, kode_barang, nama_barang FROM inventaris WHERE status_aktif = 'Aktif' ORDER BY nama_barang ASC")->fetchAll();
} catch (Exception $e) {
    $disposals = [];
    $assets = [];
    $error = 'Database error: ' . $e->getMessage();
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-trash-can me-2"></i> Penghapusan / Disposal Aset</h5>
            <p class="text-secondary small mb-0">Catat penghapusan aset dari daftar inventaris aktif karena dijual, dihibahkan, rusak total, atau dimusnahkan.</p>
        </div>
        <div>
            <?php if (has_role(['Super Admin', 'Admin'])): ?>
            <button class="btn btn-danger text-white" data-bs-toggle="modal" data-bs-target="#modalPenghapusan" onclick="openCreateModal()"><i class="fa-solid fa-trash-can me-1"></i> Catat Penghapusan</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <!-- Search Form -->
    <form method="GET" action="penghapusan.php" class="row g-2 mb-4 no-print">
        <div class="col-12 col-md-4">
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari barang, alasan..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">Cari</button>
        </div>
        <?php if ($search !== ''): ?>
            <div class="col-auto">
                <a href="penghapusan.php" class="btn btn-outline-danger">Reset</a>
            </div>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Barang Aset</th>
                    <th>Tanggal Penghapusan</th>
                    <th>Metode Disposal</th>
                    <th>Alasan</th>
                    <th>Dokumen Pendukung</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($disposals) > 0): ?>
                    <?php $no = 1; foreach ($disposals as $disp): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td>
                                <strong class="text-white"><?php echo htmlspecialchars($disp['nama_barang']); ?></strong>
                                <span class="text-secondary small d-block font-monospace"><?php echo htmlspecialchars($disp['kode_barang']); ?></span>
                            </td>
                            <td><?php echo date('d M Y', strtotime($disp['tanggal_penghapusan'])); ?></td>
                            <td>
                                <?php if ($disp['metode'] === 'Dijual'): ?>
                                    <span class="badge bg-success text-white"><i class="fa-solid fa-money-bill-wave me-1"></i> Dijual</span>
                                <?php elseif ($disp['metode'] === 'Dihibahkan'): ?>
                                    <span class="badge bg-info text-white"><i class="fa-solid fa-hand-holding-heart me-1"></i> Dihibahkan</span>
                                <?php else: ?>
                                    <span class="badge bg-danger text-white"><i class="fa-solid fa-fire me-1"></i> Dimusnahkan</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-white"><?php echo htmlspecialchars($disp['alasan']); ?></td>
                            <td>
                                <?php if (!empty($disp['dokumen_pendukung'])): ?>
                                    <a href="<?php echo $base_url; ?>assets/uploads/inventaris/docs/<?php echo $disp['dokumen_pendukung']; ?>" target="_blank" class="btn btn-xs btn-outline-custom text-gold">
                                        <i class="fa-solid fa-file-arrow-down me-1"></i> Unduh File
                                    </a>
                                <?php else: ?>
                                    <span class="text-secondary small">-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center text-secondary py-4">Belum ada catatan penghapusan aset.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Form -->
<div class="modal fade" id="modalPenghapusan" tabindex="-1" aria-labelledby="modalPenghapusanLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content modal-content-custom">
            <div class="modal-header">
                <h5 class="modal-title text-danger fw-bold" id="modalPenghapusanLabel"><i class="fa-solid fa-trash-can me-2"></i> Hapus Aset dari Inventaris</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="penghapusan.php" enctype="multipart/form-data">
                <?php csrf_input(); ?>
                <input type="hidden" name="action" value="dispose">
                <div class="modal-body">
                    <div class="alert alert-warning border-0 small text-dark bg-warning p-2 mb-3">
                        <i class="fa-solid fa-circle-info me-2"></i> Aset yang dihapus akan disembunyikan dari list inventaris aktif, tetapi data histori penempatan, pemeliharaan, dll. tetap disimpan di database.
                    </div>

                    <div class="mb-3">
                        <label for="inventaris_id" class="form-label form-label-custom">Pilih Barang Aset <span class="text-danger">*</span></label>
                        <select name="inventaris_id" id="form_inventaris_id" class="form-select form-control-custom bg-dark-select text-white" required>
                            <option value="" disabled selected>Pilih Barang...</option>
                            <?php foreach ($assets as $ast): ?>
                                <option value="<?php echo $ast['id']; ?>"><?php echo htmlspecialchars($ast['nama_barang']) . ' (' . htmlspecialchars($ast['kode_barang']) . ')'; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="tanggal_penghapusan" class="form-label form-label-custom">Tanggal Penghapusan <span class="text-danger">*</span></label>
                        <input type="date" name="tanggal_penghapusan" id="form_tanggal_penghapusan" class="form-control form-control-custom" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="metode" class="form-label form-label-custom">Metode Disposal <span class="text-danger">*</span></label>
                        <select name="metode" id="form_metode" class="form-select form-control-custom bg-dark-select text-white" required>
                            <option value="Dimusnahkan">Dimusnahkan (Rusak Total / Hilang / Dibuang)</option>
                            <option value="Dijual">Dijual</option>
                            <option value="Dihibahkan">Dihibahkan (Ke Sekolah Lain / Pihak Luar)</option>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="alasan" class="form-label form-label-custom">Alasan Penghapusan <span class="text-danger">*</span></label>
                        <textarea name="alasan" id="form_alasan" class="form-control form-control-custom" rows="3" placeholder="Rincian alasan disposal aset sekolah..." required></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="dokumen_pendukung" class="form-label form-label-custom">Dokumen Pendukung (PDF/Gambar)</label>
                        <input type="file" name="dokumen_pendukung" id="form_dokumen_pendukung" class="form-control form-control-custom" accept="image/*,application/pdf">
                    </div>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-danger text-white" id="btn-submit-dispose">Simpan Penghapusan <i class="fa-solid fa-check ms-1"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openCreateModal() {
    document.getElementById('form_inventaris_id').value = '';
    document.getElementById('form_tanggal_penghapusan').value = '<?php echo date('Y-m-d'); ?>';
    document.getElementById('form_metode').value = 'Dimusnahkan';
    document.getElementById('form_alasan').value = '';
    document.getElementById('form_dokumen_pendukung').value = '';
}

document.addEventListener('DOMContentLoaded', function() {
    const btnSubmit = document.getElementById('btn-submit-dispose');
    btnSubmit.addEventListener('click', function(e) {
        const form = this.closest('form');
        const assetSelect = document.getElementById('form_inventaris_id');
        const assetName = assetSelect.options[assetSelect.selectedIndex]?.text || '';
        
        if (!assetSelect.value) {
            Swal.fire('Error', 'Silakan pilih barang aset terlebih dahulu!', 'error');
            return;
        }

        Swal.fire({
            title: 'Konfirmasi Penghapusan',
            text: `Apakah Anda yakin ingin menghapus "${assetName}" dari daftar inventaris aktif? Tindakan ini tidak dapat dibatalkan!`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Ya, Hapus Aset!',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        });
    });
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
