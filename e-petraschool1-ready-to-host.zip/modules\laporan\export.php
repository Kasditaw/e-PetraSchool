<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\laporan\export.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';

// Enforce Login
check_login();

$type = isset($_GET['type']) ? $_GET['type'] : '';

if (empty($type)) {
    die("Error: Tipe laporan tidak ditentukan.");
}

// Log audit log
write_audit_log("Melakukan ekspor laporan Excel: " . ucfirst($type) . ".");

// Output headers for Excel download
header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=Laporan_" . ucfirst($type) . "_Petra1_" . date('Ymd_His') . ".xls");
header("Pragma: no-cache");
header("Expires: 0");

try {
    $romanize = function($nama) {
        $nama_roman = preg_replace_callback('/(\d+)/', function($matches) {
            $map = [1 => 'I', 2 => 'II', 3 => 'III', 4 => 'IV', 5 => 'V', 6 => 'VI'];
            return $map[$matches[1]] ?? $matches[1];
        }, $nama);
        return preg_replace('/([I|V|X]+)([A-HJ-UW-Z])/', '$1 $2', $nama_roman);
    };

    switch ($type) {
        case 'siswa':
            $q = "SELECT s.*, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON s.kelas_id = k.id WHERE 1=1";
            $p = [];
            if (isset($_GET['kelas_id']) && $_GET['kelas_id'] !== '') {
                $q .= " AND s.kelas_id = :kelas_id";
                $p['kelas_id'] = intval($_GET['kelas_id']);
            }
            if (isset($_GET['status_siswa']) && $_GET['status_siswa'] !== '') {
                $q .= " AND s.status_siswa = :status_siswa";
                $p['status_siswa'] = $_GET['status_siswa'];
            }
            $q .= " ORDER BY k.nama_kelas ASC, s.nama_lengkap ASC";
            $stmt = $pdo->prepare($q);
            $stmt->execute($p);
            $students = $stmt->fetchAll();
            
            echo "<table border='1'>
                <tr><th colspan='11' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN DATA SISWA SD KRISTEN PETRA 1 SURABAYA</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>NIS</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>NISN</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Lengkap</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Jenis Kelamin</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Agama</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>No HP Ortu</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kelas</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tahun Masuk</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Status</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Alamat</th>
                </tr>";
            $no = 1;
            foreach ($students as $row) {
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['nis'])."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['nisn'])."</td>
                    <td>".htmlspecialchars($row['nama_lengkap'])."</td>
                    <td style='text-align:center;'>".$row['gender']."</td>
                    <td>".htmlspecialchars($row['agama'])."</td>
                    <td style='text-align:left;'>".htmlspecialchars($row['no_hp_ortu'])."</td>
                    <td>".htmlspecialchars($row['nama_kelas'] ?? '-')."</td>
                    <td style='text-align:center;'>".$row['tahun_masuk']."</td>
                    <td style='text-align:center; font-weight:bold;'>".$row['status_siswa']."</td>
                    <td>".htmlspecialchars($row['alamat'])."</td>
                </tr>";
            }
            echo "</table>";
            break;

        case 'guru':
            $stmt = $pdo->query("SELECT g.*, k.nama_kelas FROM guru g LEFT JOIN kelas k ON k.wali_kelas_id = g.id ORDER BY CASE WHEN k.nama_kelas IS NULL THEN 1 ELSE 0 END, k.nama_kelas ASC, g.nama_guru ASC");
            $teachers = $stmt->fetchAll();
            
            echo "<table border='1'>
                <tr><th colspan='11' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN DATA GURU SD KRISTEN PETRA 1 SURABAYA</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>NIP</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Guru</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Gender</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kelas</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Pendidikan</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Jabatan</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Mata Pelajaran</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>No HP</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Alamat</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Email</th>
                </tr>";
            $no = 1;
            foreach ($teachers as $row) {
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['nip'])."</td>
                    <td>".htmlspecialchars($row['nama_guru'])."</td>
                    <td style='text-align:center;'>".$row['gender']."</td>
                    <td style='text-align:center; font-weight:bold;'>".htmlspecialchars($row['nama_kelas'] ?? '-')."</td>
                    <td>".htmlspecialchars($row['pendidikan'])."</td>
                    <td>".htmlspecialchars($row['jabatan'])."</td>
                    <td>".htmlspecialchars($row['mapel'])."</td>
                    <td style='text-align:left;'>".htmlspecialchars($row['no_hp'])."</td>
                    <td>".htmlspecialchars($row['alamat'])."</td>
                    <td>".htmlspecialchars($row['email'])."</td>
                </tr>";
            }
            echo "</table>";
            break;

        case 'karyawan':
            $stmt = $pdo->query("SELECT * FROM karyawan ORDER BY nama ASC");
            $employees = $stmt->fetchAll();
            
            echo "<table border='1'>
                <tr><th colspan='9' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN DATA KARYAWAN SD KRISTEN PETRA 1 SURABAYA</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>NIK</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Karyawan</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Jabatan</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Unit Kerja</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>No HP</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Alamat</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tanggal Masuk</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Status</th>
                </tr>";
            $no = 1;
            foreach ($employees as $row) {
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['nik'])."</td>
                    <td>".htmlspecialchars($row['nama'])."</td>
                    <td>".htmlspecialchars($row['jabatan'])."</td>
                    <td>".htmlspecialchars($row['unit_kerja'])."</td>
                    <td style='text-align:left;'>".htmlspecialchars($row['no_hp'])."</td>
                    <td>".htmlspecialchars($row['alamat'])."</td>
                    <td style='text-align:center;'>".$row['tanggal_masuk']."</td>
                    <td style='text-align:center;'>".$row['status']."</td>
                </tr>";
            }
            echo "</table>";
            break;

        case 'inventaris':
            $stmt = $pdo->query("SELECT i.*, k.nama_kategori, r.nama_ruangan FROM inventaris i JOIN kategori_barang k ON i.kategori_id = k.id LEFT JOIN ruangan r ON i.ruangan_id = r.id ORDER BY i.kode_barang ASC");
            $assets = $stmt->fetchAll();
            
            echo "<table border='1'>
                <tr><th colspan='10' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN INVENTARIS ASET SD KRISTEN PETRA 1 SURABAYA</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kode Barang</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Barang</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kategori</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Merk</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Jumlah</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kondisi</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Lokasi</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Harga Perolehan</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Sumber Dana</th>
                </tr>";
            $no = 1;
            foreach ($assets as $row) {
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['kode_barang'])."</td>
                    <td>".htmlspecialchars($row['nama_barang'])."</td>
                    <td>".htmlspecialchars($row['nama_kategori'])."</td>
                    <td>".htmlspecialchars($row['merk'])."</td>
                    <td style='text-align:center;'>".intval($row['jumlah'])."</td>
                    <td style='text-align:center;'>".$row['kondisi']."</td>
                    <td>".htmlspecialchars($row['nama_ruangan'] ?? '-')."</td>
                    <td style='text-align:right;'>".$row['harga']."</td>
                    <td style='text-align:center;'>".htmlspecialchars($row['sumber_dana'])."</td>
                </tr>";
            }
            echo "</table>";
            break;

        case 'barang_rusak':
            $stmt = $pdo->query("SELECT i.*, k.nama_kategori, r.nama_ruangan FROM inventaris i JOIN kategori_barang k ON i.kategori_id = k.id LEFT JOIN ruangan r ON i.ruangan_id = r.id WHERE i.kondisi = 'Rusak Berat' ORDER BY i.kode_barang ASC");
            $damaged = $stmt->fetchAll();
            
            echo "<table border='1'>
                <tr><th colspan='10' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN BARANG RUSAK BERAT SD KRISTEN PETRA 1 SURABAYA</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kode Barang</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Barang</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kategori</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Merk</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Jumlah</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kondisi</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Lokasi</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Harga Perolehan</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Sumber Dana</th>
                </tr>";
            $no = 1;
            foreach ($damaged as $row) {
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['kode_barang'])."</td>
                    <td>".htmlspecialchars($row['nama_barang'])."</td>
                    <td>".htmlspecialchars($row['nama_kategori'])."</td>
                    <td>".htmlspecialchars($row['merk'])."</td>
                    <td style='text-align:center;'>".intval($row['jumlah'])."</td>
                    <td style='text-align:center; font-weight:bold; color:red;'>".$row['kondisi']."</td>
                    <td>".htmlspecialchars($row['nama_ruangan'] ?? '-')."</td>
                    <td style='text-align:right;'>".$row['harga']."</td>
                    <td style='text-align:center;'>".htmlspecialchars($row['sumber_dana'])."</td>
                </tr>";
            }
            echo "</table>";
            break;

        case 'ruangan':
            $stmt = $pdo->query("SELECT r.*, g.nama_guru FROM ruangan r LEFT JOIN guru g ON r.penanggung_jawab_id = g.id ORDER BY r.kode_ruangan ASC");
            $rooms = $stmt->fetchAll();
            
            echo "<table border='1'>
                <tr><th colspan='7' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN RUANGAN SEKOLAH SD KRISTEN PETRA 1 SURABAYA</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kode Ruangan</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Ruangan</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Lantai</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kapasitas</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kondisi</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Penanggung Jawab</th>
                </tr>";
            $no = 1;
            foreach ($rooms as $row) {
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['kode_ruangan'])."</td>
                    <td>".htmlspecialchars($row['nama_ruangan'])."</td>
                    <td style='text-align:center;'>Lantai ".$row['lantai']."</td>
                    <td style='text-align:center;'>".intval($row['kapasitas'])." Orang</td>
                    <td style='text-align:center;'>".$row['kondisi']."</td>
                    <td>".htmlspecialchars($row['nama_guru'] ?? '-')."</td>
                </tr>";
            }
            echo "</table>";
            break;

        case 'alumni':
            $stmt = $pdo->query("SELECT * FROM alumni ORDER BY tahun_lulus DESC, nama_alumni ASC");
            $alumni = $stmt->fetchAll();
            
            echo "<table border='1'>
                <tr><th colspan='8' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN DATA ALUMNI SD KRISTEN PETRA 1 SURABAYA</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>NIS</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Alumni</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tahun Lulus</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>No HP</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Pekerjaan</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Pendidikan Lanjutan</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Alamat</th>
                </tr>";
            $no = 1;
            foreach ($alumni as $row) {
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['nis'])."</td>
                    <td>".htmlspecialchars($row['nama_alumni'])."</td>
                    <td style='text-align:center;'>".$row['tahun_lulus']."</td>
                    <td style='text-align:left;'>".htmlspecialchars($row['no_hp'])."</td>
                    <td>".htmlspecialchars($row['pekerjaan'])."</td>
                    <td>".htmlspecialchars($row['pendidikan_lanjutan'])."</td>
                    <td>".htmlspecialchars($row['alamat'])."</td>
                </tr>";
            }
            echo "</table>";
            break;

        case 'nilai':
            // Helper to get teacher from mapel
            $get_teacher = function($subject_name, $wali_kelas) use ($pdo) {
                static $cache = [];
                $clean_subject = strtolower(trim($subject_name));
                if (isset($cache[$clean_subject])) {
                    return $cache[$clean_subject];
                }
                
                try {
                    $stmt = $pdo->prepare("SELECT nama_guru FROM guru WHERE LOWER(mapel) LIKE :subject LIMIT 1");
                    $stmt->execute(['subject' => '%' . $clean_subject . '%']);
                    $name = $stmt->fetchColumn();
                    if ($name) {
                        $cache[$clean_subject] = $name;
                        return $name;
                    }
                } catch (Exception $e) {}
                
                $cache[$clean_subject] = $wali_kelas ?: '-';
                return $cache[$clean_subject];
            };

            // Query raport_siswa instead of nilai
            $q = "SELECT r.*, s.nama_lengkap, s.nis, k.nama_kelas, g.nama_guru as nama_wali
                  FROM raport_siswa r
                  JOIN siswa s ON r.siswa_id = s.id
                  JOIN kelas k ON r.kelas_id = k.id
                  LEFT JOIN guru g ON k.wali_kelas_id = g.id
                  WHERE 1=1";
            $p = [];
            if (isset($_GET['tahun_ajaran']) && $_GET['tahun_ajaran'] !== '') {
                $q .= " AND r.tahun_ajaran = :tahun_ajaran";
                $p['tahun_ajaran'] = $_GET['tahun_ajaran'];
            }
            if (isset($_GET['semester']) && $_GET['semester'] !== '') {
                $q .= " AND r.semester = :semester";
                $p['semester'] = $_GET['semester'];
            }
            if (isset($_GET['kelas_id']) && $_GET['kelas_id'] !== '') {
                $q .= " AND r.kelas_id = :kelas_id";
                $p['kelas_id'] = intval($_GET['kelas_id']);
            }
            $q .= " ORDER BY k.nama_kelas ASC, s.nama_lengkap ASC";
            $stmt = $pdo->prepare($q);
            $stmt->execute($p);
            $raports = $stmt->fetchAll();

            // Transform report card JSON data to flat rows structure
            $grades = [];
            foreach ($raports as $raport) {
                $academic_grades = json_decode($raport['academic_grades'], true) ?: [];
                foreach ($academic_grades as $subject_key => $grade_item) {
                    $score = (isset($grade_item['score']) && $grade_item['score'] !== '') ? floatval($grade_item['score']) : null;
                    if ($score === null) continue; // skip if score is not filled
                    
                    $predikat = 'E';
                    if ($score >= 86) $predikat = 'A';
                    elseif ($score >= 75) $predikat = 'B';
                    elseif ($score >= 60) $predikat = 'C';
                    elseif ($score >= 45) $predikat = 'D';
                    
                    $nama_guru = $get_teacher($subject_key, $raport['nama_wali']);
                    
                    $grades[] = [
                        'nis' => $raport['nis'],
                        'nama_lengkap' => $raport['nama_lengkap'],
                        'nama_kelas' => $raport['nama_kelas'],
                        'mata_pelajaran' => $subject_key,
                        'nama_guru' => $nama_guru,
                        'semester' => $raport['semester'],
                        'tahun_ajaran' => $raport['tahun_ajaran'],
                        'nilai_tugas' => '',
                        'nilai_uts' => '',
                        'nilai_uas' => '',
                        'nilai_akhir' => $score,
                        'predikat' => $predikat
                    ];
                }
            }

            
            // Resolve filter labels
            $filter_label = [];
            if (isset($_GET['tahun_ajaran']) && $_GET['tahun_ajaran'] !== '') {
                $filter_label[] = "TAHUN AJARAN: " . $_GET['tahun_ajaran'];
            }
            if (isset($_GET['semester']) && $_GET['semester'] !== '') {
                $filter_label[] = "SEMESTER: " . ($_GET['semester'] === '1' ? '1 (GANJIL)' : '2 (GENAP)');
            }
            if (isset($_GET['kelas_id']) && $_GET['kelas_id'] !== '') {
                try {
                    $selected_kelas_name = $pdo->query("SELECT nama_kelas FROM kelas WHERE id = " . intval($_GET['kelas_id']))->fetchColumn();
                    if ($selected_kelas_name) {
                        $filter_label[] = "KELAS: " . strtoupper($selected_kelas_name);
                    }
                } catch (Exception $e) {
                    // ignore
                }
            }
            $filter_str = implode(" | ", $filter_label);
            
            echo "<table border='1'>
                <tr><th colspan='12' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN LEDGER NILAI SISWA SD KRISTEN PETRA 1 SURABAYA</th></tr>";
            if (!empty($filter_str)) {
                echo "<tr><th colspan='12' style='font-size:12px; font-weight:bold; text-align:center; height:25px; background-color:#EBF2F7; color:#334155;'>".htmlspecialchars($filter_str)."</th></tr>";
            }
            echo "<tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>NIS</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Siswa</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kelas</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Mata Pelajaran</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Guru Pengajar</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Semester</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tugas (30%)</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>UTS (30%)</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>UAS (40%)</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nilai Akhir</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Predikat</th>
                </tr>";
            $no = 1;
            $current_kelas = null;
            foreach ($grades as $row) {
                $row_kelas = $row['nama_kelas'] ?: 'Tanpa Kelas';
                if ($row_kelas !== $current_kelas) {
                    $current_kelas = $row_kelas;
                    $kelas_label = $current_kelas !== 'Tanpa Kelas' ? 'Kelas ' . $romanize($current_kelas) : 'Tanpa Kelas';
                    echo "<tr style='background-color:#dbeafe;'>
                        <td colspan='12' style='font-weight:bold; font-size:12px; color:#1e3a5f; padding:6px 10px;'>
                            " . htmlspecialchars($kelas_label) . "
                        </td>
                    </tr>";
                    $no = 1; // Reset numbering per class
                }
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['nis'])."</td>
                    <td>".htmlspecialchars($row['nama_lengkap'])."</td>
                    <td>".htmlspecialchars($row['nama_kelas'] ?? '-')."</td>
                    <td>".htmlspecialchars($row['mata_pelajaran'])."</td>
                    <td>".htmlspecialchars($row['nama_guru'])."</td>
                    <td style='text-align:center;'>".$row['semester']." (".$row['tahun_ajaran'].")</td>
                    <td style='text-align:right;'>".$row['nilai_tugas']."</td>
                    <td style='text-align:right;'>".$row['nilai_uts']."</td>
                    <td style='text-align:right;'>".$row['nilai_uas']."</td>
                    <td style='text-align:right; font-weight:bold;'>".$row['nilai_akhir']."</td>
                    <td style='text-align:center; font-weight:bold;'>".$row['predikat']."</td>
                </tr>";
            }
            echo "</table>";
            break;

        case 'peminjaman':
            $stmt = $pdo->query("SELECT p.*, i.nama_barang, i.kode_barang FROM peminjaman p JOIN inventaris i ON p.inventaris_id = i.id ORDER BY p.tanggal_pinjam DESC");
            $borrowings = $stmt->fetchAll();
            
            echo "<table border='1'>
                <tr><th colspan='7' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN PEMINJAMAN ASET SD KRISTEN PETRA 1 SURABAYA</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kode Peminjaman</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Peminjam</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Barang Aset</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tanggal Pinjam</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tanggal Kembali</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Status</th>
                </tr>";
            $no = 1;
            foreach ($borrowings as $row) {
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['kode_peminjaman'])."</td>
                    <td>".htmlspecialchars($row['nama_peminjam'])."</td>
                    <td>".htmlspecialchars($row['nama_barang'])." (".htmlspecialchars($row['kode_barang']).")</td>
                    <td style='text-align:center;'>".$row['tanggal_pinjam']."</td>
                    <td style='text-align:center;'>".($row['tanggal_kembali'] ?? '-')."</td>
                    <td style='text-align:center;'>".$row['status']."</td>
                </tr>";
            }
            echo "</table>";
            break;

        case 'audit_log':
            $stmt = $pdo->query("SELECT * FROM audit_log ORDER BY tanggal DESC");
            $logs = $stmt->fetchAll();
            
            echo "<table border='1'>
                <tr><th colspan='5' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN AUDIT LOG KEAMANAN SD KRISTEN PETRA 1 SURABAYA</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Waktu</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Username</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Aktivitas</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>IP Address</th>
                </tr>";
            $no = 1;
            foreach ($logs as $row) {
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='text-align:center;'>".$row['tanggal']."</td>
                    <td>".htmlspecialchars($row['username'])."</td>
                    <td>".htmlspecialchars($row['aktivitas'])."</td>
                    <td style='text-align:center;'>".htmlspecialchars($row['ip_address'])."</td>
                </tr>";
            }
            echo "</table>";
            break;

        case 'pengumuman':
            $stmt = $pdo->query("SELECT p.*, u.nama FROM pengumuman p LEFT JOIN users u ON p.penulis_id = u.id ORDER BY p.tanggal DESC");
            $announcements = $stmt->fetchAll();
            
            echo "<table border='1'>
                <tr><th colspan='5' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN PENGUMUMAN SEKOLAH SD KRISTEN PETRA 1 SURABAYA</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tanggal</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Judul</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Isi Pengumuman</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Penulis</th>
                </tr>";
            $no = 1;
            foreach ($announcements as $row) {
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='text-align:center;'>".$row['tanggal']."</td>
                    <td>".htmlspecialchars($row['judul'])."</td>
                    <td>".htmlspecialchars(strip_tags($row['isi']))."</td>
                    <td>".htmlspecialchars($row['nama'] ?? 'Admin')."</td>
                </tr>";
            }
            echo "</table>";
            break;
            
        case 'jurnal_harian':
            $q = "SELECT jd.*, j.tanggal, j.hari, j.jabatan, g.nama_guru, g.nip, m.nama_mapel, k.nama_kelas, j.status
                  FROM jurnal_mengajar_detail jd
                  JOIN jurnal_mengajar j ON jd.jurnal_id = j.id
                  JOIN guru g ON j.guru_id = g.id
                  LEFT JOIN mata_pelajaran m ON jd.mapel_id = m.id
                  LEFT JOIN kelas k ON jd.kelas_id = k.id
                  WHERE 1=1";
            $p = [];
            
            if (isset($_GET['guru_id']) && $_GET['guru_id'] !== '') {
                $q .= " AND j.guru_id = :guru_id";
                $p['guru_id'] = intval($_GET['guru_id']);
            }
            if (isset($_GET['kelas_id']) && $_GET['kelas_id'] !== '') {
                $q .= " AND jd.kelas_id = :kelas_id";
                $p['kelas_id'] = intval($_GET['kelas_id']);
            }
            if (isset($_GET['mapel_id']) && $_GET['mapel_id'] !== '') {
                $q .= " AND jd.mapel_id = :mapel_id";
                $p['mapel_id'] = intval($_GET['mapel_id']);
            }
            if (isset($_GET['tgl_mulai']) && $_GET['tgl_mulai'] !== '') {
                $q .= " AND j.tanggal >= :tgl_mulai";
                $p['tgl_mulai'] = $_GET['tgl_mulai'];
            }
            if (isset($_GET['tgl_selesai']) && $_GET['tgl_selesai'] !== '') {
                $q .= " AND j.tanggal <= :tgl_selesai";
                $p['tgl_selesai'] = $_GET['tgl_selesai'];
            }
            if (isset($_GET['ta_id']) && $_GET['ta_id'] !== '') {
                $q .= " AND j.tahun_ajaran_id = :ta_id";
                $p['ta_id'] = intval($_GET['ta_id']);
            }
            if (isset($_GET['semester_id']) && $_GET['semester_id'] !== '') {
                $q .= " AND j.semester_id = :semester_id";
                $p['semester_id'] = intval($_GET['semester_id']);
            }

            $q .= " ORDER BY j.tanggal ASC, jd.jam_ke ASC";
            $stmt = $pdo->prepare($q);
            $stmt->execute($p);
            $rows = $stmt->fetchAll();

            echo "<table border='1'>
                <tr><th colspan='10' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN HARIAN JURNAL MENGAJAR SD KRISTEN PETRA 1 SURABAYA</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tanggal</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Hari</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Guru</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>NIP</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Jam Ke</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Mata Pelajaran</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kelas</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Materi Pokok</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kegiatan KBM</th>
                </tr>";
            $no = 1;
            foreach ($rows as $row) {
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='text-align:center;'>".$row['tanggal']."</td>
                    <td style='text-align:center;'>".htmlspecialchars($row['hari'])."</td>
                    <td>".htmlspecialchars($row['nama_guru'])."</td>
                    <td style='font-family:monospace;'>".htmlspecialchars($row['nip'])."</td>
                    <td style='text-align:center;'>".$row['jam_ke']."</td>
                    <td>".htmlspecialchars($row['nama_mapel'] ?? '-')."</td>
                    <td>".htmlspecialchars($row['nama_kelas'] ?? '-')."</td>
                    <td>".htmlspecialchars($row['materi'])."</td>
                    <td>".htmlspecialchars($row['kegiatan'])."</td>
                </tr>";
            }
            echo "</table>";
            break;

        case 'jurnal_bulanan':
            $bulan = isset($_GET['bulan']) && $_GET['bulan'] !== '' ? intval($_GET['bulan']) : intval(date('m'));
            
            $q = "SELECT g.id, g.nama_guru, g.nip,
                  (SELECT COUNT(*) FROM jurnal_mengajar_detail jd JOIN jurnal_mengajar j ON jd.jurnal_id = j.id WHERE j.guru_id = g.id AND MONTH(j.tanggal) = ?) as total_jam,
                  (SELECT COUNT(DISTINCT j.tanggal) FROM jurnal_mengajar j WHERE j.guru_id = g.id AND MONTH(j.tanggal) = ?) as total_hari
                  FROM guru g
                  ORDER BY g.nama_guru ASC";
            
            $stmt = $pdo->prepare($q);
            $stmt->execute([$bulan, $bulan]);
            $rows = $stmt->fetchAll();

            $month_names = [
                1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April', 5 => 'Mei', 6 => 'Juni',
                7 => 'Juli', 8 => 'Agustus', 9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember'
            ];
            $month_name = $month_names[$bulan] ?? '';

            echo "<table border='1'>
                <tr><th colspan='6' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN BULANAN REKAP MENGAJAR GURU - BULAN ".strtoupper($month_name)."</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Guru</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>NIP</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Total Jam Mengajar</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Total Hari Mengajar</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Persentase Kehadiran Jurnal</th>
                </tr>";
            $no = 1;
            foreach ($rows as $row) {
                $percentage = ($row['total_hari'] / 20) * 100;
                if ($percentage > 100) $percentage = 100;
                
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td>".htmlspecialchars($row['nama_guru'])."</td>
                    <td style='font-family:monospace;'>".htmlspecialchars($row['nip'])."</td>
                    <td style='text-align:center;'>".$row['total_jam']." Jam</td>
                    <td style='text-align:center;'>".$row['total_hari']." Hari</td>
                    <td style='text-align:center;'>".number_format($percentage, 1)."%</td>
                </tr>";
            }
            echo "</table>";
            break;

        case 'jurnal_semester':
            $ta_id = isset($_GET['ta_id']) && $_GET['ta_id'] !== '' ? intval($_GET['ta_id']) : null;
            $semester_id = isset($_GET['semester_id']) && $_GET['semester_id'] !== '' ? intval($_GET['semester_id']) : null;

            if (!$ta_id) {
                $ta_id = $pdo->query("SELECT id FROM tahun_ajaran WHERE status = 'Aktif'")->fetchColumn();
            }
            if (!$semester_id) {
                $semester_id = $pdo->query("SELECT id FROM semester WHERE status = 'Aktif'")->fetchColumn();
            }

            $q = "SELECT g.nama_guru, g.nip,
                  (SELECT COUNT(*) FROM jurnal_mengajar_detail jd JOIN jurnal_mengajar j ON jd.jurnal_id = j.id WHERE j.guru_id = g.id AND j.tahun_ajaran_id = ? AND j.semester_id = ?) as total_jam,
                  (SELECT COUNT(DISTINCT j.tanggal) FROM jurnal_mengajar j WHERE j.guru_id = g.id AND j.tahun_ajaran_id = ? AND j.semester_id = ?) as total_hari,
                  (SELECT COUNT(*) FROM jurnal_mengajar j WHERE j.guru_id = g.id AND j.tahun_ajaran_id = ? AND j.semester_id = ? AND j.status = 'Disetujui') as disetujui,
                  (SELECT COUNT(*) FROM jurnal_mengajar j WHERE j.guru_id = g.id AND j.tahun_ajaran_id = ? AND j.semester_id = ? AND j.status = 'Revisi') as revisi
                  FROM guru g
                  ORDER BY g.nama_guru ASC";
            
            $stmt = $pdo->prepare($q);
            $stmt->execute([
                $ta_id, $semester_id,
                $ta_id, $semester_id,
                $ta_id, $semester_id,
                $ta_id, $semester_id
            ]);
            $rows = $stmt->fetchAll();

            $ta_name = $pdo->query("SELECT tahun_ajaran FROM tahun_ajaran WHERE id = " . intval($ta_id))->fetchColumn();
            $sem_name = $pdo->query("SELECT semester FROM semester WHERE id = " . intval($semester_id))->fetchColumn();

            echo "<table border='1'>
                <tr><th colspan='7' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN SEMESTER REKAP MENGAJAR GURU - T.A ".$ta_name." (SEMESTER ".$sem_name.")</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Guru</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>NIP</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Total Jam Mengajar</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Total Hari Mengajar</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Jurnal Disetujui</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Jurnal Perlu Revisi</th>
                </tr>";
            $no = 1;
            foreach ($rows as $row) {
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td>".htmlspecialchars($row['nama_guru'])."</td>
                    <td style='font-family:monospace;'>".htmlspecialchars($row['nip'])."</td>
                    <td style='text-align:center;'>".$row['total_jam']." Jam</td>
                    <td style='text-align:center;'>".$row['total_hari']." Hari</td>
                    <td style='text-align:center; color:green;'>".$row['disetujui']."</td>
                    <td style='text-align:center; color:red;'>".$row['revisi']."</td>
                </tr>";
            }
            echo "</table>";
            break;

        case 'siswa_tingkat':
            $tingkat = isset($_GET['tingkat']) ? $_GET['tingkat'] : '';
            if (!in_array($tingkat, ['1', '2', '3', '4', '5', '6'])) {
                die("Tingkat tidak valid.");
            }
            $stmt = $pdo->prepare("
                SELECT s.*, k.nama_kelas 
                FROM siswa s 
                LEFT JOIN kelas k ON s.kelas_id = k.id 
                WHERE k.tingkat = ? AND s.status_siswa = 'Aktif' 
                ORDER BY k.nama_kelas ASC, s.nama_lengkap ASC
            ");
            $stmt->execute([$tingkat]);
            $rows = $stmt->fetchAll();

            echo "<table border='1'>
                <tr><th colspan='10' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN DAFTAR SISWA - TINGKAT ".$tingkat." - SD KRISTEN PETRA 1 SURABAYA</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>NIS</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>NISN</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Lengkap</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>L/P</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Agama</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tempat, Tanggal Lahir</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Orang Tua</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Alamat Domisili</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kelas</th>
                </tr>";
            $no = 1;
            foreach ($rows as $row) {
                $ortu = $row['nama_ayah'] ?: ($row['nama_ibu'] ?: '-');
                $ttl = $row['tempat_lahir'] . ', ' . ($row['tanggal_lahir'] ? date('d-m-Y', strtotime($row['tanggal_lahir'])) : '-');
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['nis'])."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['nisn'])."</td>
                    <td>".htmlspecialchars($row['nama_lengkap'])."</td>
                    <td style='text-align:center;'>".$row['gender']."</td>
                    <td>".htmlspecialchars($row['agama'])."</td>
                    <td>".htmlspecialchars($ttl)."</td>
                    <td>".htmlspecialchars($ortu)."</td>
                    <td>".htmlspecialchars($row['alamat'] ?: '-')."</td>
                    <td style='text-align:center;'>".htmlspecialchars($row['nama_kelas'] ? $romanize($row['nama_kelas']) : '-')."</td>
                </tr>";
            }
            echo "</table>";
            break;

        case 'rekap_tahun_ajaran':
            $ta_id = isset($_GET['ta_id']) ? intval($_GET['ta_id']) : 0;
            $ta_stmt = $pdo->prepare("SELECT tahun_ajaran FROM tahun_ajaran WHERE id = ?");
            $ta_stmt->execute([$ta_id]);
            $ta_name = $ta_stmt->fetchColumn() ?: '-';

            $stmt = $pdo->prepare("
                SELECT k.nama_kelas, k.tingkat, k.kapasitas, g.nama_guru,
                       (SELECT COUNT(*) FROM riwayat_kelas r JOIN siswa s ON r.siswa_id = s.id WHERE r.kelas_id = k.id AND r.tahun_ajaran_id = ? AND s.status_siswa = 'Aktif') as jumlah_siswa,
                       (SELECT COUNT(*) FROM riwayat_kelas r JOIN siswa s ON r.siswa_id = s.id WHERE r.kelas_id = k.id AND r.tahun_ajaran_id = ? AND s.status_siswa = 'Aktif' AND s.gender = 'L') as jumlah_l,
                       (SELECT COUNT(*) FROM riwayat_kelas r JOIN siswa s ON r.siswa_id = s.id WHERE r.kelas_id = k.id AND r.tahun_ajaran_id = ? AND s.status_siswa = 'Aktif' AND s.gender = 'P') as jumlah_p
                FROM kelas k
                LEFT JOIN guru g ON k.wali_kelas_id = g.id
                WHERE k.status = 'Aktif'
                ORDER BY k.nama_kelas ASC
            ");
            $stmt->execute([$ta_id, $ta_id, $ta_id]);
            $rows = $stmt->fetchAll();

            echo "<table border='1'>
                <tr><th colspan='9' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>REKAPITULASI SISWA PER KELAS - TAHUN AJARAN ".$ta_name."</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Kelas</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tingkat</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Wali Kelas</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kapasitas</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Siswa L</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Siswa P</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Total Siswa</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Keterisian (%)</th>
                </tr>";
            $no = 1;
            $tot_cap = 0;
            $tot_l = 0;
            $tot_p = 0;
            $tot_siswa = 0;
            foreach ($rows as $row) {
                $fill_percent = $row['kapasitas'] > 0 ? round(($row['jumlah_siswa'] / $row['kapasitas']) * 100, 1) : 0;
                $tot_cap += intval($row['kapasitas']);
                $tot_l += intval($row['jumlah_l']);
                $tot_p += intval($row['jumlah_p']);
                $tot_siswa += intval($row['jumlah_siswa']);

                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td><strong>".htmlspecialchars($romanize($row['nama_kelas']))."</strong></td>
                    <td style='text-align:center;'>Tingkat ".$row['tingkat']."</td>
                    <td>".htmlspecialchars($row['nama_guru'] ?: '-')."</td>
                    <td style='text-align:center;'>".$row['kapasitas']."</td>
                    <td style='text-align:center;'>".$row['jumlah_l']."</td>
                    <td style='text-align:center;'>".$row['jumlah_p']."</td>
                    <td style='text-align:center; font-weight:bold;'>".$row['jumlah_siswa']."</td>
                    <td style='text-align:center;'>".$fill_percent."%</td>
                </tr>";
            }
            $tot_fill_percent = $tot_cap > 0 ? round(($tot_siswa / $tot_cap) * 100, 1) : 0;
            echo "<tr style='font-weight:bold; background-color:#f8fafc;'>
                <td colspan='4' style='text-align:right;'>TOTAL / RATA-RATA:</td>
                <td style='text-align:center;'>".$tot_cap."</td>
                <td style='text-align:center;'>".$tot_l."</td>
                <td style='text-align:center;'>".$tot_p."</td>
                <td style='text-align:center;'>".$tot_siswa."</td>
                <td style='text-align:center;'>".$tot_fill_percent."%</td>
            </tr>";
            echo "</table>";
            break;

        case 'mutasi':
            $ta_id = isset($_GET['ta_id']) && $_GET['ta_id'] !== '' ? intval($_GET['ta_id']) : null;
            $q = "
                SELECT s.nis, s.nisn, s.nama_lengkap, s.gender, r.status as status_riwayat, r.tanggal_masuk, k.nama_kelas, ta.tahun_ajaran
                FROM riwayat_kelas r
                JOIN siswa s ON r.siswa_id = s.id
                JOIN kelas k ON r.kelas_id = k.id
                JOIN tahun_ajaran ta ON r.tahun_ajaran_id = ta.id
                WHERE r.status IN ('Pindahan', 'Keluar')
            ";
            $p = [];
            if ($ta_id) {
                $q .= " AND r.tahun_ajaran_id = ?";
                $p[] = $ta_id;
            }
            $q .= " ORDER BY ta.tahun_ajaran DESC, r.tanggal_masuk DESC, s.nama_lengkap ASC";
            $stmt = $pdo->prepare($q);
            $stmt->execute($p);
            $rows = $stmt->fetchAll();

            echo "<table border='1'>
                <tr><th colspan='9' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>LAPORAN MUTASI MASUK & KELUAR SISWA</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>NIS</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>NISN</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Siswa</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>L/P</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Jenis Mutasi</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tanggal Efektif</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kelas</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tahun Ajaran</th>
                </tr>";
            $no = 1;
            foreach ($rows as $row) {
                $status_label = $row['status_riwayat'] === 'Pindahan' ? 'Mutasi Masuk (Pindahan)' : 'Mutasi Keluar';
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['nis'])."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['nisn'])."</td>
                    <td>".htmlspecialchars($row['nama_lengkap'])."</td>
                    <td style='text-align:center;'>".$row['gender']."</td>
                    <td style='text-align:center; font-weight:bold; color:".($row['status_riwayat'] === 'Pindahan' ? 'green' : 'red').";'>".$status_label."</td>
                    <td style='text-align:center;'>".date('d/m/Y', strtotime($row['tanggal_masuk']))."</td>
                    <td style='text-align:center;'>".htmlspecialchars($romanize($row['nama_kelas']))."</td>
                    <td style='text-align:center;'>".htmlspecialchars($row['tahun_ajaran'])."</td>
                </tr>";
            }
            if (empty($rows)) {
                echo "<tr><td colspan='9' style='text-align:center; color:#777; padding:10px;'>Tidak ada data mutasi siswa pada periode ini.</td></tr>";
            }
            echo "</table>";
            break;

        case 'alumni_angkatan':
            $ta_id = isset($_GET['ta_id']) ? intval($_GET['ta_id']) : 0;
            $ta_stmt = $pdo->prepare("SELECT tahun_ajaran FROM tahun_ajaran WHERE id = ?");
            $ta_stmt->execute([$ta_id]);
            $ta_name = $ta_stmt->fetchColumn() ?: '-';

            $stmt = $pdo->prepare("
                SELECT s.*, k.nama_kelas
                FROM riwayat_kelas r
                JOIN siswa s ON r.siswa_id = s.id
                LEFT JOIN kelas k ON r.kelas_id = k.id
                WHERE r.tahun_ajaran_id = ? AND r.status = 'Lulus'
                ORDER BY s.nama_lengkap ASC
            ");
            $stmt->execute([$ta_id]);
            $rows = $stmt->fetchAll();

            echo "<table border='1'>
                <tr><th colspan='8' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>DAFTAR ALUMNI - ANGKATAN / TAHUN LULUS ".$ta_name."</th></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>NIS</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>NISN</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Nama Lengkap</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>L/P</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Agama</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kelas Terakhir</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tahun Lulus (Angkatan)</th>
                </tr>";
            $no = 1;
            foreach ($rows as $row) {
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['nis'])."</td>
                    <td style='font-family:monospace; text-align:left;'>".htmlspecialchars($row['nisn'])."</td>
                    <td>".htmlspecialchars($row['nama_lengkap'])."</td>
                    <td style='text-align:center;'>".$row['gender']."</td>
                    <td>".htmlspecialchars($row['agama'])."</td>
                    <td style='text-align:center;'>".htmlspecialchars($romanize($row['nama_kelas'] ?? '-'))."</td>
                    <td style='text-align:center;'>".htmlspecialchars($ta_name)."</td>
                </tr>";
            }
            if (empty($rows)) {
                echo "<tr><td colspan='8' style='text-align:center; color:#777; padding:10px;'>Tidak ada data alumni untuk angkatan ini.</td></tr>";
            }
            echo "</table>";
            break;

        case 'histori_siswa':
            $siswa_id = isset($_GET['siswa_id']) ? intval($_GET['siswa_id']) : 0;
            $siswa_stmt = $pdo->prepare("SELECT * FROM siswa WHERE id = ?");
            $siswa_stmt->execute([$siswa_id]);
            $student = $siswa_stmt->fetch();
            if (!$student) {
                die("Siswa tidak ditemukan.");
            }

            $stmt = $pdo->prepare("
                SELECT r.status as status_placement, r.tanggal_masuk, k.nama_kelas, k.tingkat, ta.tahun_ajaran, g.nama_guru
                FROM riwayat_kelas r
                JOIN kelas k ON r.kelas_id = k.id
                JOIN tahun_ajaran ta ON r.tahun_ajaran_id = ta.id
                LEFT JOIN guru g ON k.wali_kelas_id = g.id
                WHERE r.siswa_id = ?
                ORDER BY ta.tahun_ajaran ASC
            ");
            $stmt->execute([$siswa_id]);
            $rows = $stmt->fetchAll();

            $ttl = $student['tempat_lahir'] . ', ' . ($student['tanggal_lahir'] ? date('d F Y', strtotime($student['tanggal_lahir'])) : '-');

            echo "<table border='1'>
                <tr><th colspan='7' style='font-size:16px; font-weight:bold; text-align:center; height:35px; background-color:#D4AF37;'>HISTORI KELAS SISWA - ".strtoupper($student['nama_lengkap'])."</th></tr>
                <tr><td colspan='7' style='height:10px;'></td></tr>
                <tr>
                    <td colspan='2' style='font-weight:bold;'>Nama Lengkap</td>
                    <td colspan='5'>: ".htmlspecialchars($student['nama_lengkap'])."</td>
                </tr>
                <tr>
                    <td colspan='2' style='font-weight:bold;'>NIS / NISN</td>
                    <td colspan='5'>: ".htmlspecialchars($student['nis'])." / ".htmlspecialchars($student['nisn'])."</td>
                </tr>
                <tr>
                    <td colspan='2' style='font-weight:bold;'>L/P / Agama</td>
                    <td colspan='5'>: ".($student['gender'] === 'L' ? 'Laki-laki' : 'Perempuan')." / ".htmlspecialchars($student['agama'])."</td>
                </tr>
                <tr>
                    <td colspan='2' style='font-weight:bold;'>Tempat, Tanggal Lahir</td>
                    <td colspan='5'>: ".htmlspecialchars($ttl)."</td>
                </tr>
                <tr>
                    <td colspan='2' style='font-weight:bold;'>Nama Orang Tua</td>
                    <td colspan='5'>: ".htmlspecialchars($student['nama_ayah'] ?: ($student['nama_ibu'] ?: '-'))."</td>
                </tr>
                <tr>
                    <td colspan='2' style='font-weight:bold;'>Alamat Domisili</td>
                    <td colspan='5'>: ".htmlspecialchars($student['alamat'] ?: '-')."</td>
                </tr>
                <tr>
                    <td colspan='2' style='font-weight:bold;'>Status Saat Ini</td>
                    <td colspan='5'>: ".htmlspecialchars($student['status_siswa'])."</td>
                </tr>
                <tr><td colspan='7' style='height:20px;'></td></tr>
                <tr>
                    <th style='background-color:#0B132B; color:#ffffff;'>No</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tahun Ajaran</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tingkat</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Kelas</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Wali Kelas</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Tanggal Masuk</th>
                    <th style='background-color:#0B132B; color:#ffffff;'>Status Penempatan</th>
                </tr>";
            $no = 1;
            foreach ($rows as $row) {
                echo "<tr>
                    <td style='text-align:center;'>".$no++."</td>
                    <td style='text-align:center; font-weight:bold;'>".htmlspecialchars($row['tahun_ajaran'])."</td>
                    <td style='text-align:center;'>Tingkat ".$row['tingkat']."</td>
                    <td style='text-align:center; font-weight:bold;'>".htmlspecialchars($romanize($row['nama_kelas']))."</td>
                    <td>".htmlspecialchars($row['nama_guru'] ?: '-')."</td>
                    <td style='text-align:center;'>".date('d/m/Y', strtotime($row['tanggal_masuk']))."</td>
                    <td style='text-align:center; font-weight:bold;'>".htmlspecialchars($row['status_placement'])."</td>
                </tr>";
            }
            if (empty($rows)) {
                echo "<tr><td colspan='7' style='text-align:center; color:#777; padding:10px;'>Belum ada riwayat penempatan kelas untuk siswa ini.</td></tr>";
            }
            echo "</table>";

            // Fetch student grade history from raport_siswa
            $hist_grades_stmt = $pdo->prepare("
                SELECT r.*, k.nama_kelas
                FROM raport_siswa r
                JOIN kelas k ON r.kelas_id = k.id
                WHERE r.siswa_id = ?
                ORDER BY r.tahun_ajaran ASC, r.semester ASC
            ");
            $hist_grades_stmt->execute([$siswa_id]);
            $hist_grades_rows = $hist_grades_stmt->fetchAll();

            // Group by tahun_ajaran => [ semester => data ]
            $hist_grades_by_ta = [];
            foreach ($hist_grades_rows as $row) {
                $ta = $row['tahun_ajaran'];
                $sem = $row['semester'];
                $hist_grades_by_ta[$ta][$sem] = [
                    'nama_kelas'  => $row['nama_kelas'],
                    'grades'      => json_decode($row['academic_grades'], true) ?: [],
                    'ekskul'      => json_decode($row['ekstrakurikuler'], true) ?: [],
                    'kokurikuler' => $row['kokurikuler_deskripsi'],
                    'sakit'       => $row['sakit'],
                    'izin'        => $row['izin'],
                    'alpa'        => $row['alpa']
                ];
            }

            // Transkrip Nilai Akademik
            echo "<br><br>";
            echo "<table border='1'>";
            echo "<tr><th colspan='7' style='font-size:15px; font-weight:bold; text-align:center; height:35px; background-color:#6257DE; color:#ffffff;'>HISTORI NILAI AKADEMIK & RAPOR SISWA</th></tr>";
            
            if (empty($hist_grades_by_ta)) {
                echo "<tr><td colspan='7' style='text-align:center; color:#777; padding:10px;'>Belum ada data nilai/rapor untuk siswa ini.</td></tr>";
            } else {
                $default_subjects = [
                    'Agama' => 'Pendidikan Agama',
                    'Pancasila' => 'Pancasila',
                    'Bahasa Indonesia' => 'Bahasa Indonesia',
                    'Matematika' => 'Matematika',
                    'IPAS' => 'IPAS',
                    'PJOK' => 'PJOK',
                    'Seni Budaya' => 'Seni Budaya',
                    'Bhs. Inggris' => 'Bhs. Inggris',
                    'Bhs. Jawa' => 'Bhs. Jawa',
                    'Bhs. Mandarin' => 'Bhs. Mandarin'
                ];

                foreach ($hist_grades_by_ta as $ta => $semesters) {
                    foreach ($semesters as $sem_num => $sdata) {
                        echo "<tr><td colspan='7' style='height:15px;'></td></tr>";
                        echo "<tr><th colspan='7' style='background-color:#E2E8F0; text-align:left; font-weight:bold; height:25px;'>TAHUN AJARAN: " . htmlspecialchars($ta) . " | SEMESTER: " . htmlspecialchars($sem_num) . " (Kelas: " . htmlspecialchars($sdata['nama_kelas']) . ")</th></tr>";
                        echo "<tr>
                            <th style='background-color:#0B132B; color:#ffffff; width:50px;'>No</th>
                            <th colspan='2' style='background-color:#0B132B; color:#ffffff;'>Mata Pelajaran</th>
                            <th style='background-color:#0B132B; color:#ffffff; width:80px;'>Nilai</th>
                            <th colspan='3' style='background-color:#0B132B; color:#ffffff;'>Capaian Kompetensi (Tertinggi)</th>
                        </tr>";

                        $all_subjects = array_keys($sdata['grades']);
                        if (empty($all_subjects)) {
                            $all_subjects = array_keys($default_subjects);
                        }

                        $sub_no = 1;
                        foreach ($all_subjects as $subj) {
                            $subj_display = $default_subjects[$subj] ?? $subj;
                            $g = $sdata['grades'][$subj] ?? [];
                            $score = isset($g['score']) && $g['score'] !== '' ? floatval($g['score']) : null;
                            echo "<tr>
                                <td style='text-align:center;'>".$sub_no++."</td>
                                <td colspan='2' style='font-weight:bold;'>".htmlspecialchars($subj_display)."</td>
                                <td style='text-align:center; font-weight:bold; font-size:12px;'>".($score !== null ? number_format($score, 0) : '—')."</td>
                                <td colspan='3'>".htmlspecialchars($g['desc_max'] ?? '—')."</td>
                            </tr>";
                        }

                        // Average row
                        $scores = array_filter(array_column($sdata['grades'], 'score'));
                        $avg = count($scores) > 0 ? round(array_sum($scores) / count($scores), 1) : null;
                        echo "<tr style='background-color:#f8fafc; font-weight:bold;'>
                            <td colspan='3' style='text-align:right;'>📊 RATA-RATA AKADEMIK:</td>
                            <td style='text-align:center; color:#6257DE;'>".($avg !== null ? number_format($avg, 1) : '—')."</td>
                            <td colspan='3'></td>
                        </tr>";

                        // Absensi
                        $sakit = intval($sdata['sakit']);
                        $izin = intval($sdata['izin']);
                        $alpa = intval($sdata['alpa']);
                        echo "<tr>
                            <td colspan='3' style='font-weight:bold;'>Kehadiran</td>
                            <td colspan='4'>Sakit: $sakit hari | Izin: $izin hari | Tanpa Keterangan: $alpa hari</td>
                        </tr>";

                        // Ekskul
                        $ekskul_str = '';
                        if (!empty($sdata['ekskul'])) {
                            $ekskul_arr = [];
                            foreach ($sdata['ekskul'] as $ek) {
                                $ekskul_str_item = ($ek['nama'] ?? $ek['name'] ?? '');
                                if (!empty($ek['predikat'] ?? $ek['predicate'] ?? $ek['grade'] ?? '')) {
                                    $ekskul_str_item .= " (" . ($ek['predikat'] ?? $ek['predicate'] ?? $ek['grade']) . ")";
                                }
                                $ekskul_arr[] = $ekskul_str_item;
                            }
                            $ekskul_str = implode(", ", $ekskul_arr);
                        } else {
                            $ekskul_str = '—';
                        }
                        echo "<tr>
                            <td colspan='3' style='font-weight:bold;'>Ekstrakurikuler</td>
                            <td colspan='4'>".htmlspecialchars($ekskul_str)."</td>
                        </tr>";
                    }
                }
            }
            echo "</table>";
            break;

        default:
            die("Error: Tipe laporan tidak didukung.");
    }
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}
?>
