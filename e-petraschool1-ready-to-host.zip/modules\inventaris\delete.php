<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\inventaris\delete.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    try {
        // Fetch details for logging & photo delete
        $stmt = $pdo->prepare("SELECT nama_barang, foto_barang FROM inventaris WHERE id = ?");
        $stmt->execute([$id]);
        $asset = $stmt->fetch();

        if ($asset) {
            // Delete photo if exists
            if (!empty($asset['foto_barang'])) {
                $upload_dir = dirname(dirname(__DIR__)) . '/assets/uploads/inventaris/';
                if (file_exists($upload_dir . $asset['foto_barang'])) {
                    unlink($upload_dir . $asset['foto_barang']);
                }
            }

            // Delete record
            $delete_stmt = $pdo->prepare("DELETE FROM inventaris WHERE id = ?");
            $delete_stmt->execute([$id]);
            
            write_audit_log("Menghapus data aset: " . $asset['nama_barang'] . ".");
        }
    } catch (Exception $e) {
        error_log("Failed to delete asset: " . $e->getMessage());
    }
}

header("Location: index.php");
exit;
?>
