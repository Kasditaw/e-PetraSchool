<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\ruangan\index.php

$page_title = 'Data Ruangan';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

try {
    // Select rooms, joining with guru to get Supervisor name
    $query = "SELECT r.*, g.nama_guru 
              FROM ruangan r 
              LEFT JOIN guru g ON r.penanggung_jawab_id = g.id";
    
    if ($search !== '') {
        $query .= " WHERE r.nama_ruangan LIKE :search OR r.kode_ruangan LIKE :search OR g.nama_guru LIKE :search";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['search' => "%$search%"]);
    } else {
        $stmt = $pdo->query($query);
    }
    
    $rooms = $stmt->fetchAll();
} catch (Exception $e) {
    echo '<div class="alert alert-danger">Gagal memuat data ruangan: ' . $e->getMessage() . '</div>';
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-door-open me-2"></i> Pengelolaan Data Ruangan Sekolah</h5>
            <p class="text-secondary small mb-0">Kelola master data gedung, laboratorium, ruang UKS, perpustakaan, dan penanggung jawabnya.</p>
        </div>
        
        <div class="d-flex gap-2">
            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                <a href="create.php" class="btn btn-gold"><i class="fa-solid fa-plus me-1"></i> Tambah Ruangan</a>
            <?php endif; ?>
            <a href="../laporan/export.php?type=ruangan" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-excel me-1"></i> Ekspor Excel</a>
            <a href="../laporan/print.php?type=ruangan" target="_blank" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-pdf me-1"></i> Cetak PDF</a>
        </div>
    </div>

    <!-- Search Form -->
    <form method="GET" action="index.php" class="row g-2 mb-4 no-print">
        <div class="col-12 col-md-4">
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari kode, nama ruangan, guru..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">Cari</button>
        </div>
        <?php if ($search !== ''): ?>
            <div class="col-auto">
                <a href="index.php" class="btn btn-outline-danger">Reset</a>
            </div>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Kode Ruangan</th>
                    <th>Nama Ruangan</th>
                    <th>Lantai</th>
                    <th>Kapasitas</th>
                    <th>Kondisi</th>
                    <th>Penanggung Jawab</th>
                    <?php if (has_role(['Super Admin', 'Admin'])): ?>
                        <th class="no-print">Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (count($rooms) > 0): ?>
                    <?php $no = 1; foreach ($rooms as $room): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td><span class="badge badge-secondary"><?php echo htmlspecialchars($room['kode_ruangan']); ?></span></td>
                            <td class="fw-bold text-white"><?php echo htmlspecialchars($room['nama_ruangan']); ?></td>
                            <td>Lantai <?php echo htmlspecialchars($room['lantai']); ?></td>
                            <td><?php echo intval($room['kapasitas']); ?> Orang</td>
                            <td>
                                <?php 
                                    $badge_class = 'badge-secondary';
                                    if ($room['kondisi'] === 'Baik') $badge_class = 'badge-success';
                                    elseif ($room['kondisi'] === 'Rusak Ringan') $badge_class = 'badge-warning';
                                    elseif ($room['kondisi'] === 'Rusak Berat') $badge_class = 'badge-danger';
                                ?>
                                <span class="badge <?php echo $badge_class; ?>"><?php echo $room['kondisi']; ?></span>
                            </td>
                            <td><i class="fa-solid fa-user-tie me-1 text-gold"></i> <?php echo htmlspecialchars($room['nama_guru'] ?? 'Belum Ditentukan'); ?></td>
                            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                                <td class="no-print">
                                    <div class="d-flex gap-2">
                                        <a href="edit.php?id=<?php echo $room['id']; ?>" class="btn btn-xs btn-outline-warning" title="Edit"><i class="fa-solid fa-pen"></i> Edit</a>
                                        <button onclick="confirmDelete('delete.php?id=<?php echo $room['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i> Hapus</button>
                                    </div>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="<?php echo has_role(['Super Admin', 'Admin']) ? 8 : 7; ?>" class="text-center text-secondary py-4">Data ruangan tidak ditemukan.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
