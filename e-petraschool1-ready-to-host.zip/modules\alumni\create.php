<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\alumni\create.php

$page_title = 'Tambah Alumni';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $nis = trim($_POST['nis'] ?? '');
    $nama_alumni = trim($_POST['nama_alumni'] ?? '');
    $tahun_lulus = intval($_POST['tahun_lulus'] ?? date('Y'));
    $alamat = trim($_POST['alamat'] ?? '');
    $no_hp = trim($_POST['no_hp'] ?? '');
    $pekerjaan = trim($_POST['pekerjaan'] ?? '');
    $pendidikan_lanjutan = trim($_POST['pendidikan_lanjutan'] ?? '');

    if (empty($nis) || empty($nama_alumni) || $tahun_lulus <= 0 || empty($no_hp) || empty($pendidikan_lanjutan)) {
        $error = 'Field NIS, Nama, Tahun Lulus, No HP, dan Pendidikan Lanjutan wajib diisi!';
    } else {
        try {
            // Check duplicate NIS
            $chk = $pdo->prepare("SELECT COUNT(*) FROM alumni WHERE nis = ?");
            $chk->execute([$nis]);
            if ($chk->fetchColumn() > 0) {
                $error = "Alumni dengan NIS '$nis' sudah terdaftar!";
            } else {
                // Insert alumni
                $stmt = $pdo->prepare("INSERT INTO alumni (nis, nama_alumni, tahun_lulus, alamat, no_hp, pekerjaan, pendidikan_lanjutan) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$nis, $nama_alumni, $tahun_lulus, $alamat, $no_hp, $pekerjaan, $pendidikan_lanjutan]);
                
                write_audit_log("Menambahkan data alumni baru: $nama_alumni (NIS: $nis).");

                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Data alumni berhasil disimpan!', 'success').then(() => {
                            window.location.href = 'index.php';
                        });
                    });
                </script>";
            }
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}
?>

<div class="glass-card" style="max-width: 650px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-plus me-2"></i> Tambah Data Alumni Baru</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="create.php">
        <?php csrf_input(); ?>

        <div class="mb-3">
            <label for="nis" class="form-label form-label-custom">NIS (Nomor Induk Siswa) <span class="text-danger">*</span></label>
            <input type="text" name="nis" id="nis" class="form-control form-control-custom" placeholder="Contoh: 201901" required>
        </div>

        <div class="mb-3">
            <label for="nama_alumni" class="form-label form-label-custom">Nama Lengkap Alumni <span class="text-danger">*</span></label>
            <input type="text" name="nama_alumni" id="nama_alumni" class="form-control form-control-custom" placeholder="Nama lengkap alumni" required>
        </div>

        <div class="row g-3 mb-3">
            <div class="col-6">
                <label for="tahun_lulus" class="form-label form-label-custom">Tahun Lulus <span class="text-danger">*</span></label>
                <input type="number" name="tahun_lulus" id="tahun_lulus" class="form-control form-control-custom" value="<?php echo date('Y') - 1; ?>" required>
            </div>
            
            <div class="col-6">
                <label for="no_hp" class="form-label form-label-custom">Nomor HP / Kontak <span class="text-danger">*</span></label>
                <input type="text" name="no_hp" id="no_hp" class="form-control form-control-custom" placeholder="Contoh: 085678901" required>
            </div>
        </div>

        <div class="mb-3">
            <label for="pekerjaan" class="form-label form-label-custom">Pekerjaan / Aktivitas Saat Ini</label>
            <input type="text" name="pekerjaan" id="pekerjaan" class="form-control form-control-custom" placeholder="Contoh: Siswa SMP, Pelajar" value="Siswa SMP">
        </div>

        <div class="mb-3">
            <label for="pendidikan_lanjutan" class="form-label form-label-custom">Pendidikan Lanjutan <span class="text-danger">*</span></label>
            <input type="text" name="pendidikan_lanjutan" id="pendidikan_lanjutan" class="form-control form-control-custom" placeholder="Contoh: SMP Kristen Petra 1 Surabaya" required>
        </div>

        <div class="mb-4">
            <label for="alamat" class="form-label form-label-custom">Alamat Lengkap</label>
            <textarea name="alamat" id="alamat" class="form-control form-control-custom" rows="2" placeholder="Alamat domisili lengkap alumni saat ini"></textarea>
        </div>

        <div class="d-flex justify-content-end gap-2">
            <a href="index.php" class="btn btn-outline-custom">Batal</a>
            <button type="submit" class="btn btn-gold">Simpan <i class="fa-solid fa-check ms-1"></i></button>
        </div>
    </form>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
