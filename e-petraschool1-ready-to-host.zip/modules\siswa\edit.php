<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\siswa\edit.php

$page_title = 'Edit Siswa';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';

try {
    // Load current student details
    $stmt = $pdo->prepare("SELECT * FROM siswa WHERE id = ?");
    $stmt->execute([$id]);
    $student = $stmt->fetch();
    
    if (!$student) {
        die('<div class="alert alert-danger">Data siswa tidak ditemukan!</div>');
    }
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

// Process update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $nis = trim($_POST['nis'] ?? '');
    $nisn = trim($_POST['nisn'] ?? '');
    $student_code = trim($_POST['student_code'] ?? '');
    $nama_lengkap = trim($_POST['nama_lengkap'] ?? '');
    $gender = $_POST['gender'] ?? '';
    $asal_sekolah = trim($_POST['asal_sekolah'] ?? '');
    $nik = trim($_POST['nik'] ?? '');
    $tempat_lahir = trim($_POST['tempat_lahir'] ?? '');
    $tanggal_lahir = $_POST['tanggal_lahir'] ?? '';
    $agama = $_POST['agama'] ?? '';
    $alamat = trim($_POST['alamat'] ?? '');
    $alamat_kk = trim($_POST['alamat_kk'] ?? '');
    $no_hp_ortu = trim($_POST['no_hp_ortu'] ?? '');
    $nama_ayah = trim($_POST['nama_ayah'] ?? '');
    $nama_ibu = trim($_POST['nama_ibu'] ?? '');
    $pekerjaan_ayah = trim($_POST['pekerjaan_ayah'] ?? '');
    $pekerjaan_ibu = trim($_POST['pekerjaan_ibu'] ?? '');
    $kelas_id = $_POST['kelas_id'] !== '' ? intval($_POST['kelas_id']) : null;
    $tahun_masuk = intval($_POST['tahun_masuk'] ?? date('Y'));
    $status_siswa = $_POST['status_siswa'] ?? 'Aktif';
    
    // File upload handling
    $foto_name = $student['foto']; // Keep existing by default
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['foto']['tmp_name'];
        $file_name = $_FILES['foto']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed_exts = ['jpg', 'jpeg', 'png'];
        $mime_type = mime_content_type($file_tmp);
        $allowed_mimes = ['image/jpeg', 'image/png', 'image/pjpeg'];
        
        if (in_array($file_ext, $allowed_exts) && in_array($mime_type, $allowed_mimes)) {
            $upload_dir = dirname(dirname(__DIR__)) . '/assets/uploads/siswa/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            // Delete old photo if it exists
            if (!empty($student['foto']) && file_exists($upload_dir . $student['foto'])) {
                unlink($upload_dir . $student['foto']);
            }
            
            $foto_name = 'student_' . $nis . '_' . time() . '.' . $file_ext;
            if (move_uploaded_file($file_tmp, $upload_dir . $foto_name)) {
                // Upload successful
            } else {
                $error = 'Gagal memindahkan file foto baru yang diunggah.';
            }
        } else {
            $error = 'Format foto tidak valid. Hanya menerima format JPG, JPEG, dan PNG.';
        }
    }

    if ($error === '') {
        if (empty($nis) || empty($nisn) || empty($nama_lengkap) || empty($gender) || empty($agama) || empty($no_hp_ortu)) {
            $error = 'Field NIS, NISN, Nama, Gender, Agama, dan No HP wajib diisi!';
        } else {
            try {
                // Check duplicate NIS on other records
                $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM siswa WHERE nis = ? AND id != ?");
                $check_stmt->execute([$nis, $id]);
                if ($check_stmt->fetchColumn() > 0) {
                    $error = "NIS '$nis' sudah terdaftar pada siswa lain!";
                } else {
                    // Check duplicate NISN on other records
                    $check_stmt2 = $pdo->prepare("SELECT COUNT(*) FROM siswa WHERE nisn = ? AND id != ?");
                    $check_stmt2->execute([$nisn, $id]);
                    if ($check_stmt2->fetchColumn() > 0) {
                        $error = "NISN '$nisn' sudah terdaftar pada siswa lain!";
                    } else {
                        // Update student record
                        $query = "UPDATE siswa SET nis = ?, nisn = ?, student_code = ?, nama_lengkap = ?, gender = ?, asal_sekolah = ?, nik = ?, tempat_lahir = ?, tanggal_lahir = ?, agama = ?, alamat = ?, alamat_kk = ?, no_hp_ortu = ?, nama_ayah = ?, nama_ibu = ?, pekerjaan_ayah = ?, pekerjaan_ibu = ?, kelas_id = ?, tahun_masuk = ?, status_siswa = ?, foto = ? WHERE id = ?";
                        $stmt = $pdo->prepare($query);
                        $stmt->execute([
                            $nis, $nisn, $student_code, $nama_lengkap, $gender, $asal_sekolah, $nik, $tempat_lahir, $tanggal_lahir, 
                            $agama, $alamat, $alamat_kk, $no_hp_ortu, $nama_ayah, $nama_ibu, 
                            $pekerjaan_ayah, $pekerjaan_ibu, $kelas_id, $tahun_masuk, $status_siswa, $foto_name, $id
                        ]);

                        write_audit_log("Mengubah data siswa: $nama_lengkap (NIS: $nis).");

                        echo "<script>
                            document.addEventListener('DOMContentLoaded', function() {
                                Swal.fire('Berhasil', 'Data siswa berhasil diubah!', 'success').then(() => {
                                    window.location.href = 'index.php';
                                });
                            });
                        </script>";
                    }
                }
            } catch (Exception $e) {
                $error = 'Gagal menyimpan data ke database: ' . $e->getMessage();
            }
        }
    }
}

// Fetch classes for dropdown
try {
    $classes_stmt = $pdo->query("SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas ASC");
    $classes = $classes_stmt->fetchAll();
} catch (Exception $e) {
    $classes = [];
}
?>

<div class="glass-card" style="max-width: 800px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-user-pen me-2"></i> Edit Data Siswa</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="edit.php?id=<?php echo $id; ?>" enctype="multipart/form-data">
        <?php csrf_input(); ?>

        <div class="row g-3">
            <div class="col-12 col-md-4">
                <label for="nis" class="form-label form-label-custom">No. Induk (NIS) <span class="text-danger">*</span></label>
                <input type="text" name="nis" id="nis" class="form-control form-control-custom" value="<?php echo htmlspecialchars($student['nis']); ?>" required>
            </div>
            
            <div class="col-12 col-md-4">
                <label for="nisn" class="form-label form-label-custom">NISN <span class="text-danger">*</span></label>
                <input type="text" name="nisn" id="nisn" class="form-control form-control-custom" value="<?php echo htmlspecialchars($student['nisn']); ?>" required>
            </div>

            <div class="col-12 col-md-4">
                <label for="student_code" class="form-label form-label-custom">Student Code</label>
                <input type="text" name="student_code" id="student_code" class="form-control form-control-custom" value="<?php echo htmlspecialchars($student['student_code'] ?? ''); ?>">
            </div>

            <div class="col-12 col-md-6">
                <label for="nama_lengkap" class="form-label form-label-custom">Nama Lengkap Siswa <span class="text-danger">*</span></label>
                <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control form-control-custom" value="<?php echo htmlspecialchars($student['nama_lengkap']); ?>" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="nik" class="form-label form-label-custom">NIK (Nomor Induk Kependudukan)</label>
                <input type="text" name="nik" id="nik" class="form-control form-control-custom" value="<?php echo htmlspecialchars($student['nik'] ?? ''); ?>" placeholder="16 digit NIK siswa">
            </div>

            <div class="col-12 col-md-6">
                <label for="gender" class="form-label form-label-custom">Jenis Kelamin <span class="text-danger">*</span></label>
                <select name="gender" id="gender" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="L" <?php echo $student['gender'] === 'L' ? 'selected' : ''; ?>>Laki-laki</option>
                    <option value="P" <?php echo $student['gender'] === 'P' ? 'selected' : ''; ?>>Perempuan</option>
                </select>
            </div>

            <div class="col-12 col-md-6">
                <label for="asal_sekolah" class="form-label form-label-custom">Asal Sekolah (TK)</label>
                <input type="text" name="asal_sekolah" id="asal_sekolah" class="form-control form-control-custom" value="<?php echo htmlspecialchars($student['asal_sekolah'] ?? ''); ?>" placeholder="Nama TK asal">
            </div>

            <div class="col-12 col-md-6">
                <label for="tempat_lahir" class="form-label form-label-custom">Tempat Lahir</label>
                <input type="text" name="tempat_lahir" id="tempat_lahir" class="form-control form-control-custom" value="<?php echo htmlspecialchars($student['tempat_lahir']); ?>">
            </div>

            <div class="col-12 col-md-6">
                <label for="tanggal_lahir" class="form-label form-label-custom">Tanggal Lahir</label>
                <input type="date" name="tanggal_lahir" id="tanggal_lahir" class="form-control form-control-custom" value="<?php echo $student['tanggal_lahir']; ?>">
            </div>

            <div class="col-12 col-md-6">
                <label for="agama" class="form-label form-label-custom">Agama <span class="text-danger">*</span></label>
                <select name="agama" id="agama" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="Kristen" <?php echo $student['agama'] === 'Kristen' ? 'selected' : ''; ?>>Kristen</option>
                    <option value="Katolik" <?php echo $student['agama'] === 'Katolik' ? 'selected' : ''; ?>>Katolik</option>
                    <option value="Islam" <?php echo $student['agama'] === 'Islam' ? 'selected' : ''; ?>>Islam</option>
                    <option value="Hindu" <?php echo $student['agama'] === 'Hindu' ? 'selected' : ''; ?>>Hindu</option>
                    <option value="Buddha" <?php echo $student['agama'] === 'Buddha' ? 'selected' : ''; ?>>Buddha</option>
                    <option value="Konghucu" <?php echo $student['agama'] === 'Konghucu' ? 'selected' : ''; ?>>Konghucu</option>
                </select>
            </div>

            <div class="col-12 col-md-6">
                <label for="kelas_id" class="form-label form-label-custom">Kelas / Rombel</label>
                <select name="kelas_id" id="kelas_id" class="form-select form-control-custom bg-dark-select text-white">
                    <option value="">Pilih Kelas...</option>
                    <?php foreach ($classes as $cl): ?>
                        <option value="<?php echo $cl['id']; ?>" <?php echo $student['kelas_id'] == $cl['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($cl['nama_kelas']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-12 col-md-6">
                <label for="tahun_masuk" class="form-label form-label-custom">Tahun Masuk</label>
                <input type="number" name="tahun_masuk" id="tahun_masuk" class="form-control form-control-custom" value="<?php echo $student['tahun_masuk']; ?>">
            </div>

            <div class="col-12 col-md-6">
                <label for="status_siswa" class="form-label form-label-custom">Status Siswa</label>
                <select name="status_siswa" id="status_siswa" class="form-select form-control-custom bg-dark-select text-white">
                    <option value="Aktif" <?php echo $student['status_siswa'] === 'Aktif' ? 'selected' : ''; ?>>Aktif</option>
                    <option value="Alumni" <?php echo $student['status_siswa'] === 'Alumni' ? 'selected' : ''; ?>>Alumni / Lulus</option>
                    <option value="Pindahan" <?php echo $student['status_siswa'] === 'Pindahan' ? 'selected' : ''; ?>>Pindahan</option>
                    <option value="Keluar" <?php echo $student['status_siswa'] === 'Keluar' ? 'selected' : ''; ?>>Keluar / Mutasi</option>
                </select>
            </div>

            <div class="col-12 col-md-6">
                <label for="alamat" class="form-label form-label-custom">Alamat Domisili Lengkap</label>
                <textarea name="alamat" id="alamat" class="form-control form-control-custom" rows="2"><?php echo htmlspecialchars($student['alamat']); ?></textarea>
            </div>

            <div class="col-12 col-md-6">
                <label for="alamat_kk" class="form-label form-label-custom">Alamat Kartu Keluarga (KK)</label>
                <textarea name="alamat_kk" id="alamat_kk" class="form-control form-control-custom" rows="2" placeholder="Tulis alamat sesuai KK"><?php echo htmlspecialchars($student['alamat_kk'] ?? ''); ?></textarea>
            </div>

            <div class="col-12 col-md-6">
                <label for="no_hp_ortu" class="form-label form-label-custom">No HP Orang Tua <span class="text-danger">*</span></label>
                <input type="text" name="no_hp_ortu" id="no_hp_ortu" class="form-control form-control-custom" value="<?php echo htmlspecialchars($student['no_hp_ortu']); ?>" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="foto" class="form-label form-label-custom">Foto Profil Siswa</label>
                <div class="d-flex align-items-center gap-3">
                    <?php if (!empty($student['foto'])): ?>
                        <img src="<?php echo $base_url; ?>assets/uploads/siswa/<?php echo $student['foto']; ?>" alt="Foto Current" class="rounded border" style="width: 45px; height: 55px; object-fit: cover;">
                    <?php endif; ?>
                    <input type="file" name="foto" id="foto" class="form-control form-control-custom" accept="image/*">
                </div>
                <span class="text-secondary d-block mt-1" style="font-size: 10px;">Format: JPG, JPEG, PNG (Maksimal 2MB). Biarkan kosong jika tidak ingin mengubah foto.</span>
            </div>

            <div class="col-12 mt-4">
                <h6 class="text-gold border-bottom border-secondary border-opacity-25 pb-2 mb-3"><i class="fa-solid fa-users me-2"></i> Data Orang Tua / Wali</h6>
            </div>

            <div class="col-12 col-md-6">
                <label for="nama_ayah" class="form-label form-label-custom">Nama Ayah</label>
                <input type="text" name="nama_ayah" id="nama_ayah" class="form-control form-control-custom" value="<?php echo htmlspecialchars($student['nama_ayah']); ?>">
            </div>

            <div class="col-12 col-md-6">
                <label for="pekerjaan_ayah" class="form-label form-label-custom">Pekerjaan Ayah</label>
                <input type="text" name="pekerjaan_ayah" id="pekerjaan_ayah" class="form-control form-control-custom" value="<?php echo htmlspecialchars($student['pekerjaan_ayah']); ?>">
            </div>

            <div class="col-12 col-md-6">
                <label for="nama_ibu" class="form-label form-label-custom">Nama Ibu</label>
                <input type="text" name="nama_ibu" id="nama_ibu" class="form-control form-control-custom" value="<?php echo htmlspecialchars($student['nama_ibu']); ?>">
            </div>

            <div class="col-12 col-md-6">
                <label for="pekerjaan_ibu" class="form-label form-label-custom">Pekerjaan Ibu</label>
                <input type="text" name="pekerjaan_ibu" id="pekerjaan_ibu" class="form-control form-control-custom" value="<?php echo htmlspecialchars($student['pekerjaan_ibu']); ?>">
            </div>

            <div class="col-12 d-flex justify-content-end gap-2 mt-4">
                <a href="index.php" class="btn btn-outline-custom">Batal</a>
                <button type="submit" class="btn btn-gold">Simpan Perubahan <i class="fa-solid fa-check ms-1"></i></button>
            </div>
        </div>
    </form>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
