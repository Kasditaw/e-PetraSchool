<?php
// c:\xampp\htdocs\e-petraschool1\modules\profile\index.php
// Modul Profil Pengguna & Ganti Password

$page_title = 'Profil Pengguna';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Load user details
try {
    $stmt = $pdo->prepare("SELECT u.*, r.nama_role FROM users u JOIN roles r ON u.role_id = r.id WHERE u.id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (!$user) {
        die("Pengguna tidak ditemukan.");
    }

    // Load teacher details if applicable
    $guru = null;
    if (!empty($user['guru_id'])) {
        $stmt_guru = $pdo->prepare("SELECT * FROM guru WHERE id = ?");
        $stmt_guru->execute([$user['guru_id']]);
        $guru = $stmt_guru->fetch();
    }
} catch (Exception $e) {
    $error = "Gagal memuat profil: " . $e->getMessage();
}

// Process Foto Upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_foto'])) {
    check_csrf_request();
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $allowed = ['image/jpeg','image/png','image/gif','image/webp'];
        $mime = mime_content_type($_FILES['foto']['tmp_name']);
        if (!in_array($mime, $allowed)) {
            $error = 'Format foto tidak valid. Gunakan JPG, PNG, atau WebP.';
        } elseif ($_FILES['foto']['size'] > 2 * 1024 * 1024) {
            $error = 'Ukuran foto maksimal 2MB.';
        } else {
            $dir = dirname(dirname(__DIR__)) . '/assets/uploads/foto_profil/';
            if (!is_dir($dir)) mkdir($dir, 0777, true);
            $ext  = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
            $fname = 'user_' . $user_id . '_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['foto']['tmp_name'], $dir . $fname)) {
                // Hapus foto lama jika ada
                if (!empty($user['foto'])) @unlink($dir . $user['foto']);
                $pdo->prepare("UPDATE users SET foto=? WHERE id=?")->execute([$fname, $user_id]);
                $user['foto'] = $fname;
                write_audit_log("Memperbarui foto profil.");
                $success = 'Foto profil berhasil diperbarui!';
            } else { $error = 'Gagal menyimpan foto.'; }
        }
    } else { $error = 'Pilih file foto terlebih dahulu!'; }
}

// Process Password Change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $old_password = $_POST['old_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (empty($old_password) || empty($new_password) || empty($confirm_password)) {
        $error = "Semua field ganti password harus diisi!";
    } elseif ($new_password !== $confirm_password) {
        $error = "Konfirmasi password baru tidak cocok!";
    } elseif (strlen($new_password) < 6) {
        $error = "Password baru minimal terdiri dari 6 karakter!";
    } else {
        try {
            // Verify current password
            $stmt_check = $pdo->prepare("SELECT password FROM users WHERE id = ?");
            $stmt_check->execute([$user_id]);
            $current_hash = $stmt_check->fetchColumn();

            if (password_verify($old_password, $current_hash)) {
                // Encrypt and update
                $new_hash = password_hash($new_password, PASSWORD_BCRYPT);
                $stmt_update = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt_update->execute([$new_hash, $user_id]);

                $success = "Password Anda berhasil diperbarui!";
                write_audit_log("Melakukan perubahan password mandiri.");
            } else {
                $error = "Password lama yang Anda masukkan salah!";
            }
        } catch (Exception $e) {
            $error = "Gagal mengubah password: " . $e->getMessage();
        }
    }
}

// Determine active action from GET param
$active_tab = isset($_GET['action']) ? $_GET['action'] : 'profile';
if (!in_array($active_tab, ['profile','password','foto'])) $active_tab = 'profile';
?>

<div class="glass-card">
    <div class="d-flex align-items-center justify-content-between flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-regular fa-id-card me-2"></i> Profil & Akun Anda</h5>
            <p class="text-secondary small mb-0">Kelola informasi profil pribadi dan keamanan akun Anda.</p>
        </div>
    </div>

    <!-- Alert Messages (Direct display as fallback to SweetAlert) -->
    <?php if (!empty($error)): ?>
        <div class="alert alert-danger text-danger bg-danger bg-opacity-10 border-0 mb-4" role="alert">
            <i class="fa-solid fa-circle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($success)): ?>
        <div class="alert alert-success text-success bg-success bg-opacity-10 border-0 mb-4" role="alert">
            <i class="fa-solid fa-circle-check me-2"></i> <?php echo htmlspecialchars($success); ?>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Profile Navigation Sidebar -->
        <div class="col-12 col-md-3">
            <!-- Foto Avatar -->
            <div class="text-center mb-3">
                <?php if (!empty($user['foto'])): ?>
                    <img src="<?php echo $base_url; ?>assets/uploads/foto_profil/<?php echo htmlspecialchars($user['foto']); ?>" alt="Foto" style="width:80px;height:80px;border-radius:50%;object-fit:cover;border:3px solid rgba(212,175,55,.4);">
                <?php else: ?>
                    <div style="width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,#D4AF37,#A8802B);display:flex;align-items:center;justify-content:center;font-size:30px;font-weight:800;color:#000;margin:0 auto;border:3px solid rgba(212,175,55,.4);"><?php echo strtoupper(substr($user['nama'],0,1)); ?></div>
                <?php endif; ?>
                <div class="fw-bold text-white mt-2" style="font-size:13px;"><?php echo htmlspecialchars($user['nama']); ?></div>
                <div class="text-secondary" style="font-size:11px;"><?php echo htmlspecialchars($user['nama_role']??''); ?></div>
            </div>
            <div class="list-group list-group-custom border-secondary border-opacity-10 rounded-3 overflow-hidden">
                <a href="?action=profile" class="list-group-item list-group-item-action list-group-item-custom <?php echo $active_tab === 'profile' ? 'active' : ''; ?> p-3">
                    <i class="fa-regular fa-user me-2"></i> Informasi Profil
                </a>
                <a href="?action=foto" class="list-group-item list-group-item-action list-group-item-custom <?php echo $active_tab === 'foto' ? 'active' : ''; ?> p-3">
                    <i class="fa-solid fa-camera me-2"></i> Foto Profil
                </a>
                <a href="?action=password" class="list-group-item list-group-item-action list-group-item-custom <?php echo $active_tab === 'password' ? 'active' : ''; ?> p-3">
                    <i class="fa-solid fa-key me-2"></i> Ganti Password
                </a>
            </div>
        </div>

        <!-- Detail Content Panel -->
        <div class="col-12 col-md-9">
            <div class="p-4 rounded-4" style="background: rgba(255, 255, 255, 0.02); border: 1px solid rgba(255, 255, 255, 0.05);">
                
                <?php if ($active_tab === 'foto'): ?>
                    <!-- TAB: FOTO PROFIL -->
                    <h6 class="text-white fw-bold mb-4"><i class="fa-solid fa-camera text-gold me-2"></i> Upload Foto Profil</h6>
                    <?php if (!empty($user['foto'])): ?>
                        <div class="text-center mb-4">
                            <img src="<?php echo $base_url; ?>assets/uploads/foto_profil/<?php echo htmlspecialchars($user['foto']); ?>" alt="Foto Profil" style="width:120px;height:120px;border-radius:50%;object-fit:cover;border:4px solid rgba(212,175,55,.4);">
                            <p class="text-secondary small mt-2">Foto profil Anda saat ini</p>
                        </div>
                    <?php endif; ?>
                    <form method="POST" enctype="multipart/form-data" action="?action=foto">
                        <?php csrf_input(); ?>
                        <input type="hidden" name="upload_foto" value="1">
                        <div class="mb-3">
                            <label class="form-label form-label-custom">Pilih Foto Baru</label>
                            <input type="file" name="foto" class="form-control form-control-custom" accept="image/jpeg,image/png,image/webp" required>
                            <div class="text-secondary" style="font-size:11px;margin-top:6px;">Format: JPG, PNG, WebP. Maksimal 2MB. Akan otomatis dipotong menjadi lingkaran.</div>
                        </div>
                        <button type="submit" class="btn btn-gold"><i class="fa-solid fa-upload me-1"></i> Upload Foto Profil</button>
                    </form>

                <?php elseif ($active_tab === 'profile'): ?>
                    <!-- TAB 1: INFORMASI PROFIL -->
                    <div class="d-flex align-items-center gap-4 flex-wrap border-bottom border-secondary border-opacity-10 pb-4 mb-4">
                        <?php if (!empty($user['foto'])): ?>
                            <img src="<?php echo $base_url; ?>assets/uploads/foto_profil/<?php echo htmlspecialchars($user['foto']); ?>" alt="Foto" style="width:70px;height:70px;border-radius:50%;object-fit:cover;border:3px solid rgba(212,175,55,.4);">
                        <?php else: ?>
                            <div style="width:70px;height:70px;border-radius:50%;background:linear-gradient(135deg,#D4AF37,#A8802B);display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:800;color:#000;border:3px solid rgba(212,175,55,.4);"><?php echo strtoupper(substr($user['nama'],0,1)); ?></div>
                        <?php endif; ?>
                        <div>
                            <h4 class="text-white fw-bold mb-1"><?php echo htmlspecialchars($user['nama']); ?></h4>
                            <span class="badge bg-gold text-dark fw-bold px-3 py-1.5" style="font-size: 11px; letter-spacing: 0.5px;"><?php echo htmlspecialchars($user['nama_role']); ?></span>
                        </div>
                    </div>

                    <div class="row g-3">
                        <div class="col-12 col-sm-6">
                            <label class="form-label text-secondary small fw-semibold">Username</label>
                            <div class="form-control form-control-custom bg-dark text-white border-0 py-2.5 px-3 rounded-3 font-monospace">
                                <?php echo htmlspecialchars($user['username']); ?>
                            </div>
                        </div>

                        <div class="col-12 col-sm-6">
                            <label class="form-label text-secondary small fw-semibold">Status Akun</label>
                            <div class="form-control form-control-custom bg-dark text-white border-0 py-2.5 px-3 rounded-3">
                                <span class="text-success fw-bold"><i class="fa-solid fa-circle-check me-1.5"></i><?php echo htmlspecialchars($user['status_aktif'] ?? 'Aktif'); ?></span>
                            </div>
                        </div>

                        <?php if ($guru): ?>
                            <!-- Guru specific data fields -->
                            <div class="col-12"><hr class="border-secondary border-opacity-10 my-3"></div>

                            <div class="col-12 col-sm-6">
                                <label class="form-label text-secondary small fw-semibold">NIP / Nomor Induk Pegawai</label>
                                <div class="form-control form-control-custom bg-dark text-white border-0 py-2.5 px-3 rounded-3 font-monospace">
                                    <?php echo htmlspecialchars($guru['nip'] ?: '-'); ?>
                                </div>
                            </div>

                            <div class="col-12 col-sm-6">
                                <label class="form-label text-secondary small fw-semibold">Gelar Pendidikan</label>
                                <div class="form-control form-control-custom bg-dark text-white border-0 py-2.5 px-3 rounded-3">
                                    <?php echo htmlspecialchars($guru['pendidikan'] ?: '-'); ?>
                                </div>
                            </div>

                            <div class="col-12 col-sm-6">
                                <label class="form-label text-secondary small fw-semibold">Nomor Telepon</label>
                                <div class="form-control form-control-custom bg-dark text-white border-0 py-2.5 px-3 rounded-3">
                                    <?php echo htmlspecialchars($guru['no_hp'] ?: '-'); ?>
                                </div>
                            </div>

                            <div class="col-12 col-sm-6">
                                <label class="form-label text-secondary small fw-semibold">E-Mail</label>
                                <div class="form-control form-control-custom bg-dark text-white border-0 py-2.5 px-3 rounded-3">
                                    <?php echo htmlspecialchars($guru['email'] ?: '-'); ?>
                                </div>
                            </div>

                            <div class="col-12">
                                <label class="form-label text-secondary small fw-semibold">Alamat Rumah</label>
                                <div class="form-control form-control-custom bg-dark text-white border-0 py-2.5 px-3 rounded-3 text-wrap" style="height: auto;">
                                    <?php echo htmlspecialchars($guru['alamat'] ?: '-'); ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                <?php elseif ($active_tab === 'password'): ?>
                    <!-- TAB 2: GANTI PASSWORD -->
                    <h6 class="text-white fw-bold mb-3"><i class="fa-solid fa-shield-halved text-gold me-2"></i> Perbarui Keamanan Kata Sandi</h6>
                    
                    <form method="POST" action="?action=change_password" class="row g-3">
                        <input type="hidden" name="change_password" value="1">
                        
                        <div class="col-12">
                            <label for="old_password" class="form-label form-label-custom">Kata Sandi Lama</label>
                            <input type="password" name="old_password" id="old_password" class="form-control form-control-custom" placeholder="Masukkan kata sandi lama Anda" required>
                        </div>

                        <div class="col-12 col-sm-6">
                            <label for="new_password" class="form-label form-label-custom">Kata Sandi Baru</label>
                            <input type="password" name="new_password" id="new_password" class="form-control form-control-custom" placeholder="Minimal 6 karakter" required>
                        </div>

                        <div class="col-12 col-sm-6">
                            <label for="confirm_password" class="form-label form-label-custom">Konfirmasi Kata Sandi Baru</label>
                            <input type="password" name="confirm_password" id="confirm_password" class="form-control form-control-custom" placeholder="Ulangi kata sandi baru" required>
                        </div>

                        <div class="col-12 mt-4">
                            <button type="submit" class="btn btn-gold px-4 py-2"><i class="fa-solid fa-save me-1.5"></i> Perbarui Kata Sandi</button>
                        </div>
                    </form>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>

<!-- Extra styles for lists -->
<style>
.list-group-item-custom {
    background: rgba(255, 255, 255, 0.01) !important;
    border: 1px solid rgba(255, 255, 255, 0.05) !important;
    color: var(--text-secondary, #94a3b8) !important;
    font-size: 13.5px;
    font-weight: 600;
    transition: all 0.2s;
}
.list-group-item-custom:hover {
    background: rgba(212, 175, 55, 0.08) !important;
    color: #D4AF37 !important;
}
.list-group-item-custom.active {
    background: rgba(212, 175, 55, 0.12) !important;
    color: #D4AF37 !important;
    border-color: rgba(212, 175, 55, 0.3) !important;
}
</style>

<?php if (!empty($success)): ?>
<script>
Swal.fire({
    title: 'Sukses!',
    text: '<?php echo $success; ?>',
    icon: 'success',
    confirmButtonColor: '#D4AF37',
    confirmButtonText: 'OK'
});
</script>
<?php endif; ?>

<?php if (!empty($error)): ?>
<script>
Swal.fire({
    title: 'Gagal!',
    text: '<?php echo $error; ?>',
    icon: 'error',
    confirmButtonColor: '#d33',
    confirmButtonText: 'Coba Lagi'
});
</script>
<?php endif; ?>

<?php
require_once dirname(dirname(__DIR__)) . '/includes/footer.php';
?>
