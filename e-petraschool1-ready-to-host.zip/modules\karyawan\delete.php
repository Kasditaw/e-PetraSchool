<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\karyawan\delete.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    try {
        // Fetch details for logging
        $stmt = $pdo->prepare("SELECT nama FROM karyawan WHERE id = ?");
        $stmt->execute([$id]);
        $name = $stmt->fetchColumn();

        if ($name) {
            $delete_stmt = $pdo->prepare("DELETE FROM karyawan WHERE id = ?");
            $delete_stmt->execute([$id]);
            write_audit_log("Menghapus data karyawan: $name.");
        }
    } catch (Exception $e) {
        error_log("Failed to delete employee: " . $e->getMessage());
    }
}

header("Location: index.php");
exit;
?>
