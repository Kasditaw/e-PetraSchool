<?php
// c:\xampp\htdocs\e-petraschool1\modules\jurnal\print_detail.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';

// Enforce login
check_login();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

try {
    // Fetch settings
    $settings_stmt = $pdo->query("SELECT * FROM pengaturan_sistem");
    $settings_raw = $settings_stmt->fetchAll();
    $settings = [];
    foreach ($settings_raw as $s) {
        $settings[$s['nama_kunci']] = $s['nilai_kunci'];
    }

    // Fetch journal
    $jurnal_stmt = $pdo->prepare("SELECT j.*, g.nama_guru, g.nip, s.semester, t.tahun_ajaran 
                                  FROM jurnal_mengajar j
                                  JOIN guru g ON j.guru_id = g.id
                                  JOIN semester s ON j.semester_id = s.id
                                  JOIN tahun_ajaran t ON j.tahun_ajaran_id = t.id
                                  WHERE j.id = ?");
    $jurnal_stmt->execute([$id]);
    $jurnal = $jurnal_stmt->fetch();

    if (!$jurnal) {
        die("Jurnal mengajar tidak ditemukan!");
    }

    // Role verification: Guru can only print their own
    if (has_role('Guru') && $jurnal['guru_id'] != $_SESSION['guru_id']) {
        die("Akses ditolak! Anda hanya dapat mencetak jurnal Anda sendiri.");
    }

    // Fetch details
    $details_stmt = $pdo->prepare("SELECT d.*, m.nama_mapel, m.kode_mapel, k.nama_kelas 
                                  FROM jurnal_mengajar_detail d
                                  LEFT JOIN mata_pelajaran m ON d.mapel_id = m.id
                                  LEFT JOIN kelas k ON d.kelas_id = k.id
                                  WHERE d.jurnal_id = ?
                                  ORDER BY d.jam_ke ASC");
    $details_stmt->execute([$id]);
    $details = $details_stmt->fetchAll();

    // Fetch verification
    $ver_stmt = $pdo->prepare("SELECT v.*, u.nama as nama_verifikator 
                               FROM verifikasi_jurnal v 
                               LEFT JOIN users u ON v.verifikator_id = u.id 
                               WHERE v.jurnal_id = ?");
    $ver_stmt->execute([$id]);
    $verification = $ver_stmt->fetch();

    // Dynamic base_url computation
    $project_dir = str_replace('\\', '/', dirname(dirname(__DIR__)));
    $web_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
    $base_url = str_replace($web_root, '', $project_dir);
    if (empty($base_url)) {
        $base_url = '/';
    } else {
        if (substr($base_url, 0, 1) !== '/') {
            $base_url = '/' . $base_url;
        }
        if (substr($base_url, -1) !== '/') {
            $base_url .= '/';
        }
    }
    $base_url = str_replace('//', '/', $base_url);

    // Left logo: Tut Wuri Handayani
    $left_logo_file = dirname(dirname(__DIR__)) . '/assets/images/tut_wuri.png';
    if (file_exists($left_logo_file)) {
        $left_logo_data = base64_encode(file_get_contents($left_logo_file));
        $left_logo_src = 'data:image/png;base64,' . $left_logo_data;
    } else {
        $left_logo_src = 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Logo-Tut-Wuri-Handayani-PNG-Warna.png/120px-Logo-Tut-Wuri-Handayani-PNG-Warna.png';
    }

    // Right logo: Petra School Logo
    $right_logo_file = dirname(dirname(__DIR__)) . '/assets/images/logo.png';
    if (file_exists($right_logo_file)) {
        $right_logo_data = base64_encode(file_get_contents($right_logo_file));
        $right_logo_src = 'data:image/png;base64,' . $right_logo_data;
    } else {
        $right_logo_src = $base_url . 'assets/images/logo.png';
    }

    // Class Formatting Helper Function
    function formatKelas($kelas_name) {
        $name = preg_replace('/^Kelas\s+/i', '', trim($kelas_name));
        $name = preg_replace('/\s+/', '-', $name);
        
        if (preg_match('/^(\d+)[-]?([A-Z]?)$/i', $name, $matches)) {
            $num = intval($matches[1]);
            $letter = $matches[2];
            $romans = [1 => 'I', 2 => 'II', 3 => 'III', 4 => 'IV', 5 => 'V', 6 => 'VI'];
            $roman_num = $romans[$num] ?? $num;
            return $roman_num . ($letter !== '' ? '-' . strtoupper($letter) : '');
        }
        return $name;
    }

    // Determine Kelas/Semester
    $kelas_val = '';
    if (preg_match('/(?:Guru Kelas|Wali Kelas)\s+([^\s]+)/i', $jurnal['jabatan'], $matches)) {
        $kelas_val = formatKelas($matches[1]);
    } else {
        foreach ($details as $d) {
            if (!empty($d['nama_kelas'])) {
                $kelas_val = formatKelas($d['nama_kelas']);
                break;
            }
        }
    }
    if (empty($kelas_val)) {
        $kelas_val = '-';
    }
    $kelas_semester = $kelas_val . '/' . $jurnal['semester'];

} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Jurnal Mengajar - <?php echo htmlspecialchars($jurnal['nama_guru']); ?> (<?php echo date('d-m-Y', strtotime($jurnal['tanggal'])); ?>)</title>
    <style>
        * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            background-color: #ffffff;
            color: #000000;
            margin: 0;
            padding: 20px;
            font-size: 13px;
            line-height: 1.3;
        }

        .print-container {
            max-width: 820px;
            margin: 0 auto;
            border: 1px solid #ddd;
            padding: 30px;
            background-color: #ffffff;
        }

        /* Kop Surat (Header) */
        .kop-surat {
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 5px double #000;
            padding-bottom: 8px;
            margin-bottom: 15px;
        }

        .kop-logo-left, .kop-logo-right {
            width: 75px;
            height: 75px;
            flex: 0 0 75px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .kop-logo-left img, .kop-logo-right img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }

        .kop-text {
            flex: 1 1 auto;
            min-width: 0;
            text-align: center;
            padding: 0 15px;
        }

        .kop-text .line-1 {
            font-size: 14px;
            font-weight: bold;
            margin: 0;
        }

        .kop-text .line-2 {
            font-size: 14px;
            font-weight: bold;
            margin: 1px 0;
        }

        .kop-text .line-3 {
            font-size: 18px;
            font-weight: bold;
            margin: 2px 0;
        }

        .kop-text .line-4 {
            font-size: 11px;
            margin: 1px 0;
        }

        .kop-text .line-5 {
            font-size: 11px;
            margin: 0;
        }

        /* Document Title */
        .doc-title {
            text-align: center;
            margin-top: 15px;
            margin-bottom: 20px;
        }

        .doc-title .main-title {
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .doc-title .sub-title {
            font-size: 14px;
            font-weight: bold;
            margin-top: 3px;
            text-transform: uppercase;
        }

        /* Identity Grid */
        .identity-table {
            width: 100%;
            margin-bottom: 15px;
            border-collapse: collapse;
        }

        .identity-table td {
            padding: 3px 0;
            vertical-align: top;
            font-size: 13px;
        }

        .identity-table td.label-col {
            width: 110px;
            color: #000;
        }

        .identity-table td.colon-col {
            width: 15px;
            text-align: center;
            color: #000;
        }

        .identity-table td.val-col {
            color: #000;
        }

        .identity-table td.label-col-right {
            width: 80px;
            padding-left: 40px;
            color: #000;
        }

        .identity-table td.colon-col-right {
            width: 15px;
            text-align: center;
            color: #000;
        }

        /* Activity Table */
        .activity-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 25px;
        }

        .activity-table th {
            background-color: #d2ebd4; /* Pastel green */
            border: 1px solid #000;
            padding: 8px 6px;
            font-size: 13px;
            font-weight: bold;
            text-align: center;
            color: #000;
        }

        .activity-table td {
            border: 1px solid #000;
            padding: 6px 8px;
            font-size: 12.5px;
            vertical-align: middle;
            color: #000;
        }

        .activity-table td.center {
            text-align: center;
        }

        .activity-table td.istirahat-row {
            background-color: #e2f0d9; /* Lighter pastel green */
            text-align: center;
            font-weight: bold;
            font-size: 12.5px;
            padding: 5px;
        }

        /* Signatures section */
        .signatures-container {
            display: flex;
            justify-content: space-between;
            margin-top: 30px;
            page-break-inside: avoid;
        }

        .sig-box {
            width: 250px;
            text-align: center;
        }

        .sig-title {
            margin-bottom: 8px;
            font-size: 13px;
        }

        .sig-image-area {
            height: 70px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 8px;
        }

        .sig-image-area img {
            max-height: 65px;
            max-width: 180px;
            object-fit: contain;
            filter: brightness(0);
        }

        .sig-name {
            font-weight: bold;
            text-decoration: underline;
            font-size: 13.5px;
        }

        .sig-nip {
            font-size: 12px;
            margin-top: 1px;
        }

        /* Floating print button */
        .btn-print-floating {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background-color: #D4AF37;
            color: #000;
            border: none;
            padding: 12px 24px;
            border-radius: 50px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
            display: flex;
            align-items: center;
            gap: 8px;
            transition: transform 0.2s, background-color 0.2s;
            z-index: 999;
        }

        .btn-print-floating:hover {
            background-color: #F3CD48;
            transform: scale(1.05);
        }

        @media print {
            @page {
                size: 215mm 330mm;
                margin: 0;
            }
            body {
                padding: 0;
                margin: 0 !important;
                background-color: #ffffff;
            }
            .print-container {
                border: none;
                box-shadow: none;
                padding: 12mm 15mm !important;
                width: 100% !important;
                max-width: 100% !important;
                box-sizing: border-box !important;
            }
            .btn-print-floating {
                display: none !important;
            }
        }
    </style>
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>

    <button onclick="window.print()" class="btn-print-floating">
        <i class="fa-solid fa-print"></i> Cetak Dokumen
    </button>

    <div class="print-container">
        <!-- Kop Surat -->
        <div class="kop-surat">
            <div class="kop-logo-left">
                <img src="<?php echo $left_logo_src; ?>" alt="Logo Kemdikbud">
            </div>
            <div class="kop-text">
                <div class="line-1">Kementerian Pendidikan Dasar dan Menengah</div>
                <div class="line-2">Dinas Pendidikan Kota Surabaya</div>
                <div class="line-3">SD Kristen Petra 1 Surabaya</div>
                <div class="line-4">Jalan WR. Supratman 46, Surabaya 60264</div>
                <div class="line-5">Telp. +6231 5678624 E-Mail: sd1@pppkpetra.sch.id</div>
            </div>
            <div class="kop-logo-right">
                <img src="<?php echo $right_logo_src; ?>" alt="Logo Petra">
            </div>
        </div>

        <!-- Title -->
        <div class="doc-title">
            <div class="main-title">Jurnal Mengajar Harian Guru</div>
            <div class="sub-title">Tahun Ajaran <?php echo htmlspecialchars($jurnal['tahun_ajaran']); ?></div>
        </div>

        <!-- Identity -->
        <table class="identity-table">
            <tr>
                <td class="label-col">Nama Guru</td>
                <td class="colon-col">:</td>
                <td class="val-col" style="font-weight: bold; text-transform: uppercase;"><?php echo htmlspecialchars($jurnal['nama_guru']); ?></td>
                
                <td class="label-col-right">Jabatan</td>
                <td class="colon-col-right">:</td>
                <td class="val-col"><?php echo htmlspecialchars($jurnal['jabatan']); ?></td>
            </tr>
            <tr>
                <td class="label-col">NIP</td>
                <td class="colon-col">:</td>
                <td class="val-col"><?php echo htmlspecialchars($jurnal['nip']); ?></td>

                <td class="label-col-right">Hari</td>
                <td class="colon-col-right">:</td>
                <td class="val-col"><?php echo htmlspecialchars($jurnal['hari']); ?></td>
            </tr>
            <tr>
                <td class="label-col">Kelas/Semester</td>
                <td class="colon-col">:</td>
                <td class="val-col"><?php echo htmlspecialchars($kelas_semester); ?></td>

                <td class="label-col-right">Tanggal</td>
                <td class="colon-col-right">:</td>
                <td class="val-col"><?php echo date('d/m/Y', strtotime($jurnal['tanggal'])); ?></td>
            </tr>
        </table>

        <!-- Activities Table -->
        <table class="activity-table">
            <thead>
                <tr>
                    <th style="width: 22%; text-align: left; padding-left: 10px;">Mata Pelajaran</th>
                    <th style="width: 8%; text-align: center;">Jam ke-</th>
                    <th style="width: 15%; text-align: center;">Waktu</th>
                    <th style="width: 20%; text-align: left; padding-left: 10px;">Materi</th>
                    <th style="width: 35%; text-align: left; padding-left: 10px;">Kegiatan Pembelajaran</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Map details by jam_ke
                $details_by_jam = [];
                foreach ($details as $d) {
                    $details_by_jam[$d['jam_ke']] = $d;
                }

                $schedule = [
                    0 => ['waktu' => '07.20 - 07.40'],
                    1 => ['waktu' => '07.40 - 08.15'],
                    2 => ['waktu' => '08.15 - 08.50'],
                    3 => ['waktu' => '08.50 - 09.25'],
                    'istirahat_1' => ['label' => 'Istirahat'],
                    4 => ['waktu' => '09.45 - 10.20'],
                    5 => ['waktu' => '10.20 - 10.55'],
                    6 => ['waktu' => '10.55 - 11.30'],
                    'istirahat_2' => ['label' => 'Istirahat'],
                    7 => ['waktu' => '11.50 - 12.25'],
                    8 => ['waktu' => '12.25 - 13.00'],
                    9 => ['waktu' => '13.00 - 13.30']
                ];

                foreach ($schedule as $jam => $slot) {
                    if (is_string($jam) && strpos($jam, 'istirahat') !== false) {
                        // Print Break Row
                        echo '<tr>';
                        echo '<td colspan="5" class="istirahat-row">' . $slot['label'] . '</td>';
                        echo '</tr>';
                    } else {
                        // Print hour row
                        $d = $details_by_jam[$jam] ?? null;
                        
                        $mapel = '';
                        $materi = '';
                        $kegiatan = '';

                        if ($d) {
                            $mapel = !empty($d['nama_mapel']) ? $d['nama_mapel'] : ($slot['default_mapel'] ?? '');
                            $materi = $d['materi'];
                            $kegiatan = $d['kegiatan'];
                        } else {
                            $mapel = $slot['default_mapel'] ?? '';
                            $materi = '';
                            $kegiatan = $slot['default_kegiatan'] ?? '';
                        }

                        echo '<tr>';
                        echo '<td>' . htmlspecialchars($mapel) . '</td>';
                        echo '<td class="center">' . $jam . '</td>';
                        echo '<td class="center">' . $slot['waktu'] . '</td>';
                        echo '<td>' . htmlspecialchars($materi) . '</td>';
                        echo '<td>' . htmlspecialchars($kegiatan) . '</td>';
                        echo '</tr>';
                    }
                }
                ?>
            </tbody>
        </table>

        <!-- Signatures -->
        <div class="signatures-container">
            <!-- Left Side: Guru -->
            <div class="sig-box">
                <div class="sig-title">Guru Kelas / Mapel,</div>
                <div class="sig-image-area">
                    <?php if (!empty($jurnal['tanda_tangan'])): ?>
                        <img src="<?php echo $jurnal['tanda_tangan']; ?>" alt="Tanda Tangan Guru">
                    <?php endif; ?>
                </div>
                <div class="sig-name"><?php echo htmlspecialchars($jurnal['nama_guru']); ?></div>
                <div class="sig-nip">NIP. <?php echo htmlspecialchars($jurnal['nip']); ?></div>
            </div>

            <!-- Right Side: Kepala Sekolah -->
            <div class="sig-box">
                <div class="sig-title">
                    Mengetahui,<br>
                    Kepala Sekolah / Verifikator
                </div>
                <div class="sig-image-area" style="height: 70px;">
                    <?php if ($verification && !empty($verification['tanda_tangan'])): ?>
                        <img src="<?php echo $verification['tanda_tangan']; ?>" alt="Tanda Tangan Verifikator">
                    <?php elseif ($verification): ?>
                        <span style="font-size: 11px; font-weight: bold; color: green; border: 2px solid green; padding: 5px 10px; border-radius: 4px; text-transform: uppercase; transform: rotate(-3deg); display: inline-block;">
                            <i class="fa-solid fa-circle-check"></i> VERIFIED
                        </span>
                    <?php else: ?>
                        <span style="font-size: 11px; font-weight: bold; color: #888; border: 2px dashed #888; padding: 5px 10px; border-radius: 4px; text-transform: uppercase; display: inline-block;">
                            PENDING VERIFICATION
                        </span>
                    <?php endif; ?>
                </div>
                <div class="sig-name"><?php echo htmlspecialchars($verification['nama_verifikator'] ?? 'Lilia, S.Pd., M.Psi.'); ?></div>
                <div class="sig-nip">
                    <?php if ($verification): ?>
                        Tanggal: <?php echo date('d-m-Y', strtotime($verification['tanggal_verifikasi'])); ?>
                    <?php else: ?>
                        Kepala Sekolah
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
