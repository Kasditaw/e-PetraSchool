<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\kelas\edit.php

$page_title = 'Edit Kelas';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';
$success = '';

// Load class data
try {
    $stmt = $pdo->prepare("SELECT * FROM kelas WHERE id = ?");
    $stmt->execute([$id]);
    $class = $stmt->fetch();
    
    if (!$class) {
        die('<div class="alert alert-danger">Data kelas tidak ditemukan!</div>');
    }
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

// Process update submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $kode_kelas = strtoupper(trim($_POST['kode_kelas'] ?? ''));
    $nama_kelas = trim($_POST['nama_kelas'] ?? '');
    $wali_kelas_id = $_POST['wali_kelas_id'] !== '' ? intval($_POST['wali_kelas_id']) : null;
    $lokasi_ruangan = trim($_POST['lokasi_ruangan'] ?? '');
    $tingkat = $_POST['tingkat'] ?? '1';
    $kapasitas = isset($_POST['kapasitas']) ? intval($_POST['kapasitas']) : 40;
    $status = $_POST['status'] ?? 'Aktif';

    if (empty($kode_kelas) || empty($nama_kelas) || empty($lokasi_ruangan)) {
        $error = 'Semua field wajib diisi!';
    } else {
        try {
            // Check if code already exists on other records
            $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM kelas WHERE kode_kelas = ? AND id != ?");
            $check_stmt->execute([$kode_kelas, $id]);
            if ($check_stmt->fetchColumn() > 0) {
                $error = "Kode kelas '$kode_kelas' sudah digunakan oleh kelas lain!";
            } else {
                // Update class
                $stmt = $pdo->prepare("UPDATE kelas SET kode_kelas = ?, nama_kelas = ?, wali_kelas_id = ?, lokasi_ruangan = ?, tingkat = ?, kapasitas = ?, status = ? WHERE id = ?");
                $stmt->execute([$kode_kelas, $nama_kelas, $wali_kelas_id, $lokasi_ruangan, $tingkat, $kapasitas, $status, $id]);
                
                write_audit_log("Mengubah data kelas: $nama_kelas (Kode: $kode_kelas, Tingkat: $tingkat, Kapasitas: $kapasitas, Status: $status).");
                
                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Data kelas berhasil diubah!', 'success').then(() => {
                            window.location.href = 'index.php';
                        });
                    });
                </script>";
            }
        } catch (Exception $e) {
            $error = 'Gagal menyimpan data: ' . $e->getMessage();
        }
    }
}

// Fetch all teachers for Wali Kelas dropdown
try {
    $teachers_stmt = $pdo->query("SELECT id, nip, nama_guru FROM guru ORDER BY nama_guru ASC");
    $teachers = $teachers_stmt->fetchAll();
} catch (Exception $e) {
    $teachers = [];
}
?>

<div class="glass-card" style="max-width: 600px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-pen-to-square me-2"></i> Edit Data Kelas</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="edit.php?id=<?php echo $id; ?>">
        <?php csrf_input(); ?>

        <div class="mb-3">
            <label for="kode_kelas" class="form-label form-label-custom">Kode Kelas</label>
            <input type="text" name="kode_kelas" id="kode_kelas" class="form-control form-control-custom" placeholder="Contoh: K4A" value="<?php echo htmlspecialchars($class['kode_kelas']); ?>" required>
        </div>

        <div class="mb-3">
            <label for="nama_kelas" class="form-label form-label-custom">Nama Kelas</label>
            <input type="text" name="nama_kelas" id="nama_kelas" class="form-control form-control-custom" placeholder="Contoh: Kelas 4A" value="<?php echo htmlspecialchars($class['nama_kelas']); ?>" required>
        </div>

        <div class="mb-3">
            <label for="tingkat" class="form-label form-label-custom">Tingkat</label>
            <select name="tingkat" id="tingkat" class="form-select form-control-custom bg-dark-select text-white" required>
                <?php for($t = 1; $t <= 6; $t++): ?>
                    <option value="<?php echo $t; ?>" <?php echo $class['tingkat'] == $t ? 'selected' : ''; ?>>Kelas <?php echo $t; ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="wali_kelas_id" class="form-label form-label-custom">Guru Kelas / Wali Kelas</label>
            <select name="wali_kelas_id" id="wali_kelas_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Pilih Guru Kelas / Wali Kelas (Opsional)...</option>
                <?php foreach ($teachers as $teacher): ?>
                    <option value="<?php echo $teacher['id']; ?>" <?php echo $class['wali_kelas_id'] == $teacher['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($teacher['nama_guru']) . ' (' . htmlspecialchars($teacher['nip']) . ')'; ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="kapasitas" class="form-label form-label-custom">Kapasitas</label>
            <input type="number" name="kapasitas" id="kapasitas" class="form-control form-control-custom" placeholder="Contoh: 40" value="<?php echo htmlspecialchars($class['kapasitas']); ?>" required>
        </div>

        <div class="mb-3">
            <label for="status" class="form-label form-label-custom">Status</label>
            <select name="status" id="status" class="form-select form-control-custom bg-dark-select text-white" required>
                <option value="Aktif" <?php echo $class['status'] === 'Aktif' ? 'selected' : ''; ?>>Aktif</option>
                <option value="Nonaktif" <?php echo $class['status'] === 'Nonaktif' ? 'selected' : ''; ?>>Nonaktif</option>
            </select>
        </div>

        <div class="mb-4">
            <label for="lokasi_ruangan" class="form-label form-label-custom">Lokasi Ruangan</label>
            <input type="text" name="lokasi_ruangan" id="lokasi_ruangan" class="form-control form-control-custom" placeholder="Contoh: Gedung B Lantai 2 R.202" value="<?php echo htmlspecialchars($class['lokasi_ruangan']); ?>" required>
        </div>

        <div class="d-flex justify-content-end gap-2">
            <a href="index.php" class="btn btn-outline-custom">Batal</a>
            <button type="submit" class="btn btn-gold">Simpan Perubahan <i class="fa-solid fa-check ms-1"></i></button>
        </div>
    </form>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
