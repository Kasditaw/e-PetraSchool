<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\siswa\create.php

$page_title = 'Tambah Siswa';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';

// Process form submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $nis = trim($_POST['nis'] ?? '');
    $nisn = trim($_POST['nisn'] ?? '');
    $student_code = trim($_POST['student_code'] ?? '');
    $nama_lengkap = trim($_POST['nama_lengkap'] ?? '');
    $gender = $_POST['gender'] ?? '';
    $asal_sekolah = trim($_POST['asal_sekolah'] ?? '');
    $nik = trim($_POST['nik'] ?? '');
    $tempat_lahir = trim($_POST['tempat_lahir'] ?? '');
    $tanggal_lahir = $_POST['tanggal_lahir'] ?? '';
    $agama = $_POST['agama'] ?? '';
    $alamat = trim($_POST['alamat'] ?? '');
    $alamat_kk = trim($_POST['alamat_kk'] ?? '');
    $no_hp_ortu = trim($_POST['no_hp_ortu'] ?? '');
    $nama_ayah = trim($_POST['nama_ayah'] ?? '');
    $nama_ibu = trim($_POST['nama_ibu'] ?? '');
    $pekerjaan_ayah = trim($_POST['pekerjaan_ayah'] ?? '');
    $pekerjaan_ibu = trim($_POST['pekerjaan_ibu'] ?? '');
    $kelas_id = $_POST['kelas_id'] !== '' ? intval($_POST['kelas_id']) : null;
    $tahun_masuk = intval($_POST['tahun_masuk'] ?? date('Y'));
    $status_siswa = $_POST['status_siswa'] ?? 'Aktif';
    
    // File upload handling
    $foto_name = null;
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['foto']['tmp_name'];
        $file_name = $_FILES['foto']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        // Validate MIME type & extension
        $allowed_exts = ['jpg', 'jpeg', 'png'];
        $mime_type = mime_content_type($file_tmp);
        $allowed_mimes = ['image/jpeg', 'image/png', 'image/pjpeg'];
        
        if (in_array($file_ext, $allowed_exts) && in_array($mime_type, $allowed_mimes)) {
            // Ensure uploads directory exists
            $upload_dir = dirname(dirname(__DIR__)) . '/assets/uploads/siswa/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            // Clean up name
            $foto_name = 'student_' . $nis . '_' . time() . '.' . $file_ext;
            if (move_uploaded_file($file_tmp, $upload_dir . $foto_name)) {
                // Upload successful
            } else {
                $error = 'Gagal memindahkan file foto yang diunggah.';
            }
        } else {
            $error = 'Format foto tidak valid. Hanya menerima format JPG, JPEG, dan PNG.';
        }
    }

    if ($error === '') {
        if (empty($nis) || empty($nisn) || empty($nama_lengkap) || empty($gender) || empty($agama) || empty($no_hp_ortu)) {
            $error = 'Field NIS, NISN, Nama, Gender, Agama, dan No HP wajib diisi!';
        } else {
            try {
                // Check duplicate NIS
                $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM siswa WHERE nis = ?");
                $check_stmt->execute([$nis]);
                if ($check_stmt->fetchColumn() > 0) {
                    $error = "NIS '$nis' sudah terdaftar!";
                } else {
                    // Check duplicate NISN
                    $check_stmt2 = $pdo->prepare("SELECT COUNT(*) FROM siswa WHERE nisn = ?");
                    $check_stmt2->execute([$nisn]);
                    if ($check_stmt2->fetchColumn() > 0) {
                        $error = "NISN '$nisn' sudah terdaftar!";
                    } else {
                        // Insert student record
                        $query = "INSERT INTO siswa (nis, nisn, student_code, nama_lengkap, gender, asal_sekolah, nik, tempat_lahir, tanggal_lahir, agama, alamat, alamat_kk, no_hp_ortu, nama_ayah, nama_ibu, pekerjaan_ayah, pekerjaan_ibu, kelas_id, tahun_masuk, status_siswa, foto) 
                                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                        $stmt = $pdo->prepare($query);
                        $stmt->execute([
                            $nis, $nisn, $student_code, $nama_lengkap, $gender, $asal_sekolah, $nik, $tempat_lahir, $tanggal_lahir, 
                            $agama, $alamat, $alamat_kk, $no_hp_ortu, $nama_ayah, $nama_ibu, 
                            $pekerjaan_ayah, $pekerjaan_ibu, $kelas_id, $tahun_masuk, $status_siswa, $foto_name
                        ]);

                        write_audit_log("Menambahkan data siswa baru: $nama_lengkap (NIS: $nis).");

                        echo "<script>
                            document.addEventListener('DOMContentLoaded', function() {
                                Swal.fire('Berhasil', 'Data siswa berhasil disimpan!', 'success').then(() => {
                                    window.location.href = 'index.php';
                                });
                            });
                        </script>";
                    }
                }
            } catch (Exception $e) {
                $error = 'Gagal menyimpan data ke database: ' . $e->getMessage();
            }
        }
    }
}

// Fetch classes for dropdown
try {
    $classes_stmt = $pdo->query("SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas ASC");
    $classes = $classes_stmt->fetchAll();
} catch (Exception $e) {
    $classes = [];
}
?>

<div class="glass-card" style="max-width: 800px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-user-plus me-2"></i> Tambah Data Siswa Baru</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="create.php" enctype="multipart/form-data">
        <?php csrf_input(); ?>

        <div class="row g-3">
            <div class="col-12 col-md-4">
                <label for="nis" class="form-label form-label-custom">No. Induk (NIS) <span class="text-danger">*</span></label>
                <input type="text" name="nis" id="nis" class="form-control form-control-custom" placeholder="Contoh: 202401" required>
            </div>
            
            <div class="col-12 col-md-4">
                <label for="nisn" class="form-label form-label-custom">NISN <span class="text-danger">*</span></label>
                <input type="text" name="nisn" id="nisn" class="form-control form-control-custom" placeholder="Contoh: 0134567891" required>
            </div>

            <div class="col-12 col-md-4">
                <label for="student_code" class="form-label form-label-custom">Student Code</label>
                <input type="text" name="student_code" id="student_code" class="form-control form-control-custom" placeholder="Contoh: STD-202401">
            </div>

            <div class="col-12 col-md-6">
                <label for="nama_lengkap" class="form-label form-label-custom">Nama Lengkap Siswa <span class="text-danger">*</span></label>
                <input type="text" name="nama_lengkap" id="nama_lengkap" class="form-control form-control-custom" placeholder="Nama lengkap siswa sesuai KK" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="nik" class="form-label form-label-custom">NIK (Nomor Induk Kependudukan)</label>
                <input type="text" name="nik" id="nik" class="form-control form-control-custom" placeholder="16 digit NIK siswa">
            </div>

            <div class="col-12 col-md-6">
                <label for="gender" class="form-label form-label-custom">Jenis Kelamin <span class="text-danger">*</span></label>
                <select name="gender" id="gender" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="" disabled selected>Pilih...</option>
                    <option value="L">Laki-laki</option>
                    <option value="P">Perempuan</option>
                </select>
            </div>

            <div class="col-12 col-md-6">
                <label for="asal_sekolah" class="form-label form-label-custom">Asal Sekolah (TK)</label>
                <input type="text" name="asal_sekolah" id="asal_sekolah" class="form-control form-control-custom" placeholder="Nama TK asal">
            </div>

            <div class="col-12 col-md-6">
                <label for="tempat_lahir" class="form-label form-label-custom">Tempat Lahir</label>
                <input type="text" name="tempat_lahir" id="tempat_lahir" class="form-control form-control-custom" placeholder="Kota kelahiran">
            </div>

            <div class="col-12 col-md-6">
                <label for="tanggal_lahir" class="form-label form-label-custom">Tanggal Lahir</label>
                <input type="date" name="tanggal_lahir" id="tanggal_lahir" class="form-control form-control-custom">
            </div>

            <div class="col-12 col-md-6">
                <label for="agama" class="form-label form-label-custom">Agama <span class="text-danger">*</span></label>
                <select name="agama" id="agama" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="" disabled selected>Pilih...</option>
                    <option value="Kristen">Kristen</option>
                    <option value="Katolik">Katolik</option>
                    <option value="Islam">Islam</option>
                    <option value="Hindu">Hindu</option>
                    <option value="Buddha">Buddha</option>
                    <option value="Konghucu">Konghucu</option>
                </select>
            </div>

            <div class="col-12 col-md-6">
                <label for="kelas_id" class="form-label form-label-custom">Kelas / Rombel</label>
                <select name="kelas_id" id="kelas_id" class="form-select form-control-custom bg-dark-select text-white">
                    <option value="">Pilih Kelas...</option>
                    <?php foreach ($classes as $cl): ?>
                        <option value="<?php echo $cl['id']; ?>"><?php echo htmlspecialchars($cl['nama_kelas']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-12 col-md-6">
                <label for="tahun_masuk" class="form-label form-label-custom">Tahun Masuk</label>
                <input type="number" name="tahun_masuk" id="tahun_masuk" class="form-control form-control-custom" value="<?php echo date('Y'); ?>">
            </div>

            <div class="col-12 col-md-6">
                <label for="status_siswa" class="form-label form-label-custom">Status Siswa</label>
                <select name="status_siswa" id="status_siswa" class="form-select form-control-custom bg-dark-select text-white">
                    <option value="Aktif" selected>Aktif</option>
                    <option value="Alumni">Alumni / Lulus</option>
                    <option value="Pindahan">Pindahan</option>
                    <option value="Keluar">Keluar / Mutasi</option>
                </select>
            </div>

            <div class="col-12 col-md-6">
                <label for="alamat" class="form-label form-label-custom">Alamat Domisili Lengkap</label>
                <textarea name="alamat" id="alamat" class="form-control form-control-custom" rows="2" placeholder="Tulis alamat rumah siswa saat ini"></textarea>
            </div>

            <div class="col-12 col-md-6">
                <label for="alamat_kk" class="form-label form-label-custom">Alamat Kartu Keluarga (KK)</label>
                <textarea name="alamat_kk" id="alamat_kk" class="form-control form-control-custom" rows="2" placeholder="Tulis alamat sesuai KK"></textarea>
            </div>

            <div class="col-12 col-md-6">
                <label for="no_hp_ortu" class="form-label form-label-custom">No HP Orang Tua <span class="text-danger">*</span></label>
                <input type="text" name="no_hp_ortu" id="no_hp_ortu" class="form-control form-control-custom" placeholder="Contoh: 08123456789" required>
            </div>

            <div class="col-12 col-md-6">
                <label for="foto" class="form-label form-label-custom">Foto Profil Siswa</label>
                <input type="file" name="foto" id="foto" class="form-control form-control-custom" accept="image/*">
                <span class="text-secondary" style="font-size: 10px;">Format: JPG, JPEG, PNG (Maksimal 2MB).</span>
            </div>

            <div class="col-12 mt-4">
                <h6 class="text-gold border-bottom border-secondary border-opacity-25 pb-2 mb-3"><i class="fa-solid fa-users me-2"></i> Data Orang Tua / Wali</h6>
            </div>

            <div class="col-12 col-md-6">
                <label for="nama_ayah" class="form-label form-label-custom">Nama Ayah</label>
                <input type="text" name="nama_ayah" id="nama_ayah" class="form-control form-control-custom" placeholder="Nama lengkap ayah kandung">
            </div>

            <div class="col-12 col-md-6">
                <label for="pekerjaan_ayah" class="form-label form-label-custom">Pekerjaan Ayah</label>
                <input type="text" name="pekerjaan_ayah" id="pekerjaan_ayah" class="form-control form-control-custom" placeholder="Pekerjaan ayah">
            </div>

            <div class="col-12 col-md-6">
                <label for="nama_ibu" class="form-label form-label-custom">Nama Ibu</label>
                <input type="text" name="nama_ibu" id="nama_ibu" class="form-control form-control-custom" placeholder="Nama lengkap ibu kandung">
            </div>

            <div class="col-12 col-md-6">
                <label for="pekerjaan_ibu" class="form-label form-label-custom">Pekerjaan Ibu</label>
                <input type="text" name="pekerjaan_ibu" id="pekerjaan_ibu" class="form-control form-control-custom" placeholder="Pekerjaan ibu">
            </div>

            <div class="col-12 d-flex justify-content-end gap-2 mt-4">
                <a href="index.php" class="btn btn-outline-custom">Batal</a>
                <button type="submit" class="btn btn-gold">Simpan Data Siswa <i class="fa-solid fa-check ms-1"></i></button>
            </div>
        </div>
    </form>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
