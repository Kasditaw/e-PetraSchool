<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\ruangan\create.php

$page_title = 'Tambah Ruangan';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $kode_ruangan = strtoupper(trim($_POST['kode_ruangan'] ?? ''));
    $nama_ruangan = trim($_POST['nama_ruangan'] ?? '');
    $lantai = trim($_POST['lantai'] ?? '');
    $kapasitas = intval($_POST['kapasitas'] ?? 0);
    $kondisi = $_POST['kondisi'] ?? 'Baik';
    $penanggung_jawab_id = $_POST['penanggung_jawab_id'] !== '' ? intval($_POST['penanggung_jawab_id']) : null;

    if (empty($kode_ruangan) || empty($nama_ruangan) || empty($lantai) || $kapasitas <= 0) {
        $error = 'Field Kode, Nama Ruangan, Lantai, dan Kapasitas wajib diisi!';
    } else {
        try {
            // Check duplicate code
            $chk = $pdo->prepare("SELECT COUNT(*) FROM ruangan WHERE kode_ruangan = ?");
            $chk->execute([$kode_ruangan]);
            if ($chk->fetchColumn() > 0) {
                $error = "Kode ruangan '$kode_ruangan' sudah terdaftar!";
            } else {
                // Insert ruangan
                $stmt = $pdo->prepare("INSERT INTO ruangan (kode_ruangan, nama_ruangan, lantai, kapasitas, kondisi, penanggung_jawab_id) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$kode_ruangan, $nama_ruangan, $lantai, $kapasitas, $kondisi, $penanggung_jawab_id]);
                
                write_audit_log("Menambahkan ruangan baru: $nama_ruangan (Kode: $kode_ruangan).");

                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Data ruangan berhasil disimpan!', 'success').then(() => {
                            window.location.href = 'index.php';
                        });
                    });
                </script>";
            }
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

// Fetch teachers for Supervisor dropdown
try {
    $teachers = $pdo->query("SELECT id, nip, nama_guru FROM guru ORDER BY nama_guru ASC")->fetchAll();
} catch (Exception $e) {
    $teachers = [];
}
?>

<div class="glass-card" style="max-width: 600px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-plus me-2"></i> Tambah Ruangan Baru</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="create.php">
        <?php csrf_input(); ?>

        <div class="mb-3">
            <label for="kode_ruangan" class="form-label form-label-custom">Kode Ruangan <span class="text-danger">*</span></label>
            <input type="text" name="kode_ruangan" id="kode_ruangan" class="form-control form-control-custom" placeholder="Contoh: R103 atau LAB-KOMP" required>
        </div>

        <div class="mb-3">
            <label for="nama_ruangan" class="form-label form-label-custom">Nama Ruangan <span class="text-danger">*</span></label>
            <input type="text" name="nama_ruangan" id="nama_ruangan" class="form-control form-control-custom" placeholder="Contoh: Ruang Kelas 3A atau Lab Bahasa" required>
        </div>

        <div class="row g-3 mb-3">
            <div class="col-6">
                <label for="lantai" class="form-label form-label-custom">Lantai <span class="text-danger">*</span></label>
                <input type="text" name="lantai" id="lantai" class="form-control form-control-custom" placeholder="Contoh: 1, 2, atau 3" required>
            </div>
            
            <div class="col-6">
                <label for="kapasitas" class="form-label form-label-custom">Kapasitas (Orang) <span class="text-danger">*</span></label>
                <input type="number" name="kapasitas" id="kapasitas" class="form-control form-control-custom" placeholder="Contoh: 36" required>
            </div>
        </div>

        <div class="mb-3">
            <label for="kondisi" class="form-label form-label-custom">Kondisi Ruangan</label>
            <select name="kondisi" id="kondisi" class="form-select form-control-custom bg-dark-select text-white">
                <option value="Baik" selected>Baik</option>
                <option value="Rusak Ringan">Rusak Ringan</option>
                <option value="Rusak Berat">Rusak Berat</option>
            </select>
        </div>

        <div class="mb-4">
            <label for="penanggung_jawab_id" class="form-label form-label-custom">Guru Penanggung Jawab</label>
            <select name="penanggung_jawab_id" id="penanggung_jawab_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Pilih Guru...</option>
                <?php foreach ($teachers as $tc): ?>
                    <option value="<?php echo $tc['id']; ?>"><?php echo htmlspecialchars($tc['nama_guru']) . ' (' . htmlspecialchars($tc['nip']) . ')'; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="d-flex justify-content-end gap-2">
            <a href="index.php" class="btn btn-outline-custom">Batal</a>
            <button type="submit" class="btn btn-gold">Simpan <i class="fa-solid fa-check ms-1"></i></button>
        </div>
    </form>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
