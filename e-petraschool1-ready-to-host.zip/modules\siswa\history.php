<?php
// c:\xampp\htdocs\e-petraschool1\modules\siswa\history.php

$page_title = 'Histori Kelas Siswa';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$siswa_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

try {
    // Fetch student profile details
    $siswa_stmt = $pdo->prepare("SELECT s.*, k.nama_kelas FROM siswa s LEFT JOIN kelas k ON s.kelas_id = k.id WHERE s.id = ?");
    $siswa_stmt->execute([$siswa_id]);
    $student = $siswa_stmt->fetch();

    if (!$student) {
        die('<div class="alert alert-danger">Siswa tidak ditemukan!</div>');
    }

    // Check authorization: Guru (Wali Kelas) can only view history of students who are or were in their class
    if (has_role('Guru')) {
        $my_guru_id = $_SESSION['guru_id'] ?? 0;
        
        // Check current class wali
        $check_curr = $pdo->prepare("SELECT COUNT(*) FROM siswa s JOIN kelas k ON s.kelas_id = k.id WHERE s.id = ? AND k.wali_kelas_id = ?");
        $check_curr->execute([$siswa_id, $my_guru_id]);
        $is_curr_wali = intval($check_curr->fetchColumn()) > 0;

        // Check past class histories
        $check_past = $pdo->prepare("SELECT COUNT(*) FROM riwayat_kelas r JOIN kelas k ON r.kelas_id = k.id WHERE r.siswa_id = ? AND k.wali_kelas_id = ?");
        $check_past->execute([$siswa_id, $my_guru_id]);
        $is_past_wali = intval($check_past->fetchColumn()) > 0;

        if (!$is_curr_wali && !$is_past_wali) {
            write_audit_log("Mencoba mengakses riwayat kelas siswa di luar wewenang wali kelas (ID Siswa: $siswa_id).");
            echo "<div class='glass-card text-center py-5'>
                <i class='fa-solid fa-circle-exclamation text-danger mb-3' style='font-size: 48px;'></i>
                <h5 class='text-white fw-bold'>Akses Ditolak</h5>
                <p class='text-secondary small'>Anda hanya dapat melihat riwayat kelas siswa yang terdaftar di kelas Anda.</p>
                <a href='index.php' class='btn btn-gold btn-sm mt-3'>Kembali</a>
            </div>";
            require_once dirname(dirname(__DIR__)) . '/includes/footer.php';
            exit;
        }
    }

    // Fetch student class histories
    $history_stmt = $pdo->prepare("
        SELECT r.*, k.nama_kelas, t.tahun_ajaran, g.nama_guru 
        FROM riwayat_kelas r
        JOIN kelas k ON r.kelas_id = k.id
        JOIN tahun_ajaran t ON r.tahun_ajaran_id = t.id
        LEFT JOIN guru g ON k.wali_kelas_id = g.id
        WHERE r.siswa_id = ?
        ORDER BY t.tahun_ajaran DESC
    ");
    $history_stmt->execute([$siswa_id]);
    $histories = $history_stmt->fetchAll();

    // Fetch student grade history from raport_siswa
    $hist_grades_stmt = $pdo->prepare("
        SELECT r.*, k.nama_kelas
        FROM raport_siswa r
        JOIN kelas k ON r.kelas_id = k.id
        WHERE r.siswa_id = ?
        ORDER BY r.tahun_ajaran DESC, r.semester ASC
    ");
    $hist_grades_stmt->execute([$siswa_id]);
    $hist_grades_rows = $hist_grades_stmt->fetchAll();

    // Group by tahun_ajaran => [ semester => data ]
    $hist_grades_by_ta = [];
    foreach ($hist_grades_rows as $row) {
        $ta = $row['tahun_ajaran'];
        $sem = $row['semester'];
        $hist_grades_by_ta[$ta][$sem] = [
            'nama_kelas'  => $row['nama_kelas'],
            'grades'      => json_decode($row['academic_grades'], true) ?: [],
            'ekskul'      => json_decode($row['ekstrakurikuler'], true) ?: [],
            'kokurikuler' => $row['kokurikuler_deskripsi'],
            'sakit'       => $row['sakit'],
            'izin'        => $row['izin'],
            'alpa'        => $row['alpa']
        ];
    }
    krsort($hist_grades_by_ta);

    // Log detail viewing
    write_audit_log("Melihat riwayat kelas siswa: {$student['nama_lengkap']} (NIS: {$student['nis']}).");

} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}
?>

<div class="glass-card mb-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-clock-rotate-left me-2"></i> Histori Kelas Siswa</h5>
            <p class="text-secondary small mb-0">Riwayat penempatan kelas siswa dari tahun ke tahun di SD Kristen Petra 1.</p>
        </div>
        <div class="d-flex gap-2 no-print">
            <a href="index.php" class="btn btn-outline-custom"><i class="fa-solid fa-arrow-left"></i> Kembali</a>
            <a href="../laporan/export.php?type=histori_siswa&siswa_id=<?php echo $siswa_id; ?>" class="btn btn-outline-custom"><i class="fa-solid fa-file-excel"></i> Export Excel</a>
            <a href="../laporan/print.php?type=histori_siswa&siswa_id=<?php echo $siswa_id; ?>" target="_blank" class="btn btn-gold"><i class="fa-solid fa-print"></i> Cetak Histori</a>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Student Profile summary -->
    <div class="col-lg-4">
        <div class="glass-card text-center py-4">
            <?php 
                $foto_url = !empty($student['foto']) ? $base_url . 'assets/uploads/siswa/' . $student['foto'] : 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150&q=80';
            ?>
            <img src="<?php echo $foto_url; ?>" alt="Foto" class="rounded-circle border mb-3 shadow-sm" style="width: 110px; height: 110px; object-fit: cover;">
            <h5 class="text-white fw-bold mb-1"><?php echo htmlspecialchars($student['nama_lengkap']); ?></h5>
            <p class="text-secondary small mb-3">NIS: <?php echo htmlspecialchars($student['nis']); ?> | NISN: <?php echo htmlspecialchars($student['nisn']); ?></p>
            
            <hr class="border-secondary border-opacity-25 my-3">
            
            <div class="text-start px-2" style="font-size: 13px;">
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-secondary">Gender</span>
                    <span class="text-white fw-semibold"><?php echo $student['gender'] === 'L' ? 'Laki-laki' : 'Perempuan'; ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-secondary">Agama</span>
                    <span class="text-white fw-semibold"><?php echo htmlspecialchars($student['agama']); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-secondary">Kelas Sekarang</span>
                    <span class="text-gold fw-bold"><?php echo htmlspecialchars($student['nama_kelas'] ?? 'Tanpa Kelas'); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span class="text-secondary">Status Siswa</span>
                    <span class="badge <?php echo $student['status_siswa'] === 'Aktif' ? 'badge-success' : 'badge-danger'; ?>"><?php echo htmlspecialchars($student['status_siswa']); ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- History Timeline Table -->
    <div class="col-lg-8">
        <div class="glass-card">
            <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-timeline me-2"></i> Rekam Jejak Rombongan Belajar</h5>
            
            <div class="table-responsive">
                <table class="table table-custom">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tahun Ajaran</th>
                            <th>Kelas</th>
                            <th>Guru Kelas / Wali Kelas</th>
                            <th>Tanggal Masuk</th>
                            <th>Status Histori</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($histories) > 0): ?>
                            <?php $no = 1; foreach ($histories as $hist): ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td class="fw-bold text-white"><?php echo htmlspecialchars($hist['tahun_ajaran']); ?></td>
                                    <td>
                                        <span class="badge badge-secondary"><?php echo htmlspecialchars($hist['nama_kelas']); ?></span>
                                    </td>
                                    <td class="text-white"><?php echo $hist['nama_guru'] ? htmlspecialchars($hist['nama_guru']) : '<span class="text-secondary small">Belum Ditentukan</span>'; ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($hist['tanggal_masuk'])); ?></td>
                                    <td>
                                        <?php
                                            $badge_class = 'badge-secondary';
                                            if ($hist['status'] === 'Aktif') $badge_class = 'badge-success';
                                            elseif ($hist['status'] === 'Pindahan') $badge_class = 'badge-warning';
                                            elseif ($hist['status'] === 'Lulus') $badge_class = 'badge-info';
                                            elseif ($hist['status'] === 'Keluar') $badge_class = 'badge-danger';
                                        ?>
                                        <span class="badge <?php echo $badge_class; ?>"><?php echo htmlspecialchars($hist['status']); ?></span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-secondary py-4">Siswa ini belum memiliki data riwayat kelas.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
    /* Accordion premium theme integration */
    .accordion-custom .accordion-item {
        background: var(--bg-card) !important;
        border: 1px solid var(--border) !important;
        border-radius: var(--r-md) !important;
        margin-bottom: 12px;
        overflow: hidden;
    }
    .accordion-custom .accordion-button {
        background: rgba(98, 87, 222, 0.04) !important;
        color: var(--text-1) !important;
        font-weight: 600;
        border: none !important;
        box-shadow: none !important;
        padding: 14px 20px;
    }
    .accordion-custom .accordion-button:not(.collapsed) {
        background: var(--accent-dim) !important;
        color: var(--accent) !important;
        border-bottom: 1px solid var(--border) !important;
    }
    .accordion-custom .accordion-button::after {
        filter: invert(0.5);
    }
    body.dark-theme .accordion-custom .accordion-button::after {
        filter: invert(1);
    }
    .accordion-custom .accordion-body {
        background: transparent !important;
        color: var(--text-1) !important;
        padding: 20px;
    }
</style>

<!-- Academic Grades History Section -->
<div class="row g-4 mt-2">
    <div class="col-12">
        <div class="glass-card">
            <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-clock-rotate-left me-2"></i> Histori Nilai Akademik & Rapor</h5>

            <?php if (empty($hist_grades_by_ta)): ?>
                <div class="text-center py-5 text-secondary">
                    <i class="fa-solid fa-folder-open d-block mb-3" style="font-size: 3rem; opacity: 0.3;"></i>
                    <p class="mb-0 small">Belum ada data nilai/rapor yang tersimpan dari tahun ajaran sebelumnya.</p>
                </div>
            <?php else: ?>
                <div class="accordion accordion-custom" id="accordionHistoriNilai">
                    <?php 
                    $default_subjects = [
                        'Agama' => 'Pendidikan Agama',
                        'Pancasila' => 'Pancasila',
                        'Bahasa Indonesia' => 'Bahasa Indonesia',
                        'Matematika' => 'Matematika',
                        'IPAS' => 'IPAS',
                        'PJOK' => 'PJOK',
                        'Seni Budaya' => 'Seni Budaya',
                        'Bhs. Inggris' => 'Bhs. Inggris',
                        'Bhs. Jawa' => 'Bhs. Jawa',
                        'Bhs. Mandarin' => 'Bhs. Mandarin'
                    ];

                    $acc_idx = 0; 
                    foreach ($hist_grades_by_ta as $ta => $semesters): 
                        $acc_id = 'grade-hist-' . preg_replace('/[^a-z0-9]/i', '', $ta);
                        $is_open = $acc_idx === 0;
                    ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="hd-<?php echo $acc_id; ?>">
                                <button class="accordion-button <?php echo $is_open ? '' : 'collapsed'; ?>" 
                                        type="button" 
                                        data-bs-toggle="collapse" 
                                        data-bs-target="#cl-<?php echo $acc_id; ?>" 
                                        aria-expanded="<?php echo $is_open ? 'true' : 'false'; ?>" 
                                        aria-controls="cl-<?php echo $acc_id; ?>">
                                    <i class="fa-solid fa-graduation-cap me-2 text-gold"></i>
                                    Tahun Ajaran <?php echo htmlspecialchars($ta); ?>
                                    <?php 
                                    foreach ($semesters as $sem_num => $sdata) {
                                        $scores = array_filter(array_column($sdata['grades'], 'score'));
                                        $avg = count($scores) > 0 ? round(array_sum($scores) / count($scores), 1) : null;
                                        if ($avg !== null) {
                                            echo "<span class='ms-3 badge badge-success' style='font-size:10px;'>Sem $sem_num: Rata-rata $avg</span>";
                                        }
                                    }
                                    ?>
                                </button>
                            </h2>
                            <div id="cl-<?php echo $acc_id; ?>" 
                                 class="accordion-collapse collapse <?php echo $is_open ? 'show' : ''; ?>" 
                                 aria-labelledby="hd-<?php echo $acc_id; ?>" 
                                 data-bs-parent="#accordionHistoriNilai">
                                <div class="accordion-body">
                                    <?php
                                    // Collect all subjects in this TA across semesters
                                    $all_subjects_ta = [];
                                    foreach ($semesters as $sdata) {
                                        foreach (array_keys($sdata['grades']) as $sk) {
                                            $all_subjects_ta[$sk] = true;
                                        }
                                    }
                                    $all_subjects_ta = array_keys($all_subjects_ta);
                                    if (empty($all_subjects_ta)) {
                                        // Fallback to defaults
                                        $all_subjects_ta = array_keys($default_subjects);
                                    }
                                    ?>
                                    
                                    <div class="table-responsive">
                                        <table class="table table-custom text-white" style="font-size: 13px;">
                                            <thead>
                                                <tr>
                                                    <th style="padding: 10px; font-weight: 700; color: var(--accent);">Mata Pelajaran</th>
                                                    <?php foreach ($semesters as $sem_num => $sdata): ?>
                                                        <th colspan="2" style="text-align: center; font-weight: 700; color: var(--accent);">Semester <?php echo $sem_num; ?> (Kelas: <?php echo htmlspecialchars($sdata['nama_kelas']); ?>)</th>
                                                    <?php endforeach; ?>
                                                </tr>
                                                <tr>
                                                    <th style="font-size: 10px; color: var(--text-3); padding: 5px 10px;"></th>
                                                    <?php foreach ($semesters as $sem_num => $sdata): ?>
                                                        <th style="font-size: 10px; color: var(--text-3); text-align: center; padding: 5px 10px;">Nilai</th>
                                                        <th style="font-size: 10px; color: var(--text-3); padding: 5px 10px;">Capaian Tertinggi</th>
                                                    <?php endforeach; ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($all_subjects_ta as $subj): ?>
                                                    <tr>
                                                        <td class="fw-semibold text-white" style="padding: 10px; border-bottom: 1px solid var(--border);"><?php echo htmlspecialchars($default_subjects[$subj] ?? $subj); ?></td>
                                                        <?php foreach ($semesters as $sem_num => $sdata): ?>
                                                            <?php 
                                                            $g = $sdata['grades'][$subj] ?? []; 
                                                            $score = isset($g['score']) && $g['score'] !== '' ? floatval($g['score']) : null;
                                                            ?>
                                                            <td style="text-align: center; padding: 10px; border-bottom: 1px solid var(--border);">
                                                                <?php if ($score !== null): ?>
                                                                    <?php
                                                                    $color = $score >= 90 ? 'badge-success' : ($score >= 75 ? 'badge-secondary' : 'badge-warning');
                                                                    ?>
                                                                    <span class="badge <?php echo $color; ?>" style="font-size: 12px; font-weight: 700;"><?php echo number_format($score, 0); ?></span>
                                                                <?php else: ?>
                                                                    <span class="text-secondary">—</span>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td style="color: var(--text-2); font-size: 12px; max-width: 250px; padding: 10px; border-bottom: 1px solid var(--border);">
                                                                <?php echo htmlspecialchars($g['desc_max'] ?? '—'); ?>
                                                            </td>
                                                        <?php endforeach; ?>
                                                    </tr>
                                                <?php endforeach; ?>
                                                <!-- Row average -->
                                                <tr style="background: rgba(98, 87, 222, 0.05);">
                                                    <td class="fw-bold text-accent" style="padding: 10px;">📊 Rata-rata Akademik</td>
                                                    <?php foreach ($semesters as $sem_num => $sdata): ?>
                                                        <?php
                                                        $scores = array_filter(array_column($sdata['grades'], 'score'));
                                                        $avg = count($scores) > 0 ? round(array_sum($scores) / count($scores), 1) : null;
                                                        ?>
                                                        <td colspan="2" class="fw-bold text-accent" style="text-align: center; padding: 10px;">
                                                            <?php echo $avg !== null ? number_format($avg, 1) : '—'; ?>
                                                        </td>
                                                    <?php endforeach; ?>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <!-- Attendance and Extracurricular section -->
                                    <div class="row g-3 mt-3">
                                        <?php foreach ($semesters as $sem_num => $sdata): ?>
                                            <div class="col-12 col-md-6">
                                                <div class="glass-card mb-0 p-3" style="background: rgba(98, 87, 222, 0.02) !important; border-color: rgba(98, 87, 222, 0.08) !important;">
                                                    <div class="fw-bold text-accent mb-2" style="font-size: 11px; letter-spacing: 0.5px; text-transform: uppercase;">
                                                        Semester <?php echo $sem_num; ?> — Kehadiran & Ekskul
                                                    </div>
                                                    <div class="d-flex flex-wrap gap-3 mb-2 small" style="color: var(--text-2);">
                                                        <span>🤒 Sakit: <strong class="text-white"><?php echo intval($sdata['sakit']); ?> hr</strong></span>
                                                        <span>📋 Izin: <strong class="text-white"><?php echo intval($sdata['izin']); ?> hr</strong></span>
                                                        <span>❌ Alpa: <strong class="text-white"><?php echo intval($sdata['alpa']); ?> hr</strong></span>
                                                    </div>
                                                    <?php if (!empty($sdata['ekskul'])): ?>
                                                        <div class="d-flex flex-wrap gap-1 mt-2">
                                                            <?php foreach ($sdata['ekskul'] as $ek): ?>
                                                                <span class="badge badge-secondary" style="font-size: 10px; background: rgba(98, 87, 222, 0.08) !important; color: var(--accent) !important; border-color: rgba(98, 87, 222, 0.15) !important;">
                                                                    ⭐ <?php echo htmlspecialchars($ek['nama'] ?? $ek['name'] ?? ''); ?> (<?php echo htmlspecialchars($ek['predikat'] ?? $ek['predicate'] ?? $ek['grade'] ?? 'B'); ?>)
                                                                </span>
                                                            <?php endforeach; ?>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                    <?php $acc_idx++; endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
