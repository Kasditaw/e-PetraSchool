<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\config\audit.php

/**
 * Write a new entry in the audit log
 * @param string $activity The description of the activity
 * @param int|null $userId Optional user ID, falls back to session user_id
 * @param string|null $username Optional username, falls back to session username
 */
function write_audit_log($activity, $userId = null, $username = null) {
    global $pdo;

    // If PDO is not set globally, try to load it
    if (!isset($pdo)) {
        require_once __DIR__ . '/db.php';
    }

    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Resolve user details
    $user_id = $userId ?? ($_SESSION['user_id'] ?? null);
    $user_name = $username ?? ($_SESSION['username'] ?? 'Anonymous/Guest');
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

    try {
        $stmt = $pdo->prepare("INSERT INTO audit_log (user_id, username, aktivitas, ip_address) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user_id, $user_name, $activity, $ip_address]);
    } catch (Exception $e) {
        // Silently ignore log errors in production, or log to system error log
        error_log("Failed to write audit log: " . $e->getMessage());
    }
}
?>
