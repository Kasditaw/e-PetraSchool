<?php
// c:\xampp\htdocs\e-petraschool1\modules\spp\index.php

$page_title = 'SPP & Keuangan';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$filter_kelas = isset($_GET['kelas_id']) ? intval($_GET['kelas_id']) : 0;
$filter_bulan = isset($_GET['bulan'])    ? intval($_GET['bulan'])    : intval(date('m'));
$filter_tahun = isset($_GET['tahun'])    ? intval($_GET['tahun'])    : intval(date('Y'));
$filter_status= isset($_GET['status'])   ? trim($_GET['status'])     : '';

$bulan_names = ['','Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

try {
    $kelas_list = $pdo->query("SELECT id, nama_kelas FROM kelas WHERE status='Aktif' ORDER BY nama_kelas ASC")->fetchAll();
    if (!$filter_kelas && count($kelas_list) > 0) { $filter_kelas = $kelas_list[0]['id']; }

    $q = "SELECT t.*, s.nama_lengkap, s.nis, k.nama_kelas,
                 COALESCE((SELECT SUM(p.jumlah_bayar) FROM spp_pembayaran p WHERE p.tagihan_id = t.id),0) AS total_bayar
          FROM spp_tagihan t
          JOIN siswa s ON t.siswa_id = s.id
          LEFT JOIN kelas k ON t.kelas_id = k.id
          WHERE t.bulan = ? AND t.tahun = ?";
    $params = [$filter_bulan, $filter_tahun];
    if ($filter_kelas) { $q .= " AND t.kelas_id = ?"; $params[] = $filter_kelas; }
    if ($filter_status) { $q .= " AND t.status = ?"; $params[] = $filter_status; }
    $q .= " ORDER BY s.nama_lengkap ASC";
    $stmt = $pdo->prepare($q);
    $stmt->execute($params);
    $tagihan_list = $stmt->fetchAll();

    // Stats
    $total_tagihan = count($tagihan_list);
    $lunas  = count(array_filter($tagihan_list, fn($t)=>$t['status']==='Lunas'));
    $belum  = count(array_filter($tagihan_list, fn($t)=>$t['status']==='Belum Bayar'));
    $cicil  = count(array_filter($tagihan_list, fn($t)=>$t['status']==='Cicil'));
    $total_nominal = array_sum(array_column($tagihan_list,'nominal'));
    $total_terbayar= array_sum(array_column($tagihan_list,'total_bayar'));

} catch (Exception $e) {
    $tagihan_list = [];
    $error_db = $e->getMessage();
}

$status_colors = ['Lunas'=>'#10B981','Belum Bayar'=>'#EF4444','Cicil'=>'#F59E0B'];
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-money-bill-wave me-2"></i>SPP & Keuangan Siswa</h5>
            <p class="text-secondary small mb-0">Kelola tagihan dan pembayaran SPP per siswa — <?php echo $bulan_names[$filter_bulan]; ?> <?php echo $filter_tahun; ?></p>
        </div>
        <?php if (has_role(['Super Admin','Admin'])): ?>
        <div class="d-flex gap-2 flex-wrap">
            <a href="tagihan.php?kelas_id=<?php echo $filter_kelas; ?>&bulan=<?php echo $filter_bulan; ?>&tahun=<?php echo $filter_tahun; ?>" class="btn btn-gold">
                <i class="fa-solid fa-file-invoice-dollar me-1"></i> Buat Tagihan Massal
            </a>
            <a href="rekap.php?bulan=<?php echo $filter_bulan; ?>&tahun=<?php echo $filter_tahun; ?>" class="btn btn-outline-custom">
                <i class="fa-solid fa-table-list me-1"></i> Rekap Bulanan
            </a>
        </div>
        <?php endif; ?>
    </div>

    <?php if (isset($error_db)): ?>
        <div class="alert alert-danger">Tabel belum tersedia. Jalankan: <a href="<?php echo $base_url; ?>database/migrate_ekskul_spp.php" class="alert-link">migrate_ekskul_spp.php</a></div>
    <?php endif; ?>

    <!-- Stats Cards -->
    <?php if (!empty($tagihan_list)): ?>
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div style="background:rgba(212,175,55,.1);border:1px solid rgba(212,175,55,.2);border-radius:10px;padding:14px;text-align:center;">
                <div class="fw-bold text-gold" style="font-size:22px;"><?php echo $total_tagihan; ?></div>
                <div class="text-secondary small">Total Tagihan</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div style="background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.2);border-radius:10px;padding:14px;text-align:center;">
                <div class="fw-bold" style="font-size:22px;color:#10B981;"><?php echo $lunas; ?></div>
                <div class="text-secondary small">Lunas</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);border-radius:10px;padding:14px;text-align:center;">
                <div class="fw-bold" style="font-size:22px;color:#EF4444;"><?php echo $belum; ?></div>
                <div class="text-secondary small">Belum Bayar</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div style="background:rgba(245,158,11,.1);border:1px solid rgba(245,158,11,.2);border-radius:10px;padding:14px;text-align:center;">
                <div class="fw-bold" style="font-size:22px;color:#F59E0B;"><?php echo $cicil; ?></div>
                <div class="text-secondary small">Cicil</div>
            </div>
        </div>
    </div>
    <!-- Nominal -->
    <div class="row g-3 mb-4">
        <div class="col-6">
            <div style="background:rgba(255,255,255,.04);border-radius:10px;padding:14px;">
                <div class="text-secondary small">Total Tagihan (Nominal)</div>
                <div class="fw-bold text-white" style="font-size:18px;">Rp <?php echo number_format($total_nominal,0,',','.'); ?></div>
            </div>
        </div>
        <div class="col-6">
            <div style="background:rgba(16,185,129,.07);border-radius:10px;padding:14px;">
                <div class="text-secondary small">Total Terbayar</div>
                <div class="fw-bold" style="font-size:18px;color:#10B981;">Rp <?php echo number_format($total_terbayar,0,',','.'); ?></div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Filters -->
    <form method="GET" class="row g-3 mb-4 align-items-end">
        <div class="col-6 col-md-3">
            <label class="form-label form-label-custom">Kelas</label>
            <select name="kelas_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua Kelas</option>
                <?php foreach ($kelas_list as $kl): ?>
                    <option value="<?php echo $kl['id']; ?>" <?php echo $filter_kelas==$kl['id']?'selected':''; ?>><?php echo htmlspecialchars($kl['nama_kelas']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Bulan</label>
            <select name="bulan" class="form-select form-control-custom bg-dark-select text-white">
                <?php for ($m=1;$m<=12;$m++): ?><option value="<?php echo $m; ?>" <?php echo $filter_bulan==$m?'selected':''; ?>><?php echo $bulan_names[$m]; ?></option><?php endfor; ?>
            </select>
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Tahun</label>
            <input type="number" name="tahun" class="form-control form-control-custom" value="<?php echo $filter_tahun; ?>">
        </div>
        <div class="col-6 col-md-2">
            <label class="form-label form-label-custom">Status</label>
            <select name="status" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua</option>
                <option value="Lunas" <?php echo $filter_status==='Lunas'?'selected':''; ?>>Lunas</option>
                <option value="Belum Bayar" <?php echo $filter_status==='Belum Bayar'?'selected':''; ?>>Belum Bayar</option>
                <option value="Cicil" <?php echo $filter_status==='Cicil'?'selected':''; ?>>Cicil</option>
            </select>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom"><i class="fa-solid fa-filter me-1"></i> Filter</button>
        </div>
    </form>

    <?php if (empty($tagihan_list)): ?>
        <div class="text-center py-5">
            <i class="fa-solid fa-file-invoice-dollar" style="font-size:48px;color:rgba(255,255,255,.15);"></i>
            <p class="text-secondary mt-3">Belum ada tagihan SPP untuk periode ini.<br>
            <?php if (has_role(['Super Admin','Admin'])): ?><a href="tagihan.php?kelas_id=<?php echo $filter_kelas; ?>&bulan=<?php echo $filter_bulan; ?>&tahun=<?php echo $filter_tahun; ?>" class="text-gold">+ Buat tagihan massal</a><?php endif; ?></p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-custom" style="font-size:13px;">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Siswa</th>
                        <th>Kelas</th>
                        <th style="text-align:right;">Nominal</th>
                        <th style="text-align:right;">Terbayar</th>
                        <th style="text-align:right;">Sisa</th>
                        <th style="text-align:center;">Status</th>
                        <?php if (has_role(['Super Admin','Admin'])): ?><th class="no-print">Aksi</th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $no=1; foreach ($tagihan_list as $t):
                        $sisa = $t['nominal'] - $t['total_bayar'];
                        $sc = $status_colors[$t['status']] ?? '#94A3B8';
                    ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td>
                            <strong class="text-white"><?php echo htmlspecialchars($t['nama_lengkap']); ?></strong>
                            <div class="text-secondary font-monospace" style="font-size:10px;"><?php echo htmlspecialchars($t['nis']); ?></div>
                        </td>
                        <td style="font-size:12px;"><?php echo htmlspecialchars($t['nama_kelas'] ?? '-'); ?></td>
                        <td style="text-align:right; font-weight:600;">Rp <?php echo number_format($t['nominal'],0,',','.'); ?></td>
                        <td style="text-align:right; color:#10B981;">Rp <?php echo number_format($t['total_bayar'],0,',','.'); ?></td>
                        <td style="text-align:right; color:<?php echo $sisa>0?'#EF4444':'#10B981'; ?>;">Rp <?php echo number_format($sisa,0,',','.'); ?></td>
                        <td style="text-align:center;">
                            <span class="badge" style="background:<?php echo $sc; ?>22; color:<?php echo $sc; ?>; border:1px solid <?php echo $sc; ?>44; font-size:11px; padding:4px 10px;">
                                <?php echo $t['status']; ?>
                            </span>
                        </td>
                        <?php if (has_role(['Super Admin','Admin'])): ?>
                        <td class="no-print">
                            <?php if ($t['status'] !== 'Lunas'): ?>
                                <a href="bayar.php?id=<?php echo $t['id']; ?>" class="btn btn-xs btn-outline-custom text-gold"><i class="fa-solid fa-money-bill me-1"></i>Bayar</a>
                            <?php else: ?>
                                <span class="text-secondary" style="font-size:11px;"><i class="fa-solid fa-check me-1"></i>Lunas</span>
                            <?php endif; ?>
                        </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
