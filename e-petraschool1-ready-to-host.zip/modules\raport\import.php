<?php
// c:\xampp\htdocs\e-petraschool1\modules\raport\import.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';

// Get active semester and year
try {
    $active_sem_stmt = $pdo->query("SELECT semester FROM semester WHERE status = 'Aktif' LIMIT 1");
    $active_sem_db = $active_sem_stmt->fetchColumn();
    $active_sem = ($active_sem_db === 'Ganjil' || $active_sem_db === '1') ? '1' : '2';

    $active_ta_stmt = $pdo->query("SELECT tahun_ajaran FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1");
    $active_ta = $active_ta_stmt->fetchColumn() ?: '2025/2026';
} catch (Exception $e) {
    $active_sem = '1';
    $active_ta = '2025/2026';
}

$selected_sem = isset($_GET['semester']) ? $_GET['semester'] : $active_sem;
$selected_ta = $active_ta;

$default_subjects = [
    'Agama' => 'nilai_agama',
    'Pancasila' => 'nilai_pancasila',
    'Bahasa Indonesia' => 'nilai_bahasa_indonesia',
    'Matematika' => 'nilai_matematika',
    'IPAS' => 'nilai_ipas',
    'PJOK' => 'nilai_pjok',
    'Seni Budaya' => 'nilai_seni_budaya',
    'Bhs. Inggris' => 'nilai_bahasa_inggris',
    'Bhs. Jawa' => 'nilai_bahasa_jawa',
    'Bhs. Mandarin' => 'nilai_bahasa_mandarin'
];

// -----------------------------------------------------
// DOWNLOAD TEMPLATE ACTION
// -----------------------------------------------------
if (isset($_GET['action']) && $_GET['action'] === 'download_template') {
    $kelas_id = isset($_GET['kelas_id']) ? intval($_GET['kelas_id']) : 0;
    
    if ($kelas_id <= 0) {
        die("Silakan pilih kelas terlebih dahulu sebelum mengunduh template!");
    }
    
    try {
        // Fetch class name and tingkat
        $class_stmt = $pdo->prepare("SELECT nama_kelas, tingkat FROM kelas WHERE id = ? LIMIT 1");
        $class_stmt->execute([$kelas_id]);
        $class_row = $class_stmt->fetch(PDO::FETCH_ASSOC);
        $nama_kelas = $class_row['nama_kelas'] ?? 'Kelas';
        $tingkat = $class_row['tingkat'] ?? '';
        
        // Fetch active students in class
        $students_stmt = $pdo->prepare("SELECT s.id, s.nis, s.nisn, s.nama_lengkap, 
                                               r.no_absen, r.kode_siswa, r.academic_grades, 
                                               r.sakit, r.izin, r.alpa, r.catatan_wali, 
                                               r.kokurikuler_predikat, r.kokurikuler_deskripsi
                                        FROM siswa s
                                        LEFT JOIN raport_siswa r ON s.id = r.siswa_id AND r.semester = ? AND r.tahun_ajaran = ?
                                        WHERE s.kelas_id = ? AND s.status_siswa = 'Aktif'
                                        ORDER BY s.nama_lengkap ASC");
        $students_stmt->execute([$selected_sem, $selected_ta, $kelas_id]);
        $students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        die("Error database: " . $e->getMessage());
    }
    
    if (ob_get_level()) {
        ob_end_clean();
    }
    
    $filename = "template_rapor_" . str_replace(' ', '_', strtolower($nama_kelas)) . "_sem" . $selected_sem . ".csv";
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);
    
    $output = fopen('php://output', 'w');
    
    // Write CSV Headers
    $headers = [
        'siswa_id',
        'nis',
        'nisn',
        'nama_lengkap',
        'no_absen',
        'kode_siswa',
        'nilai_agama',
        'nilai_pancasila',
        'nilai_bahasa_indonesia',
        'nilai_matematika',
        'nilai_ipas',
        'nilai_pjok',
        'nilai_seni_budaya',
        'nilai_bahasa_inggris',
        'nilai_bahasa_jawa',
        'nilai_bahasa_mandarin',
        'sakit',
        'izin',
        'alpa',
        'catatan_wali',
        'kokurikuler_predikat',
        'kokurikuler_deskripsi'
    ];
    if ($tingkat === '1' || $tingkat === '2') {
        $key = array_search('nilai_ipas', $headers);
        if ($key !== false) {
            unset($headers[$key]);
            $headers = array_values($headers);
        }
    }
    fputcsv($output, $headers);
    
    // Write student records
    foreach ($students as $s) {
        $saved_grades = json_decode($s['academic_grades'] ?? '', true) ?: [];
        
        $row = [
            $s['id'],
            $s['nis'],
            $s['nisn'],
            $s['nama_lengkap'],
            $s['no_absen'] !== null ? $s['no_absen'] : '',
            $s['kode_siswa'] !== null ? $s['kode_siswa'] : '',
            $saved_grades['Agama']['score'] ?? '',
            $saved_grades['Pancasila']['score'] ?? '',
            $saved_grades['Bahasa Indonesia']['score'] ?? '',
            $saved_grades['Matematika']['score'] ?? '',
        ];
        if ($tingkat !== '1' && $tingkat !== '2') {
            $row[] = $saved_grades['IPAS']['score'] ?? '';
        }
        $row = array_merge($row, [
            $saved_grades['PJOK']['score'] ?? '',
            $saved_grades['Seni Budaya']['score'] ?? '',
            $saved_grades['Bhs. Inggris']['score'] ?? '',
            $saved_grades['Bhs. Jawa']['score'] ?? '',
            $saved_grades['Bhs. Mandarin']['score'] ?? '',
            $s['sakit'] !== null ? $s['sakit'] : '0',
            $s['izin'] !== null ? $s['izin'] : '0',
            $s['alpa'] !== null ? $s['alpa'] : '0',
            $s['catatan_wali'] !== null ? $s['catatan_wali'] : '',
            $s['kokurikuler_predikat'] !== null ? $s['kokurikuler_predikat'] : '',
            $s['kokurikuler_deskripsi'] !== null ? $s['kokurikuler_deskripsi'] : ''
        ]);
        fputcsv($output, $row);
    }
    
    fclose($output);
    exit;
}

// -----------------------------------------------------
// PROCESS UPLOAD/IMPORT
// -----------------------------------------------------
$page_title = 'Import Nilai Rapor';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin', 'Guru']);

$error = '';
$success = '';
$import_summary = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    check_csrf_request();
    
    $file_tmp = $_FILES['csv_file']['tmp_name'];
    $file_name = $_FILES['csv_file']['name'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    
    if ($file_ext !== 'csv') {
        $error = 'Hanya file format CSV yang diperbolehkan!';
    } else if ($_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        $error = 'Gagal mengunggah file. Kode error: ' . $_FILES['csv_file']['error'];
    } else {
        $success_count = 0;
        $failed_count = 0;
        $failures = [];
        
        if (($handle = fopen($file_tmp, 'r')) !== false) {
            // Read header row
            $headers = fgetcsv($handle, 1000, ',');
            
            // Map headers to column index positions
            $header_map = array_flip($headers);
            
            // Required columns check
            if (!isset($header_map['siswa_id']) || !isset($header_map['nama_lengkap'])) {
                $error = 'Format file CSV tidak valid! Kolom siswa_id dan nama_lengkap wajib ada.';
            } else {
                try {
                    $pdo->beginTransaction();
                    $row_index = 2; // Data row starts at index 2
                    
                    while (($row = fgetcsv($handle, 1000, ',')) !== false) {
                        // Skip empty rows
                        if (count($row) < 3 || empty(trim(implode('', $row)))) {
                            continue;
                        }
                        
                        $siswa_id = intval($row[$header_map['siswa_id']] ?? 0);
                        $nama_lengkap = trim($row[$header_map['nama_lengkap']] ?? '');
                        
                        if ($siswa_id <= 0) {
                            $failed_count++;
                            $failures[] = "Baris $row_index: ID siswa tidak valid.";
                            $row_index++;
                            continue;
                        }
                        
                        // Check if student exists and get class_id and tingkat
                        $student_stmt = $pdo->prepare("
                            SELECT s.id, s.kelas_id, k.tingkat 
                            FROM siswa s 
                            LEFT JOIN kelas k ON s.kelas_id = k.id 
                            WHERE s.id = ? AND s.status_siswa = 'Aktif' 
                            LIMIT 1
                        ");
                        $student_stmt->execute([$siswa_id]);
                        $student = $student_stmt->fetch();
                        
                        if (!$student) {
                            $failed_count++;
                            $failures[] = "Baris $row_index: Siswa dengan ID '$siswa_id' tidak ditemukan atau tidak aktif.";
                            $row_index++;
                            continue;
                        }
                        
                        $kelas_id = $student['kelas_id'];
                        $no_absen = isset($header_map['no_absen']) && trim($row[$header_map['no_absen']]) !== '' ? intval($row[$header_map['no_absen']]) : null;
                        $kode_siswa = isset($header_map['kode_siswa']) ? trim($row[$header_map['kode_siswa']]) : null;
                        $sakit = isset($header_map['sakit']) && trim($row[$header_map['sakit']]) !== '' ? intval($row[$header_map['sakit']]) : 0;
                        $izin = isset($header_map['izin']) && trim($row[$header_map['izin']]) !== '' ? intval($row[$header_map['izin']]) : 0;
                        $alpa = isset($header_map['alpa']) && trim($row[$header_map['alpa']]) !== '' ? intval($row[$header_map['alpa']]) : 0;
                        $catatan_wali = isset($header_map['catatan_wali']) ? trim($row[$header_map['catatan_wali']]) : null;
                        $kokurikuler_predikat = isset($header_map['kokurikuler_predikat']) ? trim($row[$header_map['kokurikuler_predikat']]) : null;
                        $kokurikuler_deskripsi = isset($header_map['kokurikuler_deskripsi']) ? trim($row[$header_map['kokurikuler_deskripsi']]) : null;
                        
                        // Fetch existing report to preserve academic grades descriptions
                        $raport_stmt = $pdo->prepare("SELECT * FROM raport_siswa WHERE siswa_id = ? AND semester = ? AND tahun_ajaran = ? LIMIT 1");
                        $raport_stmt->execute([$siswa_id, $selected_sem, $selected_ta]);
                        $existing_raport = $raport_stmt->fetch();
                        
                        $existing_grades = [];
                        if ($existing_raport) {
                            $existing_grades = json_decode($existing_raport['academic_grades'], true) ?: [];
                        }
                        
                        // Map academic grades
                        $new_grades = [];
                        $student_tingkat = $student['tingkat'] ?? '';
                        $subjects_to_map = $default_subjects;
                        if ($student_tingkat === '1' || $student_tingkat === '2') {
                            unset($subjects_to_map['IPAS']);
                        }
                        
                        foreach ($subjects_to_map as $key => $col_name) {
                            $score = null;
                            if (isset($header_map[$col_name]) && trim($row[$header_map[$col_name]]) !== '') {
                                $score = floatval($row[$header_map[$col_name]]);
                            }
                            
                            $new_grades[$key] = [
                                'score' => $score,
                                'desc_max' => $existing_grades[$key]['desc_max'] ?? '',
                                'desc_min' => $existing_grades[$key]['desc_min'] ?? ''
                            ];
                        }
                        $academic_grades_json = json_encode($new_grades, JSON_UNESCAPED_UNICODE);
                        
                        // Insert or Update Raport
                        if ($existing_raport) {
                            $save_stmt = $pdo->prepare("UPDATE raport_siswa 
                                                        SET no_absen = ?, kode_siswa = ?, academic_grades = ?, 
                                                            sakit = ?, izin = ?, alpa = ?, catatan_wali = ?, 
                                                            kokurikuler_predikat = ?, kokurikuler_deskripsi = ?, 
                                                            status_draft = 0 
                                                        WHERE id = ?");
                            $save_stmt->execute([
                                $no_absen, $kode_siswa, $academic_grades_json,
                                $sakit, $izin, $alpa, $catatan_wali,
                                $kokurikuler_predikat, $kokurikuler_deskripsi,
                                $existing_raport['id']
                            ]);
                        } else {
                            $save_stmt = $pdo->prepare("INSERT INTO raport_siswa 
                                                            (siswa_id, kelas_id, semester, tahun_ajaran, no_absen, kode_siswa, 
                                                             academic_grades, sakit, izin, alpa, catatan_wali, 
                                                             kokurikuler_predikat, kokurikuler_deskripsi, status_draft) 
                                                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)");
                            $save_stmt->execute([
                                $siswa_id, $kelas_id, $selected_sem, $selected_ta, $no_absen, $kode_siswa,
                                $academic_grades_json, $sakit, $izin, $alpa, $catatan_wali,
                                $kokurikuler_predikat, $kokurikuler_deskripsi
                            ]);
                        }
                        
                        $success_count++;
                        $row_index++;
                    }
                    
                    $pdo->commit();
                    write_audit_log("Import nilai rapor selesai. Sukses: $success_count, Gagal: $failed_count.");
                    
                    $import_summary = [
                        'success' => $success_count,
                        'failed' => $failed_count,
                        'failures' => $failures
                    ];
                    $success = "Proses import selesai. $success_count nilai siswa berhasil diimport/diperbarui, $failed_count gagal.";
                } catch (Exception $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    $error = 'Gagal memproses data database: ' . $e->getMessage();
                }
            }
            fclose($handle);
        } else {
            $error = 'Gagal membuka file CSV yang diunggah.';
        }
    }
}
?>

<div class="container-fluid px-4 py-2">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4 pb-3 border-b" style="border-color: var(--border-color) !important;">
        <div class="d-flex align-items-center gap-3">
            <div class="d-flex align-items-center justify-content-center shadow-md shadow-indigo-600/20" style="width: 40px; height: 40px; background-color: var(--color-gold) !important; border-radius: 8px;">
                <i class="fa-solid fa-file-excel text-white text-xl"></i>
            </div>
            <div>
                <h5 class="font-bold text-lg mb-0 font-sans tracking-wide" style="color: var(--text-primary) !important;">Import Nilai Rapor dari Excel/CSV</h5>
                <p class="text-xs mb-0" style="color: var(--text-secondary) !important;">Perbarui nilai capaian akademik siswa melalui berkas spreadsheet</p>
            </div>
        </div>
        <div>
            <a href="index.php?semester=<?php echo $selected_sem; ?>" class="btn btn-outline-secondary px-3 py-1.5 font-bold text-xs rounded-lg" style="color: var(--text-secondary) !important; border-color: var(--border-color) !important;">
                <i class="fa-solid fa-arrow-left me-1"></i> Kembali ke Rapor
            </a>
        </div>
    </div>

    <div class="raport-list-card" style="max-width: 800px; margin: 0 auto;">
        
        <?php if ($error !== ''): ?>
            <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
                <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <?php if ($success !== ''): ?>
            <div class="alert alert-success border-0 text-white bg-success bg-opacity-25 small mb-4 py-2" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i> <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>

        <div class="row g-4">
            <!-- Instruction panel -->
            <div class="col-12 col-md-5">
                <div class="card p-3 h-100 rounded-lg" style="background-color: var(--bg-card) !important; border: 1px solid var(--border-color) !important; color: var(--text-primary) !important;">
                    <h6 class="font-bold mb-3 text-xs" style="color: var(--color-gold) !important;"><i class="fa-solid fa-circle-info me-1"></i> Panduan Pengisian</h6>
                    <ol class="ps-3 mb-4 d-flex flex-column gap-2" style="color: var(--text-secondary) !important; font-size: 11px; line-height: 1.6;">
                        <li>Unduh template file melalui tombol di bawah list rapor kelas masing-masing.</li>
                        <li>Isi nilai subjek berupa angka (skala 0 - 100) pada kolom yang diawali <strong>nilai_</strong>.</li>
                        <li>Isi jumlah ketidakhadiran pada kolom <strong>sakit</strong>, <strong>izin</strong>, dan <strong>alpa</strong>.</li>
                        <li>Jangan mengubah struktur kolom atau memodifikasi nilai kolom <strong>siswa_id</strong>.</li>
                        <li>Simpan berkas Anda dalam format **CSV (Comma Delimited)** sebelum diunggah ke sistem.</li>
                    </ol>
                    <div class="mt-auto">
                        <span class="text-uppercase block mb-1.5 font-bold" style="color: var(--text-secondary) !important; font-size: 10px; opacity: 0.8;">Catatan Semester</span>
                        <span class="badge" style="background-color: rgba(59, 130, 246, 0.1); color: var(--color-gold); border: 1px solid rgba(59, 130, 246, 0.2); font-size: 11px; font-weight: 600; padding: 6px 12px; border-radius: 20px;">
                            Semester <?php echo $selected_sem; ?> (<?php echo htmlspecialchars($selected_ta); ?>)
                        </span>
                    </div>
                </div>
            </div>
            
            <!-- Upload form -->
            <div class="col-12 col-md-7">
                <div class="card p-3 h-100 rounded-lg" style="background-color: var(--bg-card) !important; border: 1px solid var(--border-color) !important; color: var(--text-primary) !important;">
                    <h6 class="font-bold mb-3 text-xs" style="color: var(--color-gold) !important;"><i class="fa-solid fa-cloud-arrow-up me-1"></i> Unggah File Nilai (CSV)</h6>
                    <form method="POST" action="import.php?semester=<?php echo $selected_sem; ?>" enctype="multipart/form-data">
                        <?php csrf_input(); ?>
                        
                        <div class="mb-4">
                            <label for="csv_file" class="form-label text-uppercase tracking-wider block mb-1.5" style="color: var(--text-secondary) !important; font-size: 10px; font-weight: 600;">Pilih File CSV (.csv)</label>
                            <input type="file" name="csv_file" id="csv_file" class="form-control" accept=".csv" required style="background-color: var(--bg-main) !important; border: 1px solid var(--border-color) !important; color: var(--text-primary) !important;">
                        </div>
                        
                        <button type="submit" class="btn btn-indigo w-100 py-2 font-bold text-xs rounded-lg"><i class="fa-solid fa-file-excel me-1"></i> Mulai Import Nilai</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Summary Report -->
        <?php if ($import_summary !== null): ?>
            <div class="mt-4 border-t pt-4" style="border-color: var(--border-color) !important;">
                <h6 class="font-bold mb-3 text-xs" style="color: var(--text-primary) !important;"><i class="fa-solid fa-square-poll-vertical me-1"></i> Ringkasan Hasil Import</h6>
                <div class="row g-2 mb-3 text-center">
                    <div class="col-6">
                        <div class="border rounded-lg p-2.5" style="background-color: rgba(16, 185, 129, 0.08); border-color: rgba(16, 185, 129, 0.15) !important;">
                            <span class="text-uppercase d-block font-semibold" style="color: var(--text-secondary) !important; font-size: 10px;">Berhasil Diimport</span>
                            <h4 class="fw-bold mb-0 text-sm" style="color: var(--color-success) !important;"><?php echo $import_summary['success']; ?> Siswa</h4>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="border rounded-lg p-2.5" style="background-color: rgba(239, 68, 68, 0.08); border-color: rgba(239, 68, 68, 0.15) !important;">
                            <span class="text-uppercase d-block font-semibold" style="color: var(--text-secondary) !important; font-size: 10px;">Gagal/Error</span>
                            <h4 class="fw-bold mb-0 text-sm" style="color: var(--color-danger) !important;"><?php echo $import_summary['failed']; ?> Siswa</h4>
                        </div>
                    </div>
                </div>

                <?php if (count($import_summary['failures']) > 0): ?>
                    <div class="card p-3 rounded-lg border" style="background-color: rgba(239, 68, 68, 0.05); border-color: rgba(239, 68, 68, 0.15) !important; color: var(--text-primary) !important;">
                        <span class="fw-bold text-xs d-block mb-2" style="color: var(--color-danger) !important;"><i class="fa-solid fa-triangle-exclamation me-1"></i> Rincian Masalah Baris:</span>
                        <div class="overflow-auto text-xs" style="max-height: 180px; color: var(--text-secondary) !important;">
                            <ul class="ps-3 mb-0 d-flex flex-column gap-1.5" style="line-height: 1.6;">
                                <?php foreach ($import_summary['failures'] as $fail): ?>
                                    <li><?php echo htmlspecialchars($fail); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
