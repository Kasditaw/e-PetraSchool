<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\nilai\delete.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_role(['Super Admin', 'Admin', 'Guru']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    try {
        // Fetch details for logging
        $stmt = $pdo->prepare("SELECT n.mata_pelajaran, s.nama_lengkap FROM nilai n JOIN siswa s ON n.siswa_id = s.id WHERE n.id = ?");
        $stmt->execute([$id]);
        $data = $stmt->fetch();

        if ($data) {
            $delete_stmt = $pdo->prepare("DELETE FROM nilai WHERE id = ?");
            $delete_stmt->execute([$id]);
            
            write_audit_log("Menghapus data nilai mapel " . $data['mata_pelajaran'] . " siswa: " . $data['nama_lengkap'] . ".");
        }
    } catch (Exception $e) {
        error_log("Failed to delete grade: " . $e->getMessage());
    }
}

header("Location: index.php");
exit;
?>
