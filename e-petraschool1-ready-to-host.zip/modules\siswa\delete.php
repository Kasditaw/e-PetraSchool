<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\siswa\delete.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    try {
        // Fetch student details for photo deletion and logging
        $stmt = $pdo->prepare("SELECT nama_lengkap, foto FROM siswa WHERE id = ?");
        $stmt->execute([$id]);
        $student = $stmt->fetch();

        if ($student) {
            // Delete photo if exists
            if (!empty($student['foto'])) {
                $upload_dir = dirname(dirname(__DIR__)) . '/assets/uploads/siswa/';
                if (file_exists($upload_dir . $student['foto'])) {
                    unlink($upload_dir . $student['foto']);
                }
            }

            // Delete student
            $delete_stmt = $pdo->prepare("DELETE FROM siswa WHERE id = ?");
            $delete_stmt->execute([$id]);
            
            write_audit_log("Menghapus data siswa: " . $student['nama_lengkap'] . ".");
        }
    } catch (Exception $e) {
        error_log("Failed to delete student: " . $e->getMessage());
    }
}

header("Location: index.php");
exit;
?>
