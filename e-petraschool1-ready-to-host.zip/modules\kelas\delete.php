<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\kelas\delete.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    try {
        // Fetch class details for log
        $stmt = $pdo->prepare("SELECT nama_kelas FROM kelas WHERE id = ?");
        $stmt->execute([$id]);
        $name = $stmt->fetchColumn();

        if ($name) {
            $delete_stmt = $pdo->prepare("DELETE FROM kelas WHERE id = ?");
            $delete_stmt->execute([$id]);
            write_audit_log("Menghapus data kelas: $name.");
        }
    } catch (Exception $e) {
        // Handle constraint violation error, etc.
        error_log("Failed to delete class: " . $e->getMessage());
    }
}

header("Location: index.php");
exit;
?>
