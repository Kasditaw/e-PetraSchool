<?php
// c:\xampp\htdocs\e-petraschool1\modules\laporan\get_kelas_raport.php
// AJAX endpoint: returns list of classes that have raport_siswa data
// for the given tahun_ajaran and/or semester

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
check_login();

header('Content-Type: application/json; charset=utf-8');

$tahun_ajaran = isset($_GET['tahun_ajaran']) ? trim($_GET['tahun_ajaran']) : '';
$semester     = isset($_GET['semester'])     ? trim($_GET['semester'])     : '';

try {
    // Build query: get distinct kelas that have at least 1 raport_siswa row
    // with a non-null academic_grades and that match the selected TA / semester
    $q = "SELECT DISTINCT k.id, k.nama_kelas
          FROM raport_siswa r
          JOIN kelas k ON r.kelas_id = k.id
          WHERE r.academic_grades IS NOT NULL
            AND r.academic_grades != 'null'
            AND r.academic_grades != '[]'
            AND r.academic_grades != '{}'";

    $params = [];

    if ($tahun_ajaran !== '') {
        $q .= " AND r.tahun_ajaran = :tahun_ajaran";
        $params['tahun_ajaran'] = $tahun_ajaran;
    }

    if ($semester !== '') {
        $q .= " AND r.semester = :semester";
        $params['semester'] = $semester;
    }

    $q .= " ORDER BY k.nama_kelas ASC";

    $stmt = $pdo->prepare($q);
    $stmt->execute($params);
    $kelas_list = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Also count how many students have raport data per class
    $count_q = "SELECT r.kelas_id, COUNT(DISTINCT r.siswa_id) as jumlah_siswa
                FROM raport_siswa r
                WHERE r.academic_grades IS NOT NULL
                  AND r.academic_grades != 'null'
                  AND r.academic_grades != '[]'
                  AND r.academic_grades != '{}'";

    $count_params = [];

    if ($tahun_ajaran !== '') {
        $count_q .= " AND r.tahun_ajaran = :tahun_ajaran";
        $count_params['tahun_ajaran'] = $tahun_ajaran;
    }

    if ($semester !== '') {
        $count_q .= " AND r.semester = :semester";
        $count_params['semester'] = $semester;
    }

    $count_q .= " GROUP BY r.kelas_id";

    $count_stmt = $pdo->prepare($count_q);
    $count_stmt->execute($count_params);
    $count_rows = $count_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Build count map
    $count_map = [];
    foreach ($count_rows as $cr) {
        $count_map[$cr['kelas_id']] = intval($cr['jumlah_siswa']);
    }

    // Merge count into kelas list
    foreach ($kelas_list as &$kelas) {
        $kelas['jumlah_siswa'] = $count_map[$kelas['id']] ?? 0;
    }
    unset($kelas);

    echo json_encode([
        'success' => true,
        'data'    => $kelas_list,
        'count'   => count($kelas_list),
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Gagal memuat data kelas: ' . $e->getMessage(),
        'data'    => [],
    ]);
}
