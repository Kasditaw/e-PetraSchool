<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\pengumuman\edit.php

$page_title = 'Edit Pengumuman';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$error = '';

try {
    $stmt = $pdo->prepare("SELECT * FROM pengumuman WHERE id = ?");
    $stmt->execute([$id]);
    $ann = $stmt->fetch();
    
    if (!$ann) {
        die('<div class="alert alert-danger">Pengumuman tidak ditemukan!</div>');
    }
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $judul = trim($_POST['judul'] ?? '');
    $isi = trim($_POST['isi'] ?? '');
    $tanggal = $_POST['tanggal'] ?? '';

    // File upload handling
    $lampiran_name = $ann['lampiran']; // Default
    if (isset($_FILES['lampiran']) && $_FILES['lampiran']['error'] === UPLOAD_ERR_OK) {
        $file_tmp = $_FILES['lampiran']['tmp_name'];
        $file_name = $_FILES['lampiran']['name'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        
        $allowed_exts = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];
        $mime_type = mime_content_type($file_tmp);
        $allowed_mimes = [
            'application/pdf', 'application/msword', 
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'image/jpeg', 'image/png'
        ];
        
        if (in_array($file_ext, $allowed_exts) && in_array($mime_type, $allowed_mimes)) {
            $upload_dir = dirname(dirname(__DIR__)) . '/assets/uploads/pengumuman/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            // Delete old file
            if (!empty($ann['lampiran']) && file_exists($upload_dir . $ann['lampiran'])) {
                unlink($upload_dir . $ann['lampiran']);
            }
            
            $lampiran_name = 'announcement_' . time() . '.' . $file_ext;
            if (move_uploaded_file($file_tmp, $upload_dir . $lampiran_name)) {
                // Success
            } else {
                $error = 'Gagal menyimpan file lampiran baru.';
            }
        } else {
            $error = 'Format file lampiran salah. Hanya menerima PDF, Word, JPG, atau PNG.';
        }
    }

    if ($error === '') {
        if (empty($judul) || empty($isi) || empty($tanggal)) {
            $error = 'Field Judul, Isi Pengumuman, dan Tanggal wajib diisi!';
        } else {
            try {
                // Update announcement
                $stmt = $pdo->prepare("UPDATE pengumuman SET judul = ?, isi = ?, tanggal = ?, lampiran = ? WHERE id = ?");
                $stmt->execute([$judul, $isi, $tanggal, $lampiran_name, $id]);
                
                write_audit_log("Mengubah pengumuman sekolah: $judul.");

                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Pengumuman berhasil diubah!', 'success').then(() => {
                            window.location.href = 'index.php';
                        });
                    });
                </script>";
            } catch (Exception $e) {
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    }
}
?>

<div class="glass-card" style="max-width: 700px; margin: 0 auto;">
    <h5 class="text-gold fw-bold mb-4"><i class="fa-solid fa-pen-to-square me-2"></i> Edit Pengumuman Sekolah</h5>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="edit.php?id=<?php echo $id; ?>" enctype="multipart/form-data">
        <?php csrf_input(); ?>

        <div class="mb-3">
            <label for="judul" class="form-label form-label-custom">Judul Pengumuman <span class="text-danger">*</span></label>
            <input type="text" name="judul" id="judul" class="form-control form-control-custom" value="<?php echo htmlspecialchars($ann['judul']); ?>" required>
        </div>

        <div class="mb-3">
            <label for="isi" class="form-label form-label-custom">Isi Pengumuman <span class="text-danger">*</span></label>
            <textarea name="isi" id="isi" class="form-control form-control-custom" rows="6" required><?php echo htmlspecialchars($ann['isi']); ?></textarea>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-6">
                <label for="tanggal" class="form-label form-label-custom">Tanggal Publikasi <span class="text-danger">*</span></label>
                <input type="date" name="tanggal" id="tanggal" class="form-control form-control-custom" value="<?php echo $ann['tanggal']; ?>" required>
            </div>
            
            <div class="col-6">
                <label for="lampiran" class="form-label form-label-custom">Lampiran File</label>
                <div class="d-flex align-items-center gap-2 mb-1">
                    <?php if (!empty($ann['lampiran'])): ?>
                        <span class="small text-gold"><i class="fa-solid fa-paperclip"></i> <?php echo htmlspecialchars($ann['lampiran']); ?></span>
                    <?php endif; ?>
                </div>
                <input type="file" name="lampiran" id="lampiran" class="form-control form-control-custom" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png">
                <span class="text-secondary" style="font-size: 10px;">Format: PDF, Word, Gambar. Biarkan kosong jika tidak diganti.</span>
            </div>
        </div>

        <div class="d-flex justify-content-end gap-2">
            <a href="index.php" class="btn btn-outline-custom">Batal</a>
            <button type="submit" class="btn btn-gold">Simpan Perubahan <i class="fa-solid fa-check ms-1"></i></button>
        </div>
    </form>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
