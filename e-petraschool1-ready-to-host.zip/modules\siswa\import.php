<?php
// c:\xampp\htdocs\e-petraschool1\modules\siswa\import.php

// Download CSV template (Must be run before header.php to avoid Headers Already Sent errors)
if (isset($_GET['action']) && $_GET['action'] === 'download_template') {
    if (ob_get_level()) {
        ob_end_clean();
    }
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=template_import_siswa.csv');
    
    $output = fopen('php://output', 'w');
    
    // Write headers
    fputcsv($output, [
        'nis', 
        'nisn', 
        'student_code', 
        'nama_lengkap', 
        'gender', 
        'asal_sekolah', 
        'nik', 
        'tempat_lahir', 
        'tanggal_lahir', 
        'agama', 
        'alamat', 
        'alamat_kk', 
        'no_hp_ortu', 
        'nama_ayah', 
        'nama_ibu', 
        'pekerjaan_ayah', 
        'pekerjaan_ibu', 
        'nama_kelas', 
        'tahun_masuk', 
        'status_siswa'
    ]);
    
    // Write sample row
    fputcsv($output, [
        '3192885871', 
        '0134567891', 
        'SC-001', 
        'Budi Santoso', 
        'L', 
        'TK Tarakanita', 
        '3578010101010001', 
        'Surabaya', 
        '2018-05-12', 
        'Kristen', 
        'Jl. Manyar Kertoarjo No. 12, Surabaya', 
        'Jl. Manyar Kertoarjo No. 12, Surabaya', 
        '08123456789', 
        'Hadi Santoso', 
        'Siti Aminah', 
        'Wiraswasta', 
        'Ibu Rumah Tangga', 
        'Kelas I A', 
        '2026', 
        'Aktif'
    ]);
    
    fclose($output);
    exit;
}

$page_title = 'Import Data Siswa';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';
$success = '';
$import_summary = null;


// Process Upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {
    check_csrf_request();
    
    $file_tmp = $_FILES['csv_file']['tmp_name'];
    $file_name = $_FILES['csv_file']['name'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    
    if ($file_ext !== 'csv') {
        $error = 'Hanya file format CSV yang diperbolehkan!';
    } else if ($_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        $error = 'Gagal mengunggah file. Kode error: ' . $_FILES['csv_file']['error'];
    } else {
        // Cache classes map (name => id)
        try {
            $class_stmt = $pdo->query("SELECT id, nama_kelas FROM kelas");
            $classes_map = [];
            while ($row = $class_stmt->fetch(PDO::FETCH_ASSOC)) {
                $classes_map[strtolower(trim($row['nama_kelas']))] = $row['id'];
            }
        } catch (Exception $e) {
            $classes_map = [];
        }
        
        $success_count = 0;
        $failed_count = 0;
        $failures = [];
        
        if (($handle = fopen($file_tmp, 'r')) !== false) {
            // Read header row
            $headers = fgetcsv($handle, 1000, ',');
            
            // Start PDO transaction
            $pdo->beginTransaction();
            $row_index = 2; // Rows are 1-based, index 2 is first data row after header
            
            while (($data = fgetcsv($handle, 1000, ',')) !== false) {
                // If row is empty, skip
                if (count($data) < 4 || empty(trim(implode('', $data)))) {
                    continue;
                }
                
                // Pad fields if less than expected headers
                while (count($data) < 20) {
                    $data[] = '';
                }
                
                // Map columns
                $nis             = trim($data[0]);
                $nisn            = trim($data[1]);
                $student_code    = trim($data[2]);
                $nama_lengkap    = trim($data[3]);
                $gender          = strtoupper(trim($data[4]));
                $asal_sekolah    = trim($data[5]);
                $nik             = trim($data[6]);
                $tempat_lahir    = trim($data[7]);
                $tanggal_lahir   = trim($data[8]);
                $agama           = trim($data[9]);
                $alamat          = trim($data[10]);
                $alamat_kk       = trim($data[11]);
                $no_hp_ortu      = trim($data[12]);
                $nama_ayah       = trim($data[13]);
                $nama_ibu        = trim($data[14]);
                $pekerjaan_ayah  = trim($data[15]);
                $pekerjaan_ibu   = trim($data[16]);
                $nama_kelas      = trim($data[17]);
                $tahun_masuk     = intval(trim($data[18]));
                $status_siswa    = trim($data[19]);
                
                // Validations
                if (empty($nis) || empty($nisn) || empty($nama_lengkap)) {
                    $failed_count++;
                    $failures[] = "Baris $row_index: NIS, NISN, dan Nama Lengkap wajib diisi.";
                    $row_index++;
                    continue;
                }
                
                if ($gender !== 'L' && $gender !== 'P') {
                    $gender = 'L'; // default or throw error
                }
                
                if (empty($status_siswa)) {
                    $status_siswa = 'Aktif';
                }
                
                if ($tahun_masuk <= 0) {
                    $tahun_masuk = intval(date('Y'));
                }
                
                // Resolve kelas_id
                $kelas_id = null;
                if (!empty($nama_kelas)) {
                    $normalized_kelas = strtolower($nama_kelas);
                    if (isset($classes_map[$normalized_kelas])) {
                        $kelas_id = $classes_map[$normalized_kelas];
                    }
                }
                
                try {
                    // Check duplicate NIS
                    $check_stmt = $pdo->prepare("SELECT COUNT(*) FROM siswa WHERE nis = ?");
                    $check_stmt->execute([$nis]);
                    if ($check_stmt->fetchColumn() > 0) {
                        $failed_count++;
                        $failures[] = "Baris $row_index: NIS '$nis' sudah terdaftar.";
                        $row_index++;
                        continue;
                    }
                    
                    // Check duplicate NISN
                    $check_stmt2 = $pdo->prepare("SELECT COUNT(*) FROM siswa WHERE nisn = ?");
                    $check_stmt2->execute([$nisn]);
                    if ($check_stmt2->fetchColumn() > 0) {
                        $failed_count++;
                        $failures[] = "Baris $row_index: NISN '$nisn' sudah terdaftar.";
                        $row_index++;
                        continue;
                    }
                    
                    // Insert
                    $query = "INSERT INTO siswa (nis, nisn, student_code, nama_lengkap, gender, asal_sekolah, nik, tempat_lahir, tanggal_lahir, agama, alamat, alamat_kk, no_hp_ortu, nama_ayah, nama_ibu, pekerjaan_ayah, pekerjaan_ibu, kelas_id, tahun_masuk, status_siswa) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    $stmt = $pdo->prepare($query);
                    $stmt->execute([
                        $nis, $nisn, $student_code, $nama_lengkap, $gender, $asal_sekolah, $nik, $tempat_lahir, $tanggal_lahir, 
                        $agama, $alamat, $alamat_kk, $no_hp_ortu, $nama_ayah, $nama_ibu, 
                        $pekerjaan_ayah, $pekerjaan_ibu, $kelas_id, $tahun_masuk, $status_siswa
                    ]);
                    
                    $success_count++;
                } catch (Exception $e) {
                    $failed_count++;
                    $failures[] = "Baris $row_index: Gagal menyimpan data siswa ({$e->getMessage()}).";
                }
                
                $row_index++;
            }
            
            fclose($handle);
            
            // Commit if we have successfully inserted at least one row, rollback otherwise or commit anyway
            $pdo->commit();
            
            write_audit_log("Melakukan import data siswa. Berhasil: $success_count, Gagal: $failed_count.");
            
            $import_summary = [
                'success' => $success_count,
                'failed' => $failed_count,
                'failures' => $failures
            ];
            
            $success = "Proses import selesai. $success_count data berhasil diimport, $failed_count gagal.";
        } else {
            $error = 'Gagal membuka file CSV yang diunggah.';
        }
    }
}
?>

<div class="glass-card" style="max-width: 750px; margin: 0 auto;">
    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom border-secondary border-opacity-10 pb-3">
        <h5 class="text-gold fw-bold mb-0"><i class="fa-solid fa-file-import me-2"></i> Import Data Siswa dari CSV</h5>
        <a href="index.php" class="btn btn-xs btn-outline-custom"><i class="fa-solid fa-arrow-left me-1"></i> Kembali</a>
    </div>
    
    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <?php if ($success !== ''): ?>
        <div class="alert alert-success border-0 text-white bg-success bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-circle-check me-2"></i> <?php echo htmlspecialchars($success); ?>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Panduan & Download Template -->
        <div class="col-12 col-md-5">
            <div class="card bg-dark bg-opacity-25 border-0 p-3 h-100">
                <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-circle-info me-1"></i> Panduan Import</h6>
                <ol class="text-secondary small ps-3 mb-4" style="line-height: 1.6;">
                    <li>Unduh template file CSV resmi dengan tombol di bawah.</li>
                    <li>Gunakan Excel atau editor teks untuk mengisi data siswa.</li>
                    <li>Pastikan format kolom tidak diubah/dihapus.</li>
                    <li>Kolom <strong>nis</strong> dan <strong>nisn</strong> harus unik untuk tiap siswa.</li>
                    <li>Gunakan kode <strong>L</strong> atau <strong>P</strong> pada kolom gender.</li>
                    <li>Format kelas harus persis sesuai daftar kelas di sistem (contoh: <strong>Kelas I A</strong>, bukan <strong>Kelas 1A</strong>).</li>
                </ol>
                <div class="mt-auto d-flex flex-column gap-2">
                    <a href="import.php?action=download_template" class="btn btn-outline-custom text-gold w-100"><i class="fa-solid fa-download me-1"></i> Unduh Template CSV (Umum)</a>
                    <a href="../../scratch/template_kelas2a.php" class="btn btn-outline-custom text-success w-100"><i class="fa-solid fa-download me-1"></i> Unduh Template Kelas II A</a>
                </div>
            </div>
        </div>
        
        <!-- Form Upload -->
        <div class="col-12 col-md-7">
            <div class="card bg-dark bg-opacity-10 border-0 p-3 h-100">
                <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-upload me-1"></i> Unggah File CSV</h6>
                <form method="POST" action="import.php" enctype="multipart/form-data">
                    <?php csrf_input(); ?>
                    
                    <div class="mb-4">
                        <label for="csv_file" class="form-label form-label-custom">Pilih File CSV (.csv)</label>
                        <input type="file" name="csv_file" id="csv_file" class="form-control form-control-custom" accept=".csv" required>
                    </div>
                    
                    <button type="submit" class="btn btn-gold w-100 py-2.5 fw-bold"><i class="fa-solid fa-check-double me-1"></i> Proses Import Data</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Summary Report -->
    <?php if ($import_summary !== null): ?>
        <div class="mt-4 border-top border-secondary border-opacity-10 pt-4">
            <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-square-poll-vertical me-1"></i> Ringkasan Hasil Import</h6>
            <div class="row g-2 mb-3 text-center">
                <div class="col-6">
                    <div class="bg-success bg-opacity-10 rounded p-2.5">
                        <span class="text-secondary small d-block">Berhasil</span>
                        <h4 class="text-success fw-bold mb-0"><?php echo $import_summary['success']; ?> Data</h4>
                    </div>
                </div>
                <div class="col-6">
                    <div class="bg-danger bg-opacity-10 rounded p-2.5">
                        <span class="text-secondary small d-block">Gagal</span>
                        <h4 class="text-danger fw-bold mb-0"><?php echo $import_summary['failed']; ?> Data</h4>
                    </div>
                </div>
            </div>

            <?php if (count($import_summary['failures']) > 0): ?>
                <div class="card bg-danger bg-opacity-5 border-0 p-3">
                    <span class="text-danger fw-bold small d-block mb-2"><i class="fa-solid fa-triangle-exclamation me-1"></i> Rincian Kesalahan Baris:</span>
                    <div class="overflow-auto text-secondary small" style="max-height: 180px;">
                        <ul class="ps-3 mb-0" style="line-height: 1.6;">
                            <?php foreach ($import_summary['failures'] as $fail): ?>
                                <li><?php echo htmlspecialchars($fail); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
