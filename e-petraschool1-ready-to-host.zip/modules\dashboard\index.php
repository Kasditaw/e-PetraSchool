<?php
// c:\xampp\htdocs\e-petraschool1\modules\dashboard\index.php

$page_title = 'Dashboard';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

$role = $_SESSION['role'] ?? '';
$guru_id = $_SESSION['guru_id'] ?? null;

// 1. Fetch KPI Statistics from DB
try {
    // --- GENERAL SCHOOL STATS (Needed for tab 2) ---
    // Total Siswa
    $stmt = $pdo->query("SELECT COUNT(*) FROM siswa WHERE status_siswa = 'Aktif'");
    $total_siswa = $stmt->fetchColumn();

    // Total Laki-laki
    $stmt = $pdo->query("SELECT COUNT(*) FROM siswa WHERE status_siswa = 'Aktif' AND gender = 'L'");
    $total_laki_laki = $stmt->fetchColumn();

    // Total Perempuan
    $stmt = $pdo->query("SELECT COUNT(*) FROM siswa WHERE status_siswa = 'Aktif' AND gender = 'P'");
    $total_perempuan = $stmt->fetchColumn();

    // Total Rombel
    $stmt = $pdo->query("SELECT COUNT(*) FROM kelas");
    $total_rombel = $stmt->fetchColumn();

    // --- NEW CLASS HISTORY SYSTEM METRICS ---
    // Kelas Aktif
    $stmt = $pdo->query("SELECT COUNT(*) FROM kelas WHERE status = 'Aktif'");
    $total_kelas_aktif = intval($stmt->fetchColumn());

    // Total Wali Kelas Aktif (Distinct wali_kelas_id in active classes)
    $stmt = $pdo->query("SELECT COUNT(DISTINCT wali_kelas_id) FROM kelas WHERE status = 'Aktif' AND wali_kelas_id IS NOT NULL");
    $total_wali_kelas = intval($stmt->fetchColumn());

    // Total Kapasitas
    $stmt = $pdo->query("SELECT SUM(kapasitas) FROM kelas WHERE status = 'Aktif'");
    $total_kapasitas = intval($stmt->fetchColumn());
    $capacity_filled_percent = $total_kapasitas > 0 ? round(($total_siswa / $total_kapasitas) * 100, 1) : 0;

    // Largest and Smallest class metrics
    $stmt = $pdo->query("
        SELECT k.nama_kelas, COUNT(s.id) as jumlah_siswa, k.kapasitas
        FROM kelas k
        LEFT JOIN siswa s ON k.id = s.kelas_id AND s.status_siswa = 'Aktif'
        WHERE k.status = 'Aktif'
        GROUP BY k.id
        ORDER BY jumlah_siswa DESC
    ");
    $class_sizes = $stmt->fetchAll();

    $largest_class = '-';
    $largest_class_count = 0;
    $smallest_class = '-';
    $smallest_class_count = 0;
    if (count($class_sizes) > 0) {
        $largest_class = $class_sizes[0]['nama_kelas'];
        $largest_class_count = intval($class_sizes[0]['jumlah_siswa']);
        
        $smallest_class = $class_sizes[count($class_sizes) - 1]['nama_kelas'];
        $smallest_class_count = intval($class_sizes[count($class_sizes) - 1]['jumlah_siswa']);
    }

    $romanize_class_name = function($nama) {
        $nama_roman = preg_replace_callback('/(\d+)/', function($matches) {
            $map = [1 => 'I', 2 => 'II', 3 => 'III', 4 => 'IV', 5 => 'V', 6 => 'VI'];
            return $map[$matches[1]] ?? $matches[1];
        }, $nama);
        $nama_roman = preg_replace('/([I|V|X]+)([A-HJ-UW-Z])/', '$1 $2', $nama_roman);
        return $nama_roman;
    };

    // Student Count per Level (Tingkat)
    $tingkat_stats_stmt = $pdo->query("
        SELECT k.tingkat, COUNT(s.id) as jumlah 
        FROM kelas k 
        LEFT JOIN siswa s ON k.id = s.kelas_id AND s.status_siswa = 'Aktif'
        WHERE k.status = 'Aktif'
        GROUP BY k.tingkat 
        ORDER BY k.tingkat ASC
    ");
    $tingkat_stats_data = $tingkat_stats_stmt->fetchAll();
    
    $tingkat_labels = ['Tingkat 1', 'Tingkat 2', 'Tingkat 3', 'Tingkat 4', 'Tingkat 5', 'Tingkat 6'];
    $tingkat_values = [0, 0, 0, 0, 0, 0];
    foreach ($tingkat_stats_data as $row) {
        $idx = intval($row['tingkat']) - 1;
        if ($idx >= 0 && $idx < 6) {
            $tingkat_values[$idx] = intval($row['jumlah']);
        }
    }

    // Fetch data for Chart: Statistik Per Kelas
    $class_stats_stmt = $pdo->query("
        SELECT k.nama_kelas, COUNT(s.id) as jumlah 
        FROM kelas k 
        LEFT JOIN siswa s ON k.id = s.kelas_id AND s.status_siswa = 'Aktif'
        GROUP BY k.id 
        ORDER BY k.nama_kelas ASC
    ");
    $class_stats_data = $class_stats_stmt->fetchAll();
    
    $class_labels = [];
    $class_values = [];
    foreach ($class_stats_data as $row) {
        $nama = $row['nama_kelas'];
        // Format to Roman
        $nama_roman = preg_replace_callback('/(\d+)/', function($matches) {
            $map = [1 => 'I', 2 => 'II', 3 => 'III', 4 => 'IV', 5 => 'V', 6 => 'VI'];
            return $map[$matches[1]] ?? $matches[1];
        }, $nama);
        $nama_roman = preg_replace('/([I|V|X]+)([A-HJ-UW-Z])/', '$1 $2', $nama_roman);
        
        $class_labels[] = $nama_roman;
        $class_values[] = intval($row['jumlah']);
    }

    // Total Alumni
    $stmt = $pdo->query("SELECT COUNT(*) FROM siswa WHERE status_siswa = 'Alumni'");
    $total_alumni = $stmt->fetchColumn();

    // Fetch data for Chart: Student Growth
    $growth_stmt = $pdo->query("SELECT tahun_masuk, COUNT(*) as jumlah FROM siswa WHERE status_siswa = 'Aktif' GROUP BY tahun_masuk ORDER BY tahun_masuk ASC");
    $growth_data = $growth_stmt->fetchAll();
    
    $growth_labels = [];
    $growth_values = [];
    foreach ($growth_data as $row) {
        $growth_labels[] = 'Tahun ' . $row['tahun_masuk'];
        $growth_values[] = intval($row['jumlah']);
    }

    // Fetch data for Chart: Inventory by Category
    $cat_stmt = $pdo->query("SELECT k.nama_kategori, SUM(i.jumlah) as jumlah FROM inventaris i JOIN kategori_barang k ON i.kategori_id = k.id GROUP BY k.nama_kategori");
    $cat_data = $cat_stmt->fetchAll();
    
    $cat_labels = [];
    $cat_values = [];
    foreach ($cat_data as $row) {
        $cat_labels[] = $row['nama_kategori'];
        $cat_values[] = intval($row['jumlah']);
    }

    // Fetch data for Chart: Damaged Items by Condition
    $cond_stmt = $pdo->query("SELECT kondisi, SUM(jumlah) as jumlah FROM inventaris GROUP BY kondisi");
    $cond_data = $cond_stmt->fetchAll();
    
    $cond_labels = [];
    $cond_values = [];
    foreach ($cond_data as $row) {
        $cond_labels[] = $row['kondisi'];
        $cond_values[] = intval($row['jumlah']);
    }

    // Fetch data for Chart: Asal Sekolah
    $origin_stmt = $pdo->query("
        SELECT asal_sekolah, COUNT(*) as jumlah 
        FROM siswa 
        WHERE status_siswa = 'Aktif' AND asal_sekolah IS NOT NULL AND asal_sekolah != '' 
        GROUP BY asal_sekolah 
        ORDER BY jumlah DESC 
        LIMIT 5
    ");
    $origin_data = $origin_stmt->fetchAll();
    
    $origin_labels = [];
    $origin_values = [];
    foreach ($origin_data as $row) {
        $origin_labels[] = $row['asal_sekolah'];
        $origin_values[] = intval($row['jumlah']);
    }

    // Fetch Latest Announcements
    $announce_stmt = $pdo->query("SELECT p.*, u.nama FROM pengumuman p LEFT JOIN users u ON p.penulis_id = u.id ORDER BY p.tanggal DESC LIMIT 3");
    $announcements = $announce_stmt->fetchAll();


    // --- E-JURNAL STATISTICS ---
    $is_guru = ($role === 'Guru');
    
    if ($is_guru) {
        if ($guru_id) {
            // Total Personal Journals
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM jurnal_mengajar WHERE guru_id = ?");
            $stmt->execute([$guru_id]);
            $total_jurnal_personal = $stmt->fetchColumn();

            // Approved Personal Journals
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM jurnal_mengajar WHERE guru_id = ? AND status = 'Disetujui'");
            $stmt->execute([$guru_id]);
            $total_jurnal_approved = $stmt->fetchColumn();

            // Revision Pending Personal Journals
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM jurnal_mengajar WHERE guru_id = ? AND status = 'Revisi'");
            $stmt->execute([$guru_id]);
            $total_jurnal_revision = $stmt->fetchColumn();

            // Today's Journal Check
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM jurnal_mengajar WHERE guru_id = ? AND tanggal = CURRENT_DATE()");
            $stmt->execute([$guru_id]);
            $today_journal_inputted = ($stmt->fetchColumn() > 0);

            // Revision Comments list
            $stmt = $pdo->prepare("
                SELECT j.id, j.tanggal, v.catatan, v.tanggal_verifikasi, u.nama AS verifikator_nama 
                FROM jurnal_mengajar j 
                JOIN verifikasi_jurnal v ON j.id = v.jurnal_id 
                LEFT JOIN users u ON v.verifikator_id = u.id 
                WHERE j.guru_id = ? AND j.status = 'Revisi' 
                ORDER BY v.tanggal_verifikasi DESC 
                LIMIT 5
            ");
            $stmt->execute([$guru_id]);
            $personal_revisions = $stmt->fetchAll();

            // Personal KBM hours taught by month
            $stmt = $pdo->prepare("
                SELECT MONTH(j.tanggal) as bulan, YEAR(j.tanggal) as tahun, COUNT(jd.id) as jumlah_jp 
                FROM jurnal_mengajar j 
                JOIN jurnal_mengajar_detail jd ON j.id = jd.jurnal_id 
                WHERE j.guru_id = ? 
                GROUP BY YEAR(j.tanggal), MONTH(j.tanggal) 
                ORDER BY YEAR(j.tanggal) ASC, MONTH(j.tanggal) ASC 
                LIMIT 12
            ");
            $stmt->execute([$guru_id]);
            $personal_kbm_data = $stmt->fetchAll();
            
            $personal_kbm_labels = [];
            $personal_kbm_values = [];
            $indo_months = [
                1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'Mei', 6 => 'Jun',
                7 => 'Jul', 8 => 'Agt', 9 => 'Sep', 10 => 'Okt', 11 => 'Nov', 12 => 'Des'
            ];
            foreach ($personal_kbm_data as $row) {
                $personal_kbm_labels[] = ($indo_months[intval($row['bulan'])] ?? '') . ' ' . $row['tahun'];
                $personal_kbm_values[] = intval($row['jumlah_jp']);
            }
        } else {
            $total_jurnal_personal = 0;
            $total_jurnal_approved = 0;
            $total_jurnal_revision = 0;
            $today_journal_inputted = false;
            $personal_revisions = [];
            $personal_kbm_labels = [];
            $personal_kbm_values = [];
        }
    } else {
        // Admin, Kepsek, Super Admin
        // Jumlah Guru
        $stmt = $pdo->query("SELECT COUNT(*) FROM guru");
        $total_guru = $stmt->fetchColumn();

        // Jurnal Hari Ini
        $stmt = $pdo->query("SELECT COUNT(*) FROM jurnal_mengajar WHERE tanggal = CURRENT_DATE()");
        $total_jurnal_hari_ini = $stmt->fetchColumn();

        // Jurnal Bulan Ini
        $stmt = $pdo->query("SELECT COUNT(*) FROM jurnal_mengajar WHERE MONTH(tanggal) = MONTH(CURRENT_DATE()) AND YEAR(tanggal) = YEAR(CURRENT_DATE())");
        $total_jurnal_bulan_ini = $stmt->fetchColumn();

        // Jurnal Belum Diverifikasi
        $stmt = $pdo->query("SELECT COUNT(*) FROM jurnal_mengajar WHERE status = 'Menunggu Verifikasi'");
        $total_jurnal_belum_verif = $stmt->fetchColumn();

        // Jurnal Disetujui
        $stmt = $pdo->query("SELECT COUNT(*) FROM jurnal_mengajar WHERE status = 'Disetujui'");
        $total_jurnal_disetujui_all = $stmt->fetchColumn();

        // Jurnal Revisi
        $stmt = $pdo->query("SELECT COUNT(*) FROM jurnal_mengajar WHERE status = 'Revisi'");
        $total_jurnal_revisi_all = $stmt->fetchColumn();

        $total_jurnal_all = $total_jurnal_belum_verif + $total_jurnal_disetujui_all + $total_jurnal_revisi_all;
        $completion_rate = $total_jurnal_all > 0 ? round(($total_jurnal_disetujui_all / $total_jurnal_all) * 100, 1) : 0;

        // Monthly KBM Stats (all teachers)
        $stmt = $pdo->query("
            SELECT MONTH(j.tanggal) as bulan, YEAR(j.tanggal) as tahun, COUNT(jd.id) as jumlah_jp 
            FROM jurnal_mengajar j 
            JOIN jurnal_mengajar_detail jd ON j.id = jd.jurnal_id 
            GROUP BY YEAR(j.tanggal), MONTH(j.tanggal) 
            ORDER BY YEAR(j.tanggal) ASC, MONTH(j.tanggal) ASC 
            LIMIT 12
        ");
        $monthly_kbm_data = $stmt->fetchAll();
        $monthly_kbm_labels = [];
        $monthly_kbm_values = [];
        $indo_months = [
            1 => 'Jan', 2 => 'Feb', 3 => 'Mar', 4 => 'Apr', 5 => 'Mei', 6 => 'Jun',
            7 => 'Jul', 8 => 'Agt', 9 => 'Sep', 10 => 'Okt', 11 => 'Nov', 12 => 'Des'
        ];
        foreach ($monthly_kbm_data as $row) {
            $monthly_kbm_labels[] = ($indo_months[intval($row['bulan'])] ?? '') . ' ' . $row['tahun'];
            $monthly_kbm_values[] = intval($row['jumlah_jp']);
        }

        // Top Active Teachers
        $stmt = $pdo->query("
            SELECT g.nama_guru, COUNT(j.id) as total_jurnal 
            FROM jurnal_mengajar j 
            JOIN guru g ON j.guru_id = g.id 
            GROUP BY j.guru_id 
            ORDER BY total_jurnal DESC 
            LIMIT 5
        ");
        $top_teachers_data = $stmt->fetchAll();
        $top_teachers_labels = [];
        $top_teachers_values = [];
        foreach ($top_teachers_data as $row) {
            $top_teachers_labels[] = $row['nama_guru'];
            $top_teachers_values[] = intval($row['total_jurnal']);
        }

        // Pending Verifications List
        $stmt = $pdo->query("
            SELECT j.id, j.tanggal, g.nama_guru 
            FROM jurnal_mengajar j 
            JOIN guru g ON j.guru_id = g.id 
            WHERE j.status = 'Menunggu Verifikasi' 
            ORDER BY j.tanggal DESC 
            LIMIT 5
        ");
        $pending_verifications = $stmt->fetchAll();

        // Revision Alerts List
        $stmt = $pdo->query("
            SELECT j.id, j.tanggal, g.nama_guru, v.catatan 
            FROM jurnal_mengajar j 
            JOIN guru g ON j.guru_id = g.id 
            JOIN verifikasi_jurnal v ON j.id = v.jurnal_id 
            WHERE j.status = 'Revisi' 
            ORDER BY v.tanggal_verifikasi DESC 
            LIMIT 5
        ");
        $revision_alerts = $stmt->fetchAll();

        // --- DATA GRADES STATISTICS ---
        try {
            $grades_stmt = $pdo->query("
                SELECT r.id, r.academic_grades, s.nama_lengkap, k.nama_kelas, r.tahun_ajaran, r.semester
                FROM raport_siswa r
                JOIN siswa s ON r.siswa_id = s.id
                LEFT JOIN kelas k ON r.kelas_id = k.id
                WHERE s.status_siswa = 'Aktif'
            ");
            $all_grades = $grades_stmt->fetchAll(PDO::FETCH_ASSOC);

            $total_reports = count($all_grades);
            $subject_scores = []; 
            $student_averages = []; 
            $overall_scores = [];
            $distribution = ['A' => 0, 'B' => 0, 'C' => 0, 'D' => 0]; 

            foreach ($all_grades as $row) {
                $grades = json_decode($row['academic_grades'], true) ?: [];
                $student_scores = [];
                foreach ($grades as $subject => $g) {
                    $score = isset($g['score']) && $g['score'] !== '' ? floatval($g['score']) : null;
                    if ($score !== null) {
                        $subject_scores[$subject][] = $score;
                        $student_scores[] = $score;
                        $overall_scores[] = $score;
                        
                        if ($score >= 90) $distribution['A']++;
                        elseif ($score >= 80) $distribution['B']++;
                        elseif ($score >= 70) $distribution['C']++;
                        else $distribution['D']++;
                    }
                }
                if (count($student_scores) > 0) {
                    $avg = array_sum($student_scores) / count($student_scores);
                    $c_name = $row['nama_kelas'] ? $romanize_class_name($row['nama_kelas']) : 'Tanpa Kelas';
                    $student_averages[$row['nama_lengkap'] . ' (' . $c_name . ')'] = round($avg, 1);
                }
            }

            arsort($student_averages);
            $top_students = array_slice($student_averages, 0, 5, true);

            $subject_averages = [];
            foreach ($subject_scores as $subj => $scores) {
                $subject_averages[$subj] = round(array_sum($scores) / count($scores), 1);
            }
            arsort($subject_averages);

            $avg_grade_school = count($overall_scores) > 0 ? round(array_sum($overall_scores) / count($overall_scores), 1) : 0;
            $highest_grade = count($overall_scores) > 0 ? max($overall_scores) : 0;
            $lowest_grade = count($overall_scores) > 0 ? min($overall_scores) : 0;
            $passing_count = count(array_filter($overall_scores, function($s) { return $s >= 75; }));
            $passing_percent = count($overall_scores) > 0 ? round(($passing_count / count($overall_scores)) * 100, 1) : 0;
        } catch (Exception $ge) {
            $avg_grade_school = 0;
            $highest_grade = 0;
            $lowest_grade = 0;
            $passing_percent = 0;
            $distribution = ['A' => 0, 'B' => 0, 'C' => 0, 'D' => 0];
            $top_students = [];
            $subject_averages = [];
        }
    }

} catch (Exception $e) {
    echo '<div class="alert alert-danger">Gagal memuat data dashboard: ' . $e->getMessage() . '</div>';
}
?>

<!-- Custom Premium CSS for Dashboard Components -->
<style>
#dashboard-tabs .nav-link {
    color: var(--text-secondary);
    background: rgba(18, 28, 54, 0.25);
    border: 1px solid var(--border-color);
    border-radius: 8px;
    padding: 10px 20px;
    font-weight: 600;
    transition: all 0.3s ease;
}
#dashboard-tabs .nav-link.active {
    color: #000 !important;
    background: linear-gradient(135deg, #D4AF37 0%, #F3CD48 100%) !important;
    border-color: #D4AF37 !important;
    box-shadow: 0 4px 15px rgba(212, 175, 55, 0.25);
}
#dashboard-tabs .nav-link:hover:not(.active) {
    color: var(--color-gold);
    border-color: var(--color-gold);
}

.kpi-card {
    transition: transform var(--transition-smooth), box-shadow var(--transition-smooth);
    border: 1px solid var(--border-color);
}
.kpi-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
    border-color: rgba(212, 175, 55, 0.3);
}

.kpi-icon {
    font-size: 24px;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 12px;
}
.kpi-icon.gold {
    background: rgba(212, 175, 55, 0.1);
    color: var(--color-gold);
}
.kpi-icon.blue {
    background: rgba(59, 130, 246, 0.1);
    color: #3b82f6;
}
.kpi-icon.success {
    background: rgba(16, 185, 129, 0.1);
    color: #10b981;
}
.kpi-icon.pink {
    background: rgba(244, 63, 94, 0.1);
    color: #f43f5e;
}
.kpi-icon.purple {
    background: rgba(139, 92, 246, 0.1);
    color: #8b5cf6;
}
.kpi-icon.warning {
    background: rgba(245, 158, 11, 0.1);
    color: #f59e0b;
}
.kpi-icon.danger {
    background: rgba(239, 68, 68, 0.1);
    color: #ef4444;
}

.revision-item {
    background: rgba(239, 68, 68, 0.05);
    border-left: 4px solid #ef4444;
    border-radius: 4px;
    padding: 12px;
    margin-bottom: 12px;
    transition: transform var(--transition-hover);
}
.revision-item:hover {
    transform: translateX(4px);
    background: rgba(239, 68, 68, 0.08);
}
</style>

<!-- ========================================== -->
<!-- GURU DASHBOARD                             -->
<!-- ========================================== -->
<?php if ($is_guru): ?>
    <?php if (!$guru_id): ?>
        <div class="alert alert-danger glass-card mb-4" role="alert">
            <h6 class="alert-heading fw-bold mb-1"><i class="fa-solid fa-triangle-exclamation me-2"></i> Akun Belum Ditautkan</h6>
            <p class="mb-0 small text-secondary">Akun login Anda belum ditautkan ke data guru dalam sistem. Silakan hubungi Administrator untuk menghubungkan akun Anda agar dapat mengakses modul e-Jurnal Mengajar.</p>
        </div>
    <?php else: ?>
        <!-- Today's Journal Reminder Alert -->
        <?php if (!$today_journal_inputted): ?>
            <div class="alert alert-warning d-flex align-items-center gap-3 glass-card mb-4" role="alert" style="border-left: 4px solid var(--color-warning);">
                <i class="fa-solid fa-triangle-exclamation text-warning animate-bounce" style="font-size: 24px;"></i>
                <div>
                    <h6 class="alert-heading fw-bold mb-1 text-white">Jurnal Mengajar Hari Ini Belum Diisi!</h6>
                    <p class="mb-0 text-secondary small">Anda belum melakukan pencatatan Jurnal Mengajar untuk hari ini (<?php echo date('d-m-Y'); ?>). Harap segera isi jurnal kegiatan pembelajaran Anda.</p>
                </div>
                <a href="<?php echo $base_url; ?>modules/jurnal/create.php" class="btn btn-gold text-dark btn-sm ms-auto fw-bold"><i class="fa-solid fa-plus me-1"></i> Isi Jurnal Hari Ini</a>
            </div>
        <?php endif; ?>

        <!-- KPI Grid for Guru -->
        <div class="row g-3 mb-4">
            <!-- Total Jurnal Saya -->
            <div class="col-12 col-sm-4">
                <div class="glass-card kpi-card p-3 mb-0">
                    <div class="kpi-icon blue"><i class="fa-solid fa-journal-whills"></i></div>
                    <div>
                        <span class="text-secondary small d-block mb-1">Total Jurnal Saya</span>
                        <h3 class="fw-bold mb-0 text-theme-primary" style="color: var(--text-primary);"><?php echo $total_jurnal_personal; ?></h3>
                    </div>
                </div>
            </div>
            <!-- Jurnal Disetujui -->
            <div class="col-12 col-sm-4">
                <div class="glass-card kpi-card p-3 mb-0">
                    <div class="kpi-icon success"><i class="fa-solid fa-circle-check"></i></div>
                    <div>
                        <span class="text-secondary small d-block mb-1">Disetujui</span>
                        <h3 class="fw-bold mb-0 text-theme-primary" style="color: var(--text-primary);"><?php echo $total_jurnal_approved; ?></h3>
                    </div>
                </div>
            </div>
            <!-- Butuh Revisi -->
            <div class="col-12 col-sm-4">
                <div class="glass-card kpi-card p-3 mb-0">
                    <div class="kpi-icon danger"><i class="fa-solid fa-triangle-exclamation"></i></div>
                    <div>
                        <span class="text-secondary small d-block mb-1">Butuh Revisi</span>
                        <h3 class="fw-bold mb-0 text-theme-primary" style="color: var(--text-primary);"><?php echo $total_jurnal_revision; ?></h3>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Left Column: Activity Chart -->
            <div class="col-12 col-lg-8">
                <div class="glass-card h-100 mb-0">
                    <h6 class="text-theme-primary fw-bold mb-3" style="color: var(--text-primary);"><i class="fa-solid fa-chart-line text-gold me-2"></i> Jam Pelajaran Diajar Per Bulan (KBM)</h6>
                    <p class="text-secondary small mb-3">Statistik total jam pelajaran (JP) kegiatan belajar mengajar yang Anda ajar per bulan pada semester aktif.</p>
                    <div style="position: relative; height: 300px;">
                        <canvas id="personalKbmChart"></canvas>
                    </div>
                </div>
            </div>

            <!-- Right Column: Revision Notes & Widgets -->
            <div class="col-12 col-lg-4 d-flex flex-column gap-4">
                <!-- Revision Comments Widget -->
                <div class="glass-card mb-0">
                    <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-comment-dots me-2"></i> Catatan Revisi Jurnal</h6>
                    <div class="revision-list" style="max-height: 250px; overflow-y: auto;">
                        <?php if (count($personal_revisions) > 0): ?>
                            <?php foreach ($personal_revisions as $rev): ?>
                                <div class="revision-item">
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                        <span class="text-white fw-bold small"><i class="fa-regular fa-calendar me-1"></i> <?php echo date('d M Y', strtotime($rev['tanggal'])); ?></span>
                                        <a href="<?php echo $base_url; ?>modules/jurnal/edit.php?id=<?php echo $rev['id']; ?>" class="btn btn-xs btn-gold text-dark font-monospace" style="font-size: 10px; padding: 1px 6px;">Edit Jurnal</a>
                                    </div>
                                    <p class="text-secondary small mb-1" style="font-style: italic;">"<?php echo htmlspecialchars($rev['catatan']); ?>"</p>
                                    <div class="d-flex justify-content-between text-secondary" style="font-size: 9px;">
                                        <span>Oleh: <?php echo htmlspecialchars($rev['verifikator_nama'] ?? 'Verifikator'); ?></span>
                                        <span><?php echo date('d M H:i', strtotime($rev['tanggal_verifikasi'])); ?></span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-4 text-secondary small">
                                <i class="fa-solid fa-check-circle text-success mb-2" style="font-size: 28px;"></i>
                                <p class="mb-0">Tidak ada jurnal yang membutuhkan revisi.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Announcements Widget -->
                <div class="glass-card mb-0">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h6 class="text-gold fw-bold mb-0"><i class="fa-solid fa-bullhorn me-2"></i> Pengumuman Sekolah</h6>
                        <a href="<?php echo $base_url; ?>modules/pengumuman/index.php" class="btn btn-xs btn-outline-custom text-gold" style="font-size: 10px; padding: 2px 8px;">Lihat Semua</a>
                    </div>
                    <div class="announcement-list">
                        <?php if (count($announcements) > 0): ?>
                            <?php foreach ($announcements as $ann): ?>
                                <div class="pb-2 mb-2 border-bottom border-secondary border-opacity-10">
                                    <h6 class="text-white fw-bold mb-1" style="font-size: 12.5px;"><?php echo htmlspecialchars($ann['judul']); ?></h6>
                                    <p class="text-secondary small mb-1 text-truncate" style="font-size: 11px;"><?php echo strip_tags($ann['isi']); ?></p>
                                    <div class="d-flex justify-content-between text-secondary" style="font-size: 9px;">
                                        <span><i class="fa-solid fa-calendar-days me-1"></i> <?php echo date('d M Y', strtotime($ann['tanggal'])); ?></span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-secondary small py-2 text-center">Belum ada pengumuman sekolah.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Calendar Widget -->
                <div class="glass-card mb-0">
                    <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-calendar-check me-2"></i> Kalender Akademik</h6>
                    <div class="agenda-list" style="font-size: 12px;">
                        <div class="d-flex align-items-start gap-2 mb-2">
                            <div class="bg-gold text-dark rounded px-1.5 py-0.5 text-center font-monospace" style="font-size: 9px; font-weight: 700; min-width: 42px;">08 JUN</div>
                            <div>
                                <h6 class="text-white fw-semibold mb-0" style="font-size: 12px;">PAS Genap</h6>
                                <span class="text-secondary" style="font-size: 10px;">08 - 13 Juni 2026</span>
                            </div>
                        </div>
                        <div class="d-flex align-items-start gap-2 mb-2">
                            <div class="bg-gold text-dark rounded px-1.5 py-0.5 text-center font-monospace" style="font-size: 9px; font-weight: 700; min-width: 42px;">20 JUN</div>
                            <div>
                                <h6 class="text-white fw-semibold mb-0" style="font-size: 12px;">Rapor Genap & Pensi</h6>
                                <span class="text-secondary" style="font-size: 10px;">20 Juni 2026</span>
                            </div>
                        </div>
                        <div class="d-flex align-items-start gap-2">
                            <div class="bg-gold text-dark rounded px-1.5 py-0.5 text-center font-monospace" style="font-size: 9px; font-weight: 700; min-width: 42px;">06 JUL</div>
                            <div>
                                <h6 class="text-white fw-semibold mb-0" style="font-size: 12px;">Tahun Ajaran Baru</h6>
                                <span class="text-secondary" style="font-size: 10px;">Tahun Pelajaran 2026/2027</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

<!-- ========================================== -->
<!-- ADMIN / KEPSEK / SUPER ADMIN DASHBOARD     -->
<!-- ========================================== -->
<?php else: ?>
    <!-- Jurnal Pending Verification Alert -->
    <?php if ($total_jurnal_belum_verif > 0 && has_role(['Kepala Sekolah'])): ?>
        <div class="alert alert-info d-flex align-items-center gap-3 glass-card mb-4" role="alert" style="border-left: 4px solid var(--color-info);">
            <i class="fa-solid fa-clock text-info animate-pulse" style="font-size: 24px;"></i>
            <div>
                <h6 class="alert-heading fw-bold mb-1 text-white">Jurnal Menunggu Verifikasi</h6>
                <p class="mb-0 text-secondary small">Terdapat <strong><?php echo $total_jurnal_belum_verif; ?></strong> jurnal mengajar baru dari guru yang membutuhkan pemeriksaan dan verifikasi.</p>
            </div>
            <a href="<?php echo $base_url; ?>modules/jurnal/index.php?status=Menunggu+Verifikasi" class="btn btn-info btn-sm ms-auto fw-bold" style="background: var(--color-info); color: #fff; border: none;"><i class="fa-solid fa-file-circle-check me-1"></i> Verifikasi Sekarang</a>
        </div>
    <?php endif; ?>

    <!-- Tabs Navigation -->
    <ul class="nav nav-pills mb-4 no-print" id="dashboard-tabs" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active me-2" id="jurnal-tab" data-bs-toggle="tab" data-bs-target="#jurnal-content" type="button" role="tab" aria-controls="jurnal-content" aria-selected="true">
                <i class="fa-solid fa-journal-whills me-2"></i> Monitoring E-Jurnal
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link me-2" id="school-tab" data-bs-toggle="tab" data-bs-target="#school-content" type="button" role="tab" aria-controls="school-content" aria-selected="false">
                <i class="fa-solid fa-school me-2"></i> Statistik Sekolah & Aset
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="grades-tab" data-bs-toggle="tab" data-bs-target="#grades-content" type="button" role="tab" aria-controls="grades-content" aria-selected="false">
                <i class="fa-solid fa-chart-line me-2"></i> Analisis & Nilai Siswa
            </button>
        </li>
    </ul>

    <!-- Tab Contents Container -->
    <div class="tab-content" id="dashboard-tab-content">
        
        <!-- Tab 1: Monitoring E-Jurnal -->
        <div class="tab-pane fade show active" id="jurnal-content" role="tabpanel" aria-labelledby="jurnal-tab">
            <!-- E-Jurnal KPI Grid -->
            <div class="row g-3 mb-4">
                <!-- Jumlah Guru -->
                <div class="col-6 col-md-3 col-lg-3">
                    <div class="glass-card kpi-card p-3 mb-0 h-100">
                        <div class="kpi-icon blue mb-2"><i class="fa-solid fa-chalkboard-user"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1">Jumlah Guru</span>
                            <h3 class="fw-bold mb-0 text-theme-primary" style="color: var(--text-primary);"><?php echo $total_guru; ?></h3>
                        </div>
                    </div>
                </div>
                <!-- Jurnal Hari Ini -->
                <div class="col-6 col-md-3 col-lg-3">
                    <div class="glass-card kpi-card p-3 mb-0 h-100">
                        <div class="kpi-icon success mb-2"><i class="fa-solid fa-calendar-day"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1">Jurnal Hari Ini</span>
                            <h3 class="fw-bold mb-0 text-theme-primary" style="color: var(--text-primary);"><?php echo $total_jurnal_hari_ini; ?></h3>
                        </div>
                    </div>
                </div>
                <!-- Jurnal Bulan Ini -->
                <div class="col-6 col-md-3 col-lg-3">
                    <div class="glass-card kpi-card p-3 mb-0 h-100">
                        <div class="kpi-icon purple mb-2"><i class="fa-solid fa-calendar-days"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1">Jurnal Bulan Ini</span>
                            <h3 class="fw-bold mb-0 text-theme-primary" style="color: var(--text-primary);"><?php echo $total_jurnal_bulan_ini; ?></h3>
                        </div>
                    </div>
                </div>
                <!-- Jurnal Belum Diverifikasi -->
                <div class="col-6 col-md-3 col-lg-3">
                    <div class="glass-card kpi-card p-3 mb-0 h-100" style="border-color: rgba(245, 158, 11, 0.2);">
                        <div class="kpi-icon warning mb-2"><i class="fa-solid fa-clock"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1">Belum Diverif</span>
                            <h3 class="fw-bold mb-0 text-warning"><?php echo $total_jurnal_belum_verif; ?></h3>
                        </div>
                    </div>
                </div>
                <!-- Jurnal Disetujui -->
                <div class="col-6 col-md-4 col-lg-4">
                    <div class="glass-card kpi-card p-3 mb-0 h-100">
                        <div class="kpi-icon success mb-2"><i class="fa-solid fa-circle-check"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1">Disetujui</span>
                            <h3 class="fw-bold mb-0 text-success"><?php echo $total_jurnal_disetujui_all; ?></h3>
                        </div>
                    </div>
                </div>
                <!-- Jurnal Direvisi -->
                <div class="col-6 col-md-4 col-lg-4">
                    <div class="glass-card kpi-card p-3 mb-0 h-100" style="border-color: rgba(239, 68, 68, 0.2);">
                        <div class="kpi-icon danger mb-2"><i class="fa-solid fa-triangle-exclamation"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1">Jurnal Direvisi</span>
                            <h3 class="fw-bold mb-0 text-danger"><?php echo $total_jurnal_revisi_all; ?></h3>
                        </div>
                    </div>
                </div>
                <!-- Completion Rate -->
                <div class="col-12 col-md-4 col-lg-4">
                    <div class="glass-card kpi-card p-3 mb-0 h-100" style="border-color: rgba(212, 175, 55, 0.2);">
                        <div class="kpi-icon gold mb-2"><i class="fa-solid fa-chart-pie"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1">Tingkat Penyelesaian</span>
                            <h3 class="fw-bold mb-0 text-gold"><?php echo $completion_rate; ?>% <span class="small text-secondary" style="font-size: 12px; font-weight: normal;">(Disetujui)</span></h3>
                        </div>
                    </div>
                </div>
            </div>

            <!-- E-Jurnal Charts Row -->
            <div class="row g-4 mb-4">
                <!-- Monthly Teaching Activity -->
                <div class="col-12 col-lg-6">
                    <div class="glass-card h-100 mb-0">
                        <h6 class="text-theme-primary fw-bold mb-3" style="color: var(--text-primary);"><i class="fa-solid fa-chart-line text-gold me-2"></i> Jam Pelajaran Terdokumentasi Bulanan</h6>
                        <div style="position: relative; height: 260px;">
                            <canvas id="monthlyKbmChart"></canvas>
                        </div>
                    </div>
                </div>
                <!-- Top Active Teachers & Status Share -->
                <div class="col-12 col-lg-6">
                    <div class="glass-card h-100 mb-0">
                        <h6 class="text-theme-primary fw-bold mb-3" style="color: var(--text-primary);"><i class="fa-solid fa-chart-bar text-gold me-2"></i> Aktivitas Input Guru & Status Jurnal</h6>
                        <div class="row g-2 align-items-center">
                            <div class="col-7">
                                <div style="position: relative; height: 240px;">
                                    <canvas id="topTeachersChart"></canvas>
                                </div>
                            </div>
                            <div class="col-5">
                                <div style="position: relative; height: 240px;">
                                    <canvas id="completionChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Verification Activity Lists & Widgets -->
            <div class="row g-4 mb-4">
                <?php if (has_role('Kepala Sekolah')): ?>
                    <!-- Left Column: Verification Feed -->
                    <div class="col-12 col-lg-6">
                        <div class="glass-card h-100">
                            <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-bell-concierge me-2"></i> Antrean Verifikasi & Aktivitas Terbaru</h6>
                            
                            <div class="verification-activity-feed" style="max-height: 320px; overflow-y: auto;">
                                <!-- Pending list -->
                                <div class="mb-4">
                                    <span class="text-secondary small font-monospace d-block mb-2">MENUNGGU VERIFIKASI (<?php echo count($pending_verifications); ?>)</span>
                                    <?php if (count($pending_verifications) > 0): ?>
                                        <?php foreach ($pending_verifications as $pv): ?>
                                            <div class="d-flex align-items-center justify-content-between p-2 mb-2 bg-dark bg-opacity-20 border border-secondary border-opacity-10 rounded">
                                                <div>
                                                    <h6 class="text-white small fw-bold mb-0"><?php echo htmlspecialchars($pv['nama_guru']); ?></h6>
                                                    <span class="text-secondary" style="font-size: 10px;"><i class="fa-regular fa-calendar me-1"></i> Jurnal Tanggal: <?php echo date('d-m-Y', strtotime($pv['tanggal'])); ?></span>
                                                </div>
                                                <a href="<?php echo $base_url; ?>modules/jurnal/verifikasi.php?id=<?php echo $pv['id']; ?>" class="btn btn-xs btn-gold text-dark fw-bold" style="font-size: 11px;"><i class="fa-solid fa-file-signature me-1"></i> Periksa</a>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <p class="text-success small bg-success bg-opacity-10 border border-success border-opacity-20 p-2 rounded text-center"><i class="fa-solid fa-circle-check me-1"></i> Semua jurnal telah diverifikasi!</p>
                                    <?php endif; ?>
                                </div>

                                <!-- Revisions list -->
                                <div>
                                    <span class="text-secondary small font-monospace d-block mb-2">DALAM REVISI GURU (<?php echo count($revision_alerts); ?>)</span>
                                    <?php if (count($revision_alerts) > 0): ?>
                                        <?php foreach ($revision_alerts as $ra): ?>
                                            <div class="d-flex align-items-start gap-2 p-2 mb-2 bg-danger bg-opacity-5 border border-danger border-opacity-10 rounded">
                                                <div class="text-danger mt-0.5"><i class="fa-solid fa-triangle-exclamation" style="font-size: 12px;"></i></div>
                                                <div class="flex-grow-1">
                                                    <div class="d-flex justify-content-between">
                                                        <h6 class="text-white small fw-bold mb-0"><?php echo htmlspecialchars($ra['nama_guru']); ?></h6>
                                                        <span class="text-secondary" style="font-size: 9px;"><?php echo date('d-m-Y', strtotime($ra['tanggal'])); ?></span>
                                                    </div>
                                                    <p class="text-secondary small mb-0 font-italic" style="font-size: 10.5px;">Catatan: "<?php echo htmlspecialchars($ra['catatan']); ?>"</p>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <p class="text-secondary small text-center py-2">Tidak ada jurnal yang berstatus revisi.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Right Column: Announcements & Agenda -->
                <div class="col-12 <?php echo has_role('Kepala Sekolah') ? 'col-lg-6' : ''; ?>">
                    <div class="row g-4">
                        <div class="col-12 <?php echo has_role('Kepala Sekolah') ? '' : 'col-md-6'; ?>">
                            <div class="glass-card mb-0">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <h6 class="text-gold fw-bold mb-0"><i class="fa-solid fa-bullhorn me-2"></i> Pengumuman Terbaru</h6>
                                    <a href="<?php echo $base_url; ?>modules/pengumuman/index.php" class="btn btn-xs btn-outline-custom text-gold">Lihat Semua</a>
                                </div>
                                <div class="announcement-list">
                                    <?php if (count($announcements) > 0): ?>
                                        <?php foreach ($announcements as $ann): ?>
                                            <div class="pb-2 mb-2 border-bottom border-secondary border-opacity-10">
                                                <h6 class="text-white fw-bold mb-1" style="font-size: 13px;"><?php echo htmlspecialchars($ann['judul']); ?></h6>
                                                <p class="text-secondary small mb-1 text-truncate"><?php echo strip_tags($ann['isi']); ?></p>
                                                <div class="d-flex justify-content-between text-secondary" style="font-size: 9px;">
                                                    <span><i class="fa-solid fa-calendar-days me-1"></i> <?php echo date('d M Y', strtotime($ann['tanggal'])); ?></span>
                                                    <span><i class="fa-solid fa-pen-nib me-1"></i> <?php echo htmlspecialchars($ann['nama'] ?? 'Admin'); ?></span>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <p class="text-secondary small py-2 text-center">Belum ada pengumuman sekolah.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 <?php echo has_role('Kepala Sekolah') ? '' : 'col-md-6'; ?>">
                            <div class="glass-card mb-0">
                                <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-calendar-check me-2"></i> Agenda & Kalender Akademik</h6>
                                <div class="agenda-list">
                                    <div class="d-flex align-items-start gap-3 mb-2.5">
                                        <div class="bg-gold text-dark rounded px-2 py-0.5 text-center font-monospace" style="font-size: 10px; font-weight: 700; min-width: 46px;">08 JUN</div>
                                        <div>
                                            <h6 class="text-white fw-semibold mb-0" style="font-size: 13px;">Penilaian Akhir Semester (PAS) Genap</h6>
                                            <span class="text-secondary small">08 - 13 Juni 2026</span>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start gap-3 mb-2.5">
                                        <div class="bg-gold text-dark rounded px-2 py-0.5 text-center font-monospace" style="font-size: 10px; font-weight: 700; min-width: 46px;">20 JUN</div>
                                        <div>
                                            <h6 class="text-white fw-semibold mb-0" style="font-size: 13px;">Pembagian Rapor Semester Genap & Pensi</h6>
                                            <span class="text-secondary small">20 Juni 2026</span>
                                        </div>
                                    </div>
                                    <div class="d-flex align-items-start gap-3">
                                        <div class="bg-gold text-dark rounded px-2 py-0.5 text-center font-monospace" style="font-size: 10px; font-weight: 700; min-width: 46px;">06 JUL</div>
                                        <div>
                                            <h6 class="text-white fw-semibold mb-0" style="font-size: 13px;">Hari Pertama Masuk Sekolah Ajaran Baru</h6>
                                            <span class="text-secondary small">Tahun Pelajaran 2026/2027</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tab 2: Statistik Sekolah & Aset (Original Metrics) -->
        <div class="tab-pane fade" id="school-content" role="tabpanel" aria-labelledby="school-tab">
            <!-- School Stats KPI Grid -->
            <div class="row g-3 mb-4">
                <!-- Total Siswa Aktif -->
                <div class="col-6 col-sm-4 col-lg-2">
                    <div class="glass-card kpi-card p-3 mb-0 h-100">
                        <div class="kpi-icon blue mb-2"><i class="fa-solid fa-user-graduate"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1" style="font-size: 11px;">Siswa Aktif</span>
                            <h4 class="fw-bold mb-0 text-theme-primary" style="color: var(--text-primary);"><?php echo $total_siswa; ?></h4>
                        </div>
                    </div>
                </div>
                <!-- Kelas Aktif -->
                <div class="col-6 col-sm-4 col-lg-2">
                    <div class="glass-card kpi-card p-3 mb-0 h-100">
                        <div class="kpi-icon purple mb-2"><i class="fa-solid fa-school"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1" style="font-size: 11px;">Kelas Aktif</span>
                            <h4 class="fw-bold mb-0 text-theme-primary" style="color: var(--text-primary);"><?php echo $total_kelas_aktif; ?></h4>
                        </div>
                    </div>
                </div>
                <!-- Wali Kelas -->
                <div class="col-6 col-sm-4 col-lg-2">
                    <div class="glass-card kpi-card p-3 mb-0 h-100">
                        <div class="kpi-icon success mb-2"><i class="fa-solid fa-chalkboard-user"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1" style="font-size: 11px;">Wali Kelas</span>
                            <h4 class="fw-bold mb-0 text-theme-primary" style="color: var(--text-primary);"><?php echo $total_wali_kelas; ?></h4>
                        </div>
                    </div>
                </div>
                <!-- Kapasitas Terisi -->
                <div class="col-6 col-sm-4 col-lg-2">
                    <div class="glass-card kpi-card p-3 mb-0 h-100">
                        <div class="kpi-icon gold mb-2"><i class="fa-solid fa-users"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1" style="font-size: 11px;">Kapasitas Terisi</span>
                            <h4 class="fw-bold mb-0 text-gold"><?php echo $capacity_filled_percent; ?>%</h4>
                            <span class="text-secondary font-monospace" style="font-size: 9px;"><?php echo "$total_siswa / $total_kapasitas"; ?></span>
                        </div>
                    </div>
                </div>
                <!-- Kelas Terbesar -->
                <div class="col-6 col-sm-4 col-lg-2">
                    <div class="glass-card kpi-card p-3 mb-0 h-100">
                        <div class="kpi-icon warning mb-2"><i class="fa-solid fa-arrow-trend-up"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1" style="font-size: 11px;">Kelas Terbesar</span>
                            <h4 class="fw-bold mb-0 text-warning" style="font-size: 1.15rem;"><?php echo htmlspecialchars($romanize_class_name($largest_class)); ?></h4>
                            <span class="text-secondary font-monospace" style="font-size: 9px;"><?php echo $largest_class_count; ?> Siswa</span>
                        </div>
                    </div>
                </div>
                <!-- Kelas Terkecil -->
                <div class="col-6 col-sm-4 col-lg-2">
                    <div class="glass-card kpi-card p-3 mb-0 h-100">
                        <div class="kpi-icon danger mb-2"><i class="fa-solid fa-arrow-trend-down"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1" style="font-size: 11px;">Kelas Terkecil</span>
                            <h4 class="fw-bold mb-0 text-danger" style="font-size: 1.15rem;"><?php echo htmlspecialchars($romanize_class_name($smallest_class)); ?></h4>
                            <span class="text-secondary font-monospace" style="font-size: 9px;"><?php echo $smallest_class_count; ?> Siswa</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts Row 1 -->
            <div class="row g-4 mb-4">
                <!-- Statistik Per Kelas Bar Chart -->
                <div class="col-12 col-lg-6">
                    <div class="glass-card h-100 mb-0">
                        <h6 class="text-theme-primary fw-bold mb-3" style="color: var(--text-primary);"><i class="fa-solid fa-chart-bar text-gold me-2"></i> Statistik Siswa Per Kelas</h6>
                        <div style="position: relative; height: 260px;">
                            <canvas id="classStatsChart"></canvas>
                        </div>
                    </div>
                </div>
                <!-- Statistik Per Tingkat Bar Chart -->
                <div class="col-12 col-lg-6">
                    <div class="glass-card h-100 mb-0">
                        <h6 class="text-theme-primary fw-bold mb-3" style="color: var(--text-primary);"><i class="fa-solid fa-chart-bar text-gold me-2"></i> Statistik Siswa Per Tingkat (Level)</h6>
                        <div style="position: relative; height: 260px;">
                            <canvas id="tingkatStatsChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts Row 2 -->
            <div class="row g-4 mb-4">
                <!-- Statistik Asal Sekolah & Gender -->
                <div class="col-12 col-lg-6">
                    <div class="glass-card h-100 mb-0">
                        <h6 class="text-theme-primary fw-bold mb-3" style="color: var(--text-primary);"><i class="fa-solid fa-chart-pie text-gold me-2"></i> Asal Sekolah & Gender Siswa</h6>
                        <div class="row g-2 align-items-center">
                            <div class="col-6">
                                <div style="position: relative; height: 240px;">
                                    <canvas id="genderChart"></canvas>
                                </div>
                            </div>
                            <div class="col-6">
                                <div style="position: relative; height: 240px;">
                                    <canvas id="originChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Kondisi Aset -->
                <div class="col-12 col-lg-6">
                    <div class="glass-card h-100 mb-0">
                        <h6 class="text-theme-primary fw-bold mb-3" style="color: var(--text-primary);"><i class="fa-solid fa-clipboard-list text-gold me-2"></i> Kondisi Aset Inventaris</h6>
                        <div style="position: relative; height: 240px;">
                            <canvas id="conditionChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts Row 3 -->
            <div class="row g-4 mb-4">
                <!-- Kategori Barang -->
                <div class="col-12">
                    <div class="glass-card h-100 mb-0">
                        <h6 class="text-theme-primary fw-bold mb-3" style="color: var(--text-primary);"><i class="fa-solid fa-boxes-stacked text-gold me-2"></i> Kategori Barang Inventaris</h6>
                        <div style="position: relative; height: 240px;">
                            <canvas id="categoryChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tab 3: Analisis & Nilai Siswa -->
        <div class="tab-pane fade" id="grades-content" role="tabpanel" aria-labelledby="grades-tab">
            <!-- Grades KPI Grid -->
            <div class="row g-3 mb-4">
                <!-- Rata-rata Nilai -->
                <div class="col-6 col-sm-4 col-lg-3">
                    <div class="glass-card kpi-card p-3 mb-0 h-100 position-relative overflow-hidden">
                        <div class="kpi-icon blue mb-2"><i class="fa-solid fa-graduation-cap"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1" style="font-size: 11px;">Rata-Rata Nilai</span>
                            <h4 class="fw-bold mb-0 text-theme-primary" style="color: var(--text-primary);"><?php echo $avg_grade_school; ?></h4>
                            <span class="badge bg-gold bg-opacity-10 text-gold font-monospace mt-1" style="font-size: 9px;">Target KKM: 75</span>
                        </div>
                    </div>
                </div>
                <!-- Persentase Kelulusan KKM -->
                <div class="col-6 col-sm-4 col-lg-3">
                    <div class="glass-card kpi-card p-3 mb-0 h-100 position-relative overflow-hidden">
                        <div class="kpi-icon success mb-2"><i class="fa-solid fa-award"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1" style="font-size: 11px;">Tuntas KKM</span>
                            <h4 class="fw-bold mb-0 text-success"><?php echo $passing_percent; ?>%</h4>
                            <span class="badge bg-success bg-opacity-10 text-success font-monospace mt-1" style="font-size: 9px;">Tingkat Kelulusan</span>
                        </div>
                    </div>
                </div>
                <!-- Nilai Tertinggi -->
                <div class="col-6 col-sm-4 col-lg-3">
                    <div class="glass-card kpi-card p-3 mb-0 h-100 position-relative overflow-hidden">
                        <div class="kpi-icon gold mb-2"><i class="fa-solid fa-star text-gold"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1" style="font-size: 11px;">Nilai Tertinggi</span>
                            <h4 class="fw-bold mb-0 text-gold"><?php echo $highest_grade; ?></h4>
                            <span class="badge bg-gold bg-opacity-10 text-gold font-monospace mt-1" style="font-size: 9px;">Sempurna</span>
                        </div>
                    </div>
                </div>
                <!-- Nilai Terendah -->
                <div class="col-6 col-sm-4 col-lg-3">
                    <div class="glass-card kpi-card p-3 mb-0 h-100 position-relative overflow-hidden">
                        <div class="kpi-icon danger mb-2"><i class="fa-solid fa-circle-down text-danger"></i></div>
                        <div>
                            <span class="text-secondary small d-block mb-1" style="font-size: 11px;">Nilai Terendah</span>
                            <h4 class="fw-bold mb-0 text-danger"><?php echo $lowest_grade; ?></h4>
                            <span class="badge bg-danger bg-opacity-10 text-danger font-monospace mt-1" style="font-size: 9px;">Butuh Evaluasi</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="row g-4 mb-4">
                <!-- Rata-rata Nilai Per Mata Pelajaran Bar Chart -->
                <div class="col-12 col-lg-8">
                    <div class="glass-card h-100 mb-0">
                        <h6 class="text-theme-primary fw-bold mb-3" style="color: var(--text-primary);"><i class="fa-solid fa-chart-column text-gold me-2"></i> Rata-Rata Nilai Per Mata Pelajaran</h6>
                        <div style="position: relative; height: 300px;">
                            <canvas id="subjectGradesChart"></canvas>
                        </div>
                    </div>
                </div>
                <!-- Distribusi Nilai Doughnut Chart -->
                <div class="col-12 col-lg-4">
                    <div class="glass-card h-100 mb-0">
                        <h6 class="text-theme-primary fw-bold mb-3" style="color: var(--text-primary);"><i class="fa-solid fa-chart-pie text-gold me-2"></i> Distribusi Grade Nilai</h6>
                        <div style="position: relative; height: 240px; margin-bottom: 20px;">
                            <canvas id="gradesDistributionChart"></canvas>
                        </div>
                        <div class="d-flex justify-content-around text-center small text-secondary">
                            <div>
                                <span class="d-block fw-bold text-success" style="font-size:14px;"><?php echo $distribution['A']; ?></span>
                                <span>Grade A (≥90)</span>
                            </div>
                            <div>
                                <span class="d-block fw-bold text-info" style="font-size:14px;"><?php echo $distribution['B']; ?></span>
                                <span>Grade B (80-89)</span>
                            </div>
                            <div>
                                <span class="d-block fw-bold text-warning" style="font-size:14px;"><?php echo $distribution['C']; ?></span>
                                <span>Grade C (70-79)</span>
                            </div>
                            <div>
                                <span class="d-block fw-bold text-danger" style="font-size:14px;"><?php echo $distribution['D']; ?></span>
                                <span>Grade D (&lt;70)</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- List Row -->
            <div class="row g-4">
                <!-- Top 5 Siswa Berprestasi -->
                <div class="col-12">
                    <div class="glass-card mb-0">
                        <h6 class="text-gold fw-bold mb-3"><i class="fa-solid fa-crown me-2 animate-bounce"></i> Top 5 Siswa Berprestasi Akademik (Rata-Rata Tertinggi)</h6>
                        <div class="table-responsive">
                            <table class="table table-custom mb-0">
                                <thead>
                                    <tr>
                                        <th style="width: 80px; text-align: center;">Peringkat</th>
                                        <th>Nama Siswa (Kelas)</th>
                                        <th style="width: 150px; text-align: center;">Rata-Rata Nilai</th>
                                        <th style="width: 150px; text-align: center;">Predikat</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (count($top_students) > 0): ?>
                                        <?php $rank = 1; foreach ($top_students as $name => $avg): ?>
                                            <tr style="transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.005)';" onmouseout="this.style.transform='none';">
                                                <td align="center">
                                                    <?php if ($rank === 1): ?>
                                                        <span class="badge bg-gold text-dark fw-bold rounded-circle p-2" style="width: 28px; height: 28px; display: flex; align-items: center; justify-content: center;"><i class="fa-solid fa-trophy"></i></span>
                                                    <?php elseif ($rank === 2): ?>
                                                        <span class="badge bg-light text-dark fw-bold rounded-circle p-2" style="width: 28px; height: 28px; display: flex; align-items: center; justify-content: center;"><i class="fa-solid fa-medal"></i></span>
                                                    <?php elseif ($rank === 3): ?>
                                                        <span class="badge bg-warning text-dark fw-bold rounded-circle p-2" style="width: 28px; height: 28px; display: flex; align-items: center; justify-content: center;"><i class="fa-solid fa-medal"></i></span>
                                                    <?php else: ?>
                                                        <span class="text-secondary fw-bold" style="font-size: 14px;"><?php echo $rank; ?></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><strong class="text-white"><?php echo htmlspecialchars($name); ?></strong></td>
                                                <td align="center"><strong class="text-gold" style="font-size: 16px;"><?php echo number_format($avg, 1); ?></strong></td>
                                                <td align="center">
                                                    <?php if ($avg >= 90): ?>
                                                        <span class="badge bg-success">Sangat Baik</span>
                                                    <?php elseif ($avg >= 80): ?>
                                                        <span class="badge bg-info">Baik</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-warning text-dark">Cukup</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php $rank++; endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="4" class="text-center text-secondary py-3">Belum ada data nilai siswa untuk dianalisis.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php endif; ?>

<!-- Chart Script Configurations -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    const isLight = document.body.classList.contains('light-theme');
    const textColor = isLight ? '#64748b' : '#94A3B8';
    const gridColor = isLight ? 'rgba(0, 0, 0, 0.05)' : 'rgba(255, 255, 255, 0.05)';
    
    // Safely initialize chart if element exists
    const initChart = (id, config) => {
        const el = document.getElementById(id);
        if (el) {
            return new Chart(el.getContext('2d'), config);
        }
        return null;
    };
    
    // 1. Personal KBM Chart (Guru Dashboard Only)
    const personalKbmChartObj = initChart('personalKbmChart', {
        type: 'line',
        data: {
            labels: <?php echo json_encode($personal_kbm_labels ?? []); ?>,
            datasets: [{
                label: 'JP Diajar',
                data: <?php echo json_encode($personal_kbm_values ?? []); ?>,
                borderColor: '#D4AF37',
                backgroundColor: 'rgba(212, 175, 55, 0.08)',
                borderWidth: 2,
                fill: true,
                tension: 0.3,
                pointBackgroundColor: '#D4AF37'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { 
                    grid: { color: gridColor }, 
                    ticks: { color: textColor, stepSize: 1 } 
                },
                x: { 
                    grid: { display: false }, 
                    ticks: { color: textColor } 
                }
            }
        }
    });

    // 2. Monthly KBM Stats Chart (Admin/Kepsek Dashboard Only)
    const monthlyKbmChartObj = initChart('monthlyKbmChart', {
        type: 'line',
        data: {
            labels: <?php echo json_encode($monthly_kbm_labels ?? []); ?>,
            datasets: [{
                label: 'Total JP Diajar',
                data: <?php echo json_encode($monthly_kbm_values ?? []); ?>,
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.08)',
                borderWidth: 2,
                fill: true,
                tension: 0.3,
                pointBackgroundColor: '#10b981'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { 
                    grid: { color: gridColor }, 
                    ticks: { color: textColor, stepSize: 5 } 
                },
                x: { 
                    grid: { display: false }, 
                    ticks: { color: textColor } 
                }
            }
        }
    });

    // 3. Top Active Teachers Bar Chart (Admin/Kepsek Dashboard Only)
    const topTeachersChartObj = initChart('topTeachersChart', {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($top_teachers_labels ?? []); ?>,
            datasets: [{
                label: 'Total Jurnal',
                data: <?php echo json_encode($top_teachers_values ?? []); ?>,
                backgroundColor: '#3b82f6',
                borderRadius: 4,
                barThickness: 16
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: { 
                    grid: { color: gridColor }, 
                    ticks: { color: textColor, stepSize: 1 } 
                },
                y: { 
                    grid: { display: false }, 
                    ticks: { color: textColor } 
                }
            }
        }
    });

    // 4. Completion Rate Share Chart (Admin/Kepsek Dashboard Only)
    const completionChartObj = initChart('completionChart', {
        type: 'doughnut',
        data: {
            labels: ['Disetujui', 'Revisi', 'Belum Diverif'],
            datasets: [{
                data: [
                    <?php echo $total_jurnal_disetujui_all ?? 0; ?>,
                    <?php echo $total_jurnal_revisi_all ?? 0; ?>,
                    <?php echo $total_jurnal_belum_verif ?? 0; ?>
                ],
                backgroundColor: ['#10b981', '#ef4444', '#f59e0b'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: {
                    position: 'top',
                    labels: { color: textColor, font: { family: 'Outfit', size: 10 } }
                }
            }
        }
    });

    // 5. Statistik Per Kelas (Bar Chart)
    const classStatsChartObj = initChart('classStatsChart', {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($class_labels ?? []); ?>,
            datasets: [{
                label: 'Jumlah Siswa',
                data: <?php echo json_encode($class_values ?? []); ?>,
                backgroundColor: '#3b82f6',
                borderRadius: 4,
                barThickness: 28
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { 
                    grid: { color: gridColor }, 
                    ticks: { color: textColor, stepSize: 5 } 
                },
                x: { 
                    grid: { display: false }, 
                    ticks: { color: textColor } 
                }
            }
        }
    });

    // 5b. Statistik Per Tingkat (Bar Chart)
    const tingkatStatsChartObj = initChart('tingkatStatsChart', {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($tingkat_labels ?? []); ?>,
            datasets: [{
                label: 'Jumlah Siswa',
                data: <?php echo json_encode($tingkat_values ?? []); ?>,
                backgroundColor: '#10b981',
                borderRadius: 4,
                barThickness: 28
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { 
                    grid: { color: gridColor }, 
                    ticks: { color: textColor, stepSize: 5 } 
                },
                x: { 
                    grid: { display: false }, 
                    ticks: { color: textColor } 
                }
            }
        }
    });

    // 6. Gender Chart (Doughnut)
    const genderChartObj = initChart('genderChart', {
        type: 'doughnut',
        data: {
            labels: ['Laki-laki', 'Perempuan'],
            datasets: [{
                data: [<?php echo $total_laki_laki ?? 0; ?>, <?php echo $total_perempuan ?? 0; ?>],
                backgroundColor: ['#3b82f6', '#f43f5e'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: {
                    position: 'top',
                    labels: { color: textColor, font: { family: 'Outfit', size: 11 } }
                }
            }
        }
    });

    // 7. Asal Sekolah Chart (Pie)
    const originChartObj = initChart('originChart', {
        type: 'pie',
        data: {
            labels: <?php echo json_encode($origin_labels ?? []); ?>,
            datasets: [{
                data: <?php echo json_encode($origin_values ?? []); ?>,
                backgroundColor: ['#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: { color: textColor, font: { family: 'Outfit', size: 10 } }
                }
            }
        }
    });

    // 8. Kondisi Aset Chart (Pie)
    const conditionChartObj = initChart('conditionChart', {
        type: 'pie',
        data: {
            labels: <?php echo json_encode($cond_labels ?? []); ?>,
            datasets: [{
                data: <?php echo json_encode($cond_values ?? []); ?>,
                backgroundColor: ['#10b981', '#f59e0b', '#ef4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: { color: textColor, font: { family: 'Outfit', size: 10 } }
                }
            }
        }
    });

    // 9. Kategori Barang Chart (Bar)
    const categoryChartObj = initChart('categoryChart', {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($cat_labels ?? []); ?>,
            datasets: [{
                label: 'Jumlah Barang',
                data: <?php echo json_encode($cat_values ?? []); ?>,
                backgroundColor: '#8b5cf6',
                borderRadius: 4,
                barThickness: 24
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { 
                    grid: { color: gridColor }, 
                    ticks: { color: textColor, stepSize: 5 } 
                },
                x: { 
                    grid: { display: false }, 
                    ticks: { color: textColor } 
                }
            }
        }
    });

    // 10. Subject Grades Chart (Bar Chart)
    const subjectGradesChartObj = initChart('subjectGradesChart', {
        type: 'bar',
        data: {
            labels: <?php echo json_encode(array_keys($subject_averages ?? [])); ?>,
            datasets: [{
                label: 'Rata-Rata Nilai',
                data: <?php echo json_encode(array_values($subject_averages ?? [])); ?>,
                backgroundColor: 'rgba(212, 175, 55, 0.85)',
                hoverBackgroundColor: '#F3CD48',
                borderColor: '#D4AF37',
                borderWidth: 1,
                borderRadius: 6,
                barThickness: 28
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { 
                    grid: { color: gridColor }, 
                    ticks: { color: textColor },
                    min: 0,
                    max: 100
                },
                x: { 
                    grid: { display: false }, 
                    ticks: { color: textColor } 
                }
            }
        }
    });

    // 11. Grades Distribution Chart (Doughnut Chart)
    const gradesDistributionChartObj = initChart('gradesDistributionChart', {
        type: 'doughnut',
        data: {
            labels: ['Grade A', 'Grade B', 'Grade C', 'Grade D'],
            datasets: [{
                data: [
                    <?php echo $distribution['A'] ?? 0; ?>,
                    <?php echo $distribution['B'] ?? 0; ?>,
                    <?php echo $distribution['C'] ?? 0; ?>,
                    <?php echo $distribution['D'] ?? 0; ?>
                ],
                backgroundColor: ['#10b981', '#06b6d4', '#f59e0b', '#ef4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%',
            plugins: {
                legend: { display: false }
            }
        }
    });

    // Recalculate/resize charts when tabs are toggled to prevent collapsed width bugs
    const schoolTabEl = document.getElementById('school-tab');
    if (schoolTabEl) {
        schoolTabEl.addEventListener('shown.bs.tab', () => {
            if (classStatsChartObj) classStatsChartObj.resize();
            if (tingkatStatsChartObj) tingkatStatsChartObj.resize();
            if (genderChartObj) genderChartObj.resize();
            if (originChartObj) originChartObj.resize();
            if (conditionChartObj) conditionChartObj.resize();
            if (categoryChartObj) categoryChartObj.resize();
        });
    }

    const jurnalTabEl = document.getElementById('jurnal-tab');
    if (jurnalTabEl) {
        jurnalTabEl.addEventListener('shown.bs.tab', () => {
            if (monthlyKbmChartObj) monthlyKbmChartObj.resize();
            if (topTeachersChartObj) topTeachersChartObj.resize();
            if (completionChartObj) completionChartObj.resize();
        });
    }

    const gradesTabEl = document.getElementById('grades-tab');
    if (gradesTabEl) {
        gradesTabEl.addEventListener('shown.bs.tab', () => {
            if (subjectGradesChartObj) subjectGradesChartObj.resize();
            if (gradesDistributionChartObj) gradesDistributionChartObj.resize();
        });
    }
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
