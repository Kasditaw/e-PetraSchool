<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\laporan\index.php

$page_title = 'Laporan Sekolah';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';

try {
    $teachers = $pdo->query("SELECT id, nama_guru, nip FROM guru ORDER BY nama_guru ASC")->fetchAll();
    $classes = $pdo->query("SELECT id, nama_kelas FROM kelas ORDER BY nama_kelas ASC")->fetchAll();
    $subjects = $pdo->query("SELECT id, nama_mapel, kode_mapel FROM mata_pelajaran WHERE status = 'Aktif' ORDER BY nama_mapel ASC")->fetchAll();
    $semesters = $pdo->query("SELECT id, semester FROM semester ORDER BY semester ASC")->fetchAll();
    $academic_years = $pdo->query("SELECT id, tahun_ajaran, status FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();
    $students = $pdo->query("SELECT id, nis, nama_lengkap FROM siswa ORDER BY nama_lengkap ASC")->fetchAll();
} catch (Exception $e) {
    $teachers = [];
    $classes = [];
    $subjects = [];
    $semesters = [];
    $academic_years = [];
    $students = [];
}
?>

<div class="glass-card">
    <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-file-invoice-dollar me-2"></i> Pusat Unduh Laporan & Ekspor Data</h5>
    <p class="text-secondary small mb-4">Unduh seluruh laporan administrasi sekolah dalam format Microsoft Excel (.xls) atau cetak ke PDF.</p>

    <div class="row g-4">
        <!-- 1. Laporan Siswa -->
        <div class="col-12 col-md-6 col-lg-4" id="card-siswa">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-user-graduate me-2 text-gold"></i> Laporan Data Siswa</h6>
                    <p class="text-secondary small mb-2">Seluruh data identitas siswa aktif, NIS, NISN, rombel kelas, nama orang tua, and status siswa.</p>
                    <div class="row g-2 mb-3">
                        <div class="col-12">
                            <select id="filter_siswa_kelas" class="form-select form-control-custom bg-dark-select text-white py-1 small">
                                <option value="">-- Semua Kelas --</option>
                                <?php foreach ($classes as $c): ?>
                                    <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['nama_kelas']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12">
                            <select id="filter_siswa_status" class="form-select form-control-custom bg-dark-select text-white py-1 small">
                                <option value="">-- Semua Status --</option>
                                <option value="Aktif">Aktif</option>
                                <option value="Alumni">Alumni</option>
                                <option value="Pindahan">Pindahan</option>
                                <option value="Keluar">Keluar</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" onclick="unduhLaporanSiswa('print')" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> Cetak PDF</button>
                    <button type="button" onclick="unduhLaporanSiswa('export')" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</button>
                </div>
            </div>
        </div>

        <!-- 2. Laporan Guru -->
        <div class="col-12 col-md-6 col-lg-4" id="card-guru">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-chalkboard-user me-2 text-gold"></i> Laporan Data Guru</h6>
                    <p class="text-secondary small mb-3">Informasi NIP guru, riwayat pendidikan terakhir, jabatan penugasan, dan mata pelajaran diajar.</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="print.php?type=guru" target="_blank" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> Cetak PDF</a>
                    <a href="export.php?type=guru" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</a>
                </div>
            </div>
        </div>

        <!-- 3. Laporan Karyawan -->
        <div class="col-12 col-md-6 col-lg-4" id="card-karyawan">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-users-gear me-2 text-gold"></i> Laporan Karyawan</h6>
                    <p class="text-secondary small mb-3">Seluruh berkas administrasi staf tata usaha (TU), security, janitor, medis, dan pustakawan.</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="print.php?type=karyawan" target="_blank" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> Cetak PDF</a>
                    <a href="export.php?type=karyawan" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</a>
                </div>
            </div>
        </div>

        <!-- 4. Laporan Aset Inventaris -->
        <div class="col-12 col-md-6 col-lg-4" id="card-inventaris">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-boxes-stacked me-2 text-gold"></i> Laporan Inventaris Aset</h6>
                    <p class="text-secondary small mb-3">Daftar buku induk aset barang, merk, harga perolehan, tanggal beli, sumber dana, dan kondisi aset.</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="print.php?type=inventaris" target="_blank" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> Cetak PDF</a>
                    <a href="export.php?type=inventaris" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</a>
                </div>
            </div>
        </div>

        <!-- 5. Laporan Barang Rusak -->
        <div class="col-12 col-md-6 col-lg-4" id="card-barang-rusak">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-triangle-exclamation me-2 text-gold"></i> Laporan Barang Rusak</h6>
                    <p class="text-secondary small mb-3">Khusus rekapitulasi data barang sarana-prasarana sekolah yang berada dalam kondisi rusak berat.</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="print.php?type=barang_rusak" target="_blank" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> Cetak PDF</a>
                    <a href="export.php?type=barang_rusak" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</a>
                </div>
            </div>
        </div>

        <!-- 6. Laporan Ruangan -->
        <div class="col-12 col-md-6 col-lg-4" id="card-ruangan">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-door-open me-2 text-gold"></i> Laporan Ruangan</h6>
                    <p class="text-secondary small mb-3">Daftar ruangan kelas, laboratorium komputer, perpustakaan, UKS beserta penanggung jawabnya.</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="print.php?type=ruangan" target="_blank" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> Cetak PDF</a>
                    <a href="export.php?type=ruangan" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</a>
                </div>
            </div>
        </div>

        <!-- 7. Laporan Alumni -->
        <div class="col-12 col-md-6 col-lg-4" id="card-alumni">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-award me-2 text-gold"></i> Laporan Data Alumni</h6>
                    <p class="text-secondary small mb-3">Informasi penelusuran lulusan (tracer study), tahun kelulusan, dan instansi pendidikan lanjutan.</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="print.php?type=alumni" target="_blank" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> Cetak PDF</a>
                    <a href="export.php?type=alumni" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</a>
                </div>
            </div>
        </div>

        <!-- 8. Laporan Nilai Siswa -->
        <div class="col-12 col-md-6 col-lg-4" id="card-nilai">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-book-open-reader me-2 text-gold"></i> Laporan Nilai Siswa</h6>
                    <p class="text-secondary small mb-2">Rangkuman nilai rapot per kelas berdasarkan data yang telah diisi pada setiap semester.</p>
                    <div class="row g-2 mb-3">
                        <div class="col-12">
                            <label class="text-secondary" style="font-size:10px; text-transform:uppercase; letter-spacing:.5px; margin-bottom:4px; display:block;">Tahun Ajaran</label>
                            <select id="filter_nilai_ta" class="form-select form-control-custom bg-dark-select text-white py-1 small" onchange="refreshKelasRaport()">
                                <?php foreach ($academic_years as $a): ?>
                                    <option value="<?php echo htmlspecialchars($a['tahun_ajaran']); ?>" <?php echo $a['status'] === 'Aktif' ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($a['tahun_ajaran']); ?> <?php echo $a['status'] === 'Aktif' ? '✓ Aktif' : ''; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="text-secondary" style="font-size:10px; text-transform:uppercase; letter-spacing:.5px; margin-bottom:4px; display:block;">Semester</label>
                            <select id="filter_nilai_semester" class="form-select form-control-custom bg-dark-select text-white py-1 small" onchange="refreshKelasRaport()">
                                <option value="">-- Semua Semester --</option>
                                <option value="1">Semester 1 (Ganjil)</option>
                                <option value="2">Semester 2 (Genap)</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="text-secondary d-flex justify-content-between align-items-center" style="font-size:10px; text-transform:uppercase; letter-spacing:.5px; margin-bottom:4px;">
                                <span>Kelas <span id="nilai_kelas_count_badge" class="badge bg-secondary ms-1" style="font-size:9px; display:none;"></span></span>
                                <span id="nilai_kelas_loading" style="display:none; font-size:10px; color:#D4AF37;"><i class="fa-solid fa-spinner fa-spin"></i></span>
                            </label>
                            <select id="filter_nilai_kelas" class="form-select form-control-custom bg-dark-select text-white py-1 small">
                                <option value="">-- Memuat data kelas... --</option>
                            </select>
                            <div id="nilai_kelas_empty_note" class="text-warning mt-1" style="font-size:10px; display:none;">
                                <i class="fa-solid fa-triangle-exclamation me-1"></i>
                                Belum ada rapot yang diisi untuk filter ini.
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" onclick="unduhLaporanNilai('print')" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> Cetak PDF</button>
                    <button type="button" onclick="unduhLaporanNilai('export')" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</button>
                </div>
            </div>
        </div>

        <!-- Rapor Kurikulum Merdeka -->
        <div class="col-12 col-md-6 col-lg-4" id="card-rapor-siswa">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-file-invoice me-2 text-gold"></i> Rapor Kurikulum Merdeka</h6>
                    <p class="text-secondary small mb-2">Cetak lembar Rapor Kurikulum Merdeka lengkap per siswa per semester beserta deskripsi capaian kompetensi.</p>
                    <div class="row g-2 mb-3">
                        <div class="col-12">
                            <select id="rapor_siswa_id" class="form-select form-control-custom bg-dark-select text-white py-1 small">
                                <option value="">-- Pilih Siswa --</option>
                                <?php foreach ($students as $s): ?>
                                    <option value="<?php echo $s['id']; ?>">[<?php echo htmlspecialchars($s['nis'] ?: '-'); ?>] <?php echo htmlspecialchars($s['nama_lengkap']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12">
                            <select id="rapor_semester" class="form-select form-control-custom bg-dark-select text-white py-1 small">
                                <option value="1">Semester 1 (Ganjil)</option>
                                <option value="2">Semester 2 (Genap)</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" onclick="cetakRaporMerdeka()" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> Cetak Rapor</button>
                </div>
            </div>
        </div>

        <!-- 9. Laporan Peminjaman Aset -->
        <div class="col-12 col-md-6 col-lg-4" id="card-peminjaman">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-handshake-angle me-2 text-gold"></i> Laporan Peminjaman Aset</h6>
                    <p class="text-secondary small mb-3">Rekapitulasi riwayat transaksi peminjaman barang inventaris sekolah oleh guru dan staf.</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="print.php?type=peminjaman" target="_blank" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> Cetak PDF</a>
                    <a href="export.php?type=peminjaman" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</a>
                </div>
            </div>
        </div>

        <!-- 10. Laporan Pengumuman Sekolah -->
        <div class="col-12 col-md-6 col-lg-4" id="card-pengumuman">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-bullhorn me-2 text-gold"></i> Laporan Pengumuman</h6>
                    <p class="text-secondary small mb-3">Daftar arsip pengumuman resmi sekolah, isi publikasi, tanggal terbit, dan penulis dokumen.</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="print.php?type=pengumuman" target="_blank" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> Cetak PDF</a>
                    <a href="export.php?type=pengumuman" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</a>
                </div>
            </div>
        </div>

        <!-- 11. Laporan Audit Log -->
        <?php if (has_role(['Super Admin', 'Kepala Sekolah'])): ?>
        <div class="col-12 col-md-6 col-lg-4" id="card-audit-log">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-clipboard-list me-2 text-gold"></i> Laporan Audit Log</h6>
                    <p class="text-secondary small mb-3">Seluruh rekaman log aktivitas keamanan, manipulasi data, dan sesi autentikasi sistem.</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="print.php?type=audit_log" target="_blank" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> Cetak PDF</a>
                    <a href="export.php?type=audit_log" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</a>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Class History & Mutation Reports Section Title -->
        <div class="col-12 mt-5" id="section-riwayat-mutasi">
            <h6 class="text-gold border-bottom border-secondary border-opacity-25 pb-2 mb-3"><i class="fa-solid fa-clock-rotate-left me-2"></i> Laporan Riwayat, Penempatan & Mutasi Kelas</h6>
            <p class="text-secondary small">Cetak atau ekspor data penempatan kelas siswa, rekapitulasi data tingkat, mutasi masuk/keluar, dan penelusuran histori kelas individu.</p>
        </div>

        <!-- R1. Daftar Siswa per Tingkat -->
        <div class="col-12 col-md-6 col-lg-4" id="card-siswa-tingkat">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-layer-group me-2 text-gold"></i> Siswa per Tingkat</h6>
                    <p class="text-secondary small mb-2">Daftar siswa aktif berdasarkan tingkat kelas (1-6). Berguna untuk pemetaan kapasitas tingkat.</p>
                    <div class="mb-3">
                        <select id="riwayat_tingkat" class="form-select form-control-custom bg-dark-select text-white py-1 small">
                            <option value="">-- Pilih Tingkat --</option>
                            <option value="1">Tingkat 1</option>
                            <option value="2">Tingkat 2</option>
                            <option value="3">Tingkat 3</option>
                            <option value="4">Tingkat 4</option>
                            <option value="5">Tingkat 5</option>
                            <option value="6">Tingkat 6</option>
                        </select>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" onclick="unduhLaporanRiwayat('print', 'siswa_tingkat')" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> PDF</button>
                    <button type="button" onclick="unduhLaporanRiwayat('export', 'siswa_tingkat')" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</button>
                </div>
            </div>
        </div>

        <!-- R2. Rekap Jumlah Siswa per Tahun Ajaran -->
        <div class="col-12 col-md-6 col-lg-4" id="card-rekap-ta">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-calendar-check me-2 text-gold"></i> Rekap Rombel per TA</h6>
                    <p class="text-secondary small mb-2">Rekap total siswa per kelas untuk tahun ajaran tertentu (membandingkan jumlah rombel & kapasitas).</p>
                    <div class="mb-3">
                        <select id="rekap_ta" class="form-select form-control-custom bg-dark-select text-white py-1 small">
                            <option value="">-- Pilih Tahun Ajaran --</option>
                            <?php foreach ($academic_years as $a): ?>
                                <option value="<?php echo $a['id']; ?>"><?php echo htmlspecialchars($a['tahun_ajaran']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" onclick="unduhLaporanRiwayat('print', 'rekap_tahun_ajaran')" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> PDF</button>
                    <button type="button" onclick="unduhLaporanRiwayat('export', 'rekap_tahun_ajaran')" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</button>
                </div>
            </div>
        </div>

        <!-- R3. Laporan Mutasi Siswa -->
        <div class="col-12 col-md-6 col-lg-4" id="card-mutasi">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-right-from-bracket me-2 text-gold"></i> Laporan Mutasi Siswa</h6>
                    <p class="text-secondary small mb-2">Daftar siswa yang masuk sebagai pindahan, keluar sebelum lulus, atau dikeluarkan pada tahun ajaran terpilih.</p>
                    <div class="mb-3">
                        <select id="mutasi_ta" class="form-select form-control-custom bg-dark-select text-white py-1 small">
                            <option value="">Semua Tahun Ajaran</option>
                            <?php foreach ($academic_years as $a): ?>
                                <option value="<?php echo $a['id']; ?>"><?php echo htmlspecialchars($a['tahun_ajaran']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" onclick="unduhLaporanRiwayat('print', 'mutasi')" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> PDF</button>
                    <button type="button" onclick="unduhLaporanRiwayat('export', 'mutasi')" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</button>
                </div>
            </div>
        </div>

        <!-- R4. Laporan Alumni per Angkatan -->
        <div class="col-12 col-md-6 col-lg-4" id="card-alumni-angkatan">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-graduation-cap me-2 text-gold"></i> Alumni per Angkatan</h6>
                    <p class="text-secondary small mb-2">Daftar siswa yang telah lulus (status Alumni) berdasarkan tahun kelulusan/angkatan.</p>
                    <div class="mb-3">
                        <select id="alumni_ta" class="form-select form-control-custom bg-dark-select text-white py-1 small">
                            <option value="">-- Pilih Tahun Lulus --</option>
                            <?php foreach ($academic_years as $a): ?>
                                <option value="<?php echo $a['id']; ?>"><?php echo htmlspecialchars($a['tahun_ajaran']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" onclick="unduhLaporanRiwayat('print', 'alumni_angkatan')" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> PDF</button>
                    <button type="button" onclick="unduhLaporanRiwayat('export', 'alumni_angkatan')" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</button>
                </div>
            </div>
        </div>

        <!-- R5. Histori Kelas Siswa -->
        <div class="col-12 col-md-6 col-lg-4" id="card-histori-siswa">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-timeline me-2 text-gold"></i> Histori Kelas Siswa</h6>
                    <p class="text-secondary small mb-2">Cari siswa untuk melihat riwayat kelas, wali kelas, dan status kenaikan kelas dari tahun ke tahun.</p>
                    <div class="mb-3">
                        <select id="histori_siswa_id" class="form-select form-control-custom bg-dark-select text-white py-1 small select2-siswa">
                            <option value="">-- Cari/Pilih Siswa --</option>
                            <?php foreach ($students as $s): ?>
                                <option value="<?php echo $s['id']; ?>">[<?php echo htmlspecialchars($s['nis'] ?: '-'); ?>] <?php echo htmlspecialchars($s['nama_lengkap']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" onclick="unduhLaporanRiwayat('print', 'histori_siswa')" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> PDF</button>
                    <button type="button" onclick="unduhLaporanRiwayat('export', 'histori_siswa')" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</button>
                </div>
            </div>
        </div>

        <!-- e-Jurnal Section Title -->
        <div class="col-12 mt-5" id="section-jurnal">
            <h6 class="text-gold border-bottom border-secondary border-opacity-25 pb-2 mb-3"><i class="fa-solid fa-journal-whills me-2"></i> Laporan e-Jurnal Mengajar Guru</h6>
            <p class="text-secondary small">Gunakan panel filter di bawah ini untuk memilih kriteria laporan harian, bulanan, atau semester sebelum melakukan cetak PDF atau ekspor Excel.</p>
        </div>

        <div class="col-12">
            <div class="glass-card mb-4" style="background: rgba(18, 28, 54, 0.15);">
                <form id="filter-jurnal-form" class="row g-3">
                    <div class="col-12 col-sm-6 col-md-3">
                        <label class="form-label form-label-custom">Guru Pengajar</label>
                        <select name="filter_guru" id="filter_guru" class="form-select form-control-custom bg-dark-select text-white">
                            <option value="">Semua Guru</option>
                            <?php foreach ($teachers as $t): ?>
                                <option value="<?php echo $t['id']; ?>"><?php echo htmlspecialchars($t['nama_guru']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-12 col-sm-6 col-md-3">
                        <label class="form-label form-label-custom">Kelas</label>
                        <select name="filter_kelas" id="filter_kelas" class="form-select form-control-custom bg-dark-select text-white">
                            <option value="">Semua Kelas</option>
                            <?php foreach ($classes as $c): ?>
                                <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['nama_kelas']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-12 col-sm-6 col-md-3">
                        <label class="form-label form-label-custom">Mata Pelajaran</label>
                        <select name="filter_mapel" id="filter_mapel" class="form-select form-control-custom bg-dark-select text-white">
                            <option value="">Semua Mapel</option>
                            <?php foreach ($subjects as $s): ?>
                                <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['nama_mapel']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-12 col-sm-6 col-md-3">
                        <label class="form-label form-label-custom">Tahun Ajaran</label>
                        <select name="filter_ta" id="filter_ta" class="form-select form-control-custom bg-dark-select text-white">
                            <option value="">Semua Tahun</option>
                            <?php foreach ($academic_years as $a): ?>
                                <option value="<?php echo $a['id']; ?>"><?php echo htmlspecialchars($a['tahun_ajaran']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-12 col-sm-6 col-md-3">
                        <label class="form-label form-label-custom">Semester</label>
                        <select name="filter_semester" id="filter_semester" class="form-select form-control-custom bg-dark-select text-white">
                            <option value="">Semua Semester</option>
                            <?php foreach ($semesters as $s): ?>
                                <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['semester']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-12 col-sm-6 col-md-3">
                        <label class="form-label form-label-custom">Bulan (Laporan Bulanan)</label>
                        <select name="filter_bulan" id="filter_bulan" class="form-select form-control-custom bg-dark-select text-white">
                            <option value="">Pilih Bulan...</option>
                            <option value="1">Januari</option>
                            <option value="2">Februari</option>
                            <option value="3">Maret</option>
                            <option value="4">April</option>
                            <option value="5">Mei</option>
                            <option value="6">Juni</option>
                            <option value="7">Juli</option>
                            <option value="8">Agustus</option>
                            <option value="9">September</option>
                            <option value="10">Oktober</option>
                            <option value="11">November</option>
                            <option value="12">Desember</option>
                        </select>
                    </div>

                    <div class="col-12 col-sm-6 col-md-3">
                        <label class="form-label form-label-custom">Tanggal Mulai</label>
                        <input type="date" name="filter_tgl_mulai" id="filter_tgl_mulai" class="form-control form-control-custom text-white">
                    </div>

                    <div class="col-12 col-sm-6 col-md-3">
                        <label class="form-label form-label-custom">Tanggal Selesai</label>
                        <input type="date" name="filter_tgl_selesai" id="filter_tgl_selesai" class="form-control form-control-custom text-white">
                    </div>
                </form>
            </div>
        </div>

        <!-- Cards row for Jurnal Reports -->
        <div class="col-12 col-md-6 col-lg-4">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-calendar-day me-2 text-gold"></i> Laporan Jurnal Harian</h6>
                    <p class="text-secondary small mb-3">Rekap aktivitas mengajar harian guru. Filter berdasarkan nama guru, kelas, mapel, dan tanggal.</p>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" onclick="unduhLaporan('print', 'jurnal_harian')" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> Cetak PDF</button>
                    <button type="button" onclick="unduhLaporan('export', 'jurnal_harian')" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</button>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-lg-4">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-calendar-days me-2 text-gold"></i> Laporan Jurnal Bulanan</h6>
                    <p class="text-secondary small mb-3">Laporan rekap bulanan jumlah jam mengajar, jumlah hari mengajar, dan persentase kehadiran jurnal.</p>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" onclick="unduhLaporan('print', 'jurnal_bulanan')" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> Cetak PDF</button>
                    <button type="button" onclick="unduhLaporan('export', 'jurnal_bulanan')" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</button>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-lg-4">
            <div class="glass-card mb-0 h-100 d-flex flex-column justify-content-between" style="background: rgba(18, 28, 54, 0.25);">
                <div>
                    <h6 class="text-white fw-bold"><i class="fa-solid fa-calendar-check me-2 text-gold"></i> Laporan Jurnal Semester</h6>
                    <p class="text-secondary small mb-3">Rangkuman rekap seluruh aktivitas mengajar, statistik mengajar, dan grafik pembelajaran satu semester.</p>
                </div>
                <div class="d-flex gap-2">
                    <button type="button" onclick="unduhLaporan('print', 'jurnal_semester')" class="btn btn-sm btn-outline-custom text-gold flex-grow-1"><i class="fa-solid fa-print me-1"></i> Cetak PDF</button>
                    <button type="button" onclick="unduhLaporan('export', 'jurnal_semester')" class="btn btn-sm btn-gold flex-grow-1"><i class="fa-solid fa-file-excel me-1"></i> Excel</button>
                </div>
            </div>
        </div>

        <!-- Script to build dynamic print and export links -->
        <script>
        function unduhLaporan(action, type) {
            const params = new URLSearchParams();
            params.append('type', type);
            
            const guru = document.getElementById('filter_guru').value;
            const kelas = document.getElementById('filter_kelas').value;
            const mapel = document.getElementById('filter_mapel').value;
            const ta = document.getElementById('filter_ta').value;
            const semester = document.getElementById('filter_semester').value;
            const bulan = document.getElementById('filter_bulan').value;
            const tgl_mulai = document.getElementById('filter_tgl_mulai').value;
            const tgl_selesai = document.getElementById('filter_tgl_selesai').value;

            if(guru) params.append('guru_id', guru);
            if(kelas) params.append('kelas_id', kelas);
            if(mapel) params.append('mapel_id', mapel);
            if(ta) params.append('ta_id', ta);
            if(semester) params.append('semester_id', semester);
            if(bulan) params.append('bulan', bulan);
            if(tgl_mulai) params.append('tgl_mulai', tgl_mulai);
            if(tgl_selesai) params.append('tgl_selesai', tgl_selesai);

            const url = action + '.php?' + params.toString();
            if (action === 'print') {
                window.open(url, '_blank');
            } else {
                window.location.href = url;
            }
        }

        function unduhLaporanRiwayat(action, type) {
            const params = new URLSearchParams();
            params.append('type', type);
            
            if (type === 'siswa_tingkat') {
                const tingkat = document.getElementById('riwayat_tingkat').value;
                if (!tingkat) {
                    Swal.fire('Peringatan', 'Pilih tingkat kelas terlebih dahulu!', 'warning');
                    return;
                }
                params.append('tingkat', tingkat);
            } else if (type === 'rekap_tahun_ajaran') {
                const ta = document.getElementById('rekap_ta').value;
                if (!ta) {
                    Swal.fire('Peringatan', 'Pilih tahun ajaran terlebih dahulu!', 'warning');
                    return;
                }
                params.append('ta_id', ta);
            } else if (type === 'mutasi') {
                const ta = document.getElementById('mutasi_ta').value;
                if (ta) params.append('ta_id', ta);
            } else if (type === 'alumni_angkatan') {
                const ta = document.getElementById('alumni_ta').value;
                if (!ta) {
                    Swal.fire('Peringatan', 'Pilih tahun kelulusan terlebih dahulu!', 'warning');
                    return;
                }
                params.append('ta_id', ta);
            } else if (type === 'histori_siswa') {
                const siswa = document.getElementById('histori_siswa_id').value;
                if (!siswa) {
                    Swal.fire('Peringatan', 'Pilih siswa terlebih dahulu!', 'warning');
                    return;
                }
                params.append('siswa_id', siswa);
            }
            
            const url = action + '.php?' + params.toString();
            if (action === 'print') {
                window.open(url, '_blank');
            } else {
                window.location.href = url;
            }
        }

        function cetakRaporMerdeka() {
            const siswaId = document.getElementById('rapor_siswa_id').value;
            const semester = document.getElementById('rapor_semester').value;
            if (!siswaId) {
                Swal.fire('Peringatan', 'Silakan pilih siswa terlebih dahulu!', 'warning');
                return;
            }
            const url = '../raport/print.php?siswa_id=' + siswaId + '&semester=' + semester;
            window.open(url, '_blank');
        }

        function unduhLaporanSiswa(action) {
            const params = new URLSearchParams();
            params.append('type', 'siswa');
            
            const kelas = document.getElementById('filter_siswa_kelas').value;
            const status = document.getElementById('filter_siswa_status').value;
            
            if (kelas) params.append('kelas_id', kelas);
            if (status) params.append('status_siswa', status);
            
            const url = action + '.php?' + params.toString();
            if (action === 'print') {
                window.open(url, '_blank');
            } else {
                window.location.href = url;
            }
        }

        function unduhLaporanNilai(action) {
            const kelas = document.getElementById('filter_nilai_kelas').value;
            if (!kelas) {
                Swal.fire('Peringatan', 'Silakan pilih kelas terlebih dahulu!\n\nPastikan rapot sudah diisi untuk kelas yang ingin dicetak.', 'warning');
                return;
            }

            const params = new URLSearchParams();
            params.append('type', 'nilai');
            
            const ta = document.getElementById('filter_nilai_ta').value;
            const semester = document.getElementById('filter_nilai_semester').value;
            
            if (ta) params.append('tahun_ajaran', ta);
            if (semester) params.append('semester', semester);
            params.append('kelas_id', kelas);
            
            const url = action + '.php?' + params.toString();
            if (action === 'print') {
                window.open(url, '_blank');
            } else {
                window.location.href = url;
            }
        }

        // Dynamically load classes that have raport data from DB
        function refreshKelasRaport() {
            const ta       = document.getElementById('filter_nilai_ta').value;
            const semester = document.getElementById('filter_nilai_semester').value;
            const selectEl = document.getElementById('filter_nilai_kelas');
            const loading  = document.getElementById('nilai_kelas_loading');
            const badge    = document.getElementById('nilai_kelas_count_badge');
            const emptyNote = document.getElementById('nilai_kelas_empty_note');

            // Show loading spinner
            loading.style.display  = 'inline';
            emptyNote.style.display = 'none';
            badge.style.display    = 'none';
            selectEl.innerHTML     = '<option value="">-- Memuat data kelas... --</option>';
            selectEl.disabled      = true;

            const params = new URLSearchParams();
            if (ta)       params.append('tahun_ajaran', ta);
            if (semester) params.append('semester', semester);

            fetch('get_kelas_raport.php?' + params.toString())
                .then(res => res.json())
                .then(json => {
                    loading.style.display = 'none';
                    selectEl.disabled     = false;
                    selectEl.innerHTML    = '';

                    if (json.success && json.data && json.data.length > 0) {
                        // Show badge with count
                        badge.textContent    = json.data.length + ' kelas';
                        badge.style.display  = 'inline-block';
                        emptyNote.style.display = 'none';

                        // Add placeholder option
                        const placeholder = document.createElement('option');
                        placeholder.value = '';
                        placeholder.textContent = '-- Pilih Kelas --';
                        selectEl.appendChild(placeholder);

                        json.data.forEach(kelas => {
                            const opt = document.createElement('option');
                            opt.value = kelas.id;
                            opt.textContent = kelas.nama_kelas + ' (' + kelas.jumlah_siswa + ' siswa)';
                            selectEl.appendChild(opt);
                        });
                    } else {
                        // No raport data found
                        badge.style.display = 'none';
                        emptyNote.style.display = 'block';

                        const opt = document.createElement('option');
                        opt.value = '';
                        opt.textContent = '-- Tidak ada data rapot --';
                        selectEl.appendChild(opt);
                    }
                })
                .catch(err => {
                    loading.style.display = 'none';
                    selectEl.disabled     = false;
                    selectEl.innerHTML    = '<option value="">-- Gagal memuat kelas --</option>';
                    console.error('refreshKelasRaport error:', err);
                });
        }

        // Auto-load on page ready
        document.addEventListener('DOMContentLoaded', function() {
            refreshKelasRaport();
        });
        </script>
    </div>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
