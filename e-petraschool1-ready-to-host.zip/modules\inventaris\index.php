<?php
// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\modules\inventaris\index.php

$page_title = 'Inventaris Aset';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_inventaris_access();

$error = '';
$success = '';

// Handle POST request for adding computer inventory
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_pc_inventaris') {
    require_role(['Super Admin', 'Admin']);
    check_csrf_request();

    $kode_barang = strtoupper(trim($_POST['kode_inventaris'] ?? ''));
    $jenis_perangkat = trim($_POST['jenis_perangkat'] ?? 'PC Desktop');
    $nama_ruangan = trim($_POST['ruangan'] ?? '');
    $kondisi = $_POST['kondisi'] ?? 'Baik';
    $sumber_dana = trim($_POST['sumber_dana'] ?? '');

    $sn_cpu = trim($_POST['sn_cpu'] ?? '');
    $sn_monitor = trim($_POST['sn_monitor'] ?? '');
    $sn_keyboard = trim($_POST['sn_keyboard'] ?? '');
    $sn_mouse = trim($_POST['sn_mouse'] ?? '');

    if (empty($kode_barang) || empty($jenis_perangkat) || empty($nama_ruangan) || empty($sumber_dana)) {
        $error = 'Field Kode, Jenis Perangkat, Ruangan, dan Sumber Dana wajib diisi!';
    } else {
        try {
            // Check duplicate code
            $chk = $pdo->prepare("SELECT COUNT(*) FROM inventaris WHERE kode_barang = ?");
            $chk->execute([$kode_barang]);
            if ($chk->fetchColumn() > 0) {
                $error = "Kode inventaris '$kode_barang' sudah terdaftar!";
            } else {
                // Find or create Room
                $room_id = null;
                if ($nama_ruangan !== '') {
                    $room_stmt = $pdo->prepare("SELECT id FROM ruangan WHERE nama_ruangan = ? LIMIT 1");
                    $room_stmt->execute([$nama_ruangan]);
                    $room_id = $room_stmt->fetchColumn();

                    if (!$room_id) {
                        // Generate code for new room
                        $clean_name = strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $nama_ruangan));
                        $kode_ruangan = 'R-' . substr($clean_name, 0, 10) . rand(10, 99);
                        
                        $chk_room_code = $pdo->prepare("SELECT COUNT(*) FROM ruangan WHERE kode_ruangan = ?");
                        $chk_room_code->execute([$kode_ruangan]);
                        if ($chk_room_code->fetchColumn() > 0) {
                            $kode_ruangan .= rand(1, 9);
                        }

                        $insert_room = $pdo->prepare("INSERT INTO ruangan (kode_ruangan, nama_ruangan, lantai, kapasitas, kondisi) VALUES (?, ?, '1', 30, 'Baik')");
                        $insert_room->execute([$kode_ruangan, $nama_ruangan]);
                        $room_id = $pdo->lastInsertId();
                    }
                }

                // Fetch Elektronik category ID
                $cat_stmt = $pdo->prepare("SELECT id FROM kategori_barang WHERE nama_kategori = 'Elektronik' LIMIT 1");
                $cat_stmt->execute();
                $kategori_id = $cat_stmt->fetchColumn() ?: 1;

                // Insert PC/device asset
                $stmt = $pdo->prepare("
                    INSERT INTO inventaris (
                        kode_barang, nama_barang, kategori_id, merk, jumlah, kondisi, 
                        ruangan_id, tanggal_beli, harga, sumber_dana, 
                        sn_cpu, sn_monitor, sn_keyboard, sn_mouse, jenis_perangkat, qr_code
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $kode_barang,
                    $jenis_perangkat, // nama_barang
                    $kategori_id,
                    'Custom/Assembled', // merk
                    1, // jumlah
                    $kondisi,
                    $room_id,
                    date('Y-m-d'), // tanggal_beli
                    0.00, // harga
                    $sumber_dana,
                    $sn_cpu,
                    $sn_monitor,
                    $sn_keyboard,
                    $sn_mouse,
                    $jenis_perangkat,
                    $kode_barang // qr_code
                ]);

                write_audit_log("Menambahkan data inventaris PC/Desktop baru: $jenis_perangkat (Kode: $kode_barang).");

                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Data inventaris berhasil ditambahkan!', 'success').then(() => {
                            window.location.href = 'index.php';
                        });
                    });
                </script>";
                exit;
            }
        } catch (Exception $e) {
            $error = 'Database error: ' . $e->getMessage();
        }
    }
}

$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$filter_kategori = isset($_GET['kategori_id']) ? $_GET['kategori_id'] : '';
$filter_kondisi = isset($_GET['kondisi']) ? $_GET['kondisi'] : '';

try {
    // Fetch categories for filters
    $categories_stmt = $pdo->query("SELECT id, nama_kategori FROM kategori_barang ORDER BY nama_kategori ASC");
    $categories = $categories_stmt->fetchAll();

    // Fetch rooms list for the datalist autocomplete
    $all_rooms = $pdo->query("SELECT nama_ruangan FROM ruangan ORDER BY nama_ruangan ASC")->fetchAll(PDO::FETCH_COLUMN);

    // Query for assets
    $query = "SELECT i.*, k.nama_kategori, r.nama_ruangan 
              FROM inventaris i 
              JOIN kategori_barang k ON i.kategori_id = k.id 
              LEFT JOIN ruangan r ON i.ruangan_id = r.id 
              WHERE i.status_aktif = 'Aktif'";
    $params = [];

    if ($search !== '') {
        $query .= " AND (i.nama_barang LIKE :search OR i.kode_barang LIKE :search OR i.merk LIKE :search OR i.sumber_dana LIKE :search)";
        $params['search'] = "%$search%";
    }

    if ($filter_kategori !== '') {
        $query .= " AND i.kategori_id = :kategori_id";
        $params['kategori_id'] = intval($filter_kategori);
    }

    if ($filter_kondisi !== '') {
        $query .= " AND i.kondisi = :kondisi";
        $params['kondisi'] = $filter_kondisi;
    }

    $query .= " ORDER BY i.kode_barang ASC";
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $assets = $stmt->fetchAll();

} catch (Exception $e) {
    echo '<div class="alert alert-danger">Gagal memuat data inventaris: ' . $e->getMessage() . '</div>';
}
?>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
        <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
    </div>
<?php endif; ?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-boxes-stacked me-2"></i> Inventarisasi & Manajemen Aset Sekolah</h5>
            <p class="text-secondary small mb-0">Kelola pendataan aset elektronik, furnitur belajar, buku pustaka, dan fasilitas sekolah SD Kristen Petra 1.</p>
        </div>
        
        <div class="d-flex gap-2">
            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                <a href="create.php" class="btn btn-gold"><i class="fa-solid fa-plus me-1"></i> Tambah Aset</a>
            <?php endif; ?>
            <a href="../laporan/export.php?type=inventaris" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-excel me-1"></i> Ekspor Excel</a>
            <a href="../laporan/print.php?type=inventaris" target="_blank" class="btn btn-outline-custom text-gold"><i class="fa-solid fa-file-pdf me-1"></i> Cetak PDF</a>
        </div>
    </div>

    <!-- Filter & Search Form -->
    <form method="GET" action="index.php" class="row g-3 mb-4 no-print align-items-end">
        <div class="col-12 col-md-3">
            <label class="form-label form-label-custom">Pencarian</label>
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari nama barang, merk, kode..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        
        <div class="col-12 col-sm-6 col-md-3">
            <label class="form-label form-label-custom">Filter Kategori</label>
            <select name="kategori_id" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua Kategori</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo $cat['id']; ?>" <?php echo $filter_kategori == $cat['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($cat['nama_kategori']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-12 col-sm-6 col-md-3">
            <label class="form-label form-label-custom">Filter Kondisi</label>
            <select name="kondisi" class="form-select form-control-custom bg-dark-select text-white">
                <option value="">Semua Kondisi</option>
                <option value="Baik" <?php echo $filter_kondisi === 'Baik' ? 'selected' : ''; ?>>Baik</option>
                <option value="Rusak Ringan" <?php echo $filter_kondisi === 'Rusak Ringan' ? 'selected' : ''; ?>>Rusak Ringan</option>
                <option value="Rusak Berat" <?php echo $filter_kondisi === 'Rusak Berat' ? 'selected' : ''; ?>>Rusak Berat</option>
            </select>
        </div>

        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">Filter</button>
        </div>
        
        <?php if ($search !== '' || $filter_kategori !== '' || $filter_kondisi !== ''): ?>
            <div class="col-auto">
                <a href="index.php" class="btn btn-outline-danger">Reset</a>
            </div>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>Kode Aset</th>
                    <th>Nama Barang</th>
                    <th>Kategori</th>
                    <th>Lokasi</th>
                    <th style="text-align: center;">Jumlah</th>
                    <th>Kondisi</th>
                    <th>Sumber Dana</th>
                    <th class="no-print">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($assets) > 0): ?>
                    <?php foreach ($assets as $asset): ?>
                        <tr>
                            <td><strong class="text-white font-monospace"><?php echo htmlspecialchars($asset['kode_barang']); ?></strong></td>
                            <td>
                                <strong class="text-white d-block"><?php echo htmlspecialchars($asset['nama_barang']); ?></strong>
                                <span class="text-secondary small">Merk: <?php echo htmlspecialchars($asset['merk']); ?> (Beli: <?php echo htmlspecialchars($asset['tahun_perolehan'] ?: date('Y', strtotime($asset['tanggal_beli']))); ?>)</span>
                                <?php if (!empty($asset['sn_cpu']) || !empty($asset['sn_monitor']) || !empty($asset['sn_keyboard']) || !empty($asset['sn_mouse']) || !empty($asset['kode_cpu']) || !empty($asset['kode_monitor']) || !empty($asset['kode_keyboard']) || !empty($asset['kode_mouse'])): ?>
                                    <div class="mt-1 small" style="font-size: 11.5px; opacity: 0.85; line-height: 1.4;">
                                        <?php if (!empty($asset['sn_cpu']) || !empty($asset['kode_cpu'])): ?>
                                            <span class="d-block text-gold"><i class="fa-solid fa-microchip me-1"></i> CPU: <?php echo htmlspecialchars($asset['sn_cpu'] ?: '-'); ?> (<?php echo htmlspecialchars($asset['kode_cpu'] ?: '-'); ?>)</span>
                                        <?php endif; ?>
                                        <?php if ($asset['nama_barang'] === 'PC Desktop' || $asset['nama_kategori'] === 'PC Desktop Unit' || $asset['nama_kategori'] === 'PC AIO'): ?>
                                            <?php if (!empty($asset['sn_monitor']) || !empty($asset['kode_monitor'])): ?>
                                                <span class="d-block text-secondary"><i class="fa-solid fa-desktop me-1"></i> Monitor: <?php echo htmlspecialchars($asset['sn_monitor'] ?: '-'); ?> (<?php echo htmlspecialchars($asset['kode_monitor'] ?: '-'); ?>)</span>
                                            <?php endif; ?>
                                            <?php if (!empty($asset['sn_keyboard']) || !empty($asset['kode_keyboard'])): ?>
                                                <span class="d-block text-secondary"><i class="fa-solid fa-keyboard me-1"></i> KB: <?php echo htmlspecialchars($asset['sn_keyboard'] ?: '-'); ?> (<?php echo htmlspecialchars($asset['kode_keyboard'] ?: '-'); ?>)</span>
                                            <?php endif; ?>
                                            <?php if (!empty($asset['sn_mouse']) || !empty($asset['kode_mouse'])): ?>
                                                <span class="d-block text-secondary"><i class="fa-solid fa-mouse me-1"></i> MS: <?php echo htmlspecialchars($asset['sn_mouse'] ?: '-'); ?> (<?php echo htmlspecialchars($asset['kode_mouse'] ?: '-'); ?>)</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($asset['nama_kategori']); ?></td>
                            <td><i class="fa-solid fa-location-dot me-1 text-gold"></i> <?php echo htmlspecialchars($asset['nama_ruangan'] ?? 'Belum Dialokasikan'); ?></td>
                            <td style="text-align: center;"><span class="badge badge-secondary"><?php echo intval($asset['jumlah']); ?> unit</span></td>
                            <td>
                                <?php 
                                    $badge_class = 'badge-secondary';
                                    if ($asset['kondisi'] === 'Baik') $badge_class = 'badge-success';
                                    elseif ($asset['kondisi'] === 'Rusak Ringan') $badge_class = 'badge-warning';
                                    elseif ($asset['kondisi'] === 'Rusak Berat') $badge_class = 'badge-danger';
                                ?>
                                <span class="badge <?php echo $badge_class; ?>"><?php echo $asset['kondisi']; ?></span>
                            </td>
                            <td><span class="badge badge-secondary"><?php echo htmlspecialchars($asset['sumber_dana']); ?></span></td>
                            <td class="no-print">
                                <div class="d-flex gap-2">
                                    <a href="print_qr.php?id=<?php echo $asset['id']; ?>" class="btn btn-xs btn-outline-custom text-gold" title="Cetak QR Code Label"><i class="fa-solid fa-qrcode"></i> Label</a>
                                    
                                    <?php if (has_role(['Super Admin', 'Admin']) && ($_SESSION['username'] ?? '') !== '199302001'): ?>
                                        <a href="edit.php?id=<?php echo $asset['id']; ?>" class="btn btn-xs btn-outline-warning" title="Edit"><i class="fa-solid fa-pen"></i> Edit</a>
                                        <button onclick="confirmDelete('delete.php?id=<?php echo $asset['id']; ?>')" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i> Hapus</button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center text-secondary py-4">Data inventaris barang kosong.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>



<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
