<?php
// c:\xampp\htdocs\e-petraschool1\modules\raport\print.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_role(['Super Admin', 'Admin', 'Kepala Sekolah', 'Guru']);


$siswa_id = isset($_GET['siswa_id']) ? intval($_GET['siswa_id']) : 0;

// Dapatkan semester dan tahun ajaran aktif dari sistem
try {
    $active_sem_stmt = $pdo->query("SELECT semester FROM semester WHERE status = 'Aktif' LIMIT 1");
    $active_sem_db = $active_sem_stmt->fetchColumn();
    $active_sem = ($active_sem_db === 'Ganjil' || $active_sem_db === '1') ? '1' : '2';

    $active_ta_stmt = $pdo->query("SELECT tahun_ajaran FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1");
    $active_ta = $active_ta_stmt->fetchColumn() ?: '2025/2026';
} catch (Exception $e) {
    $active_sem = '1';
    $active_ta = '2025/2026';
}

$selected_sem = isset($_GET['semester']) ? $_GET['semester'] : $active_sem;
$selected_ta = isset($_GET['tahun_ajaran']) ? $_GET['tahun_ajaran'] : $active_ta;

try {
    // Fetch student details with tingkat
    $siswa_stmt = $pdo->prepare("SELECT s.*, k.nama_kelas, k.tingkat, k.wali_kelas_id, g.nama_guru as nama_wali 
                                 FROM siswa s 
                                 LEFT JOIN kelas k ON s.kelas_id = k.id 
                                 LEFT JOIN guru g ON k.wali_kelas_id = g.id 
                                 WHERE s.id = ? LIMIT 1");
    $siswa_stmt->execute([$siswa_id]);
    $siswa = $siswa_stmt->fetch();
    
    if (!$siswa) {
        die("Siswa tidak ditemukan.");
    }
    
    // Fetch existing report card data
    $raport_stmt = $pdo->prepare("SELECT * FROM raport_siswa WHERE siswa_id = ? AND semester = ? AND tahun_ajaran = ? LIMIT 1");
    $raport_stmt->execute([$siswa_id, $selected_sem, $selected_ta]);
    $raport = $raport_stmt->fetch();
    
    if (!$raport) {
        die("Data rapor untuk siswa ini di semester terpilih belum diisi.");
    }

    // Fetch principal details
    $kepsek_stmt = $pdo->query("SELECT nama_guru FROM guru WHERE jabatan = 'Kepala Sekolah' LIMIT 1");
    $nama_kepsek = $kepsek_stmt->fetchColumn() ?: 'Lilia, S.Pd., M.Psi.';
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

// Mapel default
$default_subjects = [
    'Agama' => 'Pendidikan Agama',
    'Pancasila' => 'Pancasila',
    'Bahasa Indonesia' => 'Bahasa Indonesia',
    'Matematika' => 'Matematika',
    'IPAS' => 'IPAS',
    'PJOK' => 'PJOK',
    'Seni Budaya' => 'Seni Budaya',
    'Bhs. Inggris' => 'Bhs. Inggris',
    'Bhs. Jawa' => 'Bhs. Jawa',
    'Bhs. Mandarin' => 'Bhs. Mandarin'
];

$saved_grades = json_decode($raport['academic_grades'], true) ?: [];
$saved_ekskul = json_decode($raport['ekstrakurikuler'], true) ?: [];
$saved_slo = json_decode($raport['slo'] ?? '[]', true) ?: [];

// Load logo base64
$logo_file = dirname(dirname(__DIR__)) . '/assets/images/logo.png';
if (file_exists($logo_file)) {
    $logo_data = base64_encode(file_get_contents($logo_file));
    $logo_src  = 'data:image/png;base64,' . $logo_data;
} else {
    $logo_src  = 'https://img.icons8.com/color/96/school.png';
}

$tut_wuri_file = dirname(dirname(__DIR__)) . '/assets/images/tut_wuri.png';
if (file_exists($tut_wuri_file)) {
    $tut_wuri_data = base64_encode(file_get_contents($tut_wuri_file));
    $tut_wuri_src  = 'data:image/png;base64,' . $tut_wuri_data;
} else {
    $tut_wuri_src  = 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Logo-Tut-Wuri-Handayani-PNG-Warna.png/120px-Logo-Tut-Wuri-Handayani-PNG-Warna.png';
}

$romanize = function($nama) {
    $nama_roman = preg_replace_callback('/(\d+)/', function($matches) {
        $map = [1 => 'I', 2 => 'II', 3 => 'III', 4 => 'IV', 5 => 'V', 6 => 'VI'];
        return $map[$matches[1]] ?? $matches[1];
    }, $nama);
    return preg_replace('/([I|V|X]+)([A-HJ-UW-Z])/', '$1 $2', $nama_roman);
};

// Helper conversion: "Kelas I A" -> "1-A"
$class_arabic = '';
if (!empty($siswa['nama_kelas'])) {
    $class_name = $siswa['nama_kelas'];
    // Remove "Kelas " prefix
    $class_name = str_ireplace('Kelas ', '', $class_name);
    // Extract Roman numerals and map them
    $roman_to_arabic = [
        'VIII' => '8', 'VII' => '7', 'III' => '3', 'II' => '2', 'VI' => '6', 'IV' => '4', 'V' => '5', 'I' => '1', 'IX' => '9', 'X' => '10'
    ];
    foreach ($roman_to_arabic as $roman => $arab) {
        $class_name = preg_replace('/\b' . $roman . '\b/', $arab, $class_name);
    }
    // Replace space/dash between number and letter with hyphen, e.g. "1 A" -> "1-A" or "1A" -> "1-A"
    $class_name = preg_replace('/(\d+)\s*([A-Za-z])/', '$1-$2', $class_name);
    $class_arabic = $class_name;
} else {
    $class_arabic = '-';
}

// Calculate Indonesian date
$indo_months = [
    'January' => 'Januari',
    'February' => 'Februari',
    'March' => 'Maret',
    'April' => 'April',
    'May' => 'Mei',
    'June' => 'Juni',
    'July' => 'Juli',
    'August' => 'Agustus',
    'September' => 'September',
    'October' => 'Oktober',
    'November' => 'November',
    'December' => 'Desember'
];
$date_en = date('d F Y');
$date_id = strtr($date_en, $indo_months);

// Calculate promotion grade
$next_grade_roman = '';
$next_grade_word = '';
if (isset($siswa['tingkat'])) {
    $tingkat = intval($siswa['tingkat']);
    $map_roman = [
        1 => 'II',
        2 => 'III',
        3 => 'IV',
        4 => 'V',
        5 => 'VI'
    ];
    $map_word = [
        1 => 'dua',
        2 => 'tiga',
        3 => 'empat',
        4 => 'lima',
        5 => 'enam'
    ];
    $next_grade_roman = $map_roman[$tingkat] ?? '';
    $next_grade_word = $map_word[$tingkat] ?? '';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rapor <?php echo htmlspecialchars($siswa['nama_lengkap']); ?> - Semester <?php echo $selected_sem; ?></title>
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        * {
            box-sizing: border-box;
        }
        body {
            background-color: #9e9e9e;
            background-image: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI1IiBoZWlnaHQ9IjUiPgo8cmVjdCB3aWR0aD0iNSIgaGVpZ2h0PSI1IiBmaWxsPSIjOWU5ZTllIj48L3JlY3Q+CjxwYXRoIGQ9Ik0wIDVMNSAwWk02IDRMNCA2Wk0tMSAxTDEgLTFaIiBzdHJva2U9IiM4ODgiIHN0cm9rZS13aWR0aD0iMSI+PC9wYXRoPgo8L3N2Zz4=");
            color: #000000;
            font-family: 'Times New Roman', Times, serif;
            margin: 0;
            padding: 20px;
        }
        .print-container {
            width: 215mm;
            min-height: 330mm;
            padding: 20mm;
            margin: 13px auto;
            background: #ffffff;
            box-shadow: 1px 1px 3px 1px #333;
            border-radius: 0;
            position: relative;
        }
        /* Kop Surat */
        .report-kop-surat {
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 3px double #000;
            padding-bottom: 12px;
            margin-bottom: 20px;
        }
        .kop-logo-left, .kop-logo-right {
            width: 65px;
            height: 65px;
            flex: 0 0 65px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .kop-logo-left img, .kop-logo-right img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }
        .kop-title {
            text-align: center;
            flex: 1 1 auto;
            min-width: 0;
            padding: 0 15px;
        }
        .kop-title h4 {
            font-size: 15px;
            font-weight: 800;
            margin: 2px 0;
            text-transform: uppercase;
            color: #000;
        }
        .kop-title p {
            font-size: 10px;
            margin: 0;
            color: #000;
        }
        .report-title {
            text-align: center;
            font-size: 14px;
            font-weight: 700;
            margin-bottom: 25px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            color: #000;
        }
        .report-table-print {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            font-size: 11pt;
        }
        .report-table-print th, .report-table-print td {
            border: 1px solid #000;
            padding: 8px 10px;
            text-align: left;
            color: #000;
        }
        .report-table-print th {
            background-color: #e0e0e0 !important;
            font-weight: bold;
            color: #000;
            text-transform: uppercase;
            font-size: 10pt;
            text-align: center;
        }
        .btn-print-panel {
            position: fixed;
            top: 20px;
            right: 20px;
            display: flex;
            gap: 10px;
            z-index: 1000;
        }
        .btn-action-print {
            background: #6366f1;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-family: Arial, sans-serif;
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
        }
        .btn-action-print:hover {
            background: #4f46e5;
            transform: translateY(-1px);
        }
        .btn-action-back {
            background: #ffffff;
            color: #334155;
            border: 1px solid #e2e8f0;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-family: Arial, sans-serif;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        }
        .btn-action-back:hover {
            background: #f8fafc;
            border-color: #cbd5e1;
            transform: translateY(-1px);
        }
        @media print {
            @page {
                size: 215mm 330mm;
                margin: 0;
            }
            html {
                margin: 0;
            }
            body {
                background-color: transparent !important;
                padding: 0 !important;
                margin: 0 !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }
            .print-container {
                width: 215mm !important;
                height: 330mm !important;
                min-height: 330mm !important;
                border: none !important;
                box-shadow: none !important;
                padding: 20mm !important;
                margin: 0 !important;
                background-color: #ffffff !important;
                page-break-after: always;
                page-break-inside: avoid;
            }
            .btn-print-panel {
                display: none !important;
            }
        }
    </style>
</head>
<body>

    <div class="btn-print-panel no-print">
        <a href="index.php?semester=<?php echo $selected_sem; ?>" class="btn-action-back"><i class="fa-solid fa-chevron-left"></i> Kembali</a>
        <button onclick="window.print()" class="btn-action-print"><i class="fa-solid fa-print"></i> Cetak PDF</button>
    </div>

    <div class="print-container">
        <!-- Kop Surat -->
        <div class="report-kop-surat">
            <div class="kop-logo-left">
                <img src="<?php echo $tut_wuri_src; ?>" alt="Logo Kemdikbud">
            </div>
            <div class="kop-title">
                <div style="font-size: 11px; font-weight: bold; margin: 0; text-transform: uppercase; color: #000;">Kementerian Pendidikan Dasar dan Menengah</div>
                <div style="font-size: 11px; font-weight: bold; margin: 1px 0; text-transform: uppercase; color: #000;">Dinas Pendidikan Kota Surabaya</div>
                <h4>SD KRISTEN PETRA 1 SURABAYA</h4>
                <p>Jalan WR. Supratman 46, Surabaya 60264 | Email: sd1@pppkpetra.sch.id</p>
            </div>
            <div class="kop-logo-right">
                <img src="<?php echo $logo_src; ?>" alt="Logo Petra">
            </div>
        </div>

        <div class="report-title">
            LAPORAN HASIL BELAJAR (RAPOR)<br>
            KURIKULUM MERDEKA
        </div>

        <!-- Student Info -->
        <div style="margin-bottom: 20px;">
            <table style="width: 100%; font-size: 11pt; border-collapse: collapse; font-family: 'Times New Roman', Times, serif;">
                <tr>
                    <td style="width: 15%; font-weight: bold; padding: 4px 0;">Nama Siswa</td>
                    <td style="width: 2%; padding: 4px 0;">:</td>
                    <td style="width: 43%; padding: 4px 0; font-weight: bold; text-transform: uppercase;"><?php echo htmlspecialchars($siswa['nama_lengkap']); ?></td>
                    <td style="width: 15%; font-weight: bold; padding: 4px 0;">Kelas</td>
                    <td style="width: 2%; padding: 4px 0;">:</td>
                    <td style="width: 23%; padding: 4px 0;"><?php echo htmlspecialchars($siswa['nama_kelas'] ? $romanize($siswa['nama_kelas']) : '-'); ?></td>
                </tr>
                <tr>
                    <td style="font-weight: bold; padding: 4px 0;">NIS / NISN</td>
                    <td>:</td>
                    <td><?php echo htmlspecialchars($siswa['nis'] . ' / ' . $siswa['nisn']); ?></td>
                    <td style="font-weight: bold; padding: 4px 0;">Semester</td>
                    <td>:</td>
                    <td><?php echo htmlspecialchars($selected_sem); ?></td>
                </tr>
                <tr>
                    <td style="font-weight: bold; padding: 4px 0;">No. Absen</td>
                    <td>:</td>
                    <td><?php echo htmlspecialchars($raport['no_absen'] ?: '-'); ?></td>
                    <td style="font-weight: bold; padding: 4px 0;">Tahun Ajaran</td>
                    <td>:</td>
                    <td><?php echo htmlspecialchars($selected_ta); ?></td>
                </tr>
            </table>
        </div>

        <!-- A. Nilai Akademik -->
        <div style="font-weight: bold; font-size: 11.5pt; margin-top: 15px; margin-bottom: 8px; color: #000; border-bottom: 1px solid #000; padding-bottom: 3px;">A. NILAI AKADEMIK</div>
        <table class="report-table-print">
            <thead>
                <tr>
                    <th style="width: 5%; text-align: center;">No</th>
                    <th style="width: 25%; text-align: left;">Mata Pelajaran</th>
                    <th style="width: 10%; text-align: center;">Nilai</th>
                    <th style="width: 60%; text-align: left;">Capaian Kompetensi</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no = 1;
                $subjects_to_print = !empty($saved_grades) ? array_keys($saved_grades) : array_keys($default_subjects);
                if (isset($siswa['tingkat']) && ($siswa['tingkat'] === '1' || $siswa['tingkat'] === '2')) {
                    $subjects_to_print = array_diff($subjects_to_print, ['IPAS']);
                }
                foreach ($subjects_to_print as $key) {
                    $sub_name = $default_subjects[$key] ?? $key;
                    $grade = $saved_grades[$key] ?? null;
                    $score = ($grade && $grade['score'] !== '') ? number_format($grade['score'], 0) : '—';
                    $desc_max = $grade['desc_max'] ?? '';
                    $desc_min = $grade['desc_min'] ?? '';
                    
                    $desc_text = '';
                    if (!empty($desc_max)) {
                        $desc_text .= "<strong>Menunjukkan penguasaan sangat baik dalam:</strong> " . htmlspecialchars($desc_max);
                    }
                    if (!empty($desc_min)) {
                        if (!empty($desc_text)) $desc_text .= "<br>";
                        $desc_text .= "<strong>Perlu bimbingan dan pendampingan dalam:</strong> " . htmlspecialchars($desc_min);
                    }
                    if (empty($desc_text)) {
                        $desc_text = '—';
                    }
                    
                    echo "<tr>
                        <td style='text-align: center;'>$no</td>
                        <td><strong>$sub_name</strong></td>
                        <td style='font-size:12pt; text-align: center;'><strong>$score</strong></td>
                        <td style='font-size: 11pt; line-height: 1.4; text-align: justify;'>$desc_text</td>
                    </tr>";
                    $no++;
                }
                ?>
            </tbody>
        </table>

        <!-- Page Break before Page 2 -->
        <div style="page-break-before: always;"></div>

        <!-- Kokurikuler (P5) -->
        <div style="margin-top: 10px; margin-bottom: 20px;">
            <table class="report-table-print" style="margin-bottom: 0;">
                <thead>
                    <tr>
                        <th style="text-align: center;">KOKURIKULER</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="font-size: 11pt; line-height: 1.4; padding: 12px; text-align: justify;">
                            <?php echo nl2br(htmlspecialchars($raport['kokurikuler_deskripsi'] ?: '—')); ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Ekstrakurikuler -->
        <div style="margin-bottom: 20px;">
            <table class="report-table-print" style="margin-bottom: 0;">
                <thead>
                    <tr>
                        <th style="width: 8%; text-align: center;">NO</th>
                        <th style="width: 37%; text-align: left;">Ekstrakurikuler</th>
                        <th style="width: 55%; text-align: left;">Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($saved_ekskul)): ?>
                        <?php foreach ($saved_ekskul as $idx => $ek): ?>
                            <tr>
                                <td style="text-align: center;"><?php echo $idx + 1; ?></td>
                                <td><strong><?php echo htmlspecialchars($ek['nama'] ?? $ek['name'] ?? ''); ?></strong></td>
                                <td style="font-size: 11pt; line-height: 1.4; text-align: justify;"><?php echo htmlspecialchars(($ek['deskripsi'] ?? $ek['description'] ?? '') ?: '—'); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td style="text-align: center;">1</td>
                            <td>—</td>
                            <td style="font-size: 11pt; line-height: 1.4;">—</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Ketidakhadiran (Kehadiran) -->
        <div style="margin-bottom: 20px;">
            <table class="report-table-print" style="margin-bottom: 0;">
                <thead>
                    <tr>
                        <th style="width: 50%; text-align: center;">Alasan</th>
                        <th style="width: 50%; text-align: center;">Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="padding: 6px 15px;">Sakit</td>
                        <td style="text-align: center; position: relative; padding: 6px 15px;">
                            <?php 
                            $sakit_val = trim($raport['sakit'] ?? '0');
                            echo $sakit_val === '-' ? '<strong>-</strong>' : '<strong>' . htmlspecialchars($sakit_val) . '</strong>';
                            ?>
                            <span style="float: right;">hari</span>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 6px 15px;">Izin</td>
                        <td style="text-align: center; position: relative; padding: 6px 15px;">
                            <?php 
                            $izin_val = trim($raport['izin'] ?? '0');
                            echo $izin_val === '-' ? '<strong>-</strong>' : '<strong>' . htmlspecialchars($izin_val) . '</strong>';
                            ?>
                            <span style="float: right;">hari</span>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding: 6px 15px;">Tanpa Keterangan</td>
                        <td style="text-align: center; position: relative; padding: 6px 15px;">
                            <?php 
                            $alpa_val = trim($raport['alpa'] ?? '0');
                            echo $alpa_val === '-' ? '<strong>-</strong>' : '<strong>' . htmlspecialchars($alpa_val) . '</strong>';
                            ?>
                            <span style="float: right;">hari</span>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Catatan Guru Kelas -->
        <div style="margin-bottom: 20px;">
            <table class="report-table-print" style="margin-bottom: 0;">
                <thead>
                    <tr>
                        <th style="text-align: left; font-size: 11pt; text-transform: none;">Catatan guru kelas</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="font-size: 11pt; line-height: 1.4; padding: 12px; text-align: justify;">
                            <?php echo nl2br(htmlspecialchars($raport['catatan_wali'] ?: '—')); ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Promotion Decision Line (Semester 2 only) -->
        <?php if ($selected_sem == 2 || $selected_sem == '2'): ?>
            <div style="font-weight: bold; font-size: 11pt; margin-top: 15px; margin-bottom: 25px; padding-left: 5px;">
                Naik ke kelas / <s>Tinggal di kelas</s> *) : <?php echo htmlspecialchars($next_grade_roman); ?> (<?php echo htmlspecialchars($next_grade_word); ?>)
            </div>
        <?php endif; ?>

        <!-- Signatures -->
        <table style="width: 100%; margin-top: 35px; font-size: 11pt; text-align: center; border-collapse: collapse; border: none; page-break-inside: avoid;">
            <tr style="border: none;">
                <td style="width: 33%; border: none; padding: 5px 0; vertical-align: top;">
                    Orang tua Peserta Didik<br><br><br><br><br>
                    ( ___________________ )
                </td>
                <td style="width: 33%; border: none; padding: 5px 0; vertical-align: top;">
                    Mengetahui<br>
                    Kepala Sekolah<br><br><br><br><br>
                    <strong><u><?php echo htmlspecialchars($nama_kepsek); ?></u></strong>
                </td>
                <td style="width: 34%; border: none; padding: 5px 0; vertical-align: top;">
                    Surabaya, <?php echo $date_id; ?><br>
                    Guru Kelas <?php echo htmlspecialchars($class_arabic); ?><br><br><br><br><br>
                    <strong><u><?php echo htmlspecialchars($siswa['nama_wali'] ?: '___________________'); ?></u></strong>
                </td>
            </tr>
        </table>
    </div>

</body>
</html>
