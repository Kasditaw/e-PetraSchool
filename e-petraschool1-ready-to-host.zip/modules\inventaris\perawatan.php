<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris\perawatan.php

$page_title = 'Perawatan Barang';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_inventaris_access();

$error = '';
$success = '';

// Handle actions (Create, Update, Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_role(['Super Admin', 'Admin']);
    check_csrf_request();
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'edit') {
        $id = intval($_POST['id'] ?? 0);
        $inventaris_id = intval($_POST['inventaris_id'] ?? 0);
        $tanggal_perawatan = $_POST['tanggal_perawatan'] ?? date('Y-m-d');
        $jenis_perawatan = trim($_POST['jenis_perawatan'] ?? '');
        $biaya = floatval($_POST['biaya'] ?? 0);
        $teknisi = trim($_POST['teknisi'] ?? '');
        $hasil_perawatan = trim($_POST['hasil_perawatan'] ?? '');
        $update_kondisi = $_POST['update_kondisi'] ?? ''; // Optional asset condition update

        if ($inventaris_id === 0 || empty($jenis_perawatan)) {
            $error = 'Pilih Aset dan isi Jenis Perawatan!';
        } else {
            try {
                $pdo->beginTransaction();

                if ($action === 'create') {
                    $stmt = $pdo->prepare("INSERT INTO perawatan_barang (inventaris_id, tanggal_perawatan, jenis_perawatan, biaya, teknisi, hasil_perawatan) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$inventaris_id, $tanggal_perawatan, $jenis_perawatan, $biaya, $teknisi, $hasil_perawatan]);
                    $perawatan_id = $pdo->lastInsertId();

                    // Update asset condition if specified
                    if ($update_kondisi !== '') {
                        $upd_cond = $pdo->prepare("UPDATE inventaris SET kondisi = ? WHERE id = ?");
                        $upd_cond->execute([$update_kondisi, $inventaris_id]);
                    }

                    // Fetch asset details for log
                    $ast = $pdo->prepare("SELECT nama_barang, kode_barang FROM inventaris WHERE id = ?");
                    $ast->execute([$inventaris_id]);
                    $asset = $ast->fetch();

                    // Log history
                    $cond_note = $update_kondisi !== '' ? " (Kondisi diperbarui menjadi: $update_kondisi)" : "";
                    $hist = $pdo->prepare("INSERT INTO histori_inventaris (inventaris_id, aktivitas, pengguna, keterangan) VALUES (?, 'Perawatan', ?, ?)");
                    $hist->execute([
                        $inventaris_id,
                        $_SESSION['nama'] ?? 'Admin',
                        "Pencatatan perawatan: $jenis_perawatan oleh $teknisi. Biaya: Rp " . number_format($biaya, 0, ',', '.') . "$cond_note"
                    ]);

                    write_audit_log("Menambahkan perawatan barang: " . $asset['nama_barang'] . " (" . $asset['kode_barang'] . ")");
                } else {
                    // Fetch old record for comparison
                    $old_stmt = $pdo->prepare("SELECT * FROM perawatan_barang WHERE id = ?");
                    $old_stmt->execute([$id]);
                    $old_rec = $old_stmt->fetch();

                    $stmt = $pdo->prepare("UPDATE perawatan_barang SET inventaris_id = ?, tanggal_perawatan = ?, jenis_perawatan = ?, biaya = ?, teknisi = ?, hasil_perawatan = ? WHERE id = ?");
                    $stmt->execute([$inventaris_id, $tanggal_perawatan, $jenis_perawatan, $biaya, $teknisi, $hasil_perawatan, $id]);

                    if ($update_kondisi !== '') {
                        $upd_cond = $pdo->prepare("UPDATE inventaris SET kondisi = ? WHERE id = ?");
                        $upd_cond->execute([$update_kondisi, $inventaris_id]);
                    }

                    // Fetch asset details
                    $ast = $pdo->prepare("SELECT nama_barang, kode_barang FROM inventaris WHERE id = ?");
                    $ast->execute([$inventaris_id]);
                    $asset = $ast->fetch();

                    // Log history
                    $hist = $pdo->prepare("INSERT INTO histori_inventaris (inventaris_id, aktivitas, pengguna, keterangan) VALUES (?, 'Perawatan', ?, ?)");
                    $hist->execute([
                        $inventaris_id,
                        $_SESSION['nama'] ?? 'Admin',
                        "Mengubah catatan perawatan: $jenis_perawatan. Biaya baru: Rp " . number_format($biaya, 0, ',', '.')
                    ]);

                    write_audit_log("Mengubah catatan perawatan barang ID $id: " . $asset['nama_barang']);
                }

                $pdo->commit();
                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        Swal.fire('Berhasil', 'Catatan perawatan berhasil disimpan!', 'success').then(() => {
                            window.location.href = 'perawatan.php';
                        });
                    });
                </script>";
                exit;
            } catch (Exception $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                $error = 'Database error: ' . $e->getMessage();
            }
        }
    } elseif ($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        if ($id > 0) {
            try {
                // Fetch info before delete
                $stmt_info = $pdo->prepare("
                    SELECT p.*, i.nama_barang, i.kode_barang 
                    FROM perawatan_barang p 
                    JOIN inventaris i ON p.inventaris_id = i.id 
                    WHERE p.id = ?
                ");
                $stmt_info->execute([$id]);
                $rec = $stmt_info->fetch();

                if ($rec) {
                    $del = $pdo->prepare("DELETE FROM perawatan_barang WHERE id = ?");
                    $del->execute([$id]);

                    $hist = $pdo->prepare("INSERT INTO histori_inventaris (inventaris_id, aktivitas, pengguna, keterangan) VALUES (?, 'Perawatan', ?, ?)");
                    $hist->execute([
                        $rec['inventaris_id'],
                        $_SESSION['nama'] ?? 'Admin',
                        "Menghapus catatan perawatan: " . $rec['jenis_perawatan']
                    ]);

                    write_audit_log("Menghapus perawatan barang ID $id: " . $rec['nama_barang']);

                    echo "<script>
                        document.addEventListener('DOMContentLoaded', function() {
                            Swal.fire('Berhasil', 'Catatan perawatan berhasil dihapus!', 'success').then(() => {
                                window.location.href = 'perawatan.php';
                            });
                        });
                    </script>";
                    exit;
                }
            } catch (Exception $e) {
                $error = 'Gagal menghapus: ' . $e->getMessage();
            }
        }
    }
}

// Fetch list of active maintenance logs
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
try {
    $query = "
        SELECT p.*, i.nama_barang, i.kode_barang, i.kondisi as kondisi_sekarang 
        FROM perawatan_barang p 
        JOIN inventaris i ON p.inventaris_id = i.id
    ";
    if ($search !== '') {
        $query .= " WHERE i.nama_barang LIKE :search OR i.kode_barang LIKE :search OR p.jenis_perawatan LIKE :search OR p.teknisi LIKE :search";
        $stmt = $pdo->prepare($query);
        $stmt->execute(['search' => "%$search%"]);
    } else {
        $stmt = $pdo->query($query . " ORDER BY p.tanggal_perawatan DESC");
    }
    $logs = $stmt->fetchAll();

    // Fetch active assets for selection dropdown
    $assets = $pdo->query("SELECT id, kode_barang, nama_barang, kondisi FROM inventaris WHERE status_aktif = 'Aktif' ORDER BY nama_barang ASC")->fetchAll();
} catch (Exception $e) {
    $logs = [];
    $assets = [];
    $error = 'Database error: ' . $e->getMessage();
}
?>

<div class="glass-card">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-screwdriver-wrench me-2"></i> Perawatan & Perbaikan Barang</h5>
            <p class="text-secondary small mb-0">Catat dan pantau histori pemeliharaan berkala, perbaikan, dan biaya perawatan aset sekolah.</p>
        </div>
        <div>
            <?php if (has_role(['Super Admin', 'Admin'])): ?>
            <button class="btn btn-gold" data-bs-toggle="modal" data-bs-target="#modalPerawatan" onclick="openCreateModal()"><i class="fa-solid fa-plus me-1"></i> Catat Perawatan</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger border-0 text-white bg-danger bg-opacity-25 small mb-4 py-2" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>

    <!-- Search Form -->
    <form method="GET" action="perawatan.php" class="row g-2 mb-4 no-print">
        <div class="col-12 col-md-4">
            <div class="search-input-container">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="text" name="search" class="form-control form-control-custom" placeholder="Cari barang, jenis perawatan..." value="<?php echo htmlspecialchars($search); ?>">
            </div>
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-outline-custom">Cari</button>
        </div>
        <?php if ($search !== ''): ?>
            <div class="col-auto">
                <a href="perawatan.php" class="btn btn-outline-danger">Reset</a>
            </div>
        <?php endif; ?>
    </form>

    <div class="table-responsive">
        <table class="table table-custom">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Barang Aset</th>
                    <th>Tanggal Perawatan</th>
                    <th>Jenis Perawatan</th>
                    <th>Teknisi / Vendor</th>
                    <th>Biaya (Rp)</th>
                    <th>Hasil Perawatan</th>
                    <?php if (has_role(['Super Admin', 'Admin'])): ?>
                    <th class="no-print">Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php if (count($logs) > 0): ?>
                    <?php $no = 1; foreach ($logs as $log): ?>
                        <tr>
                            <td><?php echo $no++; ?></td>
                            <td>
                                <strong class="text-white"><?php echo htmlspecialchars($log['nama_barang']); ?></strong>
                                <span class="text-secondary small d-block font-monospace"><?php echo htmlspecialchars($log['kode_barang']); ?></span>
                            </td>
                            <td><?php echo date('d M Y', strtotime($log['tanggal_perawatan'])); ?></td>
                            <td class="text-white fw-semibold"><?php echo htmlspecialchars($log['jenis_perawatan']); ?></td>
                            <td><?php echo htmlspecialchars($log['teknisi'] ?: '-'); ?></td>
                            <td class="text-gold fw-bold">Rp <?php echo number_format($log['biaya'], 0, ',', '.'); ?></td>
                            <td class="small"><?php echo nl2br(htmlspecialchars($log['hasil_perawatan'])); ?></td>
                            <?php if (has_role(['Super Admin', 'Admin'])): ?>
                            <td class="no-print">
                                <div class="d-flex gap-2">
                                    <button class="btn btn-xs btn-outline-warning" 
                                            onclick="openEditModal(<?php echo htmlspecialchars(json_encode($log)); ?>)" 
                                            title="Edit"><i class="fa-solid fa-pen"></i> Edit</button>
                                    <button onclick="confirmDelete(<?php echo $log['id']; ?>)" class="btn btn-xs btn-outline-danger" title="Hapus"><i class="fa-solid fa-trash"></i> Hapus</button>
                                </div>
                            </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center text-secondary py-4">Belum ada catatan perawatan barang.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Form -->
<div class="modal fade" id="modalPerawatan" tabindex="-1" aria-labelledby="modalPerawatanLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content modal-content-custom">
            <div class="modal-header">
                <h5 class="modal-title text-gold fw-bold" id="modalPerawatanLabel"><i class="fa-solid fa-screwdriver-wrench me-2"></i> Catat Perawatan</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="perawatan.php">
                <?php csrf_input(); ?>
                <input type="hidden" name="action" id="form_action" value="create">
                <input type="hidden" name="id" id="form_id" value="0">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="inventaris_id" class="form-label form-label-custom">Pilih Barang Aset <span class="text-danger">*</span></label>
                        <select name="inventaris_id" id="form_inventaris_id" class="form-select form-control-custom bg-dark-select text-white" required>
                            <option value="" disabled selected>Pilih Barang...</option>
                            <?php foreach ($assets as $ast): ?>
                                <option value="<?php echo $ast['id']; ?>"><?php echo htmlspecialchars($ast['nama_barang']) . ' (' . htmlspecialchars($ast['kode_barang']) . ')'; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label for="tanggal_perawatan" class="form-label form-label-custom">Tanggal Perawatan <span class="text-danger">*</span></label>
                        <input type="date" name="tanggal_perawatan" id="form_tanggal_perawatan" class="form-control form-control-custom" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="jenis_perawatan" class="form-label form-label-custom">Jenis Perawatan <span class="text-danger">*</span></label>
                        <input type="text" name="jenis_perawatan" id="form_jenis_perawatan" class="form-control form-control-custom" placeholder="Contoh: Ganti Aki, Servis Berkala, Instal Ulang" required>
                    </div>

                    <div class="mb-3">
                        <label for="biaya" class="form-label form-label-custom">Biaya Perawatan (Rp)</label>
                        <input type="number" step="0.01" name="biaya" id="form_biaya" class="form-control form-control-custom" placeholder="0">
                    </div>

                    <div class="mb-3">
                        <label for="teknisi" class="form-label form-label-custom">Teknisi / Penanggung Jawab</label>
                        <input type="text" name="teknisi" id="form_teknisi" class="form-control form-control-custom" placeholder="Nama Teknisi / Nama Toko Servis">
                    </div>

                    <div class="mb-3">
                        <label for="hasil_perawatan" class="form-label form-label-custom">Hasil Perawatan / Keterangan</label>
                        <textarea name="hasil_perawatan" id="form_hasil_perawatan" class="form-control form-control-custom" rows="3" placeholder="Hasil servis, rincian penggantian sparepart, dll."></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="update_kondisi" class="form-label form-label-custom">Perbarui Kondisi Aset ke:</label>
                        <select name="update_kondisi" id="form_update_kondisi" class="form-select form-control-custom bg-dark-select text-white">
                            <option value="">(Jangan Ubah Kondisi)</option>
                            <option value="Baik">Baik</option>
                            <option value="Cukup">Cukup</option>
                            <option value="Rusak Ringan">Rusak Ringan</option>
                            <option value="Rusak Berat">Rusak Berat</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer border-secondary">
                    <button type="button" class="btn btn-outline-custom" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-gold">Simpan <i class="fa-solid fa-check ms-1"></i></button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Hidden Delete Form -->
<form id="deleteForm" method="POST" action="perawatan.php" style="display:none;">
    <?php csrf_input(); ?>
    <input type="hidden" name="action" value="delete">
    <input type="hidden" name="id" id="delete_id">
</form>

<script>
function openCreateModal() {
    document.getElementById('modalPerawatanLabel').innerHTML = '<i class="fa-solid fa-screwdriver-wrench me-2"></i> Catat Perawatan';
    document.getElementById('form_action').value = 'create';
    document.getElementById('form_id').value = '0';
    document.getElementById('form_inventaris_id').value = '';
    document.getElementById('form_inventaris_id').disabled = false;
    document.getElementById('form_tanggal_perawatan').value = '<?php echo date('Y-m-d'); ?>';
    document.getElementById('form_jenis_perawatan').value = '';
    document.getElementById('form_biaya').value = '';
    document.getElementById('form_teknisi').value = '';
    document.getElementById('form_hasil_perawatan').value = '';
    document.getElementById('form_update_kondisi').value = '';
}

function openEditModal(log) {
    document.getElementById('modalPerawatanLabel').innerHTML = '<i class="fa-solid fa-pen me-2"></i> Edit Catat Perawatan';
    document.getElementById('form_action').value = 'edit';
    document.getElementById('form_id').value = log.id;
    document.getElementById('form_inventaris_id').value = log.inventaris_id;
    document.getElementById('form_inventaris_id').disabled = true; // prevent changing the asset on edit
    
    // add helper hidden field to make sure inventaris_id is sent on POST when disabled
    let hiddenInventaris = document.getElementById('hidden_inventaris_id');
    if (!hiddenInventaris) {
        hiddenInventaris = document.createElement('input');
        hiddenInventaris.type = 'hidden';
        hiddenInventaris.name = 'inventaris_id';
        hiddenInventaris.id = 'hidden_inventaris_id';
        document.getElementById('form_inventaris_id').after(hiddenInventaris);
    }
    hiddenInventaris.value = log.inventaris_id;

    document.getElementById('form_tanggal_perawatan').value = log.tanggal_perawatan;
    document.getElementById('form_jenis_perawatan').value = log.jenis_perawatan;
    document.getElementById('form_biaya').value = log.biaya;
    document.getElementById('form_teknisi').value = log.teknisi;
    document.getElementById('form_hasil_perawatan').value = log.hasil_perawatan;
    document.getElementById('form_update_kondisi').value = ''; // condition is updated on-demand

    const modal = new bootstrap.Modal(document.getElementById('modalPerawatan'));
    modal.show();
}

function confirmDelete(id) {
    Swal.fire({
        title: 'Apakah Anda yakin?',
        text: "Catatan perawatan ini akan dihapus permanen dan tidak bisa dikembalikan!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('delete_id').value = id;
            document.getElementById('deleteForm').submit();
        }
    });
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
