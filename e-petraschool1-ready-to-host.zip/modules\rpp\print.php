<?php
// c:\xampp\htdocs\e-petraschool1\modules\rpp\print.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';

// Enforce login
check_login();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

try {
    // Fetch document details
    $stmt = $pdo->prepare("SELECT r.*, g.nama_guru, g.nip, m.nama_mapel, m.kode_mapel, k.nama_kelas 
                           FROM rpp_dokumen r
                           LEFT JOIN guru g ON r.guru_id = g.id
                           LEFT JOIN mata_pelajaran m ON r.mapel_id = m.id
                           LEFT JOIN kelas k ON r.kelas_id = k.id
                           WHERE r.id = ?");
    $stmt->execute([$id]);
    $doc = $stmt->fetch();

    if (!$doc) {
        die("Dokumen tidak ditemukan!");
    }

    // Role verification
    if (has_role('Guru') && $doc['guru_id'] != $_SESSION['guru_id']) {
        die("Akses ditolak! Anda hanya dapat mencetak dokumen milik Anda sendiri.");
    }

    // Dynamic base_url computation
    $project_dir = str_replace('\\', '/', dirname(dirname(__DIR__)));
    $web_root = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT']);
    $base_url = str_replace($web_root, '', $project_dir);
    if (empty($base_url)) {
        $base_url = '/';
    } else {
        if (substr($base_url, 0, 1) !== '/') {
            $base_url = '/' . $base_url;
        }
        if (substr($base_url, -1) !== '/') {
            $base_url .= '/';
        }
    }
    $base_url = str_replace('//', '/', $base_url);

    // Left logo
    $left_logo_file = dirname(dirname(__DIR__)) . '/assets/images/tut_wuri.png';
    if (file_exists($left_logo_file)) {
        $left_logo_src = 'data:image/png;base64,' . base64_encode(file_get_contents($left_logo_file));
    } else {
        $left_logo_src = 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/eb/Logo-Tut-Wuri-Handayani-PNG-Warna.png/120px-Logo-Tut-Wuri-Handayani-PNG-Warna.png';
    }

    // Right logo
    $right_logo_file = dirname(dirname(__DIR__)) . '/assets/images/logo.png';
    if (file_exists($right_logo_file)) {
        $right_logo_src = 'data:image/png;base64,' . base64_encode(file_get_contents($right_logo_file));
    } else {
        $right_logo_src = $base_url . 'assets/images/logo.png';
    }

    $type_titles = [
        'PROTA' => 'Program Tahunan (PROTA)',
        'PROSEM_1' => 'Program Semester 1 (PROSEM 1)',
        'ATP_1' => 'Alur Tujuan Pembelajaran (ATP) Semester 1',
        'RPP_DL_1' => 'RPP Deep Learning Semester 1',
        'PROSEM_2' => 'Program Semester 2 (PROSEM 2)',
        'ATP_2' => 'Alur Tujuan Pembelajaran (ATP) Semester 2',
        'RPP_DL_2' => 'RPP Deep Learning Semester 2',
        'RPP_PM_5' => 'RPP PM Bab 5',
        'RPP_PM_6' => 'RPP PM Bab 6',
        'RPP_PM_7' => 'RPP PM Bab 7',
        'RPP_PM_8' => 'RPP PM Bab 8',
        'MODUL_AJAR_S1' => 'Modul Ajar Semester 1 (Kurikulum Merdeka)',
        'MODUL_AJAR_S2' => 'Modul Ajar Semester 2 (Kurikulum Merdeka)',
    ];
    $doc_type_label = $type_titles[$doc['jenis_dokumen']] ?? $doc['jenis_dokumen'];

    // Detect if this is a Modul Ajar (JSON content)
    $is_modul_ajar = in_array($doc['jenis_dokumen'], ['MODUL_AJAR_S1', 'MODUL_AJAR_S2']);
    $ma_data = [];
    if ($is_modul_ajar) {
        $ma_data = json_decode($doc['konten'], true) ?? [];
    }

} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak Dokumen - <?php echo htmlspecialchars($doc['nama_dokumen']); ?></title>
    <style>
        * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            background-color: #ffffff;
            color: #000000;
            margin: 0;
            padding: 20px;
            font-size: 13px;
            line-height: 1.4;
        }

        .print-container {
            max-width: 820px;
            margin: 0 auto;
            border: 1px solid #ddd;
            padding: 30px;
            background-color: #ffffff;
        }

        /* Kop Surat (Header) */
        .kop-surat {
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 5px double #000;
            padding-bottom: 8px;
            margin-bottom: 15px;
        }

        .kop-logo-left, .kop-logo-right {
            width: 75px;
            height: 75px;
            flex: 0 0 75px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .kop-logo-left img, .kop-logo-right img {
            width: 100%;
            height: 100%;
            object-fit: contain;
        }

        .kop-text {
            flex: 1 1 auto;
            min-width: 0;
            text-align: center;
            padding: 0 15px;
        }

        .kop-text .line-1 {
            font-size: 14px;
            font-weight: bold;
            margin: 0;
        }

        .kop-text .line-2 {
            font-size: 14px;
            font-weight: bold;
            margin: 1px 0;
        }

        .kop-text .line-3 {
            font-size: 18px;
            font-weight: bold;
            margin: 2px 0;
        }

        .kop-text .line-4 {
            font-size: 11px;
            margin: 1px 0;
        }

        .kop-text .line-5 {
            font-size: 11px;
            margin: 0;
        }

        /* Document Title */
        .doc-title {
            text-align: center;
            margin-top: 15px;
            margin-bottom: 20px;
        }

        .doc-title .main-title {
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
        }

        .doc-title .sub-title {
            font-size: 13px;
            font-weight: normal;
            margin-top: 3px;
            color: #444;
        }

        /* Identity Grid */
        .identity-table {
            width: 100%;
            margin-bottom: 25px;
            border-collapse: collapse;
        }

        .identity-table td {
            padding: 3px 0;
            vertical-align: top;
            font-size: 13px;
        }

        .identity-table td.label-col {
            width: 110px;
            color: #000;
        }

        .identity-table td.colon-col {
            width: 15px;
            text-align: center;
            color: #000;
        }

        .identity-table td.val-col {
            color: #000;
        }

        .identity-table td.label-col-right {
            width: 100px;
            padding-left: 40px;
            color: #000;
        }

        .identity-table td.colon-col-right {
            width: 15px;
            text-align: center;
            color: #000;
        }

        /* Content Area */
        .document-content {
            border-top: 2px solid #000;
            padding-top: 20px;
            font-size: 13.5px;
            color: #000;
            min-height: 300px;
            white-space: pre-wrap; /* Preserves newlines and spaces */
        }
        .document-content table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            white-space: normal !important;
            font-family: Arial, sans-serif !important;
        }
        .document-content table th, .document-content table td {
            border: 1px solid #000 !important;
            padding: 8px 12px;
            color: #000 !important;
        }
        .document-content table th {
            font-weight: bold;
            background-color: #f2f2f2 !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }

        /* Floating print button */
        .btn-print-floating {
            position: fixed;
            bottom: 30px;
            right: 30px;
            background-color: #6257DE;
            color: #fff;
            border: none;
            padding: 12px 24px;
            border-radius: 50px;
            font-weight: 700;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
            display: flex;
            align-items: center;
            gap: 8px;
            transition: transform 0.2s, background-color 0.2s;
            z-index: 999;
        }

        .btn-print-floating:hover {
            background-color: #7B71E8;
            transform: scale(1.05);
        }

        @media print {
            @page {
                size: 215mm 330mm;
                margin: 0;
            }
            body {
                padding: 0;
                margin: 0 !important;
                background-color: #ffffff;
            }
            .print-container {
                border: none;
                box-shadow: none;
                padding: 12mm 15mm !important;
                width: 100% !important;
                max-width: 100% !important;
                box-sizing: border-box !important;
            }
            .btn-print-floating {
                display: none !important;
            }
        }

        /* Modul Ajar Print Styles */
        .ma-section-header {
            background-color: #2c3e50;
            color: #ffffff;
            font-weight: bold;
            font-size: 13px;
            padding: 6px 12px;
            margin: 20px 0 10px 0;
            letter-spacing: 0.5px;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
        }
        .ma-info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
            font-size: 12.5px;
        }
        .ma-info-table td {
            padding: 3px 6px;
            vertical-align: top;
        }
        .ma-info-table .ma-label {
            width: 160px;
            font-weight: bold;
            color: #222;
        }
        .ma-info-table .ma-colon {
            width: 12px;
            text-align: center;
        }
        .ma-field-block {
            margin-bottom: 12px;
            page-break-inside: avoid;
        }
        .ma-field-title {
            font-weight: bold;
            font-size: 12.5px;
            color: #1a1a1a;
            margin-bottom: 4px;
            padding-left: 4px;
            border-left: 3px solid #2c3e50;
        }
        .ma-field-body {
            font-size: 12.5px;
            color: #333;
            line-height: 1.6;
            padding-left: 8px;
        }
    </style>
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>

    <button onclick="window.print()" class="btn-print-floating">
        <i class="fa-solid fa-print"></i> Cetak Dokumen
    </button>

    <div class="print-container">
        <!-- Kop Surat -->
        <div class="kop-surat">
            <div class="kop-logo-left">
                <img src="<?php echo $left_logo_src; ?>" alt="Logo Kemdikbud">
            </div>
            <div class="kop-text">
                <div class="line-1">Kementerian Pendidikan Dasar dan Menengah</div>
                <div class="line-2">Dinas Pendidikan Kota Surabaya</div>
                <div class="line-3">SD Kristen Petra 1 Surabaya</div>
                <div class="line-4">Jalan WR. Supratman 46, Surabaya 60264</div>
                <div class="line-5">Telp. +6231 5678624 E-Mail: sd1@pppkpetra.sch.id</div>
            </div>
            <div class="kop-logo-right">
                <img src="<?php echo $right_logo_src; ?>" alt="Logo Petra">
            </div>
        </div>

        <!-- Title -->
        <div class="doc-title">
            <div class="main-title"><?php echo htmlspecialchars($doc['nama_dokumen']); ?></div>
            <div class="sub-title"><?php echo htmlspecialchars($doc_type_label); ?> — T.A. <?php echo htmlspecialchars($doc['tahun_ajaran']); ?></div>
        </div>

        <!-- Identity -->
        <table class="identity-table">
            <tr>
                <td class="label-col">Nama Guru</td>
                <td class="colon-col">:</td>
                <td class="val-col" style="font-weight: bold; text-transform: uppercase;"><?php echo htmlspecialchars($doc['nama_guru'] ?? 'Administrator'); ?></td>
                
                <td class="label-col-right">Mata Pelajaran</td>
                <td class="colon-col-right">:</td>
                <td class="val-col"><?php echo htmlspecialchars($doc['nama_mapel']); ?></td>
            </tr>
            <tr>
                <td class="label-col">NIP</td>
                <td class="colon-col">:</td>
                <td class="val-col"><?php echo htmlspecialchars($doc['nip'] ?? '-'); ?></td>

                <td class="label-col-right">Kelas</td>
                <td class="colon-col-right">:</td>
                <td class="val-col"><?php echo htmlspecialchars($doc['nama_kelas'] ?? 'Kelas ' . $doc['grade_level']); ?></td>
            </tr>
            <tr>
                <td class="label-col">Tanggal Buat</td>
                <td class="colon-col">:</td>
                <td class="val-col"><?php echo date('d/m/Y H:i', strtotime($doc['created_at'])); ?></td>

                <td class="label-col-right">Tahun Ajaran</td>
                <td class="colon-col-right">:</td>
                <td class="val-col"><?php echo htmlspecialchars($doc['tahun_ajaran']); ?></td>
            </tr>
        </table>

        <!-- Document Content -->
        <?php if ($is_modul_ajar): ?>
        <?php
            $info_ma = $ma_data['info_umum'] ?? [];
            $inti_ma = $ma_data['komponen_inti'] ?? [];
            $lamp_ma = $ma_data['lampiran'] ?? [];
            $p3_ma   = is_array($info_ma['profil_pelajar'] ?? null) ? implode(', ', $info_ma['profil_pelajar']) : '-';
        ?>
        <div class="document-content" style="white-space:normal;">

            <!-- Section A: Informasi Umum -->
            <div class="ma-section-header">A. INFORMASI UMUM</div>
            <table class="ma-info-table">
                <tr><td class="ma-label">Nama Penyusun</td><td class="ma-colon">:</td><td><?php echo htmlspecialchars($info_ma['nama_penyusun'] ?? $doc['nama_guru'] ?? '-'); ?></td>
                    <td class="ma-label">Institusi</td><td class="ma-colon">:</td><td><?php echo htmlspecialchars($info_ma['institusi'] ?? 'SD Kristen Petra 1 Surabaya'); ?></td></tr>
                <tr><td class="ma-label">Tahun Pelajaran</td><td class="ma-colon">:</td><td><?php echo htmlspecialchars($doc['tahun_ajaran']); ?></td>
                    <td class="ma-label">Fase Kurikulum</td><td class="ma-colon">:</td><td><?php echo htmlspecialchars($info_ma['fase'] ?? '-'); ?></td></tr>
                <tr><td class="ma-label">Mata Pelajaran</td><td class="ma-colon">:</td><td><?php echo htmlspecialchars($doc['nama_mapel'] ?? '-'); ?></td>
                    <td class="ma-label">Kelas</td><td class="ma-colon">:</td><td><?php echo htmlspecialchars($doc['nama_kelas'] ?? '-'); ?></td></tr>
                <tr><td class="ma-label">Alokasi Waktu</td><td class="ma-colon">:</td><td><?php echo htmlspecialchars($info_ma['alokasi_waktu'] ?? '-'); ?></td>
                    <td class="ma-label">Model Pembelajaran</td><td class="ma-colon">:</td><td><?php echo htmlspecialchars($info_ma['model_pembelajaran'] ?? '-'); ?></td></tr>
                <tr><td class="ma-label">Target Peserta</td><td class="ma-colon">:</td><td colspan="4"><?php echo htmlspecialchars($info_ma['target_peserta'] ?? '-'); ?></td></tr>
                <tr><td class="ma-label">Profil Pelajar Pancasila</td><td class="ma-colon">:</td><td colspan="4"><strong><?php echo htmlspecialchars($p3_ma); ?></strong></td></tr>
                <tr><td class="ma-label">Kompetensi Awal</td><td class="ma-colon">:</td><td colspan="4"><?php echo nl2br(htmlspecialchars($info_ma['kompetensi_awal'] ?? '-')); ?></td></tr>
                <tr><td class="ma-label">Sarana & Prasarana</td><td class="ma-colon">:</td><td colspan="4"><?php echo nl2br(htmlspecialchars($info_ma['sarana'] ?? '-')); ?></td></tr>
            </table>

            <!-- Section B: Komponen Inti -->
            <div class="ma-section-header">B. KOMPONEN INTI</div>

            <?php if (!empty($inti_ma['tujuan_pembelajaran'])): ?>
            <div class="ma-field-block"><div class="ma-field-title">1. Tujuan Pembelajaran (TP)</div><div class="ma-field-body"><?php echo nl2br(htmlspecialchars($inti_ma['tujuan_pembelajaran'])); ?></div></div>
            <?php endif; ?>

            <?php if (!empty($inti_ma['pemahaman_bermakna'])): ?>
            <div class="ma-field-block"><div class="ma-field-title">2. Pemahaman Bermakna</div><div class="ma-field-body"><?php echo nl2br(htmlspecialchars($inti_ma['pemahaman_bermakna'])); ?></div></div>
            <?php endif; ?>

            <?php if (!empty($inti_ma['pertanyaan_pemantik'])): ?>
            <div class="ma-field-block"><div class="ma-field-title">3. Pertanyaan Pemantik</div><div class="ma-field-body"><?php echo nl2br(htmlspecialchars($inti_ma['pertanyaan_pemantik'])); ?></div></div>
            <?php endif; ?>

            <div class="ma-field-block">
                <div class="ma-field-title">4. Kegiatan Pembelajaran</div>
                <div class="ma-field-body">
                    <?php if (!empty($inti_ma['pendahuluan'])): ?>
                    <div style="margin-bottom:10px;"><strong>a. Pendahuluan (±10 menit)</strong><br><?php echo nl2br(htmlspecialchars($inti_ma['pendahuluan'])); ?></div>
                    <?php endif; ?>
                    <?php if (!empty($inti_ma['inti'])): ?>
                    <div style="margin-bottom:10px;"><strong>b. Kegiatan Inti (±50 menit)</strong><br><?php echo nl2br(htmlspecialchars($inti_ma['inti'])); ?></div>
                    <?php endif; ?>
                    <?php if (!empty($inti_ma['penutup'])): ?>
                    <div><strong>c. Penutup (±10 menit)</strong><br><?php echo nl2br(htmlspecialchars($inti_ma['penutup'])); ?></div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (!empty($inti_ma['asesmen_formatif'])): ?>
            <div class="ma-field-block"><div class="ma-field-title">5. Asesmen Formatif (Penilaian Proses)</div><div class="ma-field-body"><?php echo nl2br(htmlspecialchars($inti_ma['asesmen_formatif'])); ?></div></div>
            <?php endif; ?>

            <?php if (!empty($inti_ma['asesmen_sumatif'])): ?>
            <div class="ma-field-block"><div class="ma-field-title">6. Asesmen Sumatif (Penilaian Hasil)</div><div class="ma-field-body"><?php echo nl2br(htmlspecialchars($inti_ma['asesmen_sumatif'])); ?></div></div>
            <?php endif; ?>

            <?php if (!empty($inti_ma['diferensiasi'])): ?>
            <div class="ma-field-block"><div class="ma-field-title">7. Diferensiasi Pembelajaran</div><div class="ma-field-body"><?php echo nl2br(htmlspecialchars($inti_ma['diferensiasi'])); ?></div></div>
            <?php endif; ?>

            <!-- Section C: Lampiran -->
            <?php if (!empty(array_filter($lamp_ma))): ?>
            <div class="ma-section-header">C. LAMPIRAN</div>

            <?php if (!empty($lamp_ma['lkpd'])): ?>
            <div class="ma-field-block"><div class="ma-field-title">Lampiran 1 — LKPD (Lembar Kerja Peserta Didik)</div><div class="ma-field-body" style="font-family: monospace, Courier; background:#f9f9f9; border:1px solid #ddd; padding:10px; border-radius:4px;"><?php echo nl2br(htmlspecialchars($lamp_ma['lkpd'])); ?></div></div>
            <?php endif; ?>

            <?php if (!empty($lamp_ma['bahan_bacaan_guru'])): ?>
            <div class="ma-field-block"><div class="ma-field-title">Lampiran 2 — Bahan Bacaan Guru</div><div class="ma-field-body"><?php echo nl2br(htmlspecialchars($lamp_ma['bahan_bacaan_guru'])); ?></div></div>
            <?php endif; ?>

            <?php if (!empty($lamp_ma['bahan_bacaan_siswa'])): ?>
            <div class="ma-field-block"><div class="ma-field-title">Lampiran 3 — Bahan Bacaan Siswa</div><div class="ma-field-body"><?php echo nl2br(htmlspecialchars($lamp_ma['bahan_bacaan_siswa'])); ?></div></div>
            <?php endif; ?>

            <?php if (!empty($lamp_ma['rubrik'])): ?>
            <div class="ma-field-block"><div class="ma-field-title">Lampiran 4 — Rubrik Penilaian</div><div class="ma-field-body" style="font-family: monospace, Courier; white-space: pre-wrap;"><?php echo htmlspecialchars($lamp_ma['rubrik']); ?></div></div>
            <?php endif; ?>

            <?php if (!empty($lamp_ma['glosarium'])): ?>
            <div class="ma-field-block"><div class="ma-field-title">Lampiran 5 — Glosarium</div><div class="ma-field-body"><?php echo nl2br(htmlspecialchars($lamp_ma['glosarium'])); ?></div></div>
            <?php endif; ?>

            <?php if (!empty($lamp_ma['daftar_pustaka'])): ?>
            <div class="ma-field-block"><div class="ma-field-title">Lampiran 6 — Daftar Pustaka</div><div class="ma-field-body"><?php echo nl2br(htmlspecialchars($lamp_ma['daftar_pustaka'])); ?></div></div>
            <?php endif; ?>
            <?php endif; ?>

            <!-- Signature line -->
            <div style="margin-top:40px; display:flex; justify-content:flex-end;">
                <div style="text-align:center; min-width:200px;">
                    <p style="margin-bottom:50px;">Surabaya, <?php echo date('d F Y'); ?></p>
                    <p style="border-top:1px solid #000; padding-top:4px; font-weight:bold; text-transform:uppercase;"><?php echo htmlspecialchars($info_ma['nama_penyusun'] ?? $doc['nama_guru'] ?? '-'); ?></p>
                    <p style="margin-top:-5px; font-size:12px;">NIP. <?php echo htmlspecialchars($doc['nip'] ?? '-'); ?></p>
                </div>
            </div>
        </div>
        <?php else: ?>
        <!-- Standard document content (non Modul Ajar) -->
        <div class="document-content"><?php echo $doc['konten']; ?></div>
        <?php endif; ?>
    </div>

    <script>
        // Trigger auto-print when loaded
        window.addEventListener('DOMContentLoaded', () => {
            setTimeout(() => {
                window.print();
            }, 500);
        });
    </script>
</body>
</html>

