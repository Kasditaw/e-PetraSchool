<?php
// c:\xampp\htdocs\e-petraschool1\modules\jadwal\create.php

$page_title = 'Tambah Jadwal Pelajaran';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$error = '';
$success = '';

try {
    $kelas_list = $pdo->query("SELECT id, nama_kelas FROM kelas WHERE status = 'Aktif' ORDER BY nama_kelas ASC")->fetchAll();
    $guru_list  = $pdo->query("SELECT id, nama_guru, nip FROM guru ORDER BY nama_guru ASC")->fetchAll();
    $mapel_list = $pdo->query("SELECT id, kode_mapel, nama_mapel FROM mata_pelajaran WHERE status = 'Aktif' ORDER BY nama_mapel ASC")->fetchAll();
    $ta_list    = $pdo->query("SELECT id, tahun_ajaran, status FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();
    $sem_list   = $pdo->query("SELECT id, semester, status FROM semester ORDER BY semester ASC")->fetchAll();

    $default_ta  = 0; foreach ($ta_list  as $t) { if ($t['status']  === 'Aktif') { $default_ta  = $t['id']; break; } }
    $default_sem = 0; foreach ($sem_list as $s) { if ($s['status']  === 'Aktif') { $default_sem = $s['id']; break; } }

} catch (Exception $e) {
    $error = 'Gagal memuat data: ' . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($error)) {
    check_csrf_request();

    $kelas_id   = intval($_POST['kelas_id'] ?? 0);
    $guru_id    = intval($_POST['guru_id']  ?? 0);
    $mapel_id   = intval($_POST['mapel_id'] ?? 0) ?: null;
    $nama_mapel = trim($_POST['nama_mapel'] ?? '');
    $hari       = trim($_POST['hari'] ?? '');
    $jam_mulai  = trim($_POST['jam_mulai'] ?? '');
    $jam_selesai= trim($_POST['jam_selesai'] ?? '');
    $ta_id      = intval($_POST['tahun_ajaran_id'] ?? 0);
    $sem_id     = intval($_POST['semester_id'] ?? 0);

    if (!$kelas_id || !$guru_id || !$nama_mapel || !$hari || !$jam_mulai || !$jam_selesai || !$ta_id || !$sem_id) {
        $error = 'Semua field wajib diisi!';
    } elseif ($jam_selesai <= $jam_mulai) {
        $error = 'Jam selesai harus lebih besar dari jam mulai!';
    } else {
        try {
            // Cek bentrok jadwal: kelas + hari + rentang waktu yang overlap
            $cek_stmt = $pdo->prepare("
                SELECT COUNT(*) FROM jadwal_pelajaran
                WHERE kelas_id = ? AND hari = ? AND tahun_ajaran_id = ? AND semester_id = ?
                  AND NOT (jam_selesai <= ? OR jam_mulai >= ?)
            ");
            $cek_stmt->execute([$kelas_id, $hari, $ta_id, $sem_id, $jam_mulai, $jam_selesai]);
            if ($cek_stmt->fetchColumn() > 0) {
                $error = 'Jadwal bentrok! Kelas ini sudah memiliki jadwal pada hari dan jam yang tumpang tindih.';
            } else {
                $ins = $pdo->prepare("
                    INSERT INTO jadwal_pelajaran (kelas_id, guru_id, mapel_id, nama_mapel, hari, jam_mulai, jam_selesai, tahun_ajaran_id, semester_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $ins->execute([$kelas_id, $guru_id, $mapel_id, $nama_mapel, $hari, $jam_mulai, $jam_selesai, $ta_id, $sem_id]);
                write_audit_log("Menambahkan jadwal pelajaran: $nama_mapel pada hari $hari.");
                echo "<script>document.addEventListener('DOMContentLoaded',function(){Swal.fire('Berhasil!','Jadwal pelajaran berhasil ditambahkan.','success').then(()=>{window.location.href='index.php';});});</script>";
            }
        } catch (Exception $e) {
            $error = 'Gagal menyimpan: ' . $e->getMessage();
        }
    }
}
?>

<div class="glass-card" style="max-width: 760px; margin: 0 auto;">
    <div class="mb-4">
        <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-calendar-plus me-2"></i>Tambah Jadwal Pelajaran</h5>
        <p class="text-secondary small mb-0">Isi form berikut untuk menambahkan sesi jadwal pelajaran baru.</p>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST" action="create.php">
        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">

        <div class="row g-3">
            <!-- Tahun Ajaran -->
            <div class="col-md-6">
                <label class="form-label form-label-custom">Tahun Ajaran <span class="text-danger">*</span></label>
                <select name="tahun_ajaran_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <?php foreach ($ta_list as $ta): ?>
                        <option value="<?php echo $ta['id']; ?>" <?php echo $default_ta == $ta['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($ta['tahun_ajaran']); ?><?php echo $ta['status'] === 'Aktif' ? ' (Aktif)' : ''; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Semester -->
            <div class="col-md-6">
                <label class="form-label form-label-custom">Semester <span class="text-danger">*</span></label>
                <select name="semester_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <?php foreach ($sem_list as $sm): ?>
                        <option value="<?php echo $sm['id']; ?>" <?php echo $default_sem == $sm['id'] ? 'selected' : ''; ?>>
                            Semester <?php echo htmlspecialchars($sm['semester']); ?><?php echo $sm['status'] === 'Aktif' ? ' (Aktif)' : ''; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Kelas -->
            <div class="col-md-6">
                <label class="form-label form-label-custom">Kelas <span class="text-danger">*</span></label>
                <select name="kelas_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="">-- Pilih Kelas --</option>
                    <?php foreach ($kelas_list as $kl): ?>
                        <option value="<?php echo $kl['id']; ?>" <?php echo ($_POST['kelas_id'] ?? '') == $kl['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($kl['nama_kelas']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Guru -->
            <div class="col-md-6">
                <label class="form-label form-label-custom">Guru Pengajar <span class="text-danger">*</span></label>
                <select name="guru_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="">-- Pilih Guru --</option>
                    <?php foreach ($guru_list as $g): ?>
                        <option value="<?php echo $g['id']; ?>" <?php echo ($_POST['guru_id'] ?? '') == $g['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($g['nama_guru']); ?> (<?php echo htmlspecialchars($g['nip']); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Mata Pelajaran dari daftar -->
            <div class="col-md-6">
                <label class="form-label form-label-custom">Mata Pelajaran <span class="text-secondary" style="font-size:11px;">(pilih dari daftar)</span></label>
                <select name="mapel_id" id="mapel_select" class="form-select form-control-custom bg-dark-select text-white" onchange="syncMapel(this.value)">
                    <option value="">-- Pilih dari Daftar --</option>
                    <?php foreach ($mapel_list as $mp): ?>
                        <option value="<?php echo $mp['id']; ?>" data-nama="<?php echo htmlspecialchars($mp['nama_mapel']); ?>">
                            <?php echo htmlspecialchars($mp['nama_mapel']); ?> (<?php echo htmlspecialchars($mp['kode_mapel']); ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Nama Mapel Manual -->
            <div class="col-md-6">
                <label class="form-label form-label-custom">Nama Mapel Tampilan <span class="text-danger">*</span></label>
                <input type="text" name="nama_mapel" id="nama_mapel" class="form-control form-control-custom"
                       placeholder="Contoh: Matematika Kelas 4" maxlength="100" required
                       value="<?php echo htmlspecialchars($_POST['nama_mapel'] ?? ''); ?>">
                <small class="text-secondary">Bisa diedit manual untuk nama yang lebih spesifik</small>
            </div>

            <!-- Hari -->
            <div class="col-md-4">
                <label class="form-label form-label-custom">Hari <span class="text-danger">*</span></label>
                <select name="hari" class="form-select form-control-custom bg-dark-select text-white" required>
                    <option value="">-- Pilih Hari --</option>
                    <?php foreach (['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'] as $h): ?>
                        <option value="<?php echo $h; ?>" <?php echo ($_POST['hari'] ?? '') === $h ? 'selected' : ''; ?>><?php echo $h; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Jam Mulai -->
            <div class="col-md-4">
                <label class="form-label form-label-custom">Jam Mulai <span class="text-danger">*</span></label>
                <input type="time" name="jam_mulai" class="form-control form-control-custom" required
                       value="<?php echo htmlspecialchars($_POST['jam_mulai'] ?? '07:00'); ?>">
            </div>

            <!-- Jam Selesai -->
            <div class="col-md-4">
                <label class="form-label form-label-custom">Jam Selesai <span class="text-danger">*</span></label>
                <input type="time" name="jam_selesai" class="form-control form-control-custom" required
                       value="<?php echo htmlspecialchars($_POST['jam_selesai'] ?? '08:00'); ?>">
            </div>
        </div>

        <!-- Buttons -->
        <div class="d-flex gap-3 mt-4">
            <button type="submit" class="btn btn-gold"><i class="fa-solid fa-floppy-disk me-1"></i> Simpan Jadwal</button>
            <a href="index.php" class="btn btn-outline-custom">Batal</a>
        </div>
    </form>
</div>

<script>
function syncMapel(mapelId) {
    const select = document.getElementById('mapel_select');
    const namaInput = document.getElementById('nama_mapel');
    if (mapelId) {
        const opt = select.options[select.selectedIndex];
        namaInput.value = opt.getAttribute('data-nama');
    }
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
