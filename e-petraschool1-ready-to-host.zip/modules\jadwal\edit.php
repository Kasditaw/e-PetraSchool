<?php
// c:\xampp\htdocs\e-petraschool1\modules\jadwal\edit.php

$page_title = 'Edit Jadwal Pelajaran';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$id    = intval($_GET['id'] ?? 0);
$error = '';

if (!$id) { header('Location: index.php'); exit; }

try {
    $kelas_list = $pdo->query("SELECT id, nama_kelas FROM kelas WHERE status = 'Aktif' ORDER BY nama_kelas ASC")->fetchAll();
    $guru_list  = $pdo->query("SELECT id, nama_guru, nip FROM guru ORDER BY nama_guru ASC")->fetchAll();
    $mapel_list = $pdo->query("SELECT id, kode_mapel, nama_mapel FROM mata_pelajaran WHERE status = 'Aktif' ORDER BY nama_mapel ASC")->fetchAll();
    $ta_list    = $pdo->query("SELECT id, tahun_ajaran, status FROM tahun_ajaran ORDER BY tahun_ajaran DESC")->fetchAll();
    $sem_list   = $pdo->query("SELECT id, semester, status FROM semester ORDER BY semester ASC")->fetchAll();

    $stmt = $pdo->prepare("SELECT * FROM jadwal_pelajaran WHERE id = ?");
    $stmt->execute([$id]);
    $jadwal = $stmt->fetch();
    if (!$jadwal) { header('Location: index.php'); exit; }

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf_request();

    $kelas_id    = intval($_POST['kelas_id'] ?? 0);
    $guru_id     = intval($_POST['guru_id']  ?? 0);
    $mapel_id    = intval($_POST['mapel_id'] ?? 0) ?: null;
    $nama_mapel  = trim($_POST['nama_mapel'] ?? '');
    $hari        = trim($_POST['hari'] ?? '');
    $jam_mulai   = trim($_POST['jam_mulai'] ?? '');
    $jam_selesai = trim($_POST['jam_selesai'] ?? '');
    $ta_id       = intval($_POST['tahun_ajaran_id'] ?? 0);
    $sem_id      = intval($_POST['semester_id'] ?? 0);

    if (!$kelas_id || !$guru_id || !$nama_mapel || !$hari || !$jam_mulai || !$jam_selesai || !$ta_id || !$sem_id) {
        $error = 'Semua field wajib diisi!';
    } elseif ($jam_selesai <= $jam_mulai) {
        $error = 'Jam selesai harus lebih besar dari jam mulai!';
    } else {
        try {
            // Cek bentrok (exclude current id)
            $cek = $pdo->prepare("
                SELECT COUNT(*) FROM jadwal_pelajaran
                WHERE id != ? AND kelas_id = ? AND hari = ? AND tahun_ajaran_id = ? AND semester_id = ?
                  AND NOT (jam_selesai <= ? OR jam_mulai >= ?)
            ");
            $cek->execute([$id, $kelas_id, $hari, $ta_id, $sem_id, $jam_mulai, $jam_selesai]);
            if ($cek->fetchColumn() > 0) {
                $error = 'Jadwal bentrok! Kelas ini sudah ada jadwal pada rentang waktu tersebut.';
            } else {
                $upd = $pdo->prepare("
                    UPDATE jadwal_pelajaran SET kelas_id=?, guru_id=?, mapel_id=?, nama_mapel=?, hari=?, jam_mulai=?, jam_selesai=?, tahun_ajaran_id=?, semester_id=?
                    WHERE id=?
                ");
                $upd->execute([$kelas_id, $guru_id, $mapel_id, $nama_mapel, $hari, $jam_mulai, $jam_selesai, $ta_id, $sem_id, $id]);
                write_audit_log("Mengubah jadwal pelajaran ID#$id: $nama_mapel pada hari $hari.");
                echo "<script>document.addEventListener('DOMContentLoaded',function(){Swal.fire('Berhasil!','Jadwal berhasil diperbarui.','success').then(()=>{window.location.href='index.php';});});</script>";
                $jadwal = array_merge($jadwal, ['kelas_id'=>$kelas_id,'guru_id'=>$guru_id,'mapel_id'=>$mapel_id,'nama_mapel'=>$nama_mapel,'hari'=>$hari,'jam_mulai'=>$jam_mulai,'jam_selesai'=>$jam_selesai,'tahun_ajaran_id'=>$ta_id,'semester_id'=>$sem_id]);
            }
        } catch (Exception $e) {
            $error = 'Gagal menyimpan: ' . $e->getMessage();
        }
    }
}
?>

<div class="glass-card" style="max-width: 760px; margin: 0 auto;">
    <div class="mb-4">
        <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-calendar-pen me-2"></i>Edit Jadwal Pelajaran</h5>
        <p class="text-secondary small mb-0">Perbarui data jadwal pelajaran.</p>
    </div>

    <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fa-solid fa-triangle-exclamation me-2"></i><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?php echo generate_csrf_token(); ?>">
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label form-label-custom">Tahun Ajaran</label>
                <select name="tahun_ajaran_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <?php foreach ($ta_list as $ta): ?>
                        <option value="<?php echo $ta['id']; ?>" <?php echo $jadwal['tahun_ajaran_id'] == $ta['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($ta['tahun_ajaran']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label form-label-custom">Semester</label>
                <select name="semester_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <?php foreach ($sem_list as $sm): ?>
                        <option value="<?php echo $sm['id']; ?>" <?php echo $jadwal['semester_id'] == $sm['id'] ? 'selected' : ''; ?>>
                            Semester <?php echo htmlspecialchars($sm['semester']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label form-label-custom">Kelas</label>
                <select name="kelas_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <?php foreach ($kelas_list as $kl): ?>
                        <option value="<?php echo $kl['id']; ?>" <?php echo $jadwal['kelas_id'] == $kl['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($kl['nama_kelas']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label form-label-custom">Guru Pengajar</label>
                <select name="guru_id" class="form-select form-control-custom bg-dark-select text-white" required>
                    <?php foreach ($guru_list as $g): ?>
                        <option value="<?php echo $g['id']; ?>" <?php echo $jadwal['guru_id'] == $g['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($g['nama_guru']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label form-label-custom">Mata Pelajaran (Daftar)</label>
                <select name="mapel_id" id="mapel_select" class="form-select form-control-custom bg-dark-select text-white" onchange="syncMapel(this.value)">
                    <option value="">-- Pilih (opsional) --</option>
                    <?php foreach ($mapel_list as $mp): ?>
                        <option value="<?php echo $mp['id']; ?>" data-nama="<?php echo htmlspecialchars($mp['nama_mapel']); ?>" <?php echo $jadwal['mapel_id'] == $mp['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($mp['nama_mapel']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label form-label-custom">Nama Mapel Tampilan</label>
                <input type="text" name="nama_mapel" id="nama_mapel" class="form-control form-control-custom" required maxlength="100"
                       value="<?php echo htmlspecialchars($jadwal['nama_mapel']); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label form-label-custom">Hari</label>
                <select name="hari" class="form-select form-control-custom bg-dark-select text-white" required>
                    <?php foreach (['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'] as $h): ?>
                        <option value="<?php echo $h; ?>" <?php echo $jadwal['hari'] === $h ? 'selected' : ''; ?>><?php echo $h; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label form-label-custom">Jam Mulai</label>
                <input type="time" name="jam_mulai" class="form-control form-control-custom" required value="<?php echo htmlspecialchars(substr($jadwal['jam_mulai'],0,5)); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label form-label-custom">Jam Selesai</label>
                <input type="time" name="jam_selesai" class="form-control form-control-custom" required value="<?php echo htmlspecialchars(substr($jadwal['jam_selesai'],0,5)); ?>">
            </div>
        </div>
        <div class="d-flex gap-3 mt-4">
            <button type="submit" class="btn btn-gold"><i class="fa-solid fa-floppy-disk me-1"></i> Simpan Perubahan</button>
            <a href="index.php" class="btn btn-outline-custom">Batal</a>
        </div>
    </form>
</div>

<script>
function syncMapel(mapelId) {
    if (mapelId) {
        const s = document.getElementById('mapel_select');
        document.getElementById('nama_mapel').value = s.options[s.selectedIndex].getAttribute('data-nama');
    }
}
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
