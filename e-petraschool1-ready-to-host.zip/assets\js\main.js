// c:\Users\SD Kristen Petra 1\Sistem SD Kristen Petra 1\assets\js\main.js

document.addEventListener('DOMContentLoaded', () => {
    // ─────────────────────────────────────────────
    // 1. Theme Init
    //    Default = light content + dark sidebar (no class)
    //    'dark-theme' class = full dark mode
    // ─────────────────────────────────────────────
    // Always force light theme
    document.body.classList.remove('dark-theme');
    document.body.classList.remove('light-theme');
    localStorage.removeItem('petra_theme');

    // ─────────────────────────────────────────────
    // 2. Mobile Sidebar Toggle
    // ─────────────────────────────────────────────
    const mobileToggle = document.getElementById('mobile-sidebar-toggle');
    const sidebar      = document.querySelector('.sidebar-container');
    const overlay      = document.getElementById('sidebar-overlay');

    function openMobileSidebar() {
        sidebar  && sidebar.classList.add('show-mobile');
        overlay  && overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeMobileSidebar() {
        sidebar  && sidebar.classList.remove('show-mobile');
        overlay  && overlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    // Expose globally (for inline onclick on overlay)
    window.closeMobileSidebar = closeMobileSidebar;

    if (mobileToggle && sidebar) {
        mobileToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            sidebar.classList.contains('show-mobile') ? closeMobileSidebar() : openMobileSidebar();
        });
    }

    // Close sidebar on nav-link click (mobile)
    document.querySelectorAll('.nav-link-custom').forEach(link => {
        link.addEventListener('click', () => {
            if (window.innerWidth < 768) closeMobileSidebar();
        });
    });

    // ─────────────────────────────────────────────
    // 3. Auto-calculate Nilai Akhir & Predikat
    // ─────────────────────────────────────────────
    const tugasInput   = document.getElementById('nilai_tugas');
    const utsInput     = document.getElementById('nilai_uts');
    const uasInput     = document.getElementById('nilai_uas');
    const akhirInput   = document.getElementById('nilai_akhir');
    const predikatInput = document.getElementById('predikat');

    function calculateFinalGrade() {
        if (tugasInput && utsInput && uasInput && akhirInput) {
            const tugas = parseFloat(tugasInput.value) || 0;
            const uts   = parseFloat(utsInput.value)   || 0;
            const uas   = parseFloat(uasInput.value)   || 0;
            const finalGrade = (tugas * 0.3) + (uts * 0.3) + (uas * 0.4);
            akhirInput.value = finalGrade.toFixed(2);
            if (predikatInput) {
                let predikat = 'E';
                if (finalGrade >= 86)      predikat = 'A';
                else if (finalGrade >= 75) predikat = 'B';
                else if (finalGrade >= 60) predikat = 'C';
                else if (finalGrade >= 45) predikat = 'D';
                predikatInput.value = predikat;
            }
        }
    }

    if (tugasInput && utsInput && uasInput) {
        tugasInput.addEventListener('input', calculateFinalGrade);
        utsInput.addEventListener('input', calculateFinalGrade);
        uasInput.addEventListener('input', calculateFinalGrade);
    }

    // ─────────────────────────────────────────────
    // 4. GLOBAL FIX: Teleport semua Bootstrap modal ke <body>
    //    Mencegah modal terblokir oleh CSS stacking context
    //    dari animasi .animated-view (transform/animation pada ancestor)
    // ─────────────────────────────────────────────
    document.querySelectorAll('.modal').forEach(function (modal) {
        if (modal.parentElement !== document.body) {
            document.body.appendChild(modal);
        }
    });

    // Hapus class .animated-view setelah animasi selesai
    // agar transform CSS tidak terus membuat stacking context
    const animEl = document.querySelector('.animated-view');
    if (animEl) {
        const removeAnim = () => animEl.classList.remove('animated-view');
        animEl.addEventListener('animationend', removeAnim, { once: true });
        // Fallback jika animasi tidak terpicu (mis: prefers-reduced-motion)
        setTimeout(removeAnim, 700);
    }
});

/* ─── Theme Toggle ─── */
function toggleTheme() {
    // Stubbed: Always light theme
}

function _updateThemeIcon() {
    // Stubbed: Always light theme
}

/* ─── Confirm Delete (SweetAlert2) ─── */
function confirmDelete(deleteUrl, message = 'Apakah Anda yakin ingin menghapus data ini?') {
    Swal.fire({
        title: 'Konfirmasi Hapus',
        text: message,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#EF4444',
        cancelButtonColor: '#94A3B8',
        confirmButtonText: 'Ya, Hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) window.location.href = deleteUrl;
    });
}

/* ─── Print Functions ─── */
function printStudentCard() {
    document.body.classList.add('print-mode-card');
    window.print();
    setTimeout(() => document.body.classList.remove('print-mode-card'), 1000);
}

function printBarcodeLabel() {
    document.body.classList.add('print-mode-barcode');
    window.print();
    setTimeout(() => document.body.classList.remove('print-mode-barcode'), 1000);
}
