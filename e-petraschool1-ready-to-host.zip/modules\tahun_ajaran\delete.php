<?php
// c:\xampp\htdocs\e-petraschool1\modules\tahun_ajaran\delete.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';
require_role(['Super Admin', 'Admin']);

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    try {
        // Fetch info for audit log
        $stmt = $pdo->prepare("SELECT tahun_ajaran FROM tahun_ajaran WHERE id = ?");
        $stmt->execute([$id]);
        $yr = $stmt->fetch();

        if ($yr) {
            // Delete year
            $delete_stmt = $pdo->prepare("DELETE FROM tahun_ajaran WHERE id = ?");
            $delete_stmt->execute([$id]);
            
            write_audit_log("Menghapus tahun ajaran: " . $yr['tahun_ajaran'] . ".");
        }
    } catch (Exception $e) {
        error_log("Failed to delete tahun ajaran: " . $e->getMessage());
    }
}

header("Location: index.php");
exit;
?>
