<?php
// c:\xampp\htdocs\e-petraschool1\modules\inventaris\qrcode.php

$page_title = 'QR Code Inventaris';
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_inventaris_access();

// AJAX Endpoint for fetching asset details by Code
if (isset($_GET['ajax_action']) && $_GET['ajax_action'] === 'get_asset') {
    header('Content-Type: application/json');
    $code = trim($_GET['code'] ?? '');
    
    if (empty($code)) {
        echo json_encode(['success' => false, 'message' => 'Kode barang kosong.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT i.*, k.nama_kategori, r.nama_ruangan 
            FROM inventaris i 
            JOIN kategori_barang k ON i.kategori_id = k.id 
            LEFT JOIN ruangan r ON i.ruangan_id = r.id 
            WHERE i.kode_barang = ? AND i.status_aktif = 'Aktif' 
            LIMIT 1
        ");
        $stmt->execute([$code]);
        $asset = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($asset) {
            // Get recent history
            $hist_stmt = $pdo->prepare("SELECT * FROM histori_inventaris WHERE inventaris_id = ? ORDER BY tanggal DESC LIMIT 3");
            $hist_stmt->execute([$asset['id']]);
            $history = $hist_stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode([
                'success' => true,
                'data' => $asset,
                'history' => $history
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Aset tidak ditemukan.']);
        }
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
    exit;
}

// Fetch all active assets for printing
try {
    $assets = $pdo->query("
        SELECT i.*, k.nama_kategori, r.nama_ruangan 
        FROM inventaris i 
        JOIN kategori_barang k ON i.kategori_id = k.id 
        LEFT JOIN ruangan r ON i.ruangan_id = r.id 
        WHERE i.status_aktif = 'Aktif' 
        ORDER BY i.kode_barang ASC
    ")->fetchAll();
} catch (Exception $e) {
    $assets = [];
}
?>

<div class="glass-card mb-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h5 class="text-gold fw-bold mb-1"><i class="fa-solid fa-qrcode me-2"></i> QR Code Manajemen</h5>
            <p class="text-secondary small mb-0">Cetak label QR Code secara massal atau pindai/pencarian cepat data barang.</p>
        </div>
        <div class="nav nav-tabs border-0 gap-2" id="qrTabs" role="tablist">
            <button class="btn btn-outline-custom text-gold active" id="print-tab" data-bs-toggle="tab" data-bs-target="#print-pane" type="button" role="tab" aria-controls="print-pane" aria-selected="true">
                <i class="fa-solid fa-print me-1"></i> Cetak QR Massal
            </button>
            <button class="btn btn-outline-custom text-gold" id="scan-tab" data-bs-toggle="tab" data-bs-target="#scan-pane" type="button" role="tab" aria-controls="scan-pane" aria-selected="false">
                <i class="fa-solid fa-expand me-1"></i> Pindai / Scan QR
            </button>
        </div>
    </div>

    <div class="tab-content" id="qrTabsContent">
        <!-- TAB 1: CETAK MASSAL -->
        <div class="tab-pane fade show active" id="print-pane" role="tabpanel" aria-labelledby="print-tab">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="check-all-assets">
                    <label class="form-check-label text-secondary small" for="check-all-assets">Pilih Semua</label>
                </div>
                <button type="button" id="btn-print-selected" class="btn btn-gold btn-sm"><i class="fa-solid fa-print me-1"></i> Cetak Label Terpilih</button>
            </div>

            <div class="row g-3">
                <?php if (count($assets) > 0): ?>
                    <?php foreach ($assets as $ast): ?>
                        <div class="col-12 col-md-6 col-lg-4">
                            <div class="p-3 rounded border border-secondary border-opacity-25 d-flex gap-3 align-items-center" style="background-color: rgba(255,255,255,0.02);">
                                <div class="form-check mb-0">
                                    <input class="form-check-input asset-checkbox" type="checkbox" value="<?php echo $ast['id']; ?>">
                                </div>
                                <div class="bg-white p-1 rounded" style="width: 70px; height: 70px; display: flex; align-items: center; justify-content: center;">
                                    <canvas class="qr-preview-canvas" data-code="<?php echo htmlspecialchars($ast['kode_barang']); ?>" style="width: 60px; height: 60px;"></canvas>
                                </div>
                                <div class="flex-grow-1" style="min-width: 0;">
                                    <h6 class="text-white fw-bold text-truncate mb-0" style="font-size: 14px;"><?php echo htmlspecialchars($ast['nama_barang']); ?></h6>
                                    <span class="font-monospace text-gold small d-block"><?php echo htmlspecialchars($ast['kode_barang']); ?></span>
                                    <span class="text-secondary small d-block text-truncate"><i class="fa-solid fa-location-dot me-1"></i> <?php echo htmlspecialchars($ast['nama_ruangan'] ?: 'Belum Alokasi'); ?></span>
                                </div>
                                <div>
                                    <a href="print_qr.php?id=<?php echo $ast['id']; ?>&preview=1" class="btn btn-xs btn-outline-custom text-gold" target="_blank" title="Cetak Satuan"><i class="fa-solid fa-print"></i></a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-12 text-center text-secondary py-5">
                        Belum ada data barang aktif.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- TAB 2: SCAN / CARI -->
        <div class="tab-pane fade" id="scan-pane" role="tabpanel" aria-labelledby="scan-tab">
            <div class="row justify-content-center">
                <div class="col-12 col-md-6 text-center">
                    <h6 class="text-white fw-bold mb-3">Pindai Menggunakan Kamera / Input Manual</h6>
                    
                    <!-- HTML5 QR Scanner Container -->
                    <div id="qr-reader" class="mx-auto rounded overflow-hidden border border-secondary mb-3" style="width: 100%; max-width: 380px; background: #000; min-height: 250px;"></div>
                    
                    <div class="mb-3">
                        <label for="manual-scan-input" class="form-label form-label-custom">Input Kode Barang Manual / Scan Gun</label>
                        <div class="input-group" style="max-width: 380px; margin: 0 auto;">
                            <input type="text" id="manual-scan-input" class="form-control form-control-custom text-center font-monospace" placeholder="Pencarian Cepat Kode Aset">
                            <button class="btn btn-gold" id="btn-manual-search" type="button"><i class="fa-solid fa-magnifying-glass"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Detail Aset Terpindai -->
<div class="modal fade" id="modalAssetScanned" tabindex="-1" aria-labelledby="modalAssetScannedLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content modal-content-custom">
            <div class="modal-header">
                <h5 class="modal-title text-gold fw-bold" id="modalAssetScannedLabel"><i class="fa-solid fa-clipboard-check me-2"></i> Detail Aset Terpindai</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-white">
                <div class="row g-3">
                    <div class="col-12 col-md-4 text-center">
                        <img id="scanned_foto" src="" alt="Foto Aset" class="img-fluid rounded border border-secondary mb-2 bg-dark" style="max-height: 200px; width: 100%; object-fit: cover;">
                        <canvas id="scanned_qr" class="bg-white p-1 rounded mb-2" style="width: 120px; height: 120px; margin: 0 auto; display: block;"></canvas>
                        <h6 id="scanned_kode" class="font-monospace text-gold fw-bold mb-0"></h6>
                    </div>
                    <div class="col-12 col-md-8">
                        <h4 id="scanned_nama" class="text-white fw-bold mb-2"></h4>
                        <div class="row g-2 text-secondary small">
                            <div class="col-6"><strong>Kategori:</strong> <span id="scanned_kategori" class="text-white"></span></div>
                            <div class="col-6"><strong>Lokasi:</strong> <span id="scanned_lokasi" class="text-white"></span></div>
                            <div class="col-6"><strong>Merk:</strong> <span id="scanned_merk" class="text-white"></span></div>
                            <div class="col-6"><strong>Model:</strong> <span id="scanned_model" class="text-white"></span></div>
                            <div class="col-6"><strong>Kondisi:</strong> <span id="scanned_kondisi" class="badge"></span></div>
                            <div class="col-6"><strong>Tahun:</strong> <span id="scanned_tahun" class="text-white"></span></div>
                            <div class="col-6"><strong>Harga:</strong> <span id="scanned_harga" class="text-white"></span></div>
                            <div class="col-6"><strong>Sumber:</strong> <span id="scanned_sumber" class="text-white"></span></div>
                        </div>
                        
                        <div class="mt-4">
                            <h6 class="text-gold fw-bold border-bottom border-secondary pb-1"><i class="fa-solid fa-clock-rotate-left me-1"></i> Log Histori Terakhir</h6>
                            <ul class="list-group list-group-flush small" id="scanned_history_list" style="max-height: 120px; overflow-y: auto;">
                                <!-- History logs loaded here -->
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer border-secondary">
                <?php if (has_role(['Super Admin', 'Admin'])): ?>
                <a id="scanned_btn_edit" href="" class="btn btn-sm btn-outline-warning"><i class="fa-solid fa-pen me-1"></i> Edit Aset</a>
                <?php endif; ?>
                <button type="button" class="btn btn-sm btn-outline-custom text-gold" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

<!-- QRious library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js"></script>
<!-- HTML5 QR Code Scanner Library -->
<script src="https://unpkg.com/html5-qrcode"></script>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Render preview QR Codes on load
    const canvases = document.querySelectorAll('.qr-preview-canvas');
    canvases.forEach(canvas => {
        const code = canvas.getAttribute('data-code');
        new QRious({
            element: canvas,
            value: code,
            size: 60,
            background: '#ffffff',
            foreground: '#000000',
            level: 'M'
        });
    });

    // Checkbox All Selector
    const checkAll = document.getElementById('check-all-assets');
    const checkboxes = document.querySelectorAll('.asset-checkbox');
    
    checkAll.addEventListener('change', function() {
        checkboxes.forEach(cb => {
            cb.checked = this.checked;
        });
    });

    // Print Selected Handler
    const btnPrintSelected = document.getElementById('btn-print-selected');
    btnPrintSelected.addEventListener('click', () => {
        const selectedIds = [];
        checkboxes.forEach(cb => {
            if (cb.checked) {
                selectedIds.push(cb.value);
            }
        });

        if (selectedIds.length === 0) {
            Swal.fire('Peringatan', 'Silakan pilih minimal satu barang untuk dicetak!', 'warning');
            return;
        }

        const url = `print_qr_massal.php?ids=${selectedIds.join(',')}`;
        window.open(url, '_blank');
    });

    // Scanned QR representation
    let scannedQrObj = null;

    // Load Scan Info function
    function lookupAsset(code) {
        if (!code) return;
        
        fetch(`qrcode.php?ajax_action=get_asset&code=${encodeURIComponent(code)}`)
            .then(res => res.json())
            .then(res => {
                if (res.success) {
                    const asset = res.data;
                    const hist = res.history;
                    
                    document.getElementById('scanned_kode').textContent = asset.kode_barang;
                    document.getElementById('scanned_nama').textContent = asset.nama_barang;
                    document.getElementById('scanned_kategori').textContent = asset.nama_kategori;
                    document.getElementById('scanned_lokasi').textContent = asset.nama_ruangan || 'Belum Dialokasikan';
                    document.getElementById('scanned_merk').textContent = asset.merk || '-';
                    document.getElementById('scanned_model').textContent = asset.tipe_model || '-';
                    document.getElementById('scanned_tahun').textContent = asset.tahun_perolehan || '-';
                    document.getElementById('scanned_sumber').textContent = asset.sumber_dana;
                    
                    // Price format
                    const priceFormatted = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(asset.harga);
                    document.getElementById('scanned_harga').textContent = priceFormatted;

                    // Condition Badge colors
                    const condBadge = document.getElementById('scanned_kondisi');
                    condBadge.textContent = asset.kondisi;
                    condBadge.className = 'badge';
                    if (asset.kondisi === 'Baik') {
                        condBadge.classList.add('bg-success');
                    } else if (asset.kondisi === 'Cukup') {
                        condBadge.classList.add('bg-info');
                    } else if (asset.kondisi === 'Rusak Ringan') {
                        condBadge.classList.add('bg-warning', 'text-dark');
                    } else {
                        condBadge.classList.add('bg-danger');
                    }

                    // Foto Asset
                    const img = document.getElementById('scanned_foto');
                    if (asset.foto_barang) {
                        img.src = `<?php echo $base_url; ?>assets/uploads/inventaris/${asset.foto_barang}`;
                        img.style.display = 'block';
                    } else {
                        img.src = '';
                        img.style.display = 'none';
                    }

                    // QR Modal canvas
                    if (!scannedQrObj) {
                        scannedQrObj = new QRious({
                            element: document.getElementById('scanned_qr'),
                            size: 120,
                            level: 'H'
                        });
                    }
                    scannedQrObj.value = asset.kode_barang;

                    // Edit button link
                    document.getElementById('scanned_btn_edit').href = `edit.php?id=${asset.id}`;

                    // Populate history logs
                    const histList = document.getElementById('scanned_history_list');
                    histList.innerHTML = '';
                    if (hist.length > 0) {
                        hist.forEach(h => {
                            const dateStr = new Date(h.tanggal).toLocaleDateString('id-ID', {day: 'numeric', month: 'short', year: 'numeric'});
                            const li = document.createElement('li');
                            li.className = 'list-group-item bg-transparent text-secondary border-secondary border-opacity-25 px-0 py-1';
                            li.innerHTML = `<span class="text-gold fw-bold">${dateStr}</span> - [${h.aktivitas}] ${h.keterangan}`;
                            histList.appendChild(li);
                        });
                    } else {
                        histList.innerHTML = '<li class="list-group-item bg-transparent text-secondary px-0 text-center">Belum ada histori aktivitas.</li>';
                    }

                    // Show Modal
                    const modal = new bootstrap.Modal(document.getElementById('modalAssetScanned'));
                    modal.show();
                    
                    // Stop camera scan temporarily
                    stopScanner();
                } else {
                    Swal.fire('Error', res.message, 'error');
                }
            })
            .catch(err => {
                Swal.fire('Error', 'Terjadi kesalahan sistem.', 'error');
            });
    }

    // Manual Search triggers lookup
    const btnSearch = document.getElementById('btn-manual-search');
    const inputSearch = document.getElementById('manual-scan-input');
    
    btnSearch.addEventListener('click', () => {
        lookupAsset(inputSearch.value.trim());
    });
    
    inputSearch.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            lookupAsset(inputSearch.value.trim());
        }
    });

    // HTML5 Camera QR Scanner
    let html5QrcodeScanner = null;
    
    const scanTab = document.getElementById('scan-tab');
    scanTab.addEventListener('click', () => {
        startScanner();
    });

    const printTab = document.getElementById('print-tab');
    printTab.addEventListener('click', () => {
        stopScanner();
    });

    function startScanner() {
        if (html5QrcodeScanner === null) {
            html5QrcodeScanner = new Html5Qrcode("qr-reader");
        }
        
        const config = { fps: 10, qrbox: { width: 250, height: 250 } };
        
        html5QrcodeScanner.start(
            { facingMode: "environment" }, 
            config, 
            (decodedText) => {
                // Success Scan callback
                lookupAsset(decodedText);
            },
            (errorMessage) => {
                // Scan failure error, just ignore for normal scanning noise
            }
        ).catch(err => {
            // failed to start, camera permission issues, etc.
            console.log('Scanner start error:', err);
        });
    }

    function stopScanner() {
        if (html5QrcodeScanner && html5QrcodeScanner.isScanning) {
            html5QrcodeScanner.stop().then(() => {
                console.log("Scanner stopped.");
            }).catch(err => {
                console.log("Scanner stop error:", err);
            });
        }
    }

    // Resume scanning on modal close
    const modalEl = document.getElementById('modalAssetScanned');
    modalEl.addEventListener('hidden.bs.modal', function () {
        if (document.getElementById('scan-pane').classList.contains('active')) {
            startScanner();
        }
    });
});
</script>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
