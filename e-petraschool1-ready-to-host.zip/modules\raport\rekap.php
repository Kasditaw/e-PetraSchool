<?php
// c:\xampp\htdocs\e-petraschool1\modules\raport\rekap.php

require_once dirname(dirname(__DIR__)) . '/config/auth.php';

// Dapatkan semester dan tahun ajaran aktif dari sistem
try {
    $active_sem_stmt = $pdo->query("SELECT semester FROM semester WHERE status = 'Aktif' LIMIT 1");
    $active_sem_db = $active_sem_stmt->fetchColumn();
    $active_sem = ($active_sem_db === 'Ganjil' || $active_sem_db === '1') ? '1' : '2';

    $active_ta_stmt = $pdo->query("SELECT tahun_ajaran FROM tahun_ajaran WHERE status = 'Aktif' LIMIT 1");
    $active_ta = $active_ta_stmt->fetchColumn() ?: '2025/2026';
} catch (Exception $e) {
    $active_sem = '1';
    $active_ta = '2025/2026';
}

$selected_sem = isset($_GET['semester']) ? $_GET['semester'] : $active_sem;
$selected_ta = $active_ta;
$kelas_id = isset($_GET['kelas_id']) ? intval($_GET['kelas_id']) : 0;

if ($kelas_id <= 0) {
    header("Location: index.php");
    exit;
}

try {
    // Ambil nama kelas dan tingkat
    $class_stmt = $pdo->prepare("SELECT nama_kelas, tingkat FROM kelas WHERE id = ? LIMIT 1");
    $class_stmt->execute([$kelas_id]);
    $class_row = $class_stmt->fetch(PDO::FETCH_ASSOC);
    $nama_kelas = $class_row['nama_kelas'] ?? 'Kelas';
    $tingkat = $class_row['tingkat'] ?? '';

    // Ambil daftar siswa beserta nilai rapor
    $students_stmt = $pdo->prepare("
        SELECT s.id, s.nis, s.nisn, s.nama_lengkap, 
               r.academic_grades, r.sakit, r.izin, r.alpa
        FROM siswa s
        LEFT JOIN raport_siswa r ON s.id = r.siswa_id AND r.semester = ? AND r.tahun_ajaran = ?
        WHERE s.kelas_id = ? AND s.status_siswa = 'Aktif'
        ORDER BY s.nama_lengkap ASC
    ");
    $students_stmt->execute([$selected_sem, $selected_ta, $kelas_id]);
    $students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage());
}

$subjects_list = [
    'Agama' => 'Pendidikan Agama',
    'Pancasila' => 'Pancasila',
    'Bahasa Indonesia' => 'Bahasa Indonesia',
    'Matematika' => 'Matematika',
    'IPAS' => 'IPAS',
    'PJOK' => 'PJOK',
    'Seni Budaya' => 'Seni Budaya',
    'Bhs. Inggris' => 'Bhs. Inggris',
    'Bhs. Jawa' => 'Bhs. Jawa',
    'Bhs. Mandarin' => 'Bhs. Mandarin'
];

if ($tingkat === '1' || $tingkat === '2') {
    unset($subjects_list['IPAS']);
}

$export = isset($_GET['export']) ? $_GET['export'] : '';

if ($export === 'excel') {
    // Log audit log
    write_audit_log("Melakukan ekspor rekap nilai rapor kelas $nama_kelas semester $selected_sem ke Excel.");

    // Headers untuk download Excel
    header("Content-Type: application/vnd.ms-excel; charset=utf-8");
    header("Content-Disposition: attachment; filename=Rekap_Nilai_Rapor_" . str_replace(' ', '_', $nama_kelas) . "_Sem" . $selected_sem . "_" . date('Ymd_His') . ".xls");
    header("Pragma: no-cache");
    header("Expires: 0");

    echo "<table border='1'>
        <tr>
            <th colspan='" . (7 + count($subjects_list)) . "' style='font-size:16px; font-weight:bold; text-align:center; height:40px; background-color:#D4AF37; color:#000;'>
                REKAP NILAI RAPOR KURIKULUM MERDEKA - " . strtoupper($nama_kelas) . "
            </th>
        </tr>
        <tr>
            <th colspan='" . (7 + count($subjects_list)) . "' style='font-size:12px; text-align:center; height:25px; background-color:#F4F4F5; color:#000;'>
                Semester: " . htmlspecialchars($selected_sem) . " | Tahun Ajaran: " . htmlspecialchars($selected_ta) . "
            </th>
        </tr>
        <tr>
            <th rowspan='2' style='background-color:#0B132B; color:#ffffff; text-align:center; vertical-align:middle;'>No</th>
            <th rowspan='2' style='background-color:#0B132B; color:#ffffff; text-align:center; vertical-align:middle;'>NIS</th>
            <th rowspan='2' style='background-color:#0B132B; color:#ffffff; text-align:center; vertical-align:middle;'>NISN</th>
            <th rowspan='2' style='background-color:#0B132B; color:#ffffff; text-align:left; vertical-align:middle;'>Nama Lengkap</th>
            <th colspan='" . count($subjects_list) . "' style='background-color:#0B132B; color:#ffffff; text-align:center;'>Mata Pelajaran</th>
            <th colspan='3' style='background-color:#0B132B; color:#ffffff; text-align:center;'>Absensi (Hari)</th>
        </tr>
        <tr>";
        foreach ($subjects_list as $key => $name) {
            echo "<th style='background-color:#1C2541; color:#ffffff; text-align:center;'>$key</th>";
        }
        echo "<th style='background-color:#1C2541; color:#ffffff; text-align:center;'>Sakit</th>
            <th style='background-color:#1C2541; color:#ffffff; text-align:center;'>Izin</th>
            <th style='background-color:#1C2541; color:#ffffff; text-align:center;'>Alpa</th>
        </tr>";

        $no = 1;
        foreach ($students as $s) {
            $saved_grades = json_decode($s['academic_grades'] ?? '', true) ?: [];
            $sakit = trim($s['sakit'] ?? '0');
            $izin = trim($s['izin'] ?? '0');
            $alpa = trim($s['alpa'] ?? '0');
            if ($sakit === '-') $sakit = '0';
            if ($izin === '-') $izin = '0';
            if ($alpa === '-') $alpa = '0';

            echo "<tr>
                <td style='text-align:center;'>" . $no++ . "</td>
                <td style='font-family:monospace; text-align:left;'>" . htmlspecialchars($s['nis']) . "</td>
                <td style='font-family:monospace; text-align:left;'>" . htmlspecialchars($s['nisn']) . "</td>
                <td style='font-weight:bold;'>" . htmlspecialchars($s['nama_lengkap']) . "</td>";

            foreach ($subjects_list as $key => $name) {
                $score = $saved_grades[$key]['score'] ?? '';
                if ($score !== '' && $score !== null) {
                    echo "<td style='text-align:right; font-weight:bold;'>" . number_format($score, 0) . "</td>";
                } else {
                    echo "<td style='text-align:center; color:#999;'>-</td>";
                }
            }

            echo "<td style='text-align:center;'>$sakit</td>
                <td style='text-align:center;'>$izin</td>
                <td style='text-align:center;'>$alpa</td>
            </tr>";
        }
    echo "</table>";
    exit;
}

// Render visual view page
$page_title = 'Rekap Nilai Rapor - ' . $nama_kelas;
require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin', 'Kepala Sekolah', 'Guru']);
?>

<style>
    .rekap-card {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 1rem;
        padding: 1.5rem;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.02);
    }
    .table-rekap thead th {
        background-color: #f8fafc;
        color: #475569;
        font-weight: 700;
        text-transform: uppercase;
        font-size: 10px;
        letter-spacing: 0.05em;
        padding: 12px 8px;
        border-bottom: 2px solid #e2e8f0;
        text-align: center;
    }
    .table-rekap tbody td {
        padding: 10px 8px;
        border-bottom: 1px solid #f1f5f9;
        vertical-align: middle;
        color: #334155;
        font-size: 12px;
    }
    .table-rekap tbody tr:hover td {
        background-color: #f8fafc;
    }
</style>

<div class="container-fluid px-4 py-2">
    
    <!-- Navigation back & actions -->
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <a href="index.php?kelas_id=<?php echo $kelas_id; ?>&semester=<?php echo $selected_sem; ?>" class="btn btn-outline-secondary d-inline-flex align-items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg">
            <i class="fa-solid fa-chevron-left"></i> Kembali ke Daftar
        </a>
        
        <a href="rekap.php?kelas_id=<?php echo $kelas_id; ?>&semester=<?php echo $selected_sem; ?>&export=excel" class="btn btn-success d-inline-flex align-items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-lg shadow-sm">
            <i class="fa-solid fa-file-excel"></i> Ekspor ke Excel
        </a>
    </div>

    <!-- Redesigned Header Info -->
    <div class="d-flex align-items-center gap-3 mb-4">
        <div class="w-10 h-10 bg-indigo-600 rounded-lg d-flex align-items-center justify-center shadow-md shadow-indigo-600/20" style="width: 40px; height: 40px;">
            <i class="fa-solid fa-table-list text-white text-xl"></i>
        </div>
        <div>
            <h5 class="text-slate-800 font-bold text-lg mb-0 font-sans tracking-wide">Rekapitulasi Capaian Nilai Rapor</h5>
            <p class="text-slate-500 text-xs mb-0">Kelas: <strong class="text-indigo-600"><?php echo htmlspecialchars($nama_kelas); ?></strong> | Semester: <strong><?php echo $selected_sem; ?></strong> | Tahun Ajaran: <strong><?php echo htmlspecialchars($selected_ta); ?></strong></p>
        </div>
    </div>

    <!-- Rekap Grid Card -->
    <div class="rekap-card">
        <div class="table-responsive">
            <table class="table table-rekap table-bordered w-full" id="table-rekap-nilai">
                <thead>
                    <tr>
                        <th rowspan="2" style="width: 3%; vertical-align: middle;">No</th>
                        <th rowspan="2" style="width: 10%; vertical-align: middle;">NIS / NISN</th>
                        <th rowspan="2" style="width: 20%; text-align: left; vertical-align: middle;">Nama Lengkap</th>
                        <th colspan="<?php echo count($subjects_list); ?>">Mata Pelajaran</th>
                        <th colspan="3">Absensi</th>
                    </tr>
                    <tr>
                        <?php foreach ($subjects_list as $key => $name): ?>
                            <th title="<?php echo htmlspecialchars($name); ?>"><?php echo htmlspecialchars($key); ?></th>
                        <?php endforeach; ?>
                        <th>S</th>
                        <th>I</th>
                        <th>A</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($students) > 0): ?>
                        <?php foreach ($students as $index => $s): 
                            $saved_grades = json_decode($s['academic_grades'] ?? '', true) ?: [];
                            $sakit = trim($s['sakit'] ?? '0');
                            $izin = trim($s['izin'] ?? '0');
                            $alpa = trim($s['alpa'] ?? '0');
                            if ($sakit === '-') $sakit = '0';
                            if ($izin === '-') $izin = '0';
                            if ($alpa === '-') $alpa = '0';
                        ?>
                            <tr>
                                <td class="text-center font-mono text-slate-400 text-xs"><?php echo $index + 1; ?></td>
                                <td class="text-center font-mono text-xs text-slate-500">
                                    <?php echo htmlspecialchars($s['nis']); ?><br>
                                    <?php echo htmlspecialchars($s['nisn']); ?>
                                </td>
                                <td>
                                    <strong class="text-slate-800"><?php echo htmlspecialchars($s['nama_lengkap']); ?></strong>
                                </td>
                                
                                <?php foreach ($subjects_list as $key => $name): ?>
                                    <?php 
                                    $score = $saved_grades[$key]['score'] ?? ''; 
                                    ?>
                                    <td class="text-center">
                                        <?php if ($score !== '' && $score !== null): ?>
                                            <strong class="text-indigo-600 font-sans"><?php echo htmlspecialchars($score); ?></strong>
                                        <?php else: ?>
                                            <span class="text-slate-300">—</span>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>

                                <td class="text-center font-semibold text-slate-600"><?php echo $sakit; ?></td>
                                <td class="text-center font-semibold text-slate-600"><?php echo $izin; ?></td>
                                <td class="text-center font-semibold text-slate-600"><?php echo $alpa; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="<?php echo (7 + count($subjects_list)); ?>" class="text-center text-slate-400 py-8">
                                <i class="fa-solid fa-folder-open d-block text-lg mb-2 text-indigo-500 opacity-60"></i>
                                Tidak ada siswa aktif ditemukan di kelas ini.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once dirname(dirname(__DIR__)) . '/includes/footer.php'; ?>
