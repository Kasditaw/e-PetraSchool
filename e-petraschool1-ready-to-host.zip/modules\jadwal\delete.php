<?php
// c:\xampp\htdocs\e-petraschool1\modules\jadwal\delete.php

require_once dirname(dirname(__DIR__)) . '/includes/header.php';
require_role(['Super Admin', 'Admin']);

$id = intval($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }

try {
    $stmt = $pdo->prepare("SELECT nama_mapel, hari FROM jadwal_pelajaran WHERE id = ?");
    $stmt->execute([$id]);
    $jadwal = $stmt->fetch();

    if ($jadwal) {
        $del = $pdo->prepare("DELETE FROM jadwal_pelajaran WHERE id = ?");
        $del->execute([$id]);
        write_audit_log("Menghapus jadwal pelajaran ID#$id: {$jadwal['nama_mapel']} ({$jadwal['hari']}).");
    }
} catch (Exception $e) {
    // silently fail
}

header('Location: index.php');
exit;
